library(dplyr)
library(tidyr)
library(stringr)
library(tibble)
library(jsonlite)
library(readr)
library(haven)
library(purrr)
library(readxl)
library(truncnorm)
library(sn)
library(broom)

issp_have_lmer    <- requireNamespace("lme4", quietly = TRUE) &&
                     requireNamespace("lmerTest", quietly = TRUE)
issp_have_emmeans <- requireNamespace("emmeans", quietly = TRUE)
issp_have_mumin   <- requireNamespace("MuMIn", quietly = TRUE)
issp_have_cluster <- requireNamespace("sandwich", quietly = TRUE) &&
                     requireNamespace("lmtest", quietly = TRUE)
issp_have_broom_mixed <- requireNamespace("broom.mixed", quietly = TRUE)

# Paths and settings
.analysis_script_dir <- local({
  script <- NULL
  for (frame in sys.frames()) {
    if (!is.null(frame$ofile)) script <- frame$ofile
  }
  if (is.null(script)) {
    arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
    if (length(arg)) script <- sub("^--file=", "", arg[1])
  }
  if (is.null(script)) getwd() else dirname(normalizePath(script, mustWork = FALSE))
})
issp_data_dir <- Sys.getenv("ISSP_BASE_DIR", unset = "")
if (!nzchar(issp_data_dir)) {
  candidates <- unique(c(
    file.path(.analysis_script_dir, "..", "data"),
    file.path(.analysis_script_dir, "data"),
    file.path(getwd(), "ISSP", "data"),
    file.path(getwd(), "data"),
    file.path(getwd(), "..", "data"),
    file.path(getwd(), "ISSP_data"),
    getwd()
  ))
  candidates <- candidates[file.exists(file.path(candidates, "ZA10000_v2-0-0.sav"))]
  if (!length(candidates)) {
    stop("Cannot locate ISSP/data. Set ISSP_BASE_DIR to the data folder.")
  }
  issp_data_dir <- candidates[1]
}
issp_data_dir <- normalizePath(issp_data_dir, mustWork = TRUE)
if (!file.exists(file.path(issp_data_dir, "ZA10000_v2-0-0.sav"))) {
  stop("Required input ZA10000_v2-0-0.sav is missing from ", issp_data_dir)
}
cat("ISSP data directory:", issp_data_dir, "\n")

# GPT distribution outputs
issp_base <- file.path(issp_data_dir, "results_by_country")

issp_global_base <- file.path(issp_data_dir, "results_global")

non_discrete_gpt_jsonl_path <- file.path(issp_data_dir, "output_non_discrete.jsonl")

# Human data, need to download from ISSP
issp_human_path <- file.path(issp_data_dir, "ZA10000_v2-0-0.sav")

# Mapping files
mapping_xlsx_path <- file.path(issp_data_dir, "ISSP Distributional Alignment Dataset.xlsx")

non_discrete_xlsx_path <- file.path(issp_data_dir, "ISSP Distributional Alignment Dataset Non-Discrete Scales.xlsx")

# Cleaned files with GPT + Llama rows
condition1_repeated_raw_path <- file.path(issp_data_dir, "condition1_repeated_raw.csv")

condition2_mean_confidence_path <- file.path(issp_data_dir, "condition2_mean_confidence_parsed.csv")

# Llama files
legacy_discrete_proportions_path <- file.path(issp_data_dir, "legacy_discrete_proportions_long.csv")

legacy_nondiscrete_proportions_path <- file.path(issp_data_dir, "legacy_nondiscrete_proportions_long.csv")

legacy_sd_alone_path <- file.path(issp_data_dir, "legacy_sd_alone.csv")

legacy_full_distribution_path <- file.path(issp_data_dir, "legacy_full_distribution.csv")

# Llama persona prompting file
demographic_llama_path <- file.path(issp_data_dir, "demographic_llama_clean.csv")

# Output folder
.default_output_root <- if (tolower(basename(issp_data_dir)) %in% c("data", "issp_data")) {
  dirname(issp_data_dir)
} else {
  issp_data_dir
}
out_dir <- Sys.getenv("ISSP_OUT_DIR", unset = file.path(.default_output_root, "results_output_issp"))
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

ISSP_ARRANGEMENT_ITEMS <- c("v28", "v29")
issp_dataset_type <- function(item) {
  ifelse(item %in% c("v19", "v26"), "non_discrete", "discrete")
}
issp_measurement_unit <- function(item) {
  ifelse(item == "v19", "children", ifelse(item == "v26", "months", "response-scale units"))
}
issp_arrangement_role <- function(item) {
  ifelse(item == "v28", "most desirable", ifelse(item == "v29", "least desirable", NA_character_))
}

# Audit log
.issp_audit_env <- new.env(parent = emptyenv())
.issp_audit_env$rows <- list()

issp_audit_record <- function(step, operation, rows_in = NA_integer_, rows_out = NA_integer_,
                              keys_in = NA_integer_, keys_out = NA_integer_,
                              unmatched_keys = NA_integer_, reason = NA_character_,
                              detail = NA_character_) {
  .issp_audit_env$rows[[length(.issp_audit_env$rows) + 1L]] <- tibble::tibble(
    script         = "ISSP.R",
    step           = as.character(step),
    operation      = as.character(operation),
    rows_in        = as.integer(rows_in),
    rows_out       = as.integer(rows_out),
    rows_delta     = as.integer(rows_out) - as.integer(rows_in),
    keys_in        = as.integer(keys_in),
    keys_out       = as.integer(keys_out),
    unmatched_keys = as.integer(unmatched_keys),
    reason         = as.character(reason),
    detail         = as.character(detail)
  )
  invisible(NULL)
}

write_issp_audit_table <- function(path = file.path(out_dir, "audit_filters_joins_exclusions_issp.csv")) {
  if (length(.issp_audit_env$rows) == 0) {
    cat("  ISSP audit log is empty; nothing written.\n")
    return(invisible(NULL))
  }
  tbl <- dplyr::bind_rows(.issp_audit_env$rows)
  readr::write_csv(tbl, path)
  cat("  ISSP audit table:", nrow(tbl), "steps ->", path, "\n")
  invisible(tbl)
}

n_sim_issp <- 1000
set.seed(42)

model_families_to_keep <- c("gpt", "llama")

focal_methods <- c(
  "repeated_sampling",
  "proportions",
  "distribution_mean_sd",
  "distribution_full",
  "hybrid_mean_sd",
  "demographic_distribution"
)

cat("\n", strrep("=", 80), "\n")
cat("ISSP DISTRIBUTIONAL ALIGNMENT — GPT + LLAMA COMBINED SCRIPT\n")
cat(strrep("=", 80), "\n\n")

required_paths <- c(
  issp_base = issp_base,
  issp_global_base = issp_global_base,
  non_discrete_gpt_jsonl_path = non_discrete_gpt_jsonl_path,
  issp_human_path = issp_human_path,
  mapping_xlsx_path = mapping_xlsx_path,
  non_discrete_xlsx_path = non_discrete_xlsx_path,
  condition1_repeated_raw_path = condition1_repeated_raw_path,
  condition2_mean_confidence_path = condition2_mean_confidence_path,
  legacy_discrete_proportions_path = legacy_discrete_proportions_path,
  legacy_nondiscrete_proportions_path = legacy_nondiscrete_proportions_path,
  legacy_sd_alone_path = legacy_sd_alone_path,
  legacy_full_distribution_path = legacy_full_distribution_path,
  demographic_llama_path = demographic_llama_path
)

file_check <- tibble(
  file_key = names(required_paths),
  path = unname(required_paths),
  exists = file.exists(required_paths)
)

cat("\nFile check:\n")
print(file_check, n = Inf, width = Inf)

missing_paths <- required_paths[!file.exists(required_paths)]
if (length(missing_paths) > 0) {
  cat("\nMissing required files/folders:\n")
  print(missing_paths)
  stop("Set the paths above before continuing.")
}


# Diagnostics accompany estimates; they never repair covariance or change a fit.
model_fit_diagnostics <- function(fit) {
  messages <- unlist(fit@optinfo$conv$lme4$messages, use.names = FALSE)
  code <- fit@optinfo$conv$opt
  if (is.null(code)) code <- 0L
  h <- fit@optinfo$derivs$Hessian
  eig <- if (!is.null(h) && all(is.finite(h)))
    min(eigen((h + t(h)) / 2, symmetric = TRUE, only.values = TRUE)$values) else NA_real_
  singular <- lme4::isSingular(fit)
  tibble(fit_singular = singular, optimizer_code = paste(code, collapse = ";"),
    convergence_messages = paste(messages, collapse = "; "),
    hessian_min_eigenvalue = eig,
    fit_diagnostic_status = if (any(code != 0) || length(messages)) "convergence_warning" else
      if (singular) "singular" else "no_reported_warning")
}

# Helpers

# Null-coalescing helper used when model-output JSON has inconsistent field names.
`%||%` <- function(x, y) {
  if (!is.null(x) && length(x) > 0 && !is.na(x[1])) x else y
}

# Parse one numeric value from a scalar, vector, or list field.
# Use this when one model-output field should produce one number.
num <- function(x) {
  if (is.null(x) || length(x) == 0) return(NA_real_)
  if (is.list(x)) x <- unlist(x, use.names = FALSE)
  if (length(x) == 0) return(NA_real_)
  suppressWarnings(as.numeric(as.character(x[1])))
}

# Parse a full numeric vector without collapsing to the first value.
num_vec <- function(x) {
  if (is.null(x) || length(x) == 0) return(numeric(0))
  if (is.list(x)) x <- unlist(x, use.names = FALSE)
  suppressWarnings(as.numeric(as.character(x)))
}

# Scalar coercion used inside row-wise simulations where tibble/list-columns
# can otherwise produce list-like values instead of plain numbers.
to_num1 <- function(x) {
  if (is.null(x) || length(x) == 0) return(NA_real_)
  if (is.list(x)) x <- unlist(x, use.names = FALSE)
  if (length(x) == 0) return(NA_real_)
  suppressWarnings(as.numeric(as.character(x[1])))
}

# Character analogue of to_num1 for row-wise metadata fields.
to_chr1 <- function(x) {
  if (is.null(x) || length(x) == 0) return(NA_character_)
  if (is.list(x)) x <- unlist(x, use.names = FALSE)
  if (length(x) == 0) return(NA_character_)
  as.character(x[1])
}

# Correlation wrapper that returns NA when vectors are
# mismatched, too short, contain missing values, or have zero variance.
safe_cor <- function(x, y) {
  x <- num_vec(x)
  y <- num_vec(y)

  if (length(x) != length(y)) return(NA_real_)

  keep <- complete.cases(x, y)
  if (sum(keep) < 3) return(NA_real_)

  x2 <- x[keep]
  y2 <- y[keep]

  if (sd(x2) == 0 || sd(y2) == 0) return(NA_real_)

  out <- tryCatch(cor(x2, y2), error = function(e) NA_real_)
  if (is.nan(out)) NA_real_ else out
}

# Correlation test wrapper
safe_cor_test <- function(x, y) {
  x <- num_vec(x)
  y <- num_vec(y)

  if (length(x) != length(y)) {
    return(tibble(r = NA_real_, p = NA_real_, n = NA_integer_))
  }

  keep <- complete.cases(x, y)
  n_keep <- sum(keep)

  if (n_keep < 3) {
    return(tibble(r = NA_real_, p = NA_real_, n = n_keep))
  }

  x2 <- x[keep]
  y2 <- y[keep]

  if (sd(x2) == 0 || sd(y2) == 0) {
    return(tibble(r = NA_real_, p = NA_real_, n = n_keep))
  }

  ct <- tryCatch(cor.test(x2, y2), error = function(e) NULL)

  if (is.null(ct)) {
    tibble(r = NA_real_, p = NA_real_, n = n_keep)
  } else {
    tibble(r = unname(ct$estimate), p = ct$p.value, n = n_keep)
  }
}

# Regression wrapper for grouped analyses
fit_lm_safe <- function(df, formula) {
  df <- df %>% drop_na()

  if (nrow(df) < 5) {
    return(tibble(
      term = NA_character_,
      estimate = NA_real_,
      std.error = NA_real_,
      statistic = NA_real_,
      p.value = NA_real_
    ))
  }

  fit <- tryCatch(lm(formula, data = df), error = function(e) NULL)

  if (is.null(fit)) {
    return(tibble(
      term = NA_character_,
      estimate = NA_real_,
      std.error = NA_real_,
      statistic = NA_real_,
      p.value = NA_real_
    ))
  }

  broom::tidy(fit)
}

# Simple bivariate regression summary 
fit_simple_lm_paper <- function(df, predictor, outcome) {
  d <- tibble(
    x = num_vec(df[[predictor]]),
    y = num_vec(df[[outcome]])
  ) %>%
    filter(complete.cases(x, y))

  n_keep <- nrow(d)

  if (n_keep < 3 || sd(d$x) == 0 || sd(d$y) == 0) {
    return(tibble(
      r = NA_real_, b = NA_real_, beta = NA_real_, se = NA_real_,
      t = NA_real_, df = NA_real_, p = NA_real_,
      ci_low = NA_real_, ci_high = NA_real_, n = n_keep
    ))
  }

  fit_raw <- lm(y ~ x, data = d)
  fit_std <- lm(scale(y) ~ scale(x), data = d)

  raw_coef <- summary(fit_raw)$coefficients
  raw_ci <- tryCatch(
    confint(fit_raw, "x"),
    error = function(e) matrix(c(NA_real_, NA_real_), nrow = 1)
  )

  tibble(
    r = cor(d$x, d$y),
    b = unname(coef(fit_raw)["x"]),
    beta = unname(coef(fit_std)[2]),
    se = unname(raw_coef["x", "Std. Error"]),
    t = unname(raw_coef["x", "t value"]),
    df = df.residual(fit_raw),
    p = unname(raw_coef["x", "Pr(>|t|)"]),
    ci_low = unname(raw_ci[1]),
    ci_high = unname(raw_ci[2]),
    n = n_keep
  )
}

# Total variation distance between two discrete distributions.
tvd_dist <- function(p, q) {
  p <- as.numeric(p)
  q <- as.numeric(q)
  if (length(p) != length(q)) return(NA_real_)
  if (anyNA(p) || anyNA(q)) return(NA_real_)
  if (sum(p) <= 0 || sum(q) <= 0) return(NA_real_)
  p <- p / sum(p)
  q <- q / sum(q)
  0.5 * sum(abs(p - q))
}

# One-dimensional Earth mover's distance
emd_1d <- function(p, q) {
  p <- as.numeric(p)
  q <- as.numeric(q)
  if (length(p) != length(q)) return(NA_real_)
  if (anyNA(p) || anyNA(q)) return(NA_real_)
  if (sum(p) <= 0 || sum(q) <= 0) return(NA_real_)
  p <- p / sum(p)
  q <- q / sum(q)
  sum(abs(cumsum(p) - cumsum(q)))
}

# Jensen-Shannon distance
jsd_fn <- function(p, q) {
  p <- as.numeric(p)
  q <- as.numeric(q)
  if (length(p) != length(q)) return(NA_real_)
  if (anyNA(p) || anyNA(q)) return(NA_real_)
  if (sum(p) <= 0 || sum(q) <= 0) return(NA_real_)

  eps <- 1e-10
  p <- p / sum(p)
  q <- q / sum(q)
  p[p == 0] <- eps
  q[q == 0] <- eps
  p <- p / sum(p)
  q <- q / sum(q)
  m <- 0.5 * (p + q)

  sqrt(0.5 * (sum(p * log(p / m)) + sum(q * log(q / m))))
}

# Standard p-value formatting
p_format <- function(p) {
  case_when(
    is.na(p) ~ NA_character_,
    p < .001 ~ "< .001",
    TRUE ~ paste0("= ", format(round(p, 3), nsmall = 3))
  )
}

# Normalize response labels before joining model-reported categories to the
# item-specific ISSP response scale.
normalize_label <- function(x) {
  x %>%
    str_replace_all("[\u2010-\u2015\u2212]", "-") %>%
    str_replace_all("[\r\n]+", " ") %>%
    str_replace_all("\\s+", " ") %>%
    str_replace_all("\\s*([:;,.])\\s*", "\\1 ") %>%
    str_replace_all("\\s+", " ") %>%
    str_trim() %>%
    str_remove("\\.$") %>%
    tolower()
}

# Only alias wording on a verified five-point agreement scale
build_likert_fallback <- function(scale_map) {
  expected <- c("strongly agree", "agree", "neither agree nor disagree",
                "disagree", "strongly disagree")
  empty <- data.frame(item = character(), norm_label = character(),
                      fallback_bin = integer())
  rows <- lapply(unique(as.character(scale_map$item)), function(id) {
    if (is.na(id)) return(NULL)
    x <- scale_map[!is.na(scale_map$item) & scale_map$item == id, , drop = FALSE]
    x <- x[order(x$bin), , drop = FALSE]
    if (nrow(x) != 5L || !identical(as.integer(x$bin), 1:5) ||
        !identical(as.character(x$norm_label), expected)) return(NULL)
    data.frame(item = id, norm_label = c("somewhat agree", "somewhat disagree"),
               fallback_bin = c(2L, 4L))
  })
  do.call(rbind, c(list(empty), rows))
}

# Check source rows before summing bins: aggregation would hide duplicates.
issp_assert_unique_proportion_cells <- function(x, audit_path) {
  keys <- c("model_family", "model", "scope", "country_folder", "dataset_type",
            "method", "item", "bin")
  stopifnot(all(keys %in% names(x)))
  key_rows <- as.data.frame(x[, keys, drop = FALSE])
  bad <- duplicated(key_rows) | duplicated(key_rows, fromLast = TRUE)
  if (any(bad)) {
    utils::write.csv(x[bad, , drop = FALSE], audit_path, row.names = FALSE)
    stop("Duplicate ISSP source proportion cells; inspect ", audit_path)
  }
  invisible(x)
}

# Do not discard invalid source probabilities or round non-integer bins before
# validation: either would alter an elicited distribution before the audit.
issp_assert_valid_discrete_proportions <- function(x, probability_col, ranges, audit_path) {
  idx <- match(x$item, ranges$item)
  lo <- ranges$scale_min[idx]
  hi <- ranges$scale_max[idx]
  p <- x[[probability_col]]
  bad <- !is.finite(p) | p < 0 | !is.finite(x$bin) |
    x$bin != round(x$bin) | !is.finite(lo) | !is.finite(hi) |
    x$bin < lo | x$bin > hi
  if (any(bad)) {
    utils::write.csv(x[bad, , drop = FALSE], audit_path, row.names = FALSE)
    stop("Invalid ISSP source proportion rows; inspect ", audit_path)
  }
  invisible(x)
}

# Parse JSON strings returned by model prompts, after removing code fences.
parse_json_safely <- function(x) {
  s <- str_trim(str_replace_all(x %||% "", "```json|```", ""))
  tryCatch(fromJSON(s, simplifyVector = TRUE), error = function(e) NULL)
}

# Custom IDs begin with the ISSP item ID (e.g., v12)
extract_item_from_custom_id <- function(custom_id) {
  str_extract(custom_id %||% "", "^v\\d+")
}

# Pull the model name from several possible JSONL batch-output structures.
extract_model_from_obj <- function(obj, fallback_model = "model_unspecified") {
  if (!is.null(obj$response) &&
      !is.null(obj$response$body) &&
      !is.null(obj$response$body$model)) {
    return(obj$response$body$model)
  }

  if (!is.null(obj$response) &&
      !is.null(obj$response$model)) {
    return(obj$response$model)
  }

  if (!is.null(obj$model)) return(obj$model)

  fallback_model
}

# Pull the assistant/model text content from several possible JSONL structures.
extract_content_from_obj <- function(obj) {
  if (!is.null(obj$response) &&
      !is.null(obj$response$body) &&
      !is.null(obj$response$body$choices) &&
      length(obj$response$body$choices) >= 1 &&
      !is.null(obj$response$body$choices[[1]]$message$content)) {
    return(obj$response$body$choices[[1]]$message$content)
  }

  if (!is.null(obj$response) &&
      !is.null(obj$response$choices) &&
      length(obj$response$choices) >= 1 &&
      !is.null(obj$response$choices[[1]]$message$content)) {
    return(obj$response$choices[[1]]$message$content)
  }

  if (!is.null(obj$content)) return(obj$content)

  for (nm in names(obj)) {
    if (is.list(obj[[nm]]) && !is.null(obj[[nm]]$content)) {
      return(obj[[nm]]$content)
    }
  }

  NA_character_
}

extract_method_from_name <- function(fname) {
  is_global_file <- str_detect(fname, "_Global(_|\\.|$)")
  case_when(
    str_detect(fname, "output_global_countrylist_Global") ~ "distribution_distribution",
    str_detect(fname, "output_distribution") & is_global_file ~ "global_output_distribution",
    str_detect(fname, "output_distribution") ~ "distribution_distribution",
    str_detect(fname, "global_simple") ~ "global_simple",
    str_detect(fname, "global_counts") ~ "global_counts",
    str_detect(fname, "mean_alone") ~ "mean_alone",
    str_detect(fname, "std_alone") ~ "std_alone",
    str_detect(fname, "std_extended") ~ "std_extended",
    str_detect(fname, "distribution") ~ "distribution_distribution",
    TRUE ~ "other"
  )
}

# Read one country/global JSONL file and return standardized metadata plus raw
# model content
read_issp_jsonl_file <- function(fpath, country_name, model_family = "gpt") {
  fname <- basename(fpath)
  method <- extract_method_from_name(fname)
  lines <- readLines(fpath, warn = FALSE)
  out <- vector("list", length(lines))
  keep <- 0

  for (line in lines) {
    if (!nzchar(str_trim(line))) next

    obj <- tryCatch(fromJSON(line, simplifyVector = FALSE), error = function(e) NULL)
    if (is.null(obj)) next

    custom_id <- obj$custom_id %||% NA_character_
    item <- extract_item_from_custom_id(custom_id)
    content <- extract_content_from_obj(obj)

    if (is.na(item) || is.na(content)) next

    keep <- keep + 1
    out[[keep]] <- tibble(
      model_family = model_family,
      model = extract_model_from_obj(obj, fallback_model = paste0(model_family, "_unspecified")),
      scope = if_else(country_name == "Global", "global", "country"),
      country_folder = country_name,
      item = item,
      method_raw = method,
      custom_id = custom_id,
      raw_content = content,
      source_file = fname,
      source_path = fpath
    )
  }

  if (keep == 0) return(NULL)
  bind_rows(out[seq_len(keep)])
}

# Read all JSONL files for one country folder.
read_issp_country_dir <- function(country_name, base_path, model_family = "gpt") {
  country_dir <- file.path(base_path, country_name)
  if (!dir.exists(country_dir)) return(NULL)

  files <- list.files(country_dir, pattern = "\\.jsonl$", full.names = TRUE)
  if (length(files) == 0) return(NULL)

  clean_files <- files[str_detect(basename(files), "_clean")]
  if (length(clean_files) > 0) {
    stop(
      "Country folder ", country_name, " contains _clean duplicate JSONL files: ",
      paste(basename(clean_files), collapse = "; ")
    )
  }

  bind_rows(lapply(files, read_issp_jsonl_file, country_name = country_name, model_family = model_family))
}

# Generic JSONL reader for files not stored in country subdirectories
read_generic_jsonl_outputs <- function(fpath, model_family = "gpt", scope = "global", country_folder = "Global") {
  lines <- readLines(fpath, warn = FALSE)
  out <- vector("list", length(lines))
  keep <- 0

  for (line in lines) {
    if (!nzchar(str_trim(line))) next

    obj <- tryCatch(fromJSON(line, simplifyVector = FALSE), error = function(e) NULL)
    if (is.null(obj)) next

    custom_id <- obj$custom_id %||% NA_character_
    item <- extract_item_from_custom_id(custom_id)
    content <- extract_content_from_obj(obj)

    if (is.na(item) || is.na(content)) next

    keep <- keep + 1
    out[[keep]] <- tibble(
      model_family = model_family,
      model = extract_model_from_obj(obj, fallback_model = paste0(model_family, "_unspecified")),
      scope = scope,
      country_folder = country_folder,
      item = item,
      custom_id = custom_id,
      raw_content = content,
      source_file = basename(fpath),
      source_path = fpath
    )
  }

  if (keep == 0) return(tibble())
  bind_rows(out[seq_len(keep)])
}

# Extract the maximum numeric response option from scale labels.
extract_numeric_range_from_scale <- function(scale_text) {
  if (is.na(scale_text) || !nzchar(as.character(scale_text))) return(NA_integer_)

  vals <- str_match_all(
    as.character(scale_text),
    "\\b(\\d+)\\s*:"
  )[[1]]

  if (nrow(vals) == 0) return(NA_integer_)

  vals <- suppressWarnings(as.integer(vals[, 2]))
  vals <- vals[!is.na(vals)]

  if (length(vals) == 0) return(NA_integer_)
  max(vals)
}

build_item_scale_map <- function(mapping_df) {
  out <- list()

  for (i in seq_len(nrow(mapping_df))) {
    item <- mapping_df$id[i]
    scale_text <- as.character(mapping_df$scale[i])

    if (is.na(item) || is.na(scale_text) || !nzchar(scale_text)) next
    if (!str_detect(scale_text, "\\b\\d+\\s*:")) next

    matches <- str_match_all(
      scale_text,
      regex("(\\d+)\\s*:\\s*(.*?)(?=\\s*;?\\s*\\d+\\s*:|$)", dotall = TRUE)
    )[[1]]

    if (nrow(matches) == 0) next

    item_map <- tibble(
      item = item,
      bin = suppressWarnings(as.integer(matches[, 2])),
      raw_label = str_squish(matches[, 3]),
      norm_label = normalize_label(matches[, 3])
    ) %>%
      filter(!is.na(bin), nzchar(raw_label)) %>%
      distinct(item, bin, norm_label, .keep_all = TRUE)

    if (nrow(item_map) > 0) {
      out[[item]] <- item_map
    }
  }

  bind_rows(out)
}

# Standalone mean/SD fields
parse_standalone_scalar <- function(x, kind = c("mean", "sd")) {
  kind <- match.arg(kind)
  if (length(x) != 1L || is.na(x)) return(NA_real_)
  s <- trimws(gsub("```(?:json)?", "", as.character(x), perl = TRUE))
  s <- gsub("[\u2212\u2013]", "-", s, perl = TRUE)
  s <- gsub("(?<=[0-9])\\\\\\.(?=[0-9])", ".", s, perl = TRUE)
  if (grepl("no data available|no estimate|cannot be estimated|cannot be calculated|cannot be provided|0 participants", s, ignore.case = TRUE)) return(NA_real_)
  number <- "[+-]?(?:[0-9]+(?:\\.[0-9]+)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?"
  unmark <- function(v) {
    if (is.list(v) || length(v) != 1L || is.na(v)) return(NA_character_)
    v <- trimws(as.character(v))
    repeat {
      old <- v
      for (mark in c("***", "**", "*", "`")) {
        n <- nchar(mark)
        if (nchar(v) > 2L*n && startsWith(v, mark) && endsWith(v, mark)) {
          inner <- substr(v, n+1L, nchar(v)-n)
          if (!grepl(mark, inner, fixed=TRUE)) {
            v <- trimws(inner)
            break
          }
        }
      }
      if (identical(old, v)) break
    }
    v
  }
  clean_field <- function(v) {
    v <- unmark(v)
    # Normalize a detached sign only at the start of a complete scalar field.
    gsub("^([+-])[[:space:]]+(?=[0-9.])", "\\1", v, perl = TRUE)
  }
  scalar <- function(v) {
    if (is.list(v) || length(v) != 1L || is.na(v)) return(NA_real_)
    v <- clean_field(v)
    # Recovery is confined to one complete decimal scalar, never "1 2".
    split <- "^[+-]?[[:space:]]*(?:[0-9]+[[:space:]]*\\.[[:space:]]*[0-9]+(?:[[:space:]]+[0-9]+)*|\\.[[:space:]]*[0-9]+(?:[[:space:]]+[0-9]+)*)(?:[eE][+-]?[0-9]+)?$"
    if (grepl(split, v, perl = TRUE)) v <- gsub("[[:space:]]", "", v)
    if (!grepl(paste0("^", number, "$"), v, perl = TRUE)) return(NA_real_)
    y <- suppressWarnings(as.numeric(v))
    if (!is.finite(y) || (kind == "sd" && y < 0)) NA_real_ else y
  }
  bare <- scalar(s)
  if (is.finite(bare)) return(bare)
  obj <- tryCatch(jsonlite::fromJSON(s, simplifyVector = FALSE), error = function(e) NULL)
  if (!is.null(obj)) {
    if (!is.list(obj)) return(scalar(obj))
    if (is.null(names(obj)) || anyDuplicated(tolower(names(obj)))) return(NA_real_)
    keys <- if (kind == "mean") c("mean", "value", "answer to q1") else c("sd", "std", "standard deviation", "value", "answer to q3")
    use <- tolower(names(obj)) %in% keys
    if (!any(use)) return(NA_real_)
    vals <- vapply(obj[use], scalar, numeric(1))
    if (all(is.finite(vals)) && length(unique(vals)) == 1L) return(vals[1])
    return(NA_real_)
  }
  # Broken JSON must not fall through to its numeric contents.
  if (grepl("^[\\s]*[\\{\\[]", s, perl = TRUE)) return(NA_real_)
  s <- unmark(s)
  # Unwrap a formatted label separately from its value; never delete the
  # value's opening wrapper or any operator between its digits.
  heading <- "(?:final\\s+(?:answer|mean|sd|standard deviation)|mean|sd|std|standard\\s+deviation|correction|corrected answer|replacement answer)(?:\\s+estimate)?[ \\t]*[:=]?"
  for (mark in c("***", "**", "*", "`")) {
    literal <- paste0("\\Q", mark, "\\E")
    s <- gsub(paste0(literal, "(", heading, ")", literal), "\\1", s,
              ignore.case = TRUE, perl = TRUE)
  }
  correction <- gregexpr("(?im)^[ \\t*`]*(?:correction|corrected answer|replacement answer)\\s*[:=][ \\t*`]*", s, perl = TRUE)[[1]]
  if (correction[1] > 0L) s <- substring(s, tail(correction, 1) + tail(attr(correction, "match.length"), 1))
  # Read complete labelled fields
  get_fields <- function(pattern) {
    at <- gregexpr(pattern, s, ignore.case = TRUE, perl = TRUE)[[1]]
    if (at[1] < 0L) return(NULL)
    vapply(at + attr(at, "match.length"), function(start) {
      tail <- substring(s, start)
      tail <- sub("^[\\s]*", "", tail, perl = TRUE)
      field <- strsplit(tail, "[\\r\\n]", perl = TRUE)[[1]][1]
      if (is.na(field) || !nzchar(trimws(field))) return(NA_real_)
      if (grepl("[0-9]\\.$", field)) {
        remainder <- substring(tail, nchar(field) + 1L)
        continuation <- regmatches(remainder, regexpr("^[\\r\\n]+[ \\t]*[0-9]+(?:[eE][+-]?[0-9]+)?(?=[ \\t*`]*(?:[\\r\\n]|$))", remainder, perl = TRUE))
        if (length(continuation) && nzchar(continuation)) field <- paste0(field, continuation)
      }
      field <- clean_field(field)
      # Permit a single sentence-ending period, never an extra decimal point.
      field <- sub(paste0("^(", number, ")\\.$"), "\\1", field, perl = TRUE)
      scalar(field)
    }, numeric(1))
  }
  final <- get_fields("\\bfinal\\s+(?:answer|mean|sd|standard deviation)[ \\t]*[:=][ \\t]*")
  if (!is.null(final)) return(if (all(is.finite(final)) && length(unique(final)) == 1L) final[1] else NA_real_)
  label <- if (kind == "mean") "mean" else "(?:SD|std|standard\\s+deviation)"
  fields <- get_fields(paste0("\\b", label, "(?:\\s+estimate)?[ \\t]*(?:[:=]|\\bis\\b)[ \\t]*"))
  if (!is.null(fields)) return(if (all(is.finite(fields)) && length(unique(fields)) == 1L) fields[1] else NA_real_)
  if (grepl("[+*/=^\u00d7\u00f7]|[0-9]\\s*[-]\\s*[0-9]|[0-9]\\.[\\s.]+[0-9]|[+-][[:space:]]+[0-9.]|[+-][[:space:]]*[+-]", s, perl = TRUE)) return(NA_real_)
  hits <- regmatches(s, gregexpr(paste0("(?<![[:alnum:]_.+-])", number, "(?![[:alnum:]_.])"), s, perl = TRUE))[[1]]
  if (length(hits) == 1L) scalar(hits) else NA_real_
}

# Parse one mean estimate from a mean-only prompt
parse_mean_alone <- function(x) parse_standalone_scalar(x, "mean")
# Parse one SD estimate from an SD-only prompt
parse_sd_alone <- function(x) parse_standalone_scalar(x, "sd")

# Parse expanded moment prompts into mean, SD, skewness, and kurtosis.
parse_extended <- function(content) {
  s <- str_trim(str_replace_all(content %||% "", "```json|```", ""))
  s_low <- tolower(s)

  if (str_detect(
    s_low,
    "no data available|no estimate|cannot be estimated|cannot be calculated|cannot be provided|no estimate possible|0 participants"
  )) {
    return(list(mean = NA, sd = NA, skew = NA, kurt = NA))
  }

  obj <- tryCatch(fromJSON(s, simplifyVector = TRUE), error = function(e) NULL)

  if (is.null(obj) || !is.list(obj)) {
    return(list(mean = NA, sd = NA, skew = NA, kurt = NA))
  }

  list(
    mean = num(obj$mean %||% obj[["Answer to Q1"]] %||% obj$value),
    sd   = num(obj$std %||% obj$sd %||% obj[["Answer to Q3"]]),
    skew = num(obj$skewness %||% obj[["Answer to Q5"]]),
    kurt = num(obj$kurtosis %||% obj[["Answer to Q4"]])
  )
}

# Parse direct response-bin probability prompts into category/probability rows.
parse_proportion <- function(content) {
  obj <- parse_json_safely(content)

  if (is.null(obj) || !is.list(obj) || length(obj) == 0) return(NULL)

  vals <- suppressWarnings(as.numeric(unlist(obj)))
  labs <- names(unlist(obj))

  if (length(vals) == 0 || length(labs) == 0) return(NULL)

  tibble(category = labs, prob = vals)
}

parse_count_response_detail <- function(x) {
  text <- trimws(tolower(enc2utf8(as.character(x))))
  text <- gsub("\u2212", "-", text, fixed = TRUE)
  number <- "[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?"
  token <- paste0("(?<![A-Za-z0-9_.+\u2010-\u2015\u2212\ufe63\uff0d-])", number, "(?![A-Za-z0-9_.])")
  values <- rep(NA_real_, length(text)); status <- rep("unparsed_raw", length(text))
  missing <- is.na(text) | !nzchar(text); status[missing] <- "missing_raw"
  plain <- !missing & grepl(paste0("^", number, "$"), text, perl = TRUE)
  values[plain] <- suppressWarnings(as.numeric(text[plain])); status[plain] <- "numeric_raw"
  overflow <- plain & !is.finite(values)
  values[overflow] <- NA_real_; status[overflow] <- "nonfinite_raw_number"
  words <- c(zero=0, one=1, two=2, three=3, four=4, five=5, six=6, seven=7,
    eight=8, nine=9, ten=10, eleven=11, twelve=12, thirteen=13,
    fourteen=14, fifteen=15, sixteen=16, seventeen=17, eighteen=18,
    nineteen=19, twenty=20)
  # Remove paired presentation delimiters only
  strip_answer_markup <- function(z) {
    for (mark in c("***", "___", "**", "__", "*", "_", "`", "$")) {
      literal <- paste0("\\Q", mark, "\\E")
      pattern <- paste0("(?<![[:alnum:]_*`$])", literal,
        "(?=\\S)([^\\r\\n]*?\\S|\\S)", literal, "(?![_*`$])")
      at <- gregexpr(pattern, z, perl=TRUE)[[1]]
      if (at[1] < 0L) next
      widths <- attr(at,"match.length")
      for (k in rev(seq_along(at))) {
        before <- substr(z,1L,at[k]-1L)
        after <- substring(z,at[k]+widths[k])
        body <- substr(z,at[k]+nchar(mark),at[k]+widths[k]-nchar(mark)-1L)
        numeric_body <- grepl("^[+-]?[0-9.eE+-]+$",body,perl=TRUE)
        decimal_continuation <-
          (grepl("^[+-]?[0-9]+$",body) && grepl("^[.][0-9]",after)) ||
          (grepl("^[+-]?[0-9]+[.]$",body) && grepl("^[0-9]",after)) ||
          (grepl("^[.][0-9]+$",body) && grepl("[0-9]$",before))
        if (numeric_body && !decimal_continuation &&
            (grepl("[0-9)][ \\t]*$",before,perl=TRUE) ||
             grepl("^[ \\t]*(?:[0-9]|[.]\\d|[(][ \\t]*[0-9.+-])",after,perl=TRUE))) next
        z <- paste0(before,body,after)
      }
    }
    z
  }
  # A clause may state one scalar, with prose or terminal punctuation. An
  # alternative, range, calculation, malformed number or second answer vetoes it.
  has_calculation <- function(z) grepl("[0-9.)]\\s*(?:[-\u2010-\u2015/+*^=\u00d7\u00f7]|[(]\\s*[0-9.+-]|\\b(?:x|times|divided\\s+by)\\b|\\\\(?:times|div|cdot)\\b)",z,perl=TRUE)
  unconsumed_sign <- function(z,positions) {
    prefixes <- substring(z,1L,positions-1L)
    any(grepl("[+\u2010-\u2015\u2212\ufe63\uff0d-]\\s*$",prefixes,perl=TRUE))
  }
  scalar_clause <- function(z) {
    z <- trimws(strip_answer_markup(z))
    # A parenthetical rounding annotation describes presentation, not another
    # answer or range. Strip only this explicit annotation grammar.
    z <- gsub("\\(rounded(?:\\s+to\\s+(?:[0-9]+|one|two|three)\\s+decimal(?:s|\\s+places?)?)?\\)","",z,perl=TRUE)
    if (grepl("\\b(?:or|to)\\b",z,perl=TRUE) || has_calculation(z)) return(NA_real_)
    # Remove a sentence period, but never repair 1.. or 1.2.3.
    z <- sub("(?<=[0-9])[.](?=\\s|$)", "", z, perl=TRUE)
    positions <- gregexpr(token,z,perl=TRUE)[[1]]
    hits <- regmatches(z, list(positions))[[1]]
    broad <- regmatches(z, gregexpr(number,z,perl=TRUE))[[1]]
    if (!length(hits) || length(hits) != length(broad)) return(NA_real_)
    # A sign separated from the matched number remains part of its token
    if (unconsumed_sign(z,positions)) return(NA_real_)
    v <- unique(suppressWarnings(as.numeric(hits)))
    if (length(v)==1L && is.finite(v)) v else NA_real_
  }
  final_header <- "(?:replaced the response with a new one|final (?:answer|response)|corrected (?:answer|response)|i will answer)\\s*[:=]?\\s*|(?m)^[ \\t]*correction\\s*[:=]\\s*"
  for (j in which(!missing & !plain)) {
    z <- strip_answer_markup(gsub("\\\\[nr]", "\n", text[j], perl=TRUE))
    # Serialized assistant-header artifacts are recoverable only when the
    # complete scalar payload agrees with every number before it
    if (grepl("assistant<|end_header_id|>", z, fixed = TRUE)) {
      payload <- trimws(sub("(?s)^.*assistant<\\|end_header_id\\|>", "", z, perl = TRUE))
      if (grepl(paste0("^", number, "$"), payload, perl = TRUE)) {
        number_positions <- gregexpr(number,z,perl=TRUE)[[1]]
        all_numbers <- suppressWarnings(as.numeric(regmatches(z,list(number_positions))[[1]]))
        if(!unconsumed_sign(z,number_positions) && !has_calculation(z) &&
            all(is.finite(all_numbers)) && length(unique(all_numbers))==1L) {
          values[j] <- as.numeric(payload); status[j] <- "repeated_identical_tokens"
        } else status[j] <- "conflicting_raw_numbers"
        next
      }
    }
    # Strip presentational punctuation only
    word <- gsub("^[[:space:]()\\[\\]{}\"'`*.,!?;:]+|[[:space:]()\\[\\]{}\"'`*.,!?;:]+$", "", z, perl=TRUE)
    word_key <- sub("^[+-]", "", word)
    if (word_key %in% names(words)) {
      sign <- if (startsWith(word, "-")) -1 else 1
      values[j] <- sign * unname(words[word_key]); status[j] <- "number_word"; next
    }
    at <- gregexpr(final_header,z,perl=TRUE)[[1]]
    if (at[1]>0L) {
      starts <- at+attr(at,"match.length")
      ends <- c(at[-1]-1L,nchar(z))
      headers <- regmatches(z,list(at))[[1]]
      clauses <- mapply(substr,MoreArgs=list(x=z),start=starts,stop=ends,USE.NAMES=FALSE)
      # Only an explicit correction/replacement supersedes earlier finals.
      correction <- which(grepl("^\\s*(?:corrected|correction|replaced)",headers,perl=TRUE))
      if (length(correction)) clauses <- clauses[seq.int(tail(correction,1L),length(clauses))]
      v <- vapply(clauses,scalar_clause,numeric(1))
      if (all(is.finite(v)) && length(unique(v))==1L) {
        values[j] <- v[1]; status[j] <- "explicit_final_correction"
      } else status[j] <- "conflicting_or_invalid_final_answer"
      next
    }
    v <- scalar_clause(z)
    if (is.finite(v)) {
      values[j] <- v
      hits <- regmatches(z,gregexpr(token,z,perl=TRUE))[[1]]
      status[j] <- if (length(hits)==1L) "single_numeric_token" else "repeated_identical_tokens"
    } else if (length(regmatches(z,gregexpr(number,z,perl=TRUE))[[1]])>1L) status[j] <- "conflicting_raw_numbers"
  }
  data.frame(value=values,status=status,stringsAsFactors=FALSE)
}
parse_count_response <- function(x) parse_count_response_detail(x)$value

standardize_legacy_country <- function(scope, country) {
  if_else(scope == "global", "Global", as.character(country))
}

# For non-discrete proportion prompts, the model reports probability mass over
# intervals. Simulate values uniformly within selected intervals, then bin them.

ISSP_INTERVAL_DIAG <- new.env(parent = emptyenv())
ISSP_INTERVAL_DIAG$rows <- list()

simulate_interval_props <- function(df, n = n_sim_issp, cell_id = NA_character_) {
  .record <- function(status) {
    ISSP_INTERVAL_DIAG$rows[[length(ISSP_INTERVAL_DIAG$rows) + 1L]] <- tibble(
      cell_id = as.character(cell_id), status = status,
      n_interval_rows = nrow(df),
      n_na_probability = sum(is.na(suppressWarnings(as.numeric(df$probability))))
    )
  }

  if (nrow(df) == 0) {
    return(tibble(bin = integer(), model_prop = numeric()))
  }

  probs_raw <- suppressWarnings(as.numeric(df$probability))
  lb <- suppressWarnings(as.numeric(df$lower_bound))
  ub <- suppressWarnings(as.numeric(df$upper_bound))

  probs <- probs_raw
  probs[is.na(probs)] <- 0

  if (any(!is.finite(probs)) || any(probs < 0)) {
    .record("REJECTED: negative or non-finite probability")
    return(tibble(bin = integer(), model_prop = numeric()))
  }
  if (sum(probs) <= 0) {
    .record("REJECTED: zero total probability")
    return(tibble(bin = integer(), model_prop = numeric()))
  }
  active <- probs > 0
  if (any(!is.finite(lb[active]) | !is.finite(ub[active]) | lb[active] > ub[active])) {
    .record("REJECTED: missing, non-finite, or inverted interval bounds")
    return(tibble(bin = integer(), model_prop = numeric()))
  }
  if (any(is.na(probs_raw))) {
    .record("kept: NA probabilities zeroed (pre-existing behavior)")
  }

  probs <- probs / sum(probs)

  idx <- sample(seq_len(nrow(df)), size = n, replace = TRUE, prob = probs)

  draws <- runif(n, min = lb[idx], max = ub[idx])

  tibble(bin = as.integer(round(draws))) %>%
    count(bin, name = "model_n_bin") %>%
    mutate(model_prop = model_n_bin / sum(model_n_bin)) %>%
    select(bin, model_prop)
}

# A zero SD is usable only when its mean is an actual response bin.
point_mass_probs <- function(mu, bins) {
  if (length(mu) != 1L || !is.finite(mu) || !length(bins) ||
      any(!is.finite(bins)) || anyDuplicated(bins)) return(NULL)
  hit <- which(abs(bins - mu) <= 1e-8)
  if (length(hit) != 1L) return(NULL)
  p <- numeric(length(bins)); p[hit] <- 1
  p
}

zero_sd_status <- function(mu, sigma, bins, skew = NA_real_, kurt = NA_real_) {
  if (!is.finite(sigma) || sigma != 0) return("not_zero_sd")
  if (is.null(point_mass_probs(mu, bins))) return("zero_sd_mean_off_grid")
  if (is.finite(skew) || is.finite(kurt)) return("zero_sd_undefined_shape_targets")
  "zero_sd_point_mass"
}

# Convert one model-reported mean and SD into a binned response distribution by
# integrating a truncated normal bounded by that item's response scale.
analytic_mean_sd_bins <- function(mu, sigma, lo, hi) {
  mu <- as.numeric(mu); sigma <- as.numeric(sigma)
  lo <- as.numeric(lo); hi <- as.numeric(hi)

  if (!is.finite(mu) || !is.finite(sigma) || sigma < 0 ||
      !is.finite(lo) || !is.finite(hi) || hi <= lo) {
    return(NULL)
  }

  bins    <- seq(lo, hi, by = 1)
  if (sigma == 0) {
    p <- point_mass_probs(mu, bins)
    return(if (is.null(p)) NULL else tibble(bin = as.integer(bins), model_prop = p))
  }
  lo_edge <- pmax(lo, bins - 0.5)
  hi_edge <- pmin(hi, bins + 0.5)

  p <- truncnorm::ptruncnorm(hi_edge, a = lo, b = hi, mean = mu, sd = sigma) -
       truncnorm::ptruncnorm(lo_edge, a = lo, b = hi, mean = mu, sd = sigma)

  if (!all(is.finite(p)) || sum(p, na.rm = TRUE) <= 0) return(NULL)

  tibble(bin = as.integer(bins), model_prop = as.numeric(p / sum(p)))
}

# Build analytic Mean + SD rows for a frame of (mean, sd) inputs, DISCRETE only.
analytic_mean_sd_props <- function(inputs) {
  if (nrow(inputs) == 0) return(empty_distribution_full_row())

  inputs %>%
    left_join(item_ranges %>% select(item, scale_min, scale_max), by = "item") %>%
    mutate(lo = coalesce(scale_min, 1), hi = coalesce(scale_max, 5)) %>%
    mutate(p = purrr::pmap(list(pred_mean, pred_sd, lo, hi), analytic_mean_sd_bins)) %>%
    filter(!purrr::map_lgl(p, is.null)) %>%
    select(model_family, model, scope, country_folder, dataset_type,
           item, scenario, scale, p) %>%
    tidyr::unnest(p) %>%
    mutate(method = "distribution_mean_sd") %>%
    select(model_family, model, scope, country_folder, dataset_type, method,
           item, scenario, scale, bin, model_prop)
}

simulate_mean_sd_one <- function(row) {
  rng <- item_ranges %>% filter(item == row$item)

  lo <- if (nrow(rng) > 0) rng$scale_min else 1
  hi <- if (nrow(rng) > 0) rng$scale_max else 5

  if (!is.finite(row$pred_mean) || !is.finite(row$pred_sd) || row$pred_sd < 0)
    return(empty_distribution_full_row())
  if (row$pred_sd == 0) {
    p <- point_mass_probs(row$pred_mean, seq(lo, hi, by = 1))
    x <- if (is.null(p)) numeric(0) else rep(seq(lo, hi, by = 1)[which(p == 1)], n_sim_issp)
  } else x <- tryCatch(
    rtruncnorm(
      n_sim_issp,
      a = lo,
      b = hi,
      mean = row$pred_mean,
      sd = row$pred_sd
    ),
    error = function(e) rep(NA_real_, n_sim_issp)
  )

  x <- x[!is.na(x)]

  if (length(x) == 0) {
    return(tibble(
      model_family = character(), model = character(), scope = character(),
      country_folder = character(), dataset_type = character(), method = character(),
      item = character(), scenario = character(), scale = character(),
      bin = integer(), model_prop = numeric()
    ))
  }

  tibble(bin = as.integer(round(x))) %>%
    count(bin, name = "model_n_bin") %>%
    mutate(
      model_prop = model_n_bin / sum(model_n_bin),
      model_family = row$model_family,
      model = row$model,
      scope = row$scope,
      country_folder = row$country_folder,
      dataset_type = row$dataset_type,
      method = "distribution_mean_sd",
      item = row$item,
      scenario = row$scenario,
      scale = row$scale
    ) %>%
    select(
      model_family, model, scope, country_folder, dataset_type, method,
      item, scenario, scale, bin, model_prop
    )
}

# Draw from a skew-normal parameterization while preserving a requested mean
# and SD. 
r_skewnorm_mean_sd <- function(n, mean, sd, alpha) {
  mean <- as.numeric(mean)
  sd <- as.numeric(sd)
  alpha <- as.numeric(alpha)

  if (is.na(mean) || is.na(sd) || sd <= 0) {
    return(rep(NA_real_, n))
  }

  if (is.na(alpha) || alpha == 0) {
    return(stats::rnorm(n, mean = mean, sd = sd))
  }

  delta <- alpha / sqrt(1 + alpha^2)
  denom <- sqrt(1 - 2 * delta^2 / pi)

  if (!is.finite(denom) || denom <= 0) {
    return(stats::rnorm(n, mean = mean, sd = sd))
  }

  omega <- sd / denom
  xi <- mean - omega * delta * sqrt(2 / pi)

  sn::rsn(n = n, xi = xi, omega = omega, alpha = alpha)
}

# Empty result with the same columns as a valid expanded moment distribution.
empty_distribution_full_row <- function() {
  tibble(
    model_family = character(), model = character(), scope = character(),
    country_folder = character(), dataset_type = character(), method = character(),
    item = character(), scenario = character(), scale = character(),
    bin = integer(), model_prop = numeric()
  )
}

# Convert unconstrained optimization parameters into valid probabilities that
# are positive and sum to one.
softmax_probs <- function(z) {
  z <- z - max(z, na.rm = TRUE)
  ez <- exp(z)
  ez / sum(ez)
}

# Compute mean, SD, skewness, and excess kurtosis for a candidate discrete
# response-bin distribution.
discrete_moments_from_probs <- function(p, bins) {
  mu <- sum(p * bins)
  var <- sum(p * (bins - mu)^2)
  sd <- sqrt(var)

  if (!is.finite(sd) || sd <= 0) {
    return(list(
      mean = mu,
      sd = sd,
      skew = NA_real_,
      kurt = NA_real_
    ))
  }

  z <- (bins - mu) / sd

  list(
    mean = mu,
    sd = sd,
    skew = sum(p * z^3),
    kurt = sum(p * z^4) - 3
  )
}

# Fit a probability distribution over valid response bins to match target
# moments from the expanded moment prompt.
moment_feasibility_small_support <- function(bins, mu, sigma, skew = NA_real_, kurt = NA_real_) {
  bins <- as.numeric(bins)
  if (length(bins) > 9L) return(list(status = "not_assessed_large_support", p = NULL))
  if (length(bins) < 2L || any(!is.finite(bins)) || anyDuplicated(bins) ||
      !is.finite(mu) || !is.finite(sigma) || sigma <= 0)
    return(list(status = "not_assessed_invalid_or_constant", p = NULL))
  center <- mean(range(bins)); width <- diff(range(bins))
  x <- (bins - center) / width; a <- (mu - center) / width; v <- (sigma / width)^2
  powers <- c(0L, 1L, 2L); target <- c(1, a, a^2 + v)
  if (is.finite(skew)) {
    powers <- c(powers, 3L); target <- c(target, a^3 + 3*a*v + skew*v^1.5)
  }
  if (is.finite(kurt)) {
    # Fourth raw moment requires the central third moment; if skew was not
    # elicited, retain the nonlinear fitter 
    if (!is.finite(skew)) return(list(status = "not_assessed_kurtosis_without_skew", p = NULL))
    powers <- c(powers, 4L)
    target <- c(target, a^4 + 6*a^2*v + 4*a*skew*v^1.5 + (kurt+3)*v^2)
  }
  A <- t(vapply(powers, function(k) x^k, numeric(length(x))))
  subsets <- combn(seq_along(x), min(nrow(A), length(x)), simplify = FALSE)
  total <- numeric(length(x)); n_vertices <- 0L; vertices <- list()
  for (idx in subsets) {
    w <- tryCatch(qr.solve(A[, idx, drop = FALSE], target, tol = 1e-12), error = function(e) NULL)
    if (is.null(w) || any(!is.finite(w)) || min(w) < -1e-10) next
    p <- numeric(length(x)); p[idx] <- pmax(w, 0)
    if (max(abs(drop(A %*% p) - target)) > 1e-9 || sum(p) <= 0) next
    total <- total + p / sum(p); n_vertices <- n_vertices + 1L
    vertices[[n_vertices]] <- p / sum(p)
  }
  if (!n_vertices) return(list(status = "infeasible_on_discrete_support", p = NULL))
  list(status = "feasible_on_discrete_support", p = total / sum(total), vertices = do.call(cbind, vertices))
}

moment_reconstruction_error <- function(p, bins, mu, sigma, skew = NA_real_, kurt = NA_real_) {
  m <- discrete_moments_from_probs(p, bins)
  residual <- c(m$mean - mu, m$sd - sigma,
    if (is.finite(skew)) m$skew - skew,
    if (is.finite(kurt)) m$kurt - kurt)
  if (any(!is.finite(residual))) Inf else max(abs(residual))
}

MOMENT_ACCURACY_TOL <- 1e-4

# Sensitivity
maxent_moment_distribution <- function(bins, mu, sigma, skew = NA_real_, kurt = NA_real_) {
  failure <- function(status) list(status=status, p=NULL, max_moment_error=NA_real_, entropy=NA_real_, optimality_gap=NA_real_)
  if (is.finite(sigma) && sigma == 0) {
    if (zero_sd_status(mu,sigma,bins,skew,kurt) != "zero_sd_point_mass") return(failure("invalid_zero_sd"))
    p <- point_mass_probs(mu,bins)
    return(list(status="exact_point_mass",p=p,max_moment_error=0,entropy=0,optimality_gap=0))
  }
  f <- moment_feasibility_small_support(bins,mu,sigma,skew,kurt)
  if (is.null(f$p)) return(failure(f$status))
  V <- f$vertices
  active <- which(rowSums(V) > 0)
  pa <- f$p[active]
  degree <- if(is.finite(kurt)) 4L else if(is.finite(skew)) 3L else 2L
  C <- outer(0:degree,bins[active],function(power,x) x^power)
  C <- C/sqrt(rowSums(C^2))
  decomposition <- qr(t(C),tol=1e-10)
  Q <- qr.Q(decomposition,complete=TRUE)
  gap <- 0
  if(decomposition$rank < length(active)) {
    X <- Q[,seq.int(2L,decomposition$rank),drop=FALSE]
    target <- drop(crossprod(X,pa)); lambda <- rep(0,ncol(X))
    evaluate <- function(lambda) {
      eta <- drop(X %*% lambda); offset <- max(eta)
      probs <- exp(eta-offset); probs <- probs/sum(probs)
      list(p=probs,value=offset+log(sum(exp(eta-offset)))-sum(target*lambda))
    }
    converged <- FALSE
    for(iter in seq_len(200L)) {
      state <- evaluate(lambda); mean_x <- drop(crossprod(X,state$p))
      gradient <- mean_x-target
      if(max(abs(gradient)) <= 1e-12) {converged <- TRUE;break}
      centered <- sweep(X,2,mean_x)
      hessian <- crossprod(centered,centered*state$p)
      eigen_h <- eigen(hessian,symmetric=TRUE)
      step <- -drop(eigen_h$vectors %*% (crossprod(eigen_h$vectors,gradient)/pmax(eigen_h$values,1e-15)))
      direction <- sum(gradient*step); alpha <- 1; accepted <- FALSE
      for(backtrack in seq_len(80L)) {
        proposal <- lambda+alpha*step
        if(evaluate(proposal)$value <= state$value+1e-4*alpha*direction+1e-15) {
          lambda <- proposal;accepted <- TRUE;break
        }
        alpha <- alpha/2
      }
      if(!accepted) return(failure("maxent_optimizer_failed"))
    }
    if(!converged) return(failure("maxent_optimizer_failed"))
    pa <- state$p
    # At matched moments the convex dual bounds the achieved entropy.
    gap <- abs(state$value + sum(pa[pa>0]*log(pa[pa>0])))
    if(!is.finite(gap) || gap>1e-7) return(failure("maxent_optimality_failed"))
  }
  p <- numeric(length(bins)); p[active] <- pa
  error <- moment_reconstruction_error(p,bins,mu,sigma,skew,kurt)
  if (!is.finite(error) || error > MOMENT_ACCURACY_TOL) return(failure("maxent_moment_accuracy_failed"))
  list(status="maximum_entropy_exact_moments",p=p,max_moment_error=error,
    entropy=-sum(p[p>0]*log(p[p>0])), optimality_gap=gap)
}


fit_discrete_moment_distribution <- function(
    bins,
    target_mean,
    target_sd,
    target_skew = NA_real_,
    target_kurt = NA_real_
) {
  if (
    length(bins) < 2 ||
    is.na(target_mean) || !is.finite(target_mean) ||
    is.na(target_sd) || !is.finite(target_sd) || target_sd < 0
  ) {
    return(NULL)
  }

  use_skew <- !is.na(target_skew) && is.finite(target_skew)
  # KURTOSIS EXCLUDED FROM THE LOSS. The ISSP full-distribution
  # prompt asked for "kurtosis" without naming a convention.
  # The stated values do not establish which convention was intended.
  use_kurt <- FALSE
  target_kurt_elicited <- target_kurt  # retained for reference; not fitted
  if (target_sd == 0) {
    if (zero_sd_status(target_mean, target_sd, bins, target_skew) != "zero_sd_point_mass")
      return(NULL)
    out <- tibble(bin = as.integer(bins), model_prop = point_mass_probs(target_mean, bins))
    attr(out, "fit_attempt") <- "exact_point_mass"
    return(out)
  }

  scale_width <- max(bins) - min(bins)

  # Construct finite starting logits without taking log(0).
  log_p <- stats::dnorm(
    bins,
    mean = target_mean,
    sd = target_sd,
    log = TRUE
  )
  
  finite <- is.finite(log_p)
  
  if (!any(finite)) {
    start_p <- rep(1 / length(bins), length(bins))
  } else {
    log_p[!finite] <- -Inf
    start_p <- exp(log_p - max(log_p[finite]))
    start_p <- start_p / sum(start_p)
    
    # Floor applies only to initialization, not the fitted probabilities.
    start_p <- pmax(start_p, 1e-8)
    start_p <- start_p / sum(start_p)
  }
  
  start_z <- log(start_p)

  objective <- function(z) {
    p <- softmax_probs(z)
    m <- discrete_moments_from_probs(p, bins)
    if (!is.finite(m$mean) || !is.finite(m$sd) ||
        (use_skew && !is.finite(m$skew)) ||
        (use_kurt && !is.finite(m$kurt))) return(1e100)

    loss <- 0

    loss <- loss + ((m$mean - target_mean) / scale_width)^2
    loss <- loss + ((m$sd - target_sd) / scale_width)^2

    if (use_skew && !is.na(m$skew) && is.finite(m$skew)) {
      loss <- loss + (m$skew - target_skew)^2
    }

    if (use_kurt && !is.na(m$kurt) && is.finite(m$kurt)) {
      loss <- loss + (m$kurt - target_kurt)^2
    }

    loss
  }

  run_fit <- function(start) {
    tryCatch(
      stats::optim(
        par = start,
        fn = objective,
        method = "BFGS",
        control = list(maxit = 5000, reltol = 1e-12)
      ),
      error = function(e) NULL
    )
  }
  
  fit_ok <- function(fit) {
    !is.null(fit) &&
      isTRUE(fit$convergence == 0) &&
      all(is.finite(fit$par)) &&
      is.finite(fit$value) && fit$value < 1e99
  }
  
  # Fit from both the initial and uniform probabilities.
  fits <- list(initial_start = run_fit(start_z), uniform_start = run_fit(rep(0, length(bins))))
  valid <- vapply(fits, fit_ok, logical(1))
  feasibility <- moment_feasibility_small_support(bins, target_mean, target_sd,
    if (use_skew) target_skew else NA_real_)
  if (any(valid)) {
    winner <- names(fits)[which(valid)[which.min(vapply(fits[valid], function(f) f$value, numeric(1)))]]
    p <- softmax_probs(fits[[winner]]$par); fit_attempt <- winner
  } else {
    p <- rep(NA_real_, length(bins)); fit_attempt <- "no_converged_start"
  }
  error_before <- moment_reconstruction_error(p, bins, target_mean, target_sd,
    if (use_skew) target_skew else NA_real_)
  if (!is.null(feasibility$p) && error_before > MOMENT_ACCURACY_TOL &&
      moment_reconstruction_error(feasibility$p, bins, target_mean, target_sd,
        if (use_skew) target_skew else NA_real_) <= MOMENT_ACCURACY_TOL) {
    p <- feasibility$p; fit_attempt <- "exact_feasible_repair"
  }
  if (any(!is.finite(p))) return(NULL)

  out <- tibble(
    bin = as.integer(bins),
    model_prop = as.numeric(p)
  )
  # Read by simulate_full_one() to distinguish selected starts and exact repairs.
  attr(out, "fit_attempt") <- fit_attempt
  attr(out, "moment_feasibility") <- feasibility$status
  attr(out, "max_moment_error") <- moment_reconstruction_error(p, bins,
    target_mean, target_sd, if (use_skew) target_skew else NA_real_)
  out
}

# Convert one expanded moment row into a full binned distribution 
ISSP_FULLFIT_DIAG <- new.env(parent = emptyenv())
ISSP_FULLFIT_DIAG$rows <- list()
ISSP_FULLFIT_DIAG$res <- list()
ISSP_FULLFIT_DIAG$outcomes <- list()
ISSP_FULLFIT_DIAG$n_attempted <- 0L
ISSP_FULLFIT_DIAG$n_exact_point_mass <- 0L
ISSP_FULLFIT_DIAG$n_exact_feasible_repair <- 0L

simulate_full_one <- function(row) {

  row_list <- as.list(row)

  ext_mean <- to_num1(row_list$ext_mean)
  ext_sd   <- to_num1(row_list$ext_sd)
  ext_skew <- to_num1(row_list$ext_skew)
  ext_kurt <- to_num1(row_list$ext_kurt)

  if (!is.finite(ext_mean) || !is.finite(ext_sd) || ext_sd < 0) {
    return(empty_distribution_full_row())
  }

  item_val <- to_chr1(row_list$item)
  rng <- item_ranges %>% filter(item == item_val)

  lo <- if (nrow(rng) > 0) rng$scale_min else 1
  hi <- if (nrow(rng) > 0) rng$scale_max else 5

  bins <- seq(lo, hi, by = 1)

  fitted <- fit_discrete_moment_distribution(
    bins = bins,
    target_mean = ext_mean,
    target_sd = ext_sd,
    target_skew = ext_skew,
    target_kurt = ext_kurt
  )

  ISSP_FULLFIT_DIAG$n_attempted <- ISSP_FULLFIT_DIAG$n_attempted + 1L
  ISSP_FULLFIT_DIAG$outcomes[[ISSP_FULLFIT_DIAG$n_attempted]] <- tibble(
    model_family=to_chr1(row_list$model_family),model=to_chr1(row_list$model),
    scope=to_chr1(row_list$scope),country_folder=to_chr1(row_list$country_folder),
    dataset_type=to_chr1(row_list$dataset_type),item=item_val,
    fit_attempt=if (is.null(fitted) || !nrow(fitted)) "omitted_fit" else to_chr1(attr(fitted,"fit_attempt")))


  if (is.null(fitted) || nrow(fitted) == 0) {
    k <- length(ISSP_FULLFIT_DIAG$rows) + 1L
    ISSP_FULLFIT_DIAG$rows[[k]] <- tibble(
      model_family = to_chr1(row_list$model_family),
      model = to_chr1(row_list$model),
      scope = to_chr1(row_list$scope),
      country_folder = to_chr1(row_list$country_folder),
      dataset_type = to_chr1(row_list$dataset_type),
      item = item_val,
      ext_mean = ext_mean, ext_sd = ext_sd,
      ext_skew = ext_skew, ext_kurt = ext_kurt,
      bin_lo = lo, bin_hi = hi,
      min_dnorm_seed = min(stats::dnorm(bins, ext_mean, ext_sd)),
      seed_has_exact_zero = any(stats::dnorm(bins, ext_mean, ext_sd) == 0)
    )
    return(empty_distribution_full_row())
  }

  if (identical(attr(fitted, "fit_attempt"), "exact_point_mass")) {
    ISSP_FULLFIT_DIAG$n_exact_point_mass <- ISSP_FULLFIT_DIAG$n_exact_point_mass + 1L
  }
  if (identical(attr(fitted, "fit_attempt"), "exact_feasible_repair"))
    ISSP_FULLFIT_DIAG$n_exact_feasible_repair <- ISSP_FULLFIT_DIAG$n_exact_feasible_repair + 1L
  if (identical(attr(fitted, "fit_attempt"), "uniform_start")) {
    ISSP_FULLFIT_DIAG$res[[length(ISSP_FULLFIT_DIAG$res) + 1L]] <- tibble(
      model_family = to_chr1(row_list$model_family),
      model = to_chr1(row_list$model),
      scope = to_chr1(row_list$scope),
      country_folder = to_chr1(row_list$country_folder),
      dataset_type = to_chr1(row_list$dataset_type),
      item = item_val,
      ext_mean = ext_mean, ext_sd = ext_sd, bin_lo = lo, bin_hi = hi
    )
  }

  fitted %>%
    mutate(
      model_family = to_chr1(row_list$model_family),
      model = to_chr1(row_list$model),
      scope = to_chr1(row_list$scope),
      country_folder = to_chr1(row_list$country_folder),
      dataset_type = to_chr1(row_list$dataset_type),
      method = "distribution_full",
      item = item_val,
      scenario = to_chr1(row_list$scenario),
      scale = to_chr1(row_list$scale)
    ) %>%
    select(
      model_family, model, scope, country_folder, dataset_type, method,
      item, scenario, scale, bin, model_prop
    )
}

# Load human data and mappings

cat("\n", strrep("-", 80), "\n")
cat("Loading human data and mappings\n")
cat(strrep("-", 80), "\n")

issp_human <- read_sav(issp_human_path)

country_var <- intersect(c("c_alphan", "country", "C_ALPHAN"), names(issp_human))[1]
if (is.na(country_var)) stop("Could not identify country variable.")

issp_item_vars <- names(issp_human)[str_detect(names(issp_human), "^v\\d+$")]

iso_to_name <- c(
  AU = "Australia", AT = "Austria", BG = "Bulgaria", HR = "Croatia",
  CZ = "Czech Republic", DK = "Denmark", FI = "Finland", FR = "France",
  DE = "Germany", GR = "Greece", HU = "Hungary", IS = "Iceland",
  IN = "India", IL = "Israel", IT = "Italy", JP = "Japan",
  LT = "Lithuania", NL = "Netherlands", NZ = "New Zealand", NO = "Norway",
  PH = "Philippines", PL = "Poland", RU = "Russia", SK = "Slovakia",
  SI = "Slovenia", ZA = "South Africa", ES = "Spain", SE = "Sweden",
  CH = "Switzerland", TW = "Taiwan", TH = "Thailand", US = "United States"
)

issp_human <- issp_human %>%
  mutate(
    across(all_of(issp_item_vars), ~ suppressWarnings(as.numeric(as.character(.x)))),
    country_code = as.character(as_factor(.data[[country_var]])),
    country_folder = iso_to_name[country_code],
    
    # Nonnumeric response categories: exclude from numerical analyses.
    v26 = na_if(v26, 960),  # Yes, but duration not specified
    v19 = na_if(v19, 95),   # As many as possible
    v54 = na_if(v54, 0)     # Cannot rely on either relatives or friends
  )

mapping_df <- read_excel(mapping_xlsx_path)
names(mapping_df) <- names(mapping_df) %>% str_trim() %>% str_replace_all("\\s+", "_") %>% tolower()

mapping_df <- mapping_df %>%
  mutate(
    id = str_trim(as.character(id)),
    scenario = as.character(scenario),
    scale = as.character(scale),
    scale_max_from_mapping = sapply(scale, extract_numeric_range_from_scale)
  )

excluded_nominal_items <- c("v30", "v31", "v32", "v33")

mapping_df <- mapping_df %>%
  filter(!id %in% excluded_nominal_items)

non_discrete_mapping_df <- read_excel(non_discrete_xlsx_path)
names(non_discrete_mapping_df) <- names(non_discrete_mapping_df) %>% str_trim() %>% str_replace_all("\\s+", "_") %>% tolower()

non_discrete_mapping_df <- non_discrete_mapping_df %>%
  mutate(
    id = str_trim(as.character(id)),
    scenario = as.character(scenario),
    scale = as.character(scale),
    scale_max_from_mapping = sapply(scale, extract_numeric_range_from_scale)
  )

main_ids <- mapping_df %>%
  transmute(item = id, scenario, scale, dataset_type = "discrete")

non_discrete_ids_df <- non_discrete_mapping_df %>%
  transmute(item = id, scenario, scale, dataset_type = "non_discrete")

item_meta <- bind_rows(main_ids, non_discrete_ids_df) %>%
  arrange(as.integer(str_remove(item, "^v"))) %>%
  distinct(item, .keep_all = TRUE) %>%
  mutate(dataset_type = issp_dataset_type(item))

expected_item_ids <- item_meta$item
non_discrete_ids <- non_discrete_ids_df$item

expected_n_collected_discrete <- 36L
expected_n_discrete <- 36L
expected_n_non_discrete <- 2L
expected_n_total <- expected_n_collected_discrete + expected_n_non_discrete
numeric_discrete_ids <- main_ids$item
stopifnot(length(main_ids$item) == expected_n_collected_discrete,
          all(ISSP_ARRANGEMENT_ITEMS %in% numeric_discrete_ids),
          !anyDuplicated(item_meta$item),
          setequal(non_discrete_ids, c("v19", "v26")))
write_csv(item_meta %>% mutate(measurement_unit = issp_measurement_unit(item),
  numeric_scale_eligible = TRUE,
  analysis = if_else(item %in% non_discrete_ids, "separate original-unit analysis by item", "primary numeric fixed-category analysis"),
  selected_arrangement_role = issp_arrangement_role(item),
  reverse_scored = FALSE,
  scale_assumption = if_else(item %in% ISSP_ARRANGEMENT_ITEMS,
    "Original codes 1-6 treated as approximately continuous; order and equal spacing are imperfect proxies; options 3/4 both equal parental employment but differ in total employment", NA_character_),
  code_direction = if_else(item %in% ISSP_ARRANGEMENT_ITEMS,
    "Higher codes: greater paternal childcare specialization in selected arrangement; preference direction differs for most versus least desirable", NA_character_),
  supplementary_analysis = if_else(item %in% ISSP_ARRANGEMENT_ITEMS,
    "Order-invariant TVD/JSD for direct distributions; persona exact-category accuracy", NA_character_)),
  file.path(out_dir, "CHECK_measurement_item_partition.csv"))

actual_n_discrete <- sum(item_meta$dataset_type == "discrete")
actual_n_non_discrete <- sum(item_meta$dataset_type == "non_discrete")
actual_n_total <- length(expected_item_ids)

cat("\nIncluded item count check:\n")
cat("Discrete items:", actual_n_discrete, "\n")
cat("Non-discrete items:", actual_n_non_discrete, "\n")
cat("Total items:", actual_n_total, "\n")

if (actual_n_discrete != expected_n_discrete) {
  stop("Expected ", expected_n_discrete, " discrete ISSP items but found ", actual_n_discrete, ".")
}

if (actual_n_non_discrete != expected_n_non_discrete) {
  stop("Expected ", expected_n_non_discrete, " non-discrete ISSP items but found ", actual_n_non_discrete, ".")
}

if (actual_n_total != expected_n_total) {
  stop("Expected ", expected_n_total, " total ISSP items but found ", actual_n_total, ".")
}

if (any(excluded_nominal_items %in% item_meta$item)) {
  stop("v30-v33 are still included in item_meta. Check mapping/exclusion code.")
}

cat("\nExcluded nominal items still present?\n")
item_meta %>%
  filter(item %in% excluded_nominal_items) %>%
  print(n = Inf, width = Inf)

item_scale_map <- bind_rows(mapping_df, non_discrete_mapping_df) %>%
  distinct(id, .keep_all = TRUE) %>%
  build_item_scale_map()

# Long human-response table: one row per respondent-item observation.
issp_human_long_raw <- issp_human %>%
  filter(!is.na(country_folder)) %>%
  select(country_folder, all_of(issp_item_vars)) %>%
  pivot_longer(cols = all_of(issp_item_vars), names_to = "item", values_to = "human_response") %>%
  filter(item %in% expected_item_ids)

v9_v10_human_above3_exclusion_report <- issp_human_long_raw %>%
  filter(item %in% c("v9", "v10"), !is.na(human_response), human_response > 3) %>%
  count(item, country_folder, human_response, name = "n_excluded") %>%
  arrange(item, country_folder, human_response)

cat("\nHuman responses excluded as out-of-scale for v9/v10 (> 3):\n")
print(v9_v10_human_above3_exclusion_report, n = Inf, width = Inf)

# Why only v9/v10: Taiwan also offers code 4, "Women should decide".
# This is a valid category but does not map onto the shared ordered 1-3
# scale. Retain the shared options and omit the extra category.
issp_human_long <- issp_human_long_raw %>%
  mutate(
    human_response = if_else(
      item %in% c("v9", "v10") & !is.na(human_response) & human_response > 3,
      NA_real_,
      as.numeric(human_response)
    )
  ) %>%
  filter(!is.na(human_response)) %>%
  mutate(bin = as.integer(round(human_response)))

issp_human_stats_country <- issp_human_long %>%
  group_by(scope = "country", country_folder, item) %>%
  summarise(
    human_mean = mean(human_response, na.rm = TRUE),
    human_sd = sd(human_response, na.rm = TRUE),
    human_n = n(),
    .groups = "drop"
  )

issp_human_stats_global <- issp_human_long %>%
  group_by(item) %>%
  summarise(
    human_mean = mean(human_response, na.rm = TRUE),
    human_sd = sd(human_response, na.rm = TRUE),
    human_n = n(),
    .groups = "drop"
  ) %>%
  mutate(scope = "global", country_folder = "Global") %>%
  select(scope, country_folder, item, human_mean, human_sd, human_n)

issp_human_stats_all <- bind_rows(issp_human_stats_country, issp_human_stats_global) %>%
  left_join(item_meta %>% select(item, dataset_type), by = "item")

issp_human_props_country <- issp_human_long %>%
  count(scope = "country", country_folder, item, bin, name = "human_n_bin") %>%
  group_by(scope, country_folder, item) %>%
  mutate(human_n_total = sum(human_n_bin), human_prop = human_n_bin / human_n_total) %>%
  ungroup()

issp_human_props_global <- issp_human_long %>%
  count(item, bin, name = "human_n_bin") %>%
  group_by(item) %>%
  mutate(human_n_total = sum(human_n_bin), human_prop = human_n_bin / human_n_total) %>%
  ungroup() %>%
  mutate(scope = "global", country_folder = "Global") %>%
  select(scope, country_folder, item, bin, human_n_bin, human_n_total, human_prop)

issp_human_props_all <- bind_rows(issp_human_props_country, issp_human_props_global) %>%
  left_join(item_meta %>% select(item, dataset_type), by = "item")

item_ranges_from_mapping <- item_scale_map %>%
  group_by(item) %>%
  summarise(
    scale_min_mapping = min(bin, na.rm = TRUE),
    scale_max_mapping = max(bin, na.rm = TRUE),
    .groups = "drop"
  )

item_ranges_from_human <- issp_human_long %>%
  group_by(item) %>%
  summarise(
    scale_min_human = min(human_response, na.rm = TRUE),
    scale_max_human = max(human_response, na.rm = TRUE),
    .groups = "drop"
  )

survey_range_overrides <- tibble(
  item = c("v54", "v55"),
  scale_min_documented = c(1, 1),
  scale_max_documented = c(7, 7)
)
item_ranges <- item_meta %>%
  select(item, dataset_type) %>%
  left_join(item_ranges_from_mapping, by = "item") %>%
  left_join(item_ranges_from_human, by = "item") %>%
  left_join(survey_range_overrides, by = "item") %>%
  mutate(
    mapped_range_valid = is.finite(scale_min_mapping) & is.finite(scale_max_mapping) &
      scale_max_mapping > scale_min_mapping,
    documented_range = is.finite(scale_min_documented) & is.finite(scale_max_documented),
    use_observed_range = dataset_type == "non_discrete" & !mapped_range_valid,
    scale_min = case_when(
      documented_range ~ scale_min_documented,
      mapped_range_valid ~ as.numeric(scale_min_mapping),
      use_observed_range ~ as.numeric(scale_min_human),
      TRUE ~ NA_real_
    ),
    scale_max = case_when(
      documented_range ~ scale_max_documented,
      mapped_range_valid ~ as.numeric(scale_max_mapping),
      use_observed_range ~ as.numeric(scale_max_human),
      TRUE ~ NA_real_
    ),
    range_source = case_when(
      documented_range ~ "survey_documented",
      mapped_range_valid ~ "mapping",
      use_observed_range ~ "cleaned_human_observed_non_discrete",
      TRUE ~ "missing_discrete_mapping"
    )
  ) %>%
  select(item, scale_min, scale_max, range_source)

write_csv(item_ranges, file.path(out_dir, "CHECK_item_ranges.csv"))
missing_discrete_ranges <- item_ranges %>% filter(range_source == "missing_discrete_mapping")
if (nrow(missing_discrete_ranges) > 0L) {
  stop("Missing/invalid discrete scale mapping for: ",
       paste(missing_discrete_ranges$item, collapse = ", "),
       ". Supply documented bounds; observed ranges are not a discrete-scale fallback.")
}

bad_item_ranges <- item_ranges %>%
  filter(
    is.na(scale_min) |
      is.na(scale_max) |
      !is.finite(scale_min) |
      !is.finite(scale_max) |
      scale_max <= scale_min
  )

if (nrow(bad_item_ranges) > 0) {
  cat("\nBad item ranges:\n")
  print(bad_item_ranges, n = Inf, width = Inf)
  stop("At least one ISSP item has an unusable response scale range.")
}

cat("Expected item IDs:", length(expected_item_ids), "\n")
cat("Discrete IDs:", sum(item_meta$dataset_type == "discrete"), "\n")
cat("Non-discrete IDs:", sum(item_meta$dataset_type == "non_discrete"), "\n")
cat("Human rows:", nrow(issp_human_long), "\n")

cat("
Item scale range sources:
")
item_ranges %>%
  count(range_source, name = "n_items") %>%
  print(n = Inf)

# Save item inclusion/exclusion diagnostics.
write_csv(
  item_meta,
  file.path(out_dir, "CHECK_included_item_meta_after_excluding_v30_v33.csv")
)

write_csv(
  v9_v10_human_above3_exclusion_report,
  file.path(out_dir, "CHECK_v9_v10_human_responses_above3_excluded.csv")
)

range_diagnostic_after_cleaning <- item_ranges %>%
  left_join(
    issp_human_long %>%
      group_by(item) %>%
      summarise(
        human_min_seen = min(human_response, na.rm = TRUE),
        human_max_seen = max(human_response, na.rm = TRUE),
        .groups = "drop"
      ),
    by = "item"
  ) %>%
  left_join(item_meta %>% select(item, dataset_type, scenario, scale), by = "item") %>%
  mutate(
    range_flag = case_when(
      is.na(scale_min) | is.na(scale_max) ~ "missing_range",
      human_min_seen < scale_min ~ "human_values_below_mapped_scale",
      human_max_seen > scale_max ~ "human_values_above_mapped_scale",
      TRUE ~ "ok"
    )
  ) %>%
  arrange(range_flag, item)

cat("\nRange diagnostic after response-code cleaning and nominal-item exclusion:\n")
print(range_diagnostic_after_cleaning, n = Inf, width = Inf)

write_csv(
  range_diagnostic_after_cleaning,
  file.path(out_dir, "CHECK_range_diagnostic_after_v9_v10_cleaning.csv")
)


# Discrete bounds must detect, rather than absorb, unhandled response codes.
bad_discrete_human_ranges <- range_diagnostic_after_cleaning %>%
  filter(dataset_type == "discrete", range_flag != "ok")
if (nrow(bad_discrete_human_ranges) > 0L) {
  stop("Cleaned human values remain outside the documented discrete scale for: ",
       paste(bad_discrete_human_ranges$item, collapse = ", "),
       ". Inspect CHECK_range_diagnostic_after_v9_v10_cleaning.csv.")
}

# Condition files
#
# These files contain cleaned repeated sampling outputs and the mean/confidence
# prompt outputs for GPT and Llama. 

cat("\n", strrep("-", 80), "\n")
cat("Loading condition files\n")
cat(strrep("-", 80), "\n")

condition1_raw <- read_csv(condition1_repeated_raw_path, show_col_types = FALSE) %>%
  mutate(source_csv_record = row_number())
condition2_raw <- read_csv(condition2_mean_confidence_path, show_col_types = FALSE)

cat("\nCondition1 coverage:\n")
condition1_raw %>%
  count(model_family, model, scope, dataset_type, name = "rows") %>%
  arrange(model_family, model, scope, dataset_type) %>%
  print(n = Inf, width = Inf)

cat("\nCondition2 coverage:\n")
condition2_raw %>%
  count(model_family, model, scope, dataset_type, name = "rows") %>%
  arrange(model_family, model, scope, dataset_type) %>%
  print(n = Inf, width = Inf)

# Standardize mean/confidence rows and attach the discrete/non-discrete flag.
condition2_model <- condition2_raw %>%
  filter(model_family %in% model_families_to_keep, item %in% expected_item_ids) %>%
  mutate(
    country_folder = if_else(scope == "global", "Global", country_folder),
    dataset_type = issp_dataset_type(item),
    pred_mean = as.numeric(pred_mean),
    confidence = as.numeric(confidence),
    human_mean = as.numeric(human_mean),
    human_sd = as.numeric(human_sd)
  )

# Repeated sampling distributions

cat("\n", strrep("-", 80), "\n")
cat("Building repeated-sampling distributions\n")
cat(strrep("-", 80), "\n")

condition1_raw_checked <- parse_count_response_detail(condition1_raw$response_raw)
condition1_raw$model_response_num_reparsed <- condition1_raw_checked$value
condition1_raw$raw_parse_status <- condition1_raw_checked$status

condition1_model <- condition1_raw %>%
  filter(model_family %in% model_families_to_keep) %>%
  mutate(
    model_response_num_original = suppressWarnings(as.numeric(model_response_num)),
    model_response_num = if_else(raw_parse_status == "missing_raw",
      model_response_num_original, model_response_num_reparsed),
    imported_disagrees = is.finite(model_response_num_original) &
      (is.na(model_response_num_reparsed) | model_response_num_original != model_response_num_reparsed),
    bin = as.integer(round(model_response_num)),
    country_folder = if_else(scope == "global", "Global", country_folder),
    dataset_type = issp_dataset_type(item)
  ) %>%
  filter(item %in% expected_item_ids) %>%
  left_join(item_meta %>% select(item, scenario, scale), by = "item")

# CSV record index is preserved; embedded newlines make it differ from physical line number.
write_csv(condition1_model %>% filter(imported_disagrees | raw_parse_status != "numeric_raw") %>%
  select(any_of(c("source_csv_record", "custom_id", "model_family", "model", "scope",
    "country_folder", "item", "rep", "repetition", "response_raw", "model_response_num_original",
    "model_response_num_reparsed", "model_response_num", "raw_parse_status", "imported_disagrees"))),
  file.path(out_dir, "CHECK_repeated_raw_validation_issp.csv"))
write_csv(condition1_model %>% count(model_family, raw_parse_status, imported_disagrees, name = "n_records"),
  file.path(out_dir, "CHECK_repeated_raw_validation_summary_issp.csv"))

# Diagnostic table showing how many repeated sampling completions were usable
# before and after reparsing free-text responses.
repeated_parse_report <- condition1_model %>%
  group_by(model_family, model) %>%
  summarise(
    n_rows = n(),
    n_original_numeric = sum(!is.na(model_response_num_original)),
    n_reparsed_numeric = sum(!is.na(model_response_num_reparsed)),
    n_final_numeric = sum(!is.na(model_response_num)),
    n_still_missing = sum(is.na(model_response_num)),
    gained_from_reparse = n_final_numeric - n_original_numeric,
    .groups = "drop"
  )

print(repeated_parse_report, n = Inf, width = Inf)

repeated_model_props <- condition1_model %>%
  filter(!is.na(bin)) %>%
  count(
    model_family, model, scope, country_folder,
    dataset_type, item, scenario, scale, bin,
    name = "model_n_bin"
  ) %>%
  group_by(model_family, model, scope, country_folder, dataset_type, item, scenario, scale) %>%
  mutate(model_prop = model_n_bin / sum(model_n_bin), method = "repeated_sampling") %>%
  ungroup() %>%
  select(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale, bin, model_prop)


# GPT distribution outputs
cat("\n", strrep("-", 80), "\n")
cat("Loading GPT distribution outputs\n")
cat(strrep("-", 80), "\n")

issp_countries <- list.dirs(issp_base, full.names = FALSE, recursive = FALSE)
issp_countries <- issp_countries[nzchar(issp_countries)]

country_clean_files <- list.files(
  issp_base, pattern = "_clean.*\\.jsonl$", full.names = TRUE, recursive = TRUE
)
cat("  country-scope '_clean' files found:", length(country_clean_files), "\n")
if (length(country_clean_files) > 0) {
  stop(
    "Country result folders contain _clean duplicate JSONL files: ",
    paste(basename(country_clean_files), collapse = "; ")
  )
}

issp_model_list <- list()

for (cn in issp_countries) {
  result <- read_issp_country_dir(cn, issp_base, model_family = "gpt")

  if (!is.null(result) && nrow(result) > 0) {
    issp_model_list[[length(issp_model_list) + 1]] <- result
  }
}

global_files <- list.files(issp_global_base, pattern = "\\.jsonl$", full.names = TRUE)
n_global_all <- length(global_files)

global_files <- global_files[!str_detect(basename(global_files), "merged")]
n_after_merged <- length(global_files)

global_clean_dropped <- basename(global_files)[str_detect(basename(global_files), "_clean")]
global_files <- global_files[!str_detect(basename(global_files), "_clean")]

cat("\n-- Global file selection --\n")
cat("  .jsonl files found:", n_global_all, "\n")
cat("  after excluding 'merged':", n_after_merged, "\n")
cat("  excluded as '_clean' duplicates:", length(global_clean_dropped),
    if (length(global_clean_dropped)) paste0("(", paste(global_clean_dropped, collapse = ", "), ")") else "", "\n")
cat("  loaded:", length(global_files), "\n")

# Input provenance manifest
issp_input_files <- unique(unlist(lapply(unname(required_paths), function(p) {
  if (dir.exists(p)) {
    list.files(p, recursive = TRUE, full.names = TRUE)
  } else {
    p
  }
}), use.names = FALSE))
issp_input_files <- issp_input_files[file.exists(issp_input_files) &
                                     !dir.exists(issp_input_files)]
issp_input_files <- normalizePath(issp_input_files, mustWork = TRUE)
issp_data_dir_norm <- normalizePath(issp_data_dir, mustWork = TRUE)
issp_input_manifest <- tibble(
  path = issp_input_files,
  rel_path = if_else(
    startsWith(path, paste0(issp_data_dir_norm, .Platform$file.sep)),
    substring(path, nchar(issp_data_dir_norm) + 2L),
    basename(path)
  ),
  input_type = if_else(
    nzchar(tools::file_ext(path)),
    tolower(tools::file_ext(path)),
    "no_extension"
  ),
  bytes = file.size(issp_input_files),
  md5 = unname(tools::md5sum(issp_input_files)),
  reference_md5 = NA_character_,
  comparison_status = "not_compared"
) %>% arrange(rel_path)

write_csv(issp_input_manifest, file.path(out_dir, "CHECK_input_md5_manifest.csv"))
cat("\nInput md5 manifest:", nrow(issp_input_manifest), "files ->",
    "CHECK_input_md5_manifest.csv\n")
cat("  distinct md5 digests:", n_distinct(issp_input_manifest$md5),
    "| any unreadable:", sum(is.na(issp_input_manifest$md5)), "\n")

issp_audit_record(
  "Input provenance", "compute md5 digests for all ISSP inputs at run time",
  rows_in = nrow(issp_input_manifest), rows_out = nrow(issp_input_manifest),
  unmatched_keys = sum(is.na(issp_input_manifest$md5)),
  reason = "record current input hashes and make the absence of an in-script reference comparison explicit",
  detail = paste0(
    nrow(issp_input_manifest), " input files digested in-script (tools::md5sum); ",
    "manifest at CHECK_input_md5_manifest.csv; comparison_status is not_compared ",
    "because no reference hash manifest is supplied to this script."
  )
)

issp_audit_record(
  "Part B country glob", "check country folders for _clean duplicates",
  rows_in = length(country_clean_files), rows_out = 0L,
  reason = "country-level results are unaffected only if no _clean duplicates exist",
  detail = paste0(length(country_clean_files), " found across ",
                  length(list.dirs(issp_base, recursive = FALSE)), " country folders")
)

global_result <- bind_rows(lapply(
  global_files,
  read_issp_jsonl_file,
  country_name = "Global",
  model_family = "gpt"
))

if (!is.null(global_result) && nrow(global_result) > 0) {
  issp_model_list[[length(issp_model_list) + 1]] <- global_result
}

issp_model_all_gpt <- bind_rows(issp_model_list) %>%
  mutate(
    model_family = "gpt",
    model = if_else(is.na(model) | model == "", "gpt_unspecified", model),
    dataset_type = issp_dataset_type(item)
  ) %>%
  left_join(item_meta %>% select(item, scenario, scale), by = "item") %>%
  filter(item %in% expected_item_ids)

cat("GPT distribution rows:", nrow(issp_model_all_gpt), "\n")
print(issp_model_all_gpt %>% count(model, method_raw, sort = TRUE), n = Inf)

distribution_methods <- c("distribution_distribution", "global_simple",
                          "global_counts", "global_output_distribution")

# Exact labels use item_scale_map; aliases are restricted to verified scales.
likert_fallback <- build_likert_fallback(item_scale_map)

issp_proportions_raw_gpt <- issp_model_all_gpt %>%
  filter(method_raw %in% distribution_methods) %>%
  mutate(parsed = lapply(raw_content, parse_proportion)) %>%
  filter(!sapply(parsed, is.null)) %>%
  unnest(parsed)

issp_proportions_mapped_gpt <- issp_proportions_raw_gpt %>%
  mutate(
    category_raw = as.character(category),
    category_norm = normalize_label(category_raw)
  ) %>%
  left_join(
    item_scale_map %>% select(item, norm_label, item_bin = bin),
    by = c("item", "category_norm" = "norm_label")
  ) %>%
  left_join(likert_fallback, by = c("item", "category_norm" = "norm_label")) %>%
  mutate(
    bin = case_when(
      !is.na(item_bin) ~ as.integer(item_bin),
      item %in% c("v9", "v10") &
        category_norm %in% c("work part-time", "work part time") ~ 2L,
      !is.na(fallback_bin) ~ as.integer(fallback_bin),
      str_detect(category_raw, "^\\d+$") ~ as.integer(category_raw),
      str_detect(category_raw, "^\\d+\\s*[:\\.-]") ~ as.integer(str_extract(category_raw, "^\\d+")),
      TRUE ~ NA_integer_
    )
  )

# Validate raw discrete probabilities before any dropping or normalization.
issp_unmapped_probability_rows <- issp_proportions_mapped_gpt %>%
  filter(dataset_type == "discrete", is.na(bin))
write_csv(issp_unmapped_probability_rows,
          file.path(out_dir, "CHECK_unmapped_proportion_rows_issp.csv"))
issp_invalid_probability_rows <- issp_proportions_mapped_gpt %>%
  filter(dataset_type == "discrete",
         !is.finite(prob) | prob < 0 | (is.na(bin) & prob > 0))
write_csv(issp_invalid_probability_rows,
          file.path(out_dir, "CHECK_invalid_raw_proportions_issp.csv"))
if (nrow(issp_invalid_probability_rows)) {
  stop("Invalid or unmapped positive ISSP probability mass; inspect ",
       "CHECK_invalid_raw_proportions_issp.csv before normalizing.")
}

# Inspect this object if direct proportion outputs fail to map to numeric bins.
unmapped_categories_gpt <- issp_proportions_mapped_gpt %>%
  filter(is.na(bin)) %>%
  distinct(item, category_raw) %>%
  arrange(item, category_raw)

# Diagnostic: fallback mappings on verified five-point agreement scales.
fallback_categories_gpt <- issp_proportions_mapped_gpt %>%
  filter(is.na(item_bin), !is.na(fallback_bin)) %>%
  count(scope, country_folder, item, category_raw, fallback_bin, name = "n_rows") %>%
  arrange(desc(n_rows), item, category_raw)

cat("\nGPT direct-proportion unmapped categories:\n")
print(unmapped_categories_gpt, n = Inf, width = Inf)

cat("\nGPT direct-proportion fallback category hits:\n")
print(fallback_categories_gpt, n = Inf, width = Inf)


prop_model_props_gpt_discrete <- issp_proportions_mapped_gpt %>%
  filter(!is.na(bin), !is.na(prob)) %>%
  mutate(
    method = case_when(
      method_raw == "distribution_distribution" ~ "proportions",
      method_raw == "global_simple" ~ "proportions_global_simple",
      method_raw == "global_counts" ~ "proportions_global_counts",
      TRUE ~ paste0("proportions_", method_raw)
    ),
    bin = as.integer(bin)
  )

# Include every framing variant in this check before any aggregation.
issp_assert_unique_proportion_cells(
  prop_model_props_gpt_discrete,
  file.path(out_dir, "CHECK_duplicate_source_proportions_gpt_issp.csv")
)

prop_model_props_gpt_discrete <- prop_model_props_gpt_discrete %>%
  filter(method == "proportions")

prop_cell_duplicates_gpt <- prop_model_props_gpt_discrete %>%
  count(model_family, model, scope, country_folder, dataset_type, method,
        item, scenario, scale, bin, name = "n_records") %>%
  filter(n_records > 1)

if (nrow(prop_cell_duplicates_gpt) > 0) {
  readr::write_csv(
    prop_cell_duplicates_gpt,
    file.path(out_dir, "CHECK_duplicate_proportions_cells_issp.csv")
  )
  stop(
    "Duplicate ISSP Proportions records found in ",
    nrow(prop_cell_duplicates_gpt),
    " cells; see CHECK_duplicate_proportions_cells_issp.csv."
  )
} else {
  cat("\n  Proportions cell check: one record per model x scope x country x item x bin.\n")
}

issp_audit_record(
  "Part B proportions", "assert one record per cell before summarise",
  rows_in = nrow(prop_model_props_gpt_discrete),
  rows_out = nrow(prop_model_props_gpt_discrete),
  unmatched_keys = nrow(prop_cell_duplicates_gpt),
  reason = "duplicate records in a cell are summed then renormalized, silently blending prompt variants",
  detail = paste0(nrow(prop_cell_duplicates_gpt), " duplicated cells")
)

prop_model_props_gpt_discrete <- prop_model_props_gpt_discrete %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale, bin) %>%
  summarise(model_prop = sum(prob, na.rm = TRUE), .groups = "drop") %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale) %>%
  mutate(model_prop = model_prop / sum(model_prop, na.rm = TRUE)) %>%
  ungroup()


issp_means_gpt <- issp_model_all_gpt %>%
  filter(method_raw == "mean_alone") %>%
  mutate(pred_mean = sapply(raw_content, parse_mean_alone)) %>%
  select(model_family, model, scope, country_folder, dataset_type, item, scenario, scale, pred_mean)

issp_sds_gpt <- issp_model_all_gpt %>%
  filter(method_raw == "std_alone") %>%
  mutate(pred_sd = sapply(raw_content, parse_sd_alone)) %>%
  select(model_family, model, scope, country_folder, dataset_type, item, scenario, scale, pred_sd)

issp_extended_gpt <- issp_model_all_gpt %>%
  filter(method_raw == "std_extended") %>%
  mutate(
    parsed = map(raw_content, parse_extended),
    ext_mean = map_dbl(parsed, ~ to_num1(.x$mean)),
    ext_sd   = map_dbl(parsed, ~ to_num1(.x$sd)),
    ext_skew = map_dbl(parsed, ~ to_num1(.x$skew)),
    ext_kurt = map_dbl(parsed, ~ to_num1(.x$kurt))
  ) %>%
  select(
    model_family, model, scope, country_folder,
    dataset_type, item, scenario, scale,
    ext_mean, ext_sd, ext_skew, ext_kurt
  )

# GPT non-discrete methods

cat("\n", strrep("-", 80), "\n")
cat("Adding GPT non-discrete methods\n")
cat(strrep("-", 80), "\n")

# Remove JSON code fences from non-discrete GPT outputs before parsing.
clean_json_nd <- function(s) {
  if (is.na(s)) return(NA_character_)
  s %>% str_replace_all("```json|```", "") %>% str_trim()
}

pluck_num_nd <- function(x, nm) {
  if (is.null(x) || !is.list(x)) return(NA_real_)
  suppressWarnings(as.numeric(x[[nm]]))
}

simulate_from_bins_nd <- function(bins, n = n_sim_issp) {
  if (is.null(bins) || nrow(bins) == 0 || all(is.na(bins$prob))) return(rep(NA_real_, n))

  probs <- suppressWarnings(as.numeric(bins$prob))
  probs[is.na(probs)] <- 0

  if (any(probs < 0) || any(!is.finite(probs)) || sum(probs) <= 0) {
    return(rep(NA_real_, n))
  }
  probs <- probs / sum(probs)

  idx <- sample(seq_len(nrow(bins)), size = n, replace = TRUE, prob = probs)
  runif(n, min = bins$lower[idx], max = bins$upper[idx])
}

# Convert simulated non-discrete draws into the common binned distribution
# schema used by all distribution distance analyses.
draws_to_model_props_nd <- function(draws_df, method_name) {
  draws_df %>%
    filter(item %in% non_discrete_ids, !is.na(response_value)) %>%
    mutate(
      bin = as.integer(round(response_value)),
      scope = "global",
      country_folder = "Global",
      dataset_type = "non_discrete",
      method = method_name
    ) %>%
    left_join(item_meta %>% select(item, scenario, scale), by = "item") %>%
    count(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale, bin, name = "model_n_bin") %>%
    group_by(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale) %>%
    mutate(model_prop = model_n_bin / sum(model_n_bin, na.rm = TRUE)) %>%
    ungroup() %>%
    select(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale, bin, model_prop)
}

non_discrete_gpt_base <- read_generic_jsonl_outputs(
  non_discrete_gpt_jsonl_path,
  model_family = "gpt",
  scope = "global",
  country_folder = "Global"
) %>%
  mutate(
    item = str_extract(custom_id, "^v[0-9]+"),
    method_raw_nd = str_match(custom_id, "^v[0-9]+-(.*)-[^-]+$")[, 2],
    context_raw = str_match(custom_id, "^v[0-9]+-.*-([^-]+)$")[, 2],
    dilemma = as.integer(str_remove(item, "^v"))
  ) %>%
  filter(item %in% non_discrete_ids)

cat("Non-discrete GPT rows:", nrow(non_discrete_gpt_base), "\n")
print(non_discrete_gpt_base %>% count(model, method_raw_nd), n = Inf)


non_discrete_prop_parsed_gpt <- non_discrete_gpt_base %>%
  filter(method_raw_nd %in% c("proportion_1", "proportion_2")) %>%
  mutate(
    json_str = map_chr(raw_content, clean_json_nd),
    parsed = map(json_str, ~ tryCatch(fromJSON(.x), error = function(e) NULL))
  ) %>%
  filter(!map_lgl(parsed, is.null)) %>%
  mutate(
    bins = map(parsed, function(x) {
      m <- as.data.frame(x)

      if (ncol(m) < 3) {
        return(tibble(lower = NA_real_, upper = NA_real_, prob = NA_real_))
      }

      names(m)[1:3] <- c("lower", "upper", "prob")

      as_tibble(m[, 1:3]) %>%
        mutate(
          lower = suppressWarnings(as.numeric(lower)),
          upper = suppressWarnings(as.numeric(upper)),
          prob = suppressWarnings(as.numeric(prob))
        )
    })
  )

non_discrete_prop_draws_gpt <- non_discrete_prop_parsed_gpt %>%
  mutate(simulated = map(bins, ~ tibble(response_value = simulate_from_bins_nd(.x, n_sim_issp)))) %>%
  select(model_family, model, item, dilemma, method_raw_nd, simulated) %>%
  unnest(simulated)

non_discrete_prop_model_props_gpt <- draws_to_model_props_nd(non_discrete_prop_draws_gpt, "proportions")

.finite_or_na <- function(v) if (length(v) == 1 && is.finite(v)) v else NA_real_

non_discrete_support_gpt <- non_discrete_prop_parsed_gpt %>%
  mutate(
    scale_min_tmp = map_dbl(bins, ~ .finite_or_na(suppressWarnings(min(.x$lower, na.rm = TRUE)))),
    scale_max_tmp = map_dbl(bins, ~ .finite_or_na(suppressWarnings(max(.x$upper, na.rm = TRUE))))
  ) %>%
  group_by(model_family, model, item, dilemma) %>%
  summarise(
    scale_min = .finite_or_na(suppressWarnings(min(scale_min_tmp, na.rm = TRUE))),
    scale_max = .finite_or_na(suppressWarnings(max(scale_max_tmp, na.rm = TRUE))),
    .groups = "drop"
  )


non_discrete_std_ext_gpt <- non_discrete_gpt_base %>%
  filter(method_raw_nd == "std_extended_units") %>%
  mutate(
    json_str = map_chr(raw_content, clean_json_nd),
    parsed = map(json_str, ~ tryCatch(fromJSON(.x), error = function(e) NULL))
  ) %>%
  transmute(
    model_family, model, item, dilemma,
    mean_ext = map_dbl(parsed, ~ pluck_num_nd(.x, "Answer to Q1")),
    confidence_ext = map_dbl(parsed, ~ pluck_num_nd(.x, "Answer to Q2")),
    sd_ext = map_dbl(parsed, ~ pluck_num_nd(.x, "Answer to Q3")),
    kurtosis_ext = map_dbl(parsed, ~ pluck_num_nd(.x, "Answer to Q4")),
    skewness_ext = map_dbl(parsed, ~ pluck_num_nd(.x, "Answer to Q5"))
  )

non_discrete_mean_units_gpt <- non_discrete_gpt_base %>%
  filter(method_raw_nd == "mean_units") %>%
  transmute(model_family, model, item, dilemma, mean_single = suppressWarnings(as.numeric(raw_content)))

non_discrete_sd_units_gpt <- non_discrete_gpt_base %>%
  filter(method_raw_nd == "sd_units") %>%
  transmute(model_family, model, item, dilemma, sd_single = suppressWarnings(as.numeric(raw_content)))

# Combine non-discrete mean/SD/moment sources
non_discrete_params_gpt <- non_discrete_std_ext_gpt %>%
  left_join(non_discrete_mean_units_gpt, by = c("model_family", "model", "item", "dilemma")) %>%
  left_join(non_discrete_sd_units_gpt, by = c("model_family", "model", "item", "dilemma")) %>%
  mutate(
    mean = coalesce(mean_single, mean_ext),
    sd = coalesce(sd_single, sd_ext),
    skewness = skewness_ext,
    kurtosis = kurtosis_ext
  ) %>%
  select(model_family, model, item, dilemma, mean, sd, skewness, kurtosis) %>%
  left_join(non_discrete_support_gpt, by = c("model_family", "model", "item", "dilemma")) %>%
  left_join(item_ranges, by = "item", suffix = c("", "_human")) %>%
  mutate(
    scale_min = coalesce(scale_min, scale_min_human),
    scale_max = coalesce(scale_max, scale_max_human)
  ) %>%
  select(model_family, model, item, dilemma, mean, sd, skewness, kurtosis, scale_min, scale_max)

non_discrete_mean_sd_draws_gpt <- non_discrete_params_gpt %>%
  mutate(
    simulated = pmap(
      list(mean, sd, scale_min, scale_max),
      function(mean, sd, a, b) {
        mean <- suppressWarnings(as.numeric(mean))
        sd <- suppressWarnings(as.numeric(sd))
        a <- suppressWarnings(as.numeric(a))
        b <- suppressWarnings(as.numeric(b))

        # Missing means and unusable SDs produce missing distributions.
        if (!is.finite(mean) || !is.finite(sd) || sd < 0) {
          return(tibble(response_value = numeric(0)))
        }
        if (is.na(a)) a <- -Inf
        if (is.na(b)) b <- Inf
        if (!isTRUE(a < b)) {
          return(tibble(response_value = numeric(0)))
        }

        if (sd == 0) {
          if (!is.finite(a) || !is.finite(b)) return(tibble(response_value = numeric(0)))
          p <- point_mass_probs(mean, seq(a, b, by = 1))
          return(tibble(response_value = if (is.null(p)) numeric(0) else
            rep(seq(a, b, by = 1)[which(p == 1)], n_sim_issp)))
        }
        tibble(response_value = rtruncnorm(n_sim_issp, a = a, b = b, mean = mean, sd = sd))
      }
    )
  ) %>%
  select(model_family, model, item, dilemma, simulated) %>%
  unnest(simulated)

non_discrete_mean_sd_model_props_gpt <- draws_to_model_props_nd(non_discrete_mean_sd_draws_gpt, "distribution_mean_sd")

non_discrete_full_inputs_gpt <- non_discrete_params_gpt %>%
  transmute(
    model_family, model, scope = "global", country_folder = "Global",
    dataset_type = "non_discrete", item,
    ext_mean = mean, ext_sd = sd, ext_skew = skewness, ext_kurt = kurtosis
  ) %>%
  left_join(item_meta %>% select(item, scenario, scale), by = "item") %>%
  filter(!is.na(ext_mean), !is.na(ext_sd), ext_sd >= 0)

non_discrete_full_model_props_gpt <- map_dfr(
  seq_len(nrow(non_discrete_full_inputs_gpt)),
  ~ simulate_full_one(non_discrete_full_inputs_gpt[.x, ])
)

# GPT moment-based distributions
#
# Moment-based methods convert model-estimated means, SDs, and optionally
# skewness into full response-bin distributions. Mean + SD uses a
# truncated normal; the expanded method fits a discrete distribution whose
# moments match the model's requested moments as closely as possible.
cat("\n", strrep("-", 80), "\n")
cat("Building GPT moment-based distributions\n")
cat(strrep("-", 80), "\n")

mean_sd_inputs_gpt <- issp_means_gpt %>%
  inner_join(
    issp_sds_gpt,
    by = c("model_family", "model", "scope", "country_folder", "dataset_type", "item", "scenario", "scale")
  ) %>%
  filter(!is.na(pred_mean), !is.na(pred_sd), pred_sd >= 0)

.mean_sd_gpt_nd_rows <- mean_sd_inputs_gpt %>% filter(dataset_type != "discrete")
if (nrow(.mean_sd_gpt_nd_rows) > 0) {
  cat("  NOTE:", nrow(.mean_sd_gpt_nd_rows),
      "non-discrete rows found in mean_sd_inputs_gpt; excluded from the",
      "analytic leg (non-discrete GPT Mean + SD comes from the dedicated",
      "non_discrete_* path).\n")
}
.mean_sd_inputs_gpt_discrete <- mean_sd_inputs_gpt %>% filter(dataset_type == "discrete")
mean_sd_model_props_gpt_discrete_mc <- map_dfr(
  seq_len(nrow(.mean_sd_inputs_gpt_discrete)),
  ~ simulate_mean_sd_one(.mean_sd_inputs_gpt_discrete[.x, ]))
mean_sd_model_props_gpt_discrete <- analytic_mean_sd_props(.mean_sd_inputs_gpt_discrete)

full_inputs_gpt <- issp_extended_gpt %>%
  filter(!is.na(ext_mean), !is.na(ext_sd), ext_sd >= 0)

full_model_props_gpt_discrete <- map_dfr(seq_len(nrow(full_inputs_gpt)), ~ simulate_full_one(full_inputs_gpt[.x, ]))

prop_model_props_gpt <- bind_rows(prop_model_props_gpt_discrete, non_discrete_prop_model_props_gpt) %>%
  filter(item %in% expected_item_ids)

mean_sd_model_props_gpt <- bind_rows(mean_sd_model_props_gpt_discrete, non_discrete_mean_sd_model_props_gpt) %>%
  filter(item %in% expected_item_ids)

full_model_props_gpt <- bind_rows(full_model_props_gpt_discrete, non_discrete_full_model_props_gpt) %>%
  filter(item %in% expected_item_ids)

cat("\nGPT method coverage:\n")
bind_rows(prop_model_props_gpt, mean_sd_model_props_gpt, full_model_props_gpt) %>%
  count(model_family, model, method, scope, dataset_type, name = "rows") %>%
  print(n = Inf)

# Llama distribution estimation methods

cat("\n", strrep("-", 80), "\n")
cat("Loading Llama distribution-estimation methods\n")
cat(strrep("-", 80), "\n")

legacy_discrete_prop_model_props_llama <- read_csv(legacy_discrete_proportions_path, show_col_types = FALSE) %>%
  transmute(
    model_family = "llama",
    model = as.character(model),
    scope = as.character(scope),
    country_folder = standardize_legacy_country(scope, country),
    dataset_type = "discrete",
    method = "proportions",
    item = as.character(item),
    bin = as.numeric(response_value),
    model_prop = as.numeric(probability)
  ) %>%
  filter(item %in% expected_item_ids) %>%
  left_join(item_meta %>% select(item, scenario, scale), by = "item")

issp_assert_valid_discrete_proportions(
  legacy_discrete_prop_model_props_llama, "model_prop", item_ranges,
  file.path(out_dir, "CHECK_invalid_source_proportions_llama_issp.csv")
)
issp_assert_unique_proportion_cells(
  legacy_discrete_prop_model_props_llama,
  file.path(out_dir, "CHECK_duplicate_source_proportions_llama_issp.csv")
)

legacy_discrete_prop_model_props_llama <- legacy_discrete_prop_model_props_llama %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale, bin) %>%
  summarise(model_prop = sum(model_prop, na.rm = TRUE), .groups = "drop") %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale) %>%
  mutate(model_prop = model_prop / sum(model_prop, na.rm = TRUE)) %>%
  ungroup()

legacy_nondiscrete_prop_model_props_llama <- read_csv(legacy_nondiscrete_proportions_path, show_col_types = FALSE) %>%
  mutate(
    model_family = "llama",
    model = as.character(model),
    scope = as.character(scope),
    country_folder = standardize_legacy_country(scope, country),
    dataset_type = "non_discrete",
    method = "proportions",
    item = as.character(item),
    lower_bound = as.numeric(lower_bound),
    upper_bound = as.numeric(upper_bound),
    probability = as.numeric(probability)
  ) %>%
  filter(item %in% expected_item_ids) %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method, item) %>%
  group_modify(~ simulate_interval_props(
    .x, n = n_sim_issp,
    cell_id = paste(.y$model_family, .y$model, .y$scope, .y$country_folder,
                    .y$item, sep = "|"))) %>%
  ungroup() %>%
  left_join(item_meta %>% select(item, scenario, scale), by = "item") %>%
  select(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale, bin, model_prop)

prop_model_props_llama <- bind_rows(legacy_discrete_prop_model_props_llama, legacy_nondiscrete_prop_model_props_llama)

legacy_sds_llama <- read_csv(legacy_sd_alone_path, show_col_types = FALSE) %>%
  transmute(
    model_family = "llama",
    model = as.character(model),
    scope = as.character(scope),
    country_folder = standardize_legacy_country(scope, country),
    dataset_type = issp_dataset_type(item),
    item = as.character(item),
    pred_sd = as.numeric(pred_sd)
  ) %>%
  filter(item %in% expected_item_ids) %>%
  left_join(item_meta %>% select(item, scenario, scale), by = "item")

legacy_full_inputs_raw_llama <- read_csv(legacy_full_distribution_path, show_col_types = FALSE) %>%
  transmute(
    model_family = "llama",
    model = as.character(model),
    scope = as.character(scope),
    country_folder = standardize_legacy_country(scope, country),
    dataset_type = issp_dataset_type(item),
    item = as.character(item),
    pred_mean = as.numeric(pred_mean),
    pred_sd = as.numeric(pred_sd),
    pred_skewness = as.numeric(pred_skewness),
    pred_kurtosis = as.numeric(pred_kurtosis)
  ) %>%
  filter(item %in% expected_item_ids) %>%
  left_join(item_meta %>% select(item, scenario, scale), by = "item")

condition2_mean_source_llama <- condition2_model %>%
  filter(model_family == "llama") %>%
  select(model_family, model, scope, country_folder, dataset_type, item, pred_mean_condition2 = pred_mean)

legacy_full_mean_source_llama <- legacy_full_inputs_raw_llama %>%
  select(model_family, model, scope, country_folder, dataset_type, item, pred_mean_full = pred_mean)

mean_sd_inputs_llama <- legacy_sds_llama %>%
  left_join(
    condition2_mean_source_llama,
    by = c("model_family", "model", "scope", "country_folder", "dataset_type", "item")
  ) %>%
  left_join(
    legacy_full_mean_source_llama,
    by = c("model_family", "model", "scope", "country_folder", "dataset_type", "item")
  ) %>%
  mutate(
    pred_mean = coalesce(pred_mean_condition2, pred_mean_full),
    mean_source = case_when(
      !is.na(pred_mean_condition2) ~ "condition2_mean_confidence",
      !is.na(pred_mean_full) ~ "legacy_full_distribution",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(pred_mean), !is.na(pred_sd), pred_sd >= 0)

mean_sd_model_props_llama_mc <- map_dfr(seq_len(nrow(mean_sd_inputs_llama)), ~ simulate_mean_sd_one(mean_sd_inputs_llama[.x, ]))

mean_sd_model_props_llama <- bind_rows(
  analytic_mean_sd_props(mean_sd_inputs_llama %>% filter(dataset_type == "discrete")),
  mean_sd_model_props_llama_mc %>% filter(dataset_type == "non_discrete")
)

full_inputs_llama <- legacy_full_inputs_raw_llama %>%
  transmute(
    model_family, model, scope, country_folder, dataset_type, item, scenario, scale,
    ext_mean = pred_mean, ext_sd = pred_sd, ext_skew = pred_skewness, ext_kurt = pred_kurtosis
  ) %>%
  filter(!is.na(ext_mean), !is.na(ext_sd), ext_sd >= 0)

full_model_props_llama <- map_dfr(seq_len(nrow(full_inputs_llama)), ~ simulate_full_one(full_inputs_llama[.x, ]))

# Preserve every zero-SD input and its disposition; kurtosis remains unfitted.
issp_zero_sd_inputs <- bind_rows(
  bind_rows(
    issp_means_gpt %>% inner_join(issp_sds_gpt,
      by = c("model_family", "model", "scope", "country_folder", "dataset_type", "item", "scenario", "scale")),
    legacy_sds_llama %>%
      left_join(condition2_mean_source_llama,
        by = c("model_family", "model", "scope", "country_folder", "dataset_type", "item")) %>%
      left_join(legacy_full_mean_source_llama,
        by = c("model_family", "model", "scope", "country_folder", "dataset_type", "item")) %>%
      mutate(pred_mean = coalesce(pred_mean_condition2, pred_mean_full))
  ) %>%
    transmute(model_family, model, scope, country_folder, dataset_type, item,
      method = "distribution_mean_sd / hybrid component", mu = pred_mean,
      sigma = pred_sd, skew = NA_real_, kurt_elicited = NA_real_,
      support_lo = NA_real_, support_hi = NA_real_),
  bind_rows(issp_extended_gpt,
    legacy_full_inputs_raw_llama %>% transmute(model_family, model, scope,
      country_folder, dataset_type, item, ext_mean = pred_mean, ext_sd = pred_sd,
      ext_skew = pred_skewness, ext_kurt = pred_kurtosis),
    non_discrete_params_gpt %>% transmute(model_family, model, scope = "global",
      country_folder = "Global", dataset_type = "non_discrete", item,
      ext_mean = mean, ext_sd = sd, ext_skew = skewness, ext_kurt = kurtosis)
  ) %>%
    transmute(model_family, model, scope, country_folder, dataset_type, item,
      method = "distribution_full", mu = ext_mean, sigma = ext_sd, skew = ext_skew,
      kurt_elicited = ext_kurt, support_lo = NA_real_, support_hi = NA_real_),
  non_discrete_params_gpt %>%
    transmute(model_family, model, scope = "global", country_folder = "Global",
      dataset_type = "non_discrete", item, method = "distribution_mean_sd / hybrid component",
      mu = mean, sigma = sd, skew = NA_real_, kurt_elicited = NA_real_,
      support_lo = scale_min, support_hi = scale_max)
) %>% filter(is.finite(sigma), sigma == 0) %>%
  left_join(item_ranges %>% select(item, scale_min, scale_max), by = "item") %>%
  mutate(support_lo = coalesce(support_lo, scale_min, 1),
    support_hi = coalesce(support_hi, scale_max, 5),
    status = purrr::pmap_chr(list(mu, sigma, skew, support_lo, support_hi),
      function(mu, sigma, skew, lo, hi) {
        if (!is.finite(lo) || !is.finite(hi) || hi <= lo) return("zero_sd_invalid_support")
        zero_sd_status(mu, sigma, seq(lo, hi, by = 1), skew)
      }),
    handling = if_else(status == "zero_sd_point_mass", "retain exact point mass",
      "omit invalid component; Hybrid may retain its proportions component"),
    kurtosis_policy = "elicited kurtosis retained for reference, not fitted")
write_csv(issp_zero_sd_inputs, file.path(out_dir, "CHECK_zero_sd_inputs_issp.csv"))

cat("\nLlama mean-source coverage:\n")
mean_sd_inputs_llama %>%
  count(mean_source, scope, dataset_type, name = "rows") %>%
  print(n = Inf)

issp_fullfit_failures <- if (length(ISSP_FULLFIT_DIAG$rows) > 0) {
  bind_rows(ISSP_FULLFIT_DIAG$rows)
} else {
  tibble(model_family = character(), model = character(), scope = character(),
    country_folder = character(), dataset_type = character(), item = character(),
    ext_mean = numeric(), ext_sd = numeric(), ext_skew = numeric(), ext_kurt = numeric(),
    bin_lo = numeric(), bin_hi = numeric(), min_dnorm_seed = numeric(), seed_has_exact_zero = logical())
}

issp_fullfit_res <- if (length(ISSP_FULLFIT_DIAG$res) > 0) {
  bind_rows(ISSP_FULLFIT_DIAG$res)
} else {
  tibble(model_family = character(), model = character(), scope = character(),
         country_folder = character(), dataset_type = character(),
         item = character(), ext_mean = numeric(), ext_sd = numeric(),
         bin_lo = numeric(), bin_hi = numeric())
}

issp_fullfit_summary <- tibble(
  n_attempted = ISSP_FULLFIT_DIAG$n_attempted,
  n_failed = nrow(issp_fullfit_failures),
  n_succeeded = n_attempted - n_failed,
  n_exact_point_mass = ISSP_FULLFIT_DIAG$n_exact_point_mass,
  n_exact_feasible_repair = ISSP_FULLFIT_DIAG$n_exact_feasible_repair,
  n_succeeded_initial_start = n_succeeded - nrow(issp_fullfit_res) - n_exact_point_mass - n_exact_feasible_repair,
  n_selected_uniform_start = nrow(issp_fullfit_res),
  failure_percent = if_else(
    n_attempted > 0,
    100 * n_failed / n_attempted,
    NA_real_
  )
)

print(issp_fullfit_summary)

write_csv(
  issp_fullfit_summary,
  file.path(out_dir, "CHECK_moment_fitter_summary.csv")
)

cat("\nExpanded reconstruction outcomes (invalid or failed cells omitted):\n")
cat("  cells attempted:", ISSP_FULLFIT_DIAG$n_attempted,
    "| exact point masses (no optimizer):", ISSP_FULLFIT_DIAG$n_exact_point_mass,
    "| selected uniform start:", nrow(issp_fullfit_res),
    "| exact feasible repairs:", ISSP_FULLFIT_DIAG$n_exact_feasible_repair,
    "| omitted:", nrow(issp_fullfit_failures), "\n")
if (nrow(issp_fullfit_res) > 0) {
  print(issp_fullfit_res %>%
          count(model, scope, dataset_type, name = "n_selected_uniform_start"), n = Inf)
}
if (nrow(issp_fullfit_failures) > 0) {
  print(issp_fullfit_failures %>%
          count(model, scope, dataset_type, name = "n_omitted"), n = Inf)
  cat("  of those, unfloored normal-density start containing an exact zero:",
      sum(issp_fullfit_failures$seed_has_exact_zero), "\n")
} else {
  cat("  none omitted -- every attempted fit returned a distribution; inspect moment-accuracy QC separately.\n")
}
write_csv(issp_fullfit_failures,
          file.path(out_dir, "CHECK_moment_fitter_omitted_cells.csv"))
write_csv(issp_fullfit_res,
          file.path(out_dir, "CHECK_moment_fitter_res_cells.csv"))

# KURTOSIS-CONVENTION DIAGNOSTIC
.kurt_diag <- bind_rows(
  issp_extended_gpt %>% transmute(model_family = "gpt", kurt = ext_kurt),
  legacy_full_inputs_raw_llama %>%
    transmute(model_family = "llama",
              kurt = suppressWarnings(as.numeric(pred_kurtosis)))
) %>% filter(is.finite(kurt))
if (nrow(.kurt_diag) > 0) {
  cat("\n  Elicited kurtosis by model family (convention unspecified; NOT fitted):\n")
  print(as.data.frame(.kurt_diag %>%
    group_by(model_family) %>%
    summarise(n = n(),
              q10 = quantile(kurt, .10), median = median(kurt), q90 = quantile(kurt, .90),
              share_within_1_of_0 = mean(abs(kurt) <= 1),
              share_within_1_of_3 = mean(abs(kurt - 3) <= 1),
              .groups = "drop") %>%
    mutate(across(where(is.numeric), ~ round(.x, 3)))))
  cat("  These frequencies do not establish the requested kurtosis convention.\n")
  cat("  Kurtosis is excluded from ISSP fitting; its residual is descriptive only.\n\n")
}

# Hybrid distributions
#
# The hybrid method averages two distributions for the same model-country-item:
# the directly elicited Proportions distribution and the distribution implied by
# the Mean + SD prompt. When both components are available, Hybrid averages the
# two distributions. When only one component is available for a model-item pair,
# Hybrid uses the available component rather than dropping the row.

cat("\n", strrep("-", 80), "\n")
cat("Building hybrid distributions\n")
cat(strrep("-", 80), "\n")

prop_model_props <- bind_rows(prop_model_props_gpt, prop_model_props_llama) %>%
  filter(item %in% expected_item_ids)

mean_sd_model_props <- bind_rows(mean_sd_model_props_gpt, mean_sd_model_props_llama) %>%
  filter(item %in% expected_item_ids)

# Report achieved discrete moments alongside the untruncated parent parameters.
mean_sd_parent_targets <- bind_rows(mean_sd_inputs_gpt, mean_sd_inputs_llama) %>%
  filter(dataset_type == "discrete") %>%
  select(model_family, model, scope, country_folder, dataset_type, item,
         parent_mean = pred_mean, parent_sd = pred_sd)
mean_sd_parent_keys <- c("model_family", "model", "scope", "country_folder", "dataset_type", "item")
if (anyDuplicated(mean_sd_parent_targets[mean_sd_parent_keys])) stop("Duplicate Mean + SD target diagnostics keys.")
mean_sd_parameter_drift <- mean_sd_model_props %>% filter(dataset_type == "discrete") %>%
  group_by(across(all_of(mean_sd_parent_keys))) %>%
  summarise(achieved_mean = sum(bin * model_prop),
    achieved_sd = sqrt(sum((bin - achieved_mean)^2 * model_prop)), .groups = "drop") %>%
  left_join(mean_sd_parent_targets, by = mean_sd_parent_keys) %>%
  mutate(mean_drift = achieved_mean - parent_mean, sd_drift = achieved_sd - parent_sd,
    interpretation = "elicited values are untruncated normal parameters; bounded/discrete moments need not match")
write_csv(mean_sd_parameter_drift, file.path(out_dir, "CHECK_mean_sd_parent_parameter_drift_issp.csv"))

full_model_props <- bind_rows(full_model_props_gpt, full_model_props_llama) %>%
  filter(item %in% expected_item_ids)

# Expanded coverage after omitted fits. Losing country-item cells need not
# reduce the number of distinct items, so both are reported.
issp_expanded_coverage <- full_model_props %>%
  distinct(model_family, model, scope, dataset_type, country_folder, item) %>%
  group_by(model_family, model, scope, dataset_type) %>%
  summarise(n_cells = n(), n_items = n_distinct(item),
            n_countries_or_global = n_distinct(country_folder), .groups = "drop")
write_csv(issp_expanded_coverage,
          file.path(out_dir, "CHECK_expanded_coverage_issp.csv"))
cat("\nMoments: Expanded coverage after omitted fits:\n")
print(issp_expanded_coverage, n = Inf)

# MOMENT-FIT QUALITY CHECK
.fullfit_targets <- bind_rows(
  issp_extended_gpt %>% filter(!is.na(ext_mean), !is.na(ext_sd), ext_sd >= 0),
  full_inputs_llama,
  non_discrete_full_inputs_gpt
) %>%
  select(model_family, model, scope, country_folder, item,
         ext_mean, ext_sd, ext_skew, ext_kurt)
.fullfit_keys <- c("model_family", "model", "scope", "country_folder", "item")
if (anyDuplicated(.fullfit_targets[.fullfit_keys])) stop("Duplicate Expanded target QC keys.")
if (nrow(.fullfit_targets) != ISSP_FULLFIT_DIAG$n_attempted)
  stop("Expanded target QC does not cover every attempted fit.")

hybrid_keys <- c(
  "model_family", "model", "scope", "country_folder",
  "dataset_type", "item", "scenario", "scale", "bin"
)

hybrid_group_keys <- c(
  "model_family", "model", "scope", "country_folder",
  "dataset_type", "item", "scenario", "scale"
)

direct_for_hybrid <- prop_model_props %>%
  filter(method == "proportions") %>%
  select(all_of(hybrid_keys), prop_direct = model_prop)

meansd_for_hybrid <- mean_sd_model_props %>%
  select(all_of(hybrid_keys), prop_mean_sd = model_prop)

direct_groups <- direct_for_hybrid %>%
  distinct(across(all_of(hybrid_group_keys))) %>%
  mutate(has_proportions = TRUE)

meansd_groups <- meansd_for_hybrid %>%
  distinct(across(all_of(hybrid_group_keys))) %>%
  mutate(has_mean_sd = TRUE)

hybrid_group_coverage <- full_join(
  direct_groups,
  meansd_groups,
  by = hybrid_group_keys
) %>%
  mutate(
    has_proportions = replace_na(has_proportions, FALSE),
    has_mean_sd = replace_na(has_mean_sd, FALSE),
    hybrid_component_status = case_when(
      has_proportions & has_mean_sd ~ "both_components",
      has_proportions & !has_mean_sd ~ "proportions_only",
      !has_proportions & has_mean_sd ~ "mean_sd_only",
      TRUE ~ "neither_component"
    )
  ) %>%
  filter(hybrid_component_status != "neither_component")

cat("
Hybrid input coverage:
")
hybrid_group_coverage %>%
  count(model_family, model, scope, dataset_type, hybrid_component_status, name = "rows") %>%
  print(n = Inf)

hybrid_component_coverage_summary <- hybrid_group_coverage %>%
  count(
    model_family, model, scope, dataset_type, hybrid_component_status,
    name = "n_cells"
  ) %>%
  group_by(model_family, model, scope, dataset_type) %>%
  mutate(
    total_hybrid_cells = sum(n_cells),
    component_share = n_cells / total_hybrid_cells
  ) %>%
  ungroup()

hybrid_single_component_cells <- hybrid_group_coverage %>%
  filter(hybrid_component_status != "both_components")

readr::write_csv(
  hybrid_component_coverage_summary,
  file.path(out_dir, "PAPER_hybrid_component_coverage_by_model_scope.csv")
)
readr::write_csv(
  hybrid_single_component_cells,
  file.path(out_dir, "CHECK_hybrid_single_component_cells.csv")
)

issp_audit_record(
  "Hybrid construction", "report component availability before applying documented fallback",
  rows_in = nrow(hybrid_group_coverage), rows_out = nrow(hybrid_single_component_cells),
  unmatched_keys = nrow(hybrid_single_component_cells),
  reason = "Hybrid intentionally falls back to the available component, so fallback frequency must be visible",
  detail = paste0(
    sum(hybrid_group_coverage$hybrid_component_status == "both_components"),
    " both-component cells; ", nrow(hybrid_single_component_cells),
    " single-component cells"
  )
)

build_hybrid_from_legs <- function(direct_props, meansd_props) {
  dfh <- direct_props %>%
    filter(method == "proportions") %>%
    select(all_of(hybrid_keys), prop_direct = model_prop)

  mfh <- meansd_props %>%
    select(all_of(hybrid_keys), prop_mean_sd = model_prop)

  cov <- full_join(
    dfh %>% distinct(across(all_of(hybrid_group_keys))) %>% mutate(has_proportions = TRUE),
    mfh %>% distinct(across(all_of(hybrid_group_keys))) %>% mutate(has_mean_sd = TRUE),
    by = hybrid_group_keys
  ) %>%
    mutate(
      has_proportions = replace_na(has_proportions, FALSE),
      has_mean_sd     = replace_na(has_mean_sd, FALSE),
      hybrid_component_status = case_when(
        has_proportions &  has_mean_sd ~ "both_components",
        has_proportions & !has_mean_sd ~ "proportions_only",
        !has_proportions &  has_mean_sd ~ "mean_sd_only",
        TRUE ~ "neither_component"
      )
    ) %>%
    filter(hybrid_component_status != "neither_component")

  full_join(dfh, mfh, by = hybrid_keys) %>%
    left_join(cov, by = hybrid_group_keys) %>%
    filter(hybrid_component_status != "neither_component") %>%
    mutate(
      prop_direct  = if_else(has_proportions, replace_na(prop_direct, 0), NA_real_),
      prop_mean_sd = if_else(has_mean_sd,     replace_na(prop_mean_sd, 0), NA_real_),
      model_prop = case_when(
        has_proportions &  has_mean_sd ~ 0.5 * prop_direct + 0.5 * prop_mean_sd,
        has_proportions & !has_mean_sd ~ prop_direct,
        !has_proportions &  has_mean_sd ~ prop_mean_sd,
        TRUE ~ NA_real_
      ),
      method = "hybrid_mean_sd"
    ) %>%
    filter(!is.na(model_prop)) %>%
    group_by(across(all_of(hybrid_group_keys))) %>%
    mutate(model_prop = model_prop / sum(model_prop, na.rm = TRUE)) %>%
    ungroup() %>%
    select(model_family, model, scope, country_folder, dataset_type, method,
           item, scenario, scale, bin, model_prop)
}

hybrid_model_props <- full_join(
  direct_for_hybrid,
  meansd_for_hybrid,
  by = hybrid_keys
) %>%
  left_join(hybrid_group_coverage, by = hybrid_group_keys) %>%
  filter(hybrid_component_status != "neither_component") %>%
  mutate(
    prop_direct = if_else(has_proportions, replace_na(prop_direct, 0), NA_real_),
    prop_mean_sd = if_else(has_mean_sd, replace_na(prop_mean_sd, 0), NA_real_),
    model_prop = case_when(
      has_proportions & has_mean_sd ~ 0.5 * prop_direct + 0.5 * prop_mean_sd,
      has_proportions & !has_mean_sd ~ prop_direct,
      !has_proportions & has_mean_sd ~ prop_mean_sd,
      TRUE ~ NA_real_
    ),
    method = "hybrid_mean_sd"
  ) %>%
  filter(!is.na(model_prop)) %>%
  group_by(across(all_of(hybrid_group_keys))) %>%
  mutate(model_prop = model_prop / sum(model_prop, na.rm = TRUE)) %>%
  ungroup() %>%
  select(
    model_family, model, scope, country_folder, dataset_type, method,
    item, scenario, scale, bin, model_prop
  )

# Persona prompting distributions

cat("\n", strrep("-", 80), "\n")
cat("Building persona-prompting distributions for Llama\n")
cat(strrep("-", 80), "\n")

demographic_llama_source <- read_csv(demographic_llama_path, show_col_types = FALSE)
if (nrow(problems(demographic_llama_source))) stop("Persona CSV has parsing problems.")
# The source inventory is assessed before parse_ok and human-join exclusions.
# The mapping fixes 38 included items; v30-v33 are collected but excluded.
persona_source_items <- sort(unique(as.character(demographic_llama_source$item)))
persona_numeric_item_ids <- intersect(numeric_discrete_ids, persona_source_items)
stopifnot(setequal(persona_source_items, c(expected_item_ids, excluded_nominal_items)),
          setequal(persona_numeric_item_ids, numeric_discrete_ids))
persona_source_profiles <- demographic_llama_source %>%
  distinct(country_from_prompt, respondent_id) %>%
  count(country_from_prompt, name = "n_expected_profiles")
persona_source_duplicates <- demographic_llama_source %>%
  count(country_from_prompt, respondent_id, item) %>% filter(n != 1L)
write_csv(persona_source_duplicates, file.path(out_dir, "CHECK_persona_source_duplicate_keys.csv"))
persona_source_coverage <- tidyr::crossing(
  country_from_prompt = unname(iso_to_name), item = persona_source_items) %>%
  left_join(persona_source_profiles, by = "country_from_prompt") %>%
  left_join(demographic_llama_source %>% count(country_from_prompt, item, name = "n_source"),
    by = c("country_from_prompt", "item")) %>%
  mutate(n_source = replace_na(n_source, 0L),
    included = item %in% expected_item_ids,
    primary_numeric = item %in% persona_numeric_item_ids,
    complete = !is.na(n_expected_profiles) & n_source == n_expected_profiles)
write_csv(persona_source_coverage, file.path(out_dir, "CHECK_persona_source_coverage.csv"))
if (nrow(persona_source_duplicates) || any(!persona_source_coverage$complete))
  stop("Incomplete or duplicate persona source records; inspect CHECK_persona_source_coverage.csv. Restore the complete source; do not reduce expected coverage.")
write_csv(tibble(item = persona_source_items,
  included = item %in% expected_item_ids,
  primary_numeric = item %in% persona_numeric_item_ids,
  unit = issp_measurement_unit(item),
  selected_arrangement_role = issp_arrangement_role(item)),
  file.path(out_dir, "CHECK_persona_source_item_inventory.csv"))

demographic_llama <- demographic_llama_source %>%
  mutate(
    model_family = "llama",
    model = as.character(model),
    item = as.character(item),
    pred_q1 = as.numeric(pred_q1),
    pred_confidence_q2 = as.numeric(pred_confidence_q2),
    country_folder = as.character(country_from_prompt),
    dataset_type = issp_dataset_type(item),
    bin = as.integer(round(pred_q1))
  ) %>%
  filter(item %in% expected_item_ids, parse_ok, !is.na(pred_q1), !is.na(bin))

demographic_country_props <- demographic_llama %>%
  mutate(scope = "country", method = "demographic_distribution") %>%
  count(model_family, model, scope, country_folder, dataset_type, method, item, bin, name = "model_n_bin") %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method, item) %>%
  mutate(model_prop = model_n_bin / sum(model_n_bin)) %>%
  ungroup()

demographic_global_props <- demographic_llama %>%
  mutate(scope = "global", country_folder = "Global", method = "demographic_distribution") %>%
  count(model_family, model, scope, country_folder, dataset_type, method, item, bin, name = "model_n_bin") %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method, item) %>%
  mutate(model_prop = model_n_bin / sum(model_n_bin)) %>%
  ungroup()

demographic_model_props <- bind_rows(demographic_country_props, demographic_global_props) %>%
  left_join(item_meta %>% select(item, scenario, scale), by = "item") %>%
  select(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale, bin, model_prop)


# Persona prompting participant-level accuracy
#
# This section joins each persona-prompted prediction back to the corresponding
# participant's ISSP response when respondent IDs can be matched.

cat("\n", strrep("-", 80), "\n")
cat("Building participant-level persona-prompting accuracy tables\n")
cat(strrep("-", 80), "\n")

if (!"respondent_id" %in% names(demographic_llama)) {
  stop("demographic_llama_clean.csv must include respondent_id to run participant-level persona-prompting analyses.")
}

issp_human_with_join_ids <- issp_human %>%
  filter(!is.na(country_folder)) %>%
  mutate(.global_row_id = row_number()) %>%
  group_by(country_folder) %>%
  mutate(.country_row_id = row_number()) %>%
  ungroup()

possible_real_id_vars <- intersect(
  c(
    "CASEID", "caseid", "CaseID", "case_id",
    "id", "ID", "respondent_id", "RESPID", "respid",
    "SAMPLEID", "sampleid"
  ),
  names(issp_human_with_join_ids)
)

participant_id_candidates <- c(".global_row_id", ".country_row_id", possible_real_id_vars)

human_participant_long <- issp_human_with_join_ids %>%
  select(
    country_folder,
    all_of(participant_id_candidates),
    all_of(issp_item_vars)
  ) %>%
  pivot_longer(
    cols = all_of(issp_item_vars),
    names_to = "item",
    values_to = "human_response"
  ) %>%
  filter(item %in% expected_item_ids) %>%
  mutate(
    human_response = if_else(
      item %in% c("v9", "v10") & !is.na(human_response) & human_response > 3,
      NA_real_,
      as.numeric(human_response)
    )
  ) %>%
  filter(!is.na(human_response)) %>%
  mutate(
    human_bin = as.integer(round(human_response)),
    dataset_type = issp_dataset_type(item)
  )

demographic_llama_participant_base <- demographic_llama %>%
  mutate(
    respondent_id_chr = as.character(respondent_id),
    country_folder = as.character(country_folder),
    item = as.character(item)
  )

join_diagnostics <- map_dfr(participant_id_candidates, function(id_var) {
  human_for_join <- human_participant_long %>%
    mutate(join_id = as.character(.data[[id_var]])) %>%
    select(country_folder, item, join_id, human_response, dataset_type)

  joined <- demographic_llama_participant_base %>%
    left_join(
      human_for_join,
      by = c("country_folder", "item", "respondent_id_chr" = "join_id"),
      suffix = c("", "_human")
    )

  tibble(
    id_mapping = id_var,
    n_demographic_rows = nrow(demographic_llama_participant_base),
    n_joined_rows = sum(!is.na(joined$human_response)),
    join_rate = n_joined_rows / n_demographic_rows,
    n_joined_discrete_rows = sum(!is.na(joined$human_response) & joined$dataset_type == "discrete"),
    n_joined_non_discrete_rows = sum(!is.na(joined$human_response) & joined$dataset_type == "non_discrete"),
    n_joined_participants = n_distinct(paste(
      joined$country_folder[!is.na(joined$human_response)],
      joined$respondent_id[!is.na(joined$human_response)],
      sep = "::"
    )),
    n_joined_countries = n_distinct(joined$country_folder[!is.na(joined$human_response)]),
    n_joined_items = n_distinct(joined$item[!is.na(joined$human_response)])
  )
}) %>%
  arrange(desc(join_rate))

best_persona_id_mapping <- join_diagnostics %>%
  slice_max(order_by = join_rate, n = 1, with_ties = FALSE) %>%
  pull(id_mapping)

cat("\nPersona-prompting respondent-ID join diagnostics:\n")
print(join_diagnostics, n = Inf, width = Inf)
cat("\nUsing respondent-ID mapping:", best_persona_id_mapping, "\n")


human_profile_best_join <- issp_human_with_join_ids %>%
  mutate(join_id = as.character(.data[[best_persona_id_mapping]])) %>%
  select(country_folder, join_id) %>%
  distinct() %>%
  mutate(.human_profile_joined = TRUE)

persona_profile_join_verification <- demographic_llama_participant_base %>%
  distinct(country_folder, respondent_id, respondent_id_chr) %>%
  left_join(
    human_profile_best_join,
    by = c("country_folder", "respondent_id_chr" = "join_id")
  ) %>%
  summarise(
    id_mapping = best_persona_id_mapping,
    n_demographic_profiles = n(),
    n_joined_profiles = sum(.human_profile_joined, na.rm = TRUE),
    profile_join_rate = n_joined_profiles / n_demographic_profiles,
    n_joined_countries = n_distinct(country_folder[.human_profile_joined %in% TRUE])
  )

persona_profile_join_verification_by_country <- demographic_llama_participant_base %>%
  distinct(country_folder, respondent_id, respondent_id_chr) %>%
  left_join(
    human_profile_best_join,
    by = c("country_folder", "respondent_id_chr" = "join_id")
  ) %>%
  group_by(country_folder) %>%
  summarise(
    n_demographic_profiles = n(),
    n_joined_profiles = sum(.human_profile_joined, na.rm = TRUE),
    profile_join_rate = n_joined_profiles / n_demographic_profiles,
    .groups = "drop"
  ) %>%
  arrange(country_folder)

cat("\nPersona-prompting profile-level join verification:\n")
print(persona_profile_join_verification, n = Inf, width = Inf)

cat("\nPersona-prompting profile-level join verification by country:\n")
print(persona_profile_join_verification_by_country, n = Inf, width = Inf)

human_participant_best_join <- human_participant_long %>%
  mutate(join_id = as.character(.data[[best_persona_id_mapping]])) %>%
  select(
    country_folder,
    item,
    join_id,
    human_response,
    human_bin,
    human_dataset_type = dataset_type
  )

demographic_participant_item_level <- demographic_llama_participant_base %>%
  left_join(
    human_participant_best_join,
    by = c("country_folder", "item", "respondent_id_chr" = "join_id")
  ) %>%
  filter(!is.na(human_response)) %>%
  mutate(
    dataset_type = coalesce(dataset_type, human_dataset_type),
    participant_uid = paste(country_folder, respondent_id, sep = "::"),
    exact_category_match = if_else(item %in% ISSP_ARRANGEMENT_ITEMS, pred_q1 == human_response, NA),
    error = pred_q1 - human_response,
    abs_error = abs(error),
    sq_error = error^2,
    alignment_accuracy = -abs_error
  ) %>%
  select(-any_of(c("scenario", "scale"))) %>%
  left_join(item_meta %>% select(item, scenario, scale), by = "item") %>%
  select(
    model_family, model, country_folder, respondent_id, participant_uid, item, dataset_type,
    scenario, scale, pred_q1, pred_confidence_q2, human_response, human_bin,
    error, abs_error, sq_error, alignment_accuracy,
    everything(), -any_of(c("respondent_id_chr", "human_dataset_type"))
  )

# Keep source, accepted predictions, and human-matched denominators visible by cell.
persona_analysis_coverage <- persona_source_coverage %>% filter(included) %>%
  left_join(demographic_llama %>% count(country_folder, item, name = "n_valid_predictions"),
    by = c("country_from_prompt" = "country_folder", "item")) %>%
  left_join(demographic_participant_item_level %>%
    count(country_folder, item, name = "n_human_matched"),
    by = c("country_from_prompt" = "country_folder", "item")) %>%
  mutate(across(c(n_valid_predictions, n_human_matched), ~ replace_na(.x, 0L)),
    n_rejected_predictions = n_source - n_valid_predictions,
    n_without_valid_human_response = n_valid_predictions - n_human_matched,
    selected_arrangement_role = issp_arrangement_role(item))
stopifnot(all(persona_analysis_coverage$n_human_matched <= persona_analysis_coverage$n_valid_predictions),
          all(persona_analysis_coverage$n_valid_predictions <= persona_analysis_coverage$n_source))
write_csv(persona_analysis_coverage, file.path(out_dir, "CHECK_persona_analysis_coverage.csv"))

persona_categorical_accuracy <- demographic_participant_item_level %>%
  filter(item %in% ISSP_ARRANGEMENT_ITEMS) %>%
  group_by(model_family, model, country_folder, item) %>%
  summarise(n = n(), exact_match_rate = mean(exact_category_match), .groups = "drop") %>%
  mutate(analysis_role = "supplementary categorical sensitivity",
    selected_arrangement_role = issp_arrangement_role(item))
write_csv(persona_categorical_accuracy, file.path(out_dir, "SUPPLEMENT_persona_categorical_exact_accuracy_issp.csv"))

persona_participant_item_summary <- demographic_participant_item_level %>%
  filter(dataset_type == "discrete") %>%
  summarise(
    model_family = first(model_family),
    model = first(model),
    r_pred_human = safe_cor(pred_q1, human_response),
    mse = mean(sq_error, na.rm = TRUE),
    rmse = sqrt(mse),
    mae = mean(abs_error, na.rm = TRUE),
    mean_model = mean(pred_q1, na.rm = TRUE),
    mean_human = mean(human_response, na.rm = TRUE),
    mean_error = mean(error, na.rm = TRUE),
    n_rows = n(),
    n_participants = n_distinct(participant_uid),
    n_countries = n_distinct(country_folder),
    n_items = n_distinct(item)
  )

persona_participant_item_lm <- demographic_participant_item_level %>%
  filter(dataset_type == "discrete") %>%
  fit_simple_lm_paper(predictor = "pred_q1", outcome = "human_response") %>%
  mutate(
    model_family = first(persona_participant_item_summary$model_family),
    model = first(persona_participant_item_summary$model),
    analysis = "persona_prompting_participant_item_predicted_response_vs_human_response",
    p_formatted = p_format(p)
  ) %>%
  select(model_family, model, analysis, r, b, beta, se, t, df, p, p_formatted, ci_low, ci_high, n)

persona_country_participant_item_accuracy <- demographic_participant_item_level %>%
  filter(dataset_type == "discrete") %>%
  group_by(country_folder) %>%
  summarise(
    r = safe_cor(pred_q1, human_response),
    mse = mean(sq_error, na.rm = TRUE),
    rmse = sqrt(mse),
    mae = mean(abs_error, na.rm = TRUE),
    mean_model = mean(pred_q1, na.rm = TRUE),
    mean_human = mean(human_response, na.rm = TRUE),
    mean_error = mean(error, na.rm = TRUE),
    n_rows = n(),
    n_participants = n_distinct(participant_uid),
    n_items = n_distinct(item),
    .groups = "drop"
  ) %>%
  arrange(mse)

persona_country_participant_item_best_worst <- bind_rows(
  persona_country_participant_item_accuracy %>%
    slice_min(order_by = mse, n = 5, with_ties = FALSE) %>%
    mutate(fit_group = "best_fit_by_mse"),
  persona_country_participant_item_accuracy %>%
    slice_max(order_by = mse, n = 5, with_ties = FALSE) %>%
    arrange(desc(mse)) %>%
    mutate(fit_group = "worst_fit_by_mse")
) %>%
  select(fit_group, everything())

persona_participant_accuracy <- demographic_participant_item_level %>%
  filter(dataset_type == "discrete") %>%
  group_by(country_folder, respondent_id) %>%
  summarise(
    r = safe_cor(pred_q1, human_response),
    mse = mean(sq_error, na.rm = TRUE),
    rmse = sqrt(mse),
    mae = mean(abs_error, na.rm = TRUE),
    mean_model = mean(pred_q1, na.rm = TRUE),
    mean_human = mean(human_response, na.rm = TRUE),
    mean_error = mean(error, na.rm = TRUE),
    n_items = n_distinct(item),
    .groups = "drop"
  ) %>%
  filter(n_items >= 30)

persona_country_avg_participant_accuracy <- persona_participant_accuracy %>%
  group_by(country_folder) %>%
  summarise(
    mean_participant_r = mean(r, na.rm = TRUE),
    median_participant_r = median(r, na.rm = TRUE),
    mean_participant_mse = mean(mse, na.rm = TRUE),
    mean_participant_rmse = mean(rmse, na.rm = TRUE),
    mean_participant_mae = mean(mae, na.rm = TRUE),
    mean_model = mean(mean_model, na.rm = TRUE),
    mean_human = mean(mean_human, na.rm = TRUE),
    mean_error = mean(mean_error, na.rm = TRUE),
    n_participants = n(),
    mean_n_items = mean(n_items, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(mean_participant_mse)

persona_country_weighted_average_accuracy <- persona_country_avg_participant_accuracy %>%
  summarise(
    avg_country_mean_participant_r = mean(mean_participant_r, na.rm = TRUE),
    avg_country_median_participant_r = mean(median_participant_r, na.rm = TRUE),
    avg_country_mean_participant_mse = mean(mean_participant_mse, na.rm = TRUE),
    avg_country_mean_participant_rmse = mean(mean_participant_rmse, na.rm = TRUE),
    avg_country_mean_participant_mae = mean(mean_participant_mae, na.rm = TRUE),
    avg_country_mean_model = mean(mean_model, na.rm = TRUE),
    avg_country_mean_human = mean(mean_human, na.rm = TRUE),
    avg_country_mean_error = mean(mean_error, na.rm = TRUE),
    n_countries = n()
  )

persona_country_avg_participant_accuracy_paper <- persona_country_avg_participant_accuracy %>%
  transmute(
    Country = country_folder,
    `Mean participant r` = round(mean_participant_r, 3),
    `Median participant r` = round(median_participant_r, 3),
    `Mean participant MSE` = round(mean_participant_mse, 3),
    `Mean participant RMSE` = round(mean_participant_rmse, 3),
    `Mean participant MAE` = round(mean_participant_mae, 3),
    `Mean error` = round(mean_error, 3),
    `N participants` = n_participants,
    `Mean N items` = round(mean_n_items, 1)
  ) %>%
  arrange(`Mean participant MSE`)

persona_country_avg_participant_top_bottom <- bind_rows(
  persona_country_avg_participant_accuracy %>%
    slice_min(order_by = mean_participant_mse, n = 5, with_ties = FALSE) %>%
    mutate(fit_group = "best_fit_by_mse"),
  persona_country_avg_participant_accuracy %>%
    slice_max(order_by = mean_participant_mse, n = 5, with_ties = FALSE) %>%
    arrange(desc(mean_participant_mse)) %>%
    mutate(fit_group = "worst_fit_by_mse")
) %>%
  select(
    fit_group,
    country_folder,
    mean_participant_r,
    median_participant_r,
    mean_participant_mse,
    mean_participant_rmse,
    mean_participant_mae,
    mean_model,
    mean_human,
    mean_error,
    n_participants,
    mean_n_items
  )

cat("\nPersona prompting participant-item summary:\n")
print(persona_participant_item_summary, n = Inf, width = Inf)

cat("\nPersona prompting participant-item LM:\n")
print(persona_participant_item_lm, n = Inf, width = Inf)

cat("\nPersona prompting country participant-item accuracy:\n")
print(persona_country_participant_item_accuracy, n = Inf, width = Inf)

cat("\nPersona prompting country-balanced participant accuracy:\n")
print(persona_country_avg_participant_accuracy, n = Inf, width = Inf)

cat("\nPersona prompting country-weighted average participant accuracy:\n")
print(persona_country_weighted_average_accuracy, width = Inf)

cat("\nPersona prompting top/bottom countries by participant-averaged MSE:\n")
print(persona_country_avg_participant_top_bottom, n = Inf, width = Inf)
# 
# write_csv(persona_participant_item_summary, file.path(out_dir, "PAPER_persona_prompting_participant_item_summary_llama.csv"))
# write_csv(persona_country_avg_participant_accuracy, file.path(out_dir, "PAPER_persona_country_avg_participant_accuracy_llama.csv"))
# write_csv(persona_country_weighted_average_accuracy, file.path(out_dir, "PAPER_persona_country_weighted_average_accuracy_llama.csv"))
# write_csv(persona_country_avg_participant_accuracy_paper, file.path(out_dir, "PAPER_persona_country_avg_participant_accuracy_paper_llama.csv"))
# write_csv(persona_country_avg_participant_top_bottom, file.path(out_dir, "PAPER_persona_country_avg_participant_top_bottom_llama.csv"))

# Combine distributions
#
# Combine every model-implied distribution into a common long format. Each row
# is one response bin for a specific model, method, scope, country/global sample,
# and ISSP item. 

cat("\n", strrep("-", 80), "\n")
cat("Combining distributions\n")
cat(strrep("-", 80), "\n")

# Common distribution table used for all distributional analyses.
all_model_props <- bind_rows(
  repeated_model_props,
  prop_model_props,
  mean_sd_model_props,
  full_model_props,
  hybrid_model_props,
  demographic_model_props
) %>%
  mutate(
    bin = as.integer(bin),
    dataset_type = issp_dataset_type(item)
  ) %>%
  filter(
    model_family %in% model_families_to_keep,
    item %in% expected_item_ids,
    method %in% focal_methods,
    !is.na(bin),
    !is.na(model_prop)
  )

.amp_invalid_cells <- all_model_props %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method, item) %>%
  filter(any(model_prop < 0 | !is.finite(model_prop)) |
           sum(model_prop[is.finite(model_prop)], na.rm = TRUE) <= 0) %>%
  ungroup()
if (nrow(.amp_invalid_cells) > 0) {
  readr::write_csv(.amp_invalid_cells %>%
                     distinct(model_family, model, scope, country_folder, method, item),
                   file.path(out_dir, "CHECK_cells_dropped_invalid_probability.csv"))
  cat("  ⚠", n_distinct(paste(.amp_invalid_cells$model, .amp_invalid_cells$method,
                              .amp_invalid_cells$country_folder, .amp_invalid_cells$item)),
      "cells dropped for a negative/non-finite probability or zero total mass; see",
      "CHECK_cells_dropped_invalid_probability.csv\n")
  all_model_props <- all_model_props %>%
    anti_join(.amp_invalid_cells %>%
                distinct(model_family, model, scope, country_folder, dataset_type, method, item),
              by = c("model_family", "model", "scope", "country_folder",
                     "dataset_type", "method", "item"))
}

.amp_dupe_bins <- all_model_props %>%
  count(model_family, model, scope, country_folder, dataset_type, method, item, bin,
        name = "n_rows") %>%
  filter(n_rows > 1)
if (nrow(.amp_dupe_bins) > 0) {
  readr::write_csv(.amp_dupe_bins, file.path(out_dir, "CHECK_duplicated_cell_bins.csv"))
  print(.amp_dupe_bins %>% count(model_family, model, method, dataset_type), n = 20)
  stop(nrow(.amp_dupe_bins),
       " duplicated (cell, bin) rows reached all_model_props; renormalizing ",
       "would silently blend two distributions per cell. See ",
       "CHECK_duplicated_cell_bins.csv and fix the source before rerunning.")
}

# A single analysis cell must not split into separate normalization groups
# because its scenario or scale metadata differ across source rows.
.amp_metadata_conflicts <- all_model_props %>%
  distinct(model_family, model, scope, country_folder, dataset_type, method, item,
           scenario, scale) %>%
  count(model_family, model, scope, country_folder, dataset_type, method, item,
        name = "n_metadata_versions") %>%
  filter(n_metadata_versions > 1L)
if (nrow(.amp_metadata_conflicts) > 0) {
  readr::write_csv(.amp_metadata_conflicts,
                  file.path(out_dir, "CHECK_conflicting_cell_metadata.csv"))
  stop("Conflicting scenario/scale metadata within a distribution cell. See CHECK_conflicting_cell_metadata.csv.")
}

write_csv(all_model_props %>% filter(item %in% ISSP_ARRANGEMENT_ITEMS) %>%
  distinct(model_family, model, scope, country_folder, item, method) %>%
  mutate(analysis_role = "primary numerical; original 1-6 approximate scale"),
  file.path(out_dir, "CHECK_arrangement_primary_method_inclusion.csv"))
all_model_props <- all_model_props %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale) %>%
  mutate(model_prop = model_prop / sum(model_prop, na.rm = TRUE)) %>%
  ungroup()

cat("All model-prop rows:", nrow(all_model_props), "\n")
print(all_model_props %>% count(model_family, model, method, dataset_type, scope), n = Inf)


# Distribution distances

cat("\n", strrep("-", 80), "\n")
cat("Computing distribution distances\n")
cat(strrep("-", 80), "\n")

compute_distances_for_group <- function(df, key) {
  this_scope <- key$scope
  this_country <- key$country_folder
  this_item <- key$item

  human_df <- issp_human_props_all %>%
    filter(scope == this_scope, country_folder == this_country, item == this_item) %>%
    select(bin, human_prop, human_n_total)

  if (nrow(human_df) == 0) {
    return(tibble(
      tvd = NA_real_, emd = NA_real_, jsd = NA_real_,
      model_n_bins = n_distinct(df$bin), human_n_bins = NA_integer_,
      support_min = NA_integer_, support_max = NA_integer_,
      support_min_observed = NA_integer_, support_max_observed = NA_integer_,
      n_bins = NA_integer_, emd_norm = NA_real_
    ))
  }

  model_bins <- df$bin[!is.na(df$bin)]
  human_bins <- human_df$bin[!is.na(human_df$bin)]

  if (length(model_bins) == 0 || length(human_bins) == 0) {
    return(tibble(
      tvd = NA_real_, emd = NA_real_, jsd = NA_real_,
      model_n_bins = n_distinct(df$bin), human_n_bins = n_distinct(human_df$bin),
      support_min = NA_integer_, support_max = NA_integer_,
      support_min_observed = NA_integer_, support_max_observed = NA_integer_,
      n_bins = NA_integer_, emd_norm = NA_real_
    ))
  }

  # SUPPORT CONVENTION
  rng_row <- item_ranges %>% filter(item == this_item)

  support_min_observed <- min(c(model_bins, human_bins), na.rm = TRUE)
  support_max_observed <- max(c(model_bins, human_bins), na.rm = TRUE)

  if (nrow(rng_row) > 0 && is.finite(rng_row$scale_min[1]) &&
      is.finite(rng_row$scale_max[1]) && rng_row$scale_max[1] > rng_row$scale_min[1]) {
    support_min <- as.integer(rng_row$scale_min[1])
    support_max <- as.integer(rng_row$scale_max[1])
  } else {
    support_min <- support_min_observed
    support_max <- support_max_observed
  }

  support_min <- min(support_min, support_min_observed)
  support_max <- max(support_max, support_max_observed)

  joined <- tibble(bin = seq(support_min, support_max, by = 1L)) %>%
    left_join(
      df %>%
        group_by(bin) %>%
        summarise(model_prop = sum(model_prop, na.rm = TRUE), .groups = "drop"),
      by = "bin"
    ) %>%
    left_join(
      human_df %>%
        group_by(bin) %>%
        summarise(
          human_prop = sum(human_prop, na.rm = TRUE),
          human_n_total = max(human_n_total, na.rm = TRUE),
          .groups = "drop"
        ),
      by = "bin"
    ) %>%
    mutate(
      model_prop = replace_na(model_prop, 0),
      human_prop = replace_na(human_prop, 0)
    ) %>%
    arrange(bin)

  raw_emd <- emd_1d(joined$model_prop, joined$human_prop)

  tibble(
    tvd = tvd_dist(joined$model_prop, joined$human_prop),
    emd = raw_emd,
    jsd = jsd_fn(joined$model_prop, joined$human_prop),
    model_n_bins = sum(joined$model_prop > 0, na.rm = TRUE),
    human_n_bins = sum(joined$human_prop > 0, na.rm = TRUE),
    support_min = support_min,
    support_max = support_max,
    support_min_observed = support_min_observed,
    support_max_observed = support_max_observed,
    n_bins = nrow(joined),
    emd_norm = ifelse(support_max > support_min, raw_emd / (support_max - support_min), NA_real_)
  )
}

# Join model and human proportions by response bin, then compute distances
# within each model-method-country-item group.
issp_distribution_distances <- all_model_props %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale) %>%
  group_modify(~ compute_distances_for_group(.x, .y)) %>%
  ungroup() %>%
  filter(item %in% expected_item_ids, method %in% focal_methods) %>%
  arrange(model_family, model, scope, dataset_type, method, country_folder, item)

# Primary numerical tables use all 36 fixed-category items. v19/v26 remain
# separate by item/unit.
issp_distribution_distances_all_measurements <- issp_distribution_distances
issp_categorical_distances <- issp_distribution_distances %>%
  filter(item %in% ISSP_ARRANGEMENT_ITEMS,
    method %in% c("repeated_sampling", "proportions", "demographic_distribution")) %>%
  select(-emd, -emd_norm) %>%
  mutate(analysis_role = "supplementary categorical sensitivity",
    selected_arrangement_role = issp_arrangement_role(item))
issp_nondiscrete_distances <- issp_distribution_distances %>%
  filter(item %in% non_discrete_ids) %>% mutate(unit = issp_measurement_unit(item))
write_csv(issp_categorical_distances, file.path(out_dir, "SUPPLEMENT_categorical_distances_by_cell_issp.csv"))
write_csv(issp_nondiscrete_distances, file.path(out_dir, "PAPER_non_discrete_distances_by_cell_issp.csv"))
issp_categorical_summary <- issp_categorical_distances %>%
  group_by(model_family, model, scope, item, method) %>%
  summarise(mean_tvd = mean(tvd, na.rm = TRUE), mean_jsd = mean(jsd, na.rm = TRUE),
    n_expected = if_else(first(scope) == "country", length(iso_to_name), 1L),
    n_usable = sum(is.finite(tvd) & is.finite(jsd)), .groups = "drop") %>%
  mutate(analysis_role = "supplementary categorical sensitivity",
    selected_arrangement_role = issp_arrangement_role(item))
write_csv(issp_categorical_summary, file.path(out_dir, "SUPPLEMENT_categorical_summary_issp.csv"))

cat_models <- condition1_model %>% distinct(model_family, model)
cat_cells <- bind_rows(
  tidyr::crossing(cat_models, country_folder = unname(iso_to_name), item = ISSP_ARRANGEMENT_ITEMS) %>% mutate(scope = "country"),
  tidyr::crossing(cat_models, country_folder = "Global", item = ISSP_ARRANGEMENT_ITEMS) %>% mutate(scope = "global"))
cat_expected <- bind_rows(
  tidyr::crossing(cat_cells, method = c("repeated_sampling", "proportions")),
  cat_cells %>% filter(model_family == "llama") %>% mutate(method = "demographic_distribution"))
cat_coverage <- cat_expected %>% left_join(issp_categorical_distances %>%
  select(model_family, model, scope, country_folder, item, method, tvd, jsd),
  by = c("model_family", "model", "scope", "country_folder", "item", "method")) %>%
  mutate(usable = is.finite(tvd) & is.finite(jsd))
stopifnot(nrow(cat_coverage) == nrow(cat_expected))
write_csv(cat_coverage, file.path(out_dir, "CHECK_categorical_expected_coverage_issp.csv"))
issp_nondiscrete_summary <- issp_nondiscrete_distances %>%
  group_by(model_family, model, scope, item, unit, method) %>%
  summarise(mean_tvd = mean(tvd, na.rm = TRUE), mean_emd = mean(emd, na.rm = TRUE),
    mean_jsd = mean(jsd, na.rm = TRUE), n_cells = n(),
    n_usable = sum(is.finite(tvd) & is.finite(emd) & is.finite(jsd)), .groups = "drop")
write_csv(issp_nondiscrete_summary, file.path(out_dir, "PAPER_non_discrete_distribution_summary_by_item_issp.csv"))
issp_distribution_distances <- issp_distribution_distances %>% filter(dataset_type == "discrete")

# Maximum-entropy sensitivity uses the same fitted ISSP moments 
.entropy_meta <- .fullfit_targets %>% left_join(item_ranges,by="item")
.entropy_diag <- list(); .entropy_props <- list()
for (.j in seq_len(nrow(.entropy_meta))) {
  .r <- .entropy_meta[.j, ]
  .bins <- seq(.r$scale_min,.r$scale_max)
  # Catch only this supplementary solver; keep primary calculations and guards intact.
  .a <- tryCatch(maxent_moment_distribution(.bins,.r$ext_mean,.r$ext_sd,.r$ext_skew),
    error = function(e) list(status="maxent_exception_failed",p=NULL,
      max_moment_error=NA_real_,entropy=NA_real_,optimality_gap=NA_real_,
      failure_message=conditionMessage(e)))
  .entropy_diag[[.j]] <- .r %>% select(all_of(.fullfit_keys)) %>%
    mutate(alternative_status=.a$status,max_moment_error=.a$max_moment_error,entropy=.a$entropy, entropy_optimality_gap=.a$optimality_gap,
      failure_message=if (is.null(.a$failure_message)) NA_character_ else .a$failure_message)
  if (.a$status %in% c("maximum_entropy_exact_moments","exact_point_mass") &&
      !is.null(.a$p)) .entropy_props[[.j]] <- tibble(bin=.bins,model_prop=.a$p) %>%
    mutate(model_family=.r$model_family,model=.r$model,scope=.r$scope,
      country_folder=.r$country_folder,item=.r$item,dataset_type=issp_dataset_type(.r$item),method="distribution_full")
}
issp_entropy_diagnostics <- bind_rows(
  .entropy_meta[0, .fullfit_keys] %>% mutate(alternative_status=character(),
    max_moment_error=double(),entropy=double(),entropy_optimality_gap=double(),
    failure_message=character()), .entropy_diag)
write_csv(issp_entropy_diagnostics,file.path(out_dir,"CHECK_expanded_maxent_diagnostics_issp.csv"))
# These failures affect only the supplementary comparison
issp_entropy_failures <- issp_entropy_diagnostics %>% filter(grepl("failed$",alternative_status))
write_csv(issp_entropy_failures,file.path(out_dir,"CHECK_expanded_maxent_failed_cells_issp.csv"))
issp_entropy_run_status <- tibble(
  analysis="expanded_maximum_entropy_sensitivity",
  n_target_cells=nrow(issp_entropy_diagnostics),
  n_alternative_available=sum(issp_entropy_diagnostics$alternative_status %in%
    c("maximum_entropy_exact_moments","exact_point_mass")),
  n_solver_failed=nrow(issp_entropy_failures)) %>%
  mutate(n_other_unavailable=n_target_cells-n_alternative_available-n_solver_failed,
    sensitivity_status=case_when(n_alternative_available==0L ~ "unavailable",
      n_solver_failed>0L ~ "partial_solver_failures", TRUE ~ "completed_on_available_targets"))
write_csv(issp_entropy_run_status,file.path(out_dir,"CHECK_expanded_maxent_run_status_issp.csv"))
issp_entropy_coverage <- issp_entropy_diagnostics %>%
  group_by(model_family,model,scope) %>%
  summarise(n_target_cells=n(),
    n_alternative_available=sum(alternative_status %in% c("maximum_entropy_exact_moments","exact_point_mass")),
    n_solver_failed=sum(grepl("failed$",alternative_status)),.groups="drop") %>%
  mutate(n_other_unavailable=n_target_cells-n_alternative_available-n_solver_failed,
    sensitivity_status=case_when(n_alternative_available==0L ~ "unavailable",
      n_solver_failed>0L ~ "partial_solver_failures", TRUE ~ "completed_on_available_targets"))
write_csv(issp_entropy_coverage,file.path(out_dir,"CHECK_expanded_maxent_coverage_issp.csv"))
if (nrow(issp_entropy_failures))
  warning("Expanded maximum-entropy sensitivity: ",nrow(issp_entropy_failures),
    " failed cell(s); excluded only from this sensitivity. Primary analyses continue. ",
    "See CHECK_expanded_maxent_failed_cells_issp.csv.",call.=FALSE,immediate.=TRUE)
issp_fit_outcomes <- bind_rows(ISSP_FULLFIT_DIAG$outcomes)
stopifnot(nrow(issp_fit_outcomes)==ISSP_FULLFIT_DIAG$n_attempted,
          !anyDuplicated(issp_fit_outcomes[.fullfit_keys]))
write_csv(issp_fit_outcomes,file.path(out_dir,"CHECK_expanded_fit_outcomes_issp.csv"))
issp_repair_frequency <- issp_fit_outcomes %>%
  group_by(model_family,model,scope,dataset_type) %>%
  summarise(n_attempted=n(),n_repaired=sum(fit_attempt=="exact_feasible_repair"),
    repair_rate=n_repaired/n_attempted,n_omitted=sum(fit_attempt=="omitted_fit"),.groups="drop")
write_csv(issp_repair_frequency,file.path(out_dir,"CHECK_expanded_repair_frequency_issp.csv"))

issp_entropy_distances <- issp_distribution_distances_all_measurements[0, ] %>%
  select(all_of(c(.fullfit_keys,"dataset_type","method","tvd","emd","jsd",
    "model_n_bins","human_n_bins","support_min","support_max",
    "support_min_observed","support_max_observed","n_bins","emd_norm")))
if (length(.entropy_props)) issp_entropy_distances <- bind_rows(.entropy_props) %>%
  group_by(model_family,model,scope,country_folder,item,dataset_type,method) %>%
  group_modify(~ compute_distances_for_group(.x,.y)) %>% ungroup()
write_csv(issp_entropy_distances,file.path(out_dir,"PAPER_expanded_maxent_distances_by_cell_issp.csv"))
.entropy_keys <- issp_entropy_distances %>% filter(if_all(c(tvd,emd,jsd),is.finite)) %>%
  distinct(model_family,model,scope,country_folder,item)

.entropy_primary <- issp_distribution_distances_all_measurements %>%
  filter(dataset_type=="discrete",method %in% c("repeated_sampling","proportions","distribution_mean_sd","distribution_full","hybrid_mean_sd"),
         if_all(c(tvd,emd,jsd),is.finite)) %>%
  semi_join(.entropy_keys,by=c("model_family","model","scope","country_folder","item")) %>%
  group_by(model_family,model,scope,country_folder,item) %>% filter(n_distinct(method)==5L) %>% ungroup()
.entropy_matched_keys <- .entropy_primary %>% distinct(model_family,model,scope,country_folder,item)
issp_entropy_method_comparison <- bind_rows(
  .entropy_primary %>% mutate(reconstruction="primary_fitted_probabilities"),
  bind_rows(.entropy_primary %>% filter(method!="distribution_full"),
    issp_entropy_distances %>% semi_join(.entropy_matched_keys,by=c("model_family","model","scope","country_folder","item"))) %>%
    mutate(reconstruction="maximum_entropy")) %>%
  group_by(model_family,model,scope,reconstruction,method) %>%
  summarise(n_cells=n(),across(c(tvd,emd,jsd),mean),.groups="drop") %>%
  group_by(model_family,model,scope,reconstruction) %>%
  mutate(rank_tvd=min_rank(tvd),rank_emd=min_rank(emd),rank_jsd=min_rank(jsd)) %>% ungroup()
issp_entropy_method_comparison <- issp_entropy_method_comparison %>%
  left_join(issp_entropy_coverage,by=c("model_family","model","scope"))
write_csv(issp_entropy_method_comparison,file.path(out_dir,"PAPER_expanded_reconstruction_sensitivity_method_comparison_issp.csv"))

# CHECK: human-N-weighted persona GLOBAL distribution
demographic_global_props_popweighted <- demographic_country_props %>%
  left_join(
    issp_human_stats_all %>%
      filter(scope == "country") %>%
      select(country_folder, item, human_n),
    by = c("country_folder", "item")
  ) %>%
  filter(!is.na(human_n)) %>%
  group_by(model_family, model, dataset_type, item, bin) %>%
  summarise(.w = sum(model_prop * human_n), .groups = "drop") %>%
  group_by(model_family, model, dataset_type, item) %>%
  mutate(model_prop = .w / sum(.w)) %>%
  ungroup() %>%
  mutate(scope = "global", country_folder = "Global",
         method = "demographic_distribution") %>%
  left_join(item_meta %>% select(item, scenario, scale), by = "item") %>%
  select(model_family, model, scope, country_folder, dataset_type, method,
         item, scenario, scale, bin, model_prop)

persona_global_popweighted_distances <- demographic_global_props_popweighted %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method,
           item, scenario, scale) %>%
  group_modify(~ compute_distances_for_group(.x, .y)) %>%
  ungroup()

demographic_global_props_equalcountry <- demographic_country_props %>%
  group_by(model_family, model, dataset_type, item, bin) %>%
  summarise(.w = sum(model_prop), .groups = "drop") %>%
  group_by(model_family, model, dataset_type, item) %>%
  mutate(model_prop = .w / sum(.w)) %>%
  ungroup() %>%
  mutate(scope = "global", country_folder = "Global",
         method = "demographic_distribution") %>%
  left_join(item_meta %>% select(item, scenario, scale), by = "item") %>%
  select(model_family, model, scope, country_folder, dataset_type, method,
         item, scenario, scale, bin, model_prop)

persona_global_equalcountry_distances <- demographic_global_props_equalcountry %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method,
           item, scenario, scale) %>%
  group_modify(~ compute_distances_for_group(.x, .y)) %>%
  ungroup()


# ROBUSTNESS: analytic (primary) vs Monte Carlo for Mean + SD and Hybrid

mean_sd_model_props_mc <- bind_rows(
  mean_sd_model_props_gpt_discrete_mc,
  non_discrete_mean_sd_model_props_gpt,
  mean_sd_model_props_llama_mc
) %>%
  filter(item %in% expected_item_ids)

hybrid_model_props_mc <- build_hybrid_from_legs(prop_model_props, mean_sd_model_props_mc)

issp_mc_distances <- bind_rows(mean_sd_model_props_mc, hybrid_model_props_mc) %>%
  mutate(bin = as.integer(bin),
         dataset_type = issp_dataset_type(item)) %>%
  filter(model_family %in% model_families_to_keep, item %in% expected_item_ids,
         method %in% focal_methods, !is.na(bin), !is.na(model_prop)) %>%
  group_by(model_family, model, scope, country_folder, dataset_type, method, item, scenario, scale) %>%
  mutate(model_prop = model_prop / sum(model_prop, na.rm = TRUE)) %>%
  group_modify(~ compute_distances_for_group(.x, .y)) %>%
  ungroup()

.rb_keys <- c("model_family", "model", "scope", "country_folder",
              "dataset_type", "method", "item")

issp_analytic_vs_mc_cells <- issp_distribution_distances %>%
  filter(method %in% c("distribution_mean_sd", "hybrid_mean_sd")) %>%
  select(all_of(.rb_keys), tvd_analytic = tvd, emd_analytic = emd,
         jsd_analytic = jsd, emd_norm_analytic = emd_norm) %>%
  inner_join(
    issp_mc_distances %>%
      select(all_of(.rb_keys), tvd_mc = tvd, emd_mc = emd,
             jsd_mc = jsd, emd_norm_mc = emd_norm),
    by = .rb_keys
  ) %>%
  mutate(delta_tvd = tvd_analytic - tvd_mc,
         delta_emd = emd_analytic - emd_mc,
         delta_jsd = jsd_analytic - jsd_mc,
         delta_emd_norm = emd_norm_analytic - emd_norm_mc)

issp_analytic_vs_mc_summary <- issp_analytic_vs_mc_cells %>%
  group_by(model, method, dataset_type) %>%
  summarise(n_cells = dplyr::n(),
            across(c(tvd_analytic, tvd_mc, emd_analytic, emd_mc,
                     jsd_analytic, jsd_mc), ~ mean(.x, na.rm = TRUE)),
            med_abs_delta_tvd = median(abs(delta_tvd), na.rm = TRUE),
            max_abs_delta_tvd = max(abs(delta_tvd), na.rm = TRUE),
            med_abs_delta_emd = median(abs(delta_emd), na.rm = TRUE),
            max_abs_delta_emd = max(abs(delta_emd), na.rm = TRUE),
            med_abs_delta_jsd = median(abs(delta_jsd), na.rm = TRUE),
            max_abs_delta_jsd = max(abs(delta_jsd), na.rm = TRUE),
            .groups = "drop")

# Rank comparison
.rb_rank <- function(d) {
  d %>%
    filter(dataset_type == "discrete") %>%
    group_by(model, scope, method) %>%
    summarise(across(c(tvd, emd, jsd), ~ mean(.x, na.rm = TRUE)),
              n_items = n_distinct(item), .groups = "drop") %>%
    group_by(model, scope) %>%
    mutate(rank_tvd = rank(tvd), rank_emd = rank(emd), rank_jsd = rank(jsd)) %>%
    ungroup()
}

issp_analytic_vs_mc_ranks <- inner_join(
  .rb_rank(issp_distribution_distances) %>%
    select(model, scope, method, rank_tvd_analytic = rank_tvd,
           rank_emd_analytic = rank_emd, rank_jsd_analytic = rank_jsd),
  .rb_rank(bind_rows(
    issp_distribution_distances %>%
      filter(!(dataset_type == "discrete" &
               method %in% c("distribution_mean_sd", "hybrid_mean_sd"))),
    issp_mc_distances)) %>%
    select(model, scope, method, rank_tvd_mc = rank_tvd,
           rank_emd_mc = rank_emd, rank_jsd_mc = rank_jsd),
  by = c("model", "scope", "method")
) %>%
  mutate(rank_changed = rank_tvd_analytic != rank_tvd_mc |
                        rank_emd_analytic != rank_emd_mc |
                        rank_jsd_analytic != rank_jsd_mc)

readr::write_csv(issp_analytic_vs_mc_cells,
                 file.path(out_dir, "table_analytic_vs_monte_carlo_mean_sd_hybrid_issp.csv"))
readr::write_csv(issp_analytic_vs_mc_summary,
                 file.path(out_dir, "CHECK_analytic_vs_monte_carlo_summary_issp.csv"))
readr::write_csv(issp_analytic_vs_mc_ranks,
                 file.path(out_dir, "CHECK_analytic_vs_monte_carlo_ranks_issp.csv"))

cat("\n-- Analytic (primary) vs Monte Carlo (robustness), Mean + SD and Hybrid --\n")
print(as.data.frame(issp_analytic_vs_mc_summary %>%
  mutate(across(where(is.numeric), ~ round(.x, 5)))))
cat("  scope-level ranking positions changed:",
    sum(issp_analytic_vs_mc_ranks$rank_changed), "of", nrow(issp_analytic_vs_mc_ranks), "\n")

# Supplementary Table 15: Country-level ISSP distributional fit by best method

method_labels_issp <- c(
  repeated_sampling = "Repeated sampling",
  proportions = "Proportions",
  distribution_mean_sd = "Moments: Mean + SD",
  distribution_full = "Moments: Expanded",
  hybrid_mean_sd = "Hybrid Proportions + Moments",
  demographic_distribution = "Persona Prompting"
)

model_labels_issp <- c(
  gpt = "GPT-4.1",
  llama = "Llama-3.3-70B"
)

# Bin-wise r is computed by pooling item-bin rows within each
# model x country x method and correlating model bin proportions with human bin
# proportions. 

.binwise_model_side <- all_model_props %>%
  filter(
    scope == "country",
    dataset_type == "discrete",
    method %in% focal_methods
  ) %>%
  select(model_family, model, country_folder, method, item, bin, model_prop)

.binwise_human_side <- issp_human_props_all %>%
  filter(
    scope == "country",
    item %in% item_meta$item[item_meta$dataset_type == "discrete"]
  ) %>%
  select(country_folder, item, bin, human_prop)

.binwise_support <- bind_rows(
  item_ranges %>%
    filter(item %in% item_meta$item[item_meta$dataset_type == "discrete"],
           is.finite(scale_min), is.finite(scale_max), scale_max > scale_min) %>%
    transmute(item,
              bin = purrr::map2(as.integer(scale_min), as.integer(scale_max),
                                ~ seq(.x, .y, by = 1L))) %>%
    tidyr::unnest(bin),
  .binwise_model_side %>% distinct(item, bin),
  .binwise_human_side %>% distinct(item, bin)
) %>%
  filter(!is.na(bin)) %>%
  mutate(bin = as.integer(bin)) %>%
  distinct(item, bin)

per_country_binwise_r <- .binwise_model_side %>%
  distinct(model_family, model, country_folder, method, item) %>%
  inner_join(.binwise_support, by = "item", relationship = "many-to-many") %>%
  left_join(.binwise_model_side,
            by = c("model_family", "model", "country_folder", "method", "item", "bin")) %>%
  left_join(.binwise_human_side, by = c("country_folder", "item", "bin")) %>%
  mutate(
    model_prop = replace_na(model_prop, 0),
    human_prop = replace_na(human_prop, 0)
  ) %>%
  group_by(model_family, model, country_folder, method) %>%
  summarise(
    binwise_r = safe_cor(model_prop, human_prop),
    n_bin_rows_for_r = n(),
    .groups = "drop"
  )

per_country_method_performance <- issp_distribution_distances %>%
  filter(
    scope == "country",
    dataset_type == "discrete",
    method %in% focal_methods
  ) %>%
  group_by(
    model_family,
    model,
    country_folder,
    method
  ) %>%
  summarise(
    mean_tvd = mean(tvd, na.rm = TRUE),
    mean_emd = mean(emd, na.rm = TRUE),
    mean_emd_norm = mean(emd_norm, na.rm = TRUE),
    mean_jsd = mean(jsd, na.rm = TRUE),
    n_items = n_distinct(item),
    .groups = "drop"
  ) %>%
  left_join(
    per_country_binwise_r,
    by = c("model_family", "model", "country_folder", "method")
  )

# Best method within each model x country, using EMD.
per_country_best_method <- per_country_method_performance %>%
  group_by(model_family, model, country_folder) %>%
  slice_min(order_by = mean_emd, n = 1, with_ties = FALSE) %>%
  ungroup() %>%
  arrange(model_family, model, mean_emd)

per_country_best_method_counts <- per_country_best_method %>%
  count(model_family, model, method, name = "n_countries") %>%
  group_by(model_family, model) %>%
  mutate(prop_countries = n_countries / sum(n_countries)) %>%
  ungroup() %>%
  mutate(
    Model = recode(model_family, !!!model_labels_issp, .default = model),
    Method = recode(method, !!!method_labels_issp, .default = method)
  ) %>%
  select(Model, model_family, model, Method, method, n_countries, prop_countries) %>%
  arrange(Model, desc(n_countries), Method)

per_country_best_worst <- bind_rows(
  per_country_best_method %>%
    group_by(model_family, model) %>%
    slice_min(order_by = mean_emd, n = 5, with_ties = FALSE) %>%
    ungroup() %>%
    mutate(fit_group = "best_fit"),
  
  per_country_best_method %>%
    group_by(model_family, model) %>%
    slice_max(order_by = mean_emd, n = 5, with_ties = FALSE) %>%
    ungroup() %>%
    mutate(fit_group = "worst_fit")
) %>%
  mutate(
    Model = recode(model_family, !!!model_labels_issp, .default = model),
    Method = recode(method, !!!method_labels_issp, .default = method)
  ) %>%
  arrange(Model, fit_group, mean_emd) %>%
  select(
    Model, model_family, model, fit_group, country_folder, Method, method,
    mean_tvd, mean_emd, mean_emd_norm, mean_jsd, binwise_r,
    n_items, n_bin_rows_for_r
  )

# Supplementary Table 15.
paper_supplementary_table5_country_best_method <- per_country_best_method %>%
  mutate(
    Model = recode(model_family, !!!model_labels_issp, .default = model),
    `Best-performing method` = recode(method, !!!method_labels_issp, .default = method)
  ) %>%
  group_by(Model) %>%
  arrange(mean_emd, .by_group = TRUE) %>%
  mutate(Rank = row_number()) %>%
  ungroup() %>%
  transmute(
    Model,
    Rank,
    Country = country_folder,
    `Best-performing method`,
    TVD = round(mean_tvd, 3),
    EMD = round(mean_emd, 3),
    `Normalized EMD` = round(mean_emd_norm, 3),
    JSD = round(mean_jsd, 3),
    `Bin-wise r` = round(binwise_r, 3),
    `Items covered` = n_items
  ) %>%
  arrange(Model, Rank)
# 
# write_csv(
#   per_country_method_performance,
#   file.path(out_dir, "PAPER_per_country_method_performance_gpt_llama.csv")
# )
# 
# write_csv(
#   per_country_best_method,
#   file.path(out_dir, "PAPER_per_country_best_method_by_emd_gpt_llama.csv")
# )
# 
# write_csv(
#   per_country_best_method_counts,
#   file.path(out_dir, "PAPER_per_country_best_method_counts_gpt_llama.csv")
# )
# 
# write_csv(
#   per_country_best_worst,
#   file.path(out_dir, "PAPER_per_country_best_worst_countries_by_emd_gpt_llama.csv")
# )

write_csv(
  paper_supplementary_table5_country_best_method,
  file.path(out_dir, "PAPER_Supplementary_Table5_country_best_method_by_model.csv")
)

cat("\nSupplementary Table 15. Country-level ISSP distributional fit by best-performing method, separately by model:\n")
print(paper_supplementary_table5_country_best_method, n = Inf, width = Inf)

cat("\nPer-country best method counts:\n")
print(per_country_best_method_counts, n = Inf, width = Inf)

cat("\nPer-country best/worst countries:\n")
print(per_country_best_worst, n = Inf, width = Inf)

cat("Distribution distance rows:", nrow(issp_distribution_distances), "\n")
print(
  issp_distribution_distances %>%
    count(model_family, model, scope, dataset_type, method, name = "n_distance_rows") %>%
    arrange(model_family, model, scope, dataset_type, method),
  n = Inf
)

# Distribution summaries and tables
#
# Average the item-level distribution distances into the model/method summaries

cat("\n", strrep("-", 80), "\n")
cat("Summarising distribution results\n")
cat(strrep("-", 80), "\n")

issp_distribution_summary_scope_type_method <- issp_distribution_distances %>%
  filter(method %in% focal_methods) %>%
  group_by(model_family, model, scope, dataset_type, method) %>%
  summarise(
    mean_tvd = mean(tvd, na.rm = TRUE),
    mean_emd = mean(emd, na.rm = TRUE),
    mean_emd_norm = mean(emd_norm, na.rm = TRUE),
    mean_jsd = mean(jsd, na.rm = TRUE),
    n_item_country_rows = n(),
    n_items = n_distinct(item),
    n_countries_or_global = n_distinct(country_folder),
    items = paste(sort(unique(item)), collapse = ", "),
    .groups = "drop"
  ) %>%
  mutate(
    method = factor(method, levels = focal_methods),
    dataset_type = factor(dataset_type, levels = c("discrete", "non_discrete"))
  ) %>%
  arrange(model_family, model, scope, dataset_type, method)

best_distribution_method_by_model_scope_type <- issp_distribution_summary_scope_type_method %>%
  group_by(model_family, model, scope, dataset_type) %>%
  slice_min(order_by = mean_emd, n = 1, with_ties = FALSE) %>%
  ungroup() %>%
  arrange(model_family, model, scope, dataset_type)
# 
# write_csv(
#   issp_distribution_summary_scope_type_method,
#   file.path(out_dir, "issp_distribution_summary_scope_type_method_gpt_llama.csv")
# )
# 
# write_csv(
#   best_distribution_method_by_model_scope_type,
#   file.path(out_dir, "issp_distribution_best_method_by_model_scope_type_gpt_llama.csv")
# )

# SD correspondence
#
# These analyses test whether model-estimated SDs track empirical human response
# SDs across ISSP items and countries. 

cat("\n", strrep("-", 80), "\n")
cat("Computing SD correspondence\n")
cat(strrep("-", 80), "\n")

sd_inputs_all <- bind_rows(
  issp_sds_gpt %>%
    mutate(pred_sd = as.numeric(pred_sd)) %>%
    select(model_family, model, scope, country_folder, dataset_type, item, scenario, scale, pred_sd),
  legacy_sds_llama %>%
    select(model_family, model, scope, country_folder, dataset_type, item, scenario, scale, pred_sd)
) %>%
  filter(item %in% expected_item_ids)

sd_correspondence <- sd_inputs_all %>%
  inner_join(issp_human_stats_all, by = c("scope", "country_folder", "dataset_type", "item")) %>%
  mutate(
    sd_error = pred_sd - human_sd,
    sd_abs_error = abs(sd_error),
    sd_sq_error = sd_error^2
  )

sd_nondiscrete_by_item <- sd_correspondence %>% filter(item %in% non_discrete_ids) %>%
  mutate(unit = issp_measurement_unit(item)) %>%
  group_by(model_family, model, scope, item, unit) %>%
  summarise(r_sd = safe_cor(pred_sd, human_sd), mse = mean(sd_sq_error, na.rm = TRUE),
    mae = mean(sd_abs_error, na.rm = TRUE), n = n(), .groups = "drop")
write_csv(sd_nondiscrete_by_item, file.path(out_dir, "PAPER_non_discrete_sd_by_item_issp.csv"))
sd_correspondence <- sd_correspondence %>% filter(dataset_type == "discrete")

sd_correspondence_summary <- sd_correspondence %>%
  group_by(model_family, model, scope, dataset_type) %>%
  summarise(
    r_sd = safe_cor(pred_sd, human_sd),
    mse = mean(sd_sq_error, na.rm = TRUE),
    rmse = sqrt(mse),
    mae = mean(sd_abs_error, na.rm = TRUE),
    mean_model_sd = mean(pred_sd, na.rm = TRUE),
    mean_human_sd = mean(human_sd, na.rm = TRUE),
    n_rows = n(),
    n_items = n_distinct(item),
    n_countries_or_global = n_distinct(country_folder),
    .groups = "drop"
  ) %>%
  arrange(model_family, model, scope, dataset_type)


write_csv(sd_correspondence_summary,
          file.path(out_dir, "table_stated_sd_descriptive_summary_issp.csv"))

issp_stated_sd_global <- sd_correspondence %>%
  filter(scope == "global", dataset_type == "discrete") %>%
  left_join(item_ranges %>% select(item, scale_min, scale_max), by = "item") %>%
  mutate(
    scale_width = scale_max - scale_min,
    pred_sd_norm = pred_sd / scale_width,
    human_sd_norm = human_sd / scale_width,
    sd_source = "standalone SD prompt",
    human_sd_estimator = "sample SD of cleaned human responses"
  )
if (anyDuplicated(issp_stated_sd_global[c("model_family", "model", "item")])) {
  stop("Standalone SD test requires one global estimate per model and item.")
}
write_csv(issp_stated_sd_global,
          file.path(out_dir, "PAPER_stated_sd_global_discrete_by_item_issp.csv"))

issp_stated_sd_test <- function(d, scale_basis, item_set) {
  if (item_set == "excluding_v54_v55") d <- d %>% filter(!item %in% c("v54", "v55"))
  x <- if (scale_basis == "normalized") d$pred_sd_norm else d$pred_sd
  y <- if (scale_basis == "normalized") d$human_sd_norm else d$human_sd
  keep <- is.finite(x) & is.finite(y)
  x <- x[keep]; y <- y[keep]
  n_pairs <- length(x)
  estimable <- n_pairs >= 3L && stats::sd(x) > 0 && stats::sd(y) > 0
  ct <- if (estimable) stats::cor.test(x, y, method = "pearson") else NULL
  tibble(
    sd_source = "standalone SD prompt",
    scope = "global", dataset_type = "discrete",
    scale_basis = scale_basis, item_set = item_set,
    n_items = n_pairs,
    n_expected_items = length(setdiff(numeric_discrete_ids, if (item_set == "excluding_v54_v55") c("v54", "v55") else character())),
    r = if (estimable) unname(ct$estimate) else NA_real_,
    t = if (estimable) unname(ct$statistic) else NA_real_,
    df = if (estimable) unname(ct$parameter) else NA_real_,
    p = if (estimable) ct$p.value else NA_real_,
    ci_low = if (estimable && length(ct$conf.int) == 2L) ct$conf.int[1] else NA_real_,
    ci_high = if (estimable && length(ct$conf.int) == 2L) ct$conf.int[2] else NA_real_,
    mean_model_sd = if (n_pairs) mean(x) else NA_real_,
    mean_human_sd = if (n_pairs) mean(y) else NA_real_,
    test_status = if (estimable) "Pearson item-level correlation" else "insufficient pairs or zero variance"
  )
}
issp_stated_sd_tests <- issp_stated_sd_global %>%
  group_by(model_family, model) %>%
  group_modify(~ bind_rows(
    issp_stated_sd_test(.x, "raw", "all_discrete"),
    issp_stated_sd_test(.x, "normalized", "all_discrete"),
    issp_stated_sd_test(.x, "raw", "excluding_v54_v55"),
    issp_stated_sd_test(.x, "normalized", "excluding_v54_v55")
  )) %>%
  ungroup() %>%
  group_by(scale_basis, item_set) %>%
  mutate(
    p_holm = stats::p.adjust(p, method = "holm"),
    holm_family = paste("models within", scale_basis, item_set),
    n_family_tests = n()
  ) %>%
  ungroup()
write_csv(issp_stated_sd_tests,
          file.path(out_dir, "PAPER_stated_sd_global_discrete_tests_issp.csv"))
.stated_sd_incomplete <- issp_stated_sd_tests %>%
  filter(n_items != n_expected_items) %>%
  distinct(model, item_set, n_items, n_expected_items)
if (nrow(.stated_sd_incomplete) > 0) {
  warning("Stated-SD tests have unexpected item coverage: ",
          paste0(.stated_sd_incomplete$model, " / ", .stated_sd_incomplete$item_set,
                 " (", .stated_sd_incomplete$n_items, "/",
                 .stated_sd_incomplete$n_expected_items, ")", collapse = "; "),
          call. = FALSE)
}
cat("\nStandalone SD-prompt tests: raw and width-normalized scales\n")
print(issp_stated_sd_tests, n = Inf, width = Inf)


# Confidence analyses
#

cat("\n", strrep("-", 80), "\n")
cat("Running confidence analyses\n")
cat(strrep("-", 80), "\n")

condition2_confidence <- condition2_model %>%
  mutate(condition_name = "mean_confidence") %>%
  left_join(
    issp_human_stats_all %>%
      select(scope, country_folder, dataset_type, item, human_mean_ref = human_mean, human_sd_ref = human_sd, human_n_ref = human_n),
    by = c("scope", "country_folder", "dataset_type", "item")
  ) %>%
  mutate(
    human_mean = human_mean_ref,
    human_sd = human_sd_ref,
    human_n = human_n_ref
  ) %>%
  select(model_family, model, condition_name, scope, country_folder, dataset_type, item, pred_mean, confidence, human_mean, human_sd, human_n)

demographic_confidence <- bind_rows(
  demographic_llama %>%
    group_by(model_family, model, scope = "country", country_folder, dataset_type, item) %>%
    summarise(
      pred_mean = mean(pred_q1, na.rm = TRUE),
      confidence = mean(pred_confidence_q2, na.rm = TRUE),
      .groups = "drop"
    ),
  demographic_llama %>%
    group_by(model_family, model, scope = "global", country_folder = "Global", dataset_type, item) %>%
    summarise(
      pred_mean = mean(pred_q1, na.rm = TRUE),
      confidence = mean(pred_confidence_q2, na.rm = TRUE),
      .groups = "drop"
    )
) %>%
  mutate(condition_name = "demographic_distribution") %>%
  left_join(
    issp_human_stats_all %>%
      select(scope, country_folder, dataset_type, item, human_mean, human_sd, human_n),
    by = c("scope", "country_folder", "dataset_type", "item")
  ) %>%
  select(model_family, model, condition_name, scope, country_folder, dataset_type, item, pred_mean, confidence, human_mean, human_sd, human_n)

# Item-level confidence dataset
confidence_item_level <- bind_rows(condition2_confidence, demographic_confidence) %>%
  filter(model_family %in% model_families_to_keep) %>%
  mutate(
    mean_error = pred_mean - human_mean,
    mean_abs_error = abs(mean_error),
    mean_sq_error = mean_error^2,
    alignment_accuracy = -mean_abs_error
  )

confidence_nondiscrete_by_item <- confidence_item_level %>%
  filter(item %in% non_discrete_ids) %>% mutate(unit = issp_measurement_unit(item))
write_csv(confidence_nondiscrete_by_item, file.path(out_dir, "PAPER_non_discrete_mean_confidence_by_cell_issp.csv"))
nd_mean_summary <- confidence_nondiscrete_by_item %>%
  group_by(model_family, model, condition_name, scope, item, unit) %>%
  summarise(n = n(), bias = mean(mean_error), mae = mean(mean_abs_error), mse = mean(mean_sq_error),
    r = safe_cor(pred_mean, human_mean), .groups = "drop")
write_csv(nd_mean_summary, file.path(out_dir, "PAPER_non_discrete_mean_summary_by_item_issp.csv"))

nd_fits <- confidence_nondiscrete_by_item %>% filter(scope == "country", condition_name == "mean_confidence") %>%
  group_by(model_family, model, item, unit) %>% group_modify(~ bind_rows(
    fit_simple_lm_paper(.x, "pred_mean", "human_mean") %>% mutate(outcome = "mean_correspondence"),
    fit_simple_lm_paper(.x, "confidence", "mean_abs_error") %>% mutate(outcome = "confidence_vs_absolute_error"),
    fit_simple_lm_paper(.x, "confidence", "human_sd") %>% mutate(outcome = "confidence_vs_human_sd")
  )) %>% ungroup() %>%
  mutate(p_holm = p.adjust(p, "holm"),
    testing_family = "all models x v19/v26 x three stated associations; country scope",
    n_family_planned = n(), n_family_estimable = sum(is.finite(p)))
write_csv(nd_fits, file.path(out_dir, "PAPER_non_discrete_associations_by_item_issp.csv"))

nd_bias_tests <- confidence_nondiscrete_by_item %>%
  filter(scope == "country", condition_name == "mean_confidence") %>%
  group_by(model_family, model, item, unit) %>% group_modify(~ {
    x <- .x$mean_error[is.finite(.x$mean_error)]
    estimable <- length(x) >= 3L && stats::sd(x) > 0
    test <- if (estimable) stats::t.test(x) else NULL
    tibble(n=length(x),bias=mean(x),ci_low=if(estimable) test$conf.int[1] else NA_real_,
      ci_high=if(estimable) test$conf.int[2] else NA_real_,p=if(estimable) test$p.value else NA_real_,
      status=if(estimable) "one observation per country; per-item t interval" else "insufficient data or zero variance")
  }) %>% ungroup() %>% mutate(p_holm=p.adjust(p,"holm"),
    testing_family="all models x v19/v26 directional biases; country scope")
write_csv(nd_bias_tests,file.path(out_dir,"PAPER_non_discrete_bias_by_item_issp.csv"))

confidence_item_level <- confidence_item_level %>% filter(dataset_type == "discrete")

# Guard: one row per (model, condition, scope, country, item). 
stopifnot(!anyDuplicated(
  confidence_item_level[, c("model_family", "model", "condition_name",
                            "scope", "country_folder", "item")]))

confidence_summary_scope_type <- confidence_item_level %>%
  group_by(model_family, model, condition_name, scope, dataset_type) %>%
  summarise(
    r_pred_mean_human_mean = safe_cor(pred_mean, human_mean),
    mse = mean(mean_sq_error, na.rm = TRUE),
    rmse = sqrt(mse),
    mae = mean(mean_abs_error, na.rm = TRUE),
    mean_confidence = mean(confidence, na.rm = TRUE),
    mean_human_sd = mean(human_sd, na.rm = TRUE),
    r_conf_abs_error = safe_cor(confidence, mean_abs_error),
    r_conf_alignment_accuracy = safe_cor(confidence, alignment_accuracy),
    r_conf_human_sd = safe_cor(confidence, human_sd),
    n_rows = n(),
    n_items = n_distinct(item),
    n_countries_or_global = n_distinct(country_folder),
    .groups = "drop"
  ) %>%
  arrange(model_family, model, condition_name, scope, dataset_type)

confidence_cor_tests_scope_type <- confidence_item_level %>%
  group_by(model_family, model, condition_name, scope, dataset_type) %>%
  group_modify(~ {
    bind_rows(
      safe_cor_test(.x$pred_mean, .x$human_mean) %>%
        mutate(test = "predicted_mean_vs_human_mean"),
      safe_cor_test(.x$confidence, .x$mean_abs_error) %>%
        mutate(test = "confidence_vs_absolute_error"),
      safe_cor_test(.x$confidence, .x$alignment_accuracy) %>%
        mutate(test = "confidence_vs_alignment_accuracy"),
      safe_cor_test(.x$confidence, .x$human_sd) %>%
        mutate(test = "confidence_vs_human_sd")
    )
  }) %>%
  ungroup() %>%
  select(model_family, model, condition_name, scope, dataset_type, test, r, p, n) %>%
  arrange(model_family, model, condition_name, scope, dataset_type, test)

confidence_lm_scope_type <- confidence_item_level %>%
  group_by(model_family, model, condition_name, scope, dataset_type) %>%
  group_modify(~ {
    bind_rows(
      fit_lm_safe(.x %>% select(mean_abs_error, confidence), mean_abs_error ~ confidence) %>%
        mutate(outcome = "mean_abs_error"),
      fit_lm_safe(.x %>% select(alignment_accuracy, confidence), alignment_accuracy ~ confidence) %>%
        mutate(outcome = "alignment_accuracy"),
      fit_lm_safe(.x %>% select(human_sd, confidence), human_sd ~ confidence) %>%
        mutate(outcome = "human_sd")
    )
  }) %>%
  ungroup() %>%
  select(model_family, model, condition_name, scope, dataset_type, outcome, term, estimate, std.error, statistic, p.value)

confidence_cor_tests_scope_type <- confidence_cor_tests_scope_type %>%
  mutate(inference = "ordinary Pearson test; unclustered diagnostic")
write_csv(confidence_cor_tests_scope_type,
  file.path(out_dir, "CHECK_confidence_correlations_unclustered_issp.csv"))
confidence_paper_table <- confidence_cor_tests_scope_type %>%
  transmute(model_family, model, condition_name, scope, dataset_type, test,
    r = round(r, 3), n, inference = "descriptive Pearson correlation; no independence-based p-value")

write_csv(confidence_paper_table, file.path(out_dir, "PAPER_confidence_table_gpt_llama.csv"))


condition2_confidence_item_lm_table <- bind_rows(
  confidence_item_level %>%
    filter(condition_name == "mean_confidence") %>%
    group_by(model_family, model, scope, dataset_type) %>%
    group_modify(~ fit_simple_lm_paper(.x, predictor = "confidence", outcome = "mean_abs_error")) %>%
    ungroup() %>%
    mutate(outcome = "mean_abs_error"),
  confidence_item_level %>%
    filter(condition_name == "mean_confidence") %>%
    group_by(model_family, model, scope, dataset_type) %>%
    group_modify(~ fit_simple_lm_paper(.x, predictor = "confidence", outcome = "alignment_accuracy")) %>%
    ungroup() %>%
    mutate(outcome = "alignment_accuracy"),
  confidence_item_level %>%
    filter(condition_name == "mean_confidence") %>%
    group_by(model_family, model, scope, dataset_type) %>%
    group_modify(~ fit_simple_lm_paper(.x, predictor = "confidence", outcome = "human_sd")) %>%
    ungroup() %>%
    mutate(outcome = "human_sd")
) %>%
  mutate(
    predictor = "confidence",
    p_formatted = p_format(p)
  ) %>%
  select(
    model_family, model, scope, dataset_type, predictor, outcome,
    r, b, beta, se, t, df, p, p_formatted, ci_low, ci_high, n
  ) %>%
  arrange(model_family, model, scope, dataset_type, outcome)

write_csv(
  condition2_confidence_item_lm_table,
  file.path(out_dir, "PAPER_condition2_confidence_item_lm_with_beta_gpt_llama.csv")
)

cat("\nCondition2 confidence item-level LM table with standardized beta:\n")
print(condition2_confidence_item_lm_table, n = Inf, width = Inf)


condition2_mean_lm_table <- confidence_item_level %>%
  filter(condition_name == "mean_confidence") %>%
  group_by(model_family, model, scope, dataset_type) %>%
  group_modify(~ fit_simple_lm_paper(.x, predictor = "pred_mean", outcome = "human_mean")) %>%
  ungroup() %>%
  mutate(
    analysis = "condition2_predicted_mean_vs_human_mean",
    p_formatted = p_format(p)
  ) %>%
  select(
    model_family, model, scope, dataset_type, analysis,
    r, b, beta, se, t, df, p, p_formatted, ci_low, ci_high, n
  )

condition2_mean_paired_t_table <- confidence_item_level %>%
  filter(condition_name == "mean_confidence") %>%
  group_by(model_family, model, scope, dataset_type) %>%
  group_modify(~ {
    d <- .x %>% filter(complete.cases(pred_mean, human_mean))

    if (nrow(d) < 3) {
      return(tibble(
        mean_model = NA_real_,
        mean_human = NA_real_,
        mean_difference = NA_real_,
        t = NA_real_,
        df = NA_real_,
        p = NA_real_,
        ci_low = NA_real_,
        ci_high = NA_real_,
        n = nrow(d)
      ))
    }

    tt <- t.test(d$pred_mean, d$human_mean, paired = TRUE)

    tibble(
      mean_model = mean(d$pred_mean, na.rm = TRUE),
      mean_human = mean(d$human_mean, na.rm = TRUE),
      mean_difference = mean(d$pred_mean - d$human_mean, na.rm = TRUE),
      t = unname(tt$statistic),
      df = unname(tt$parameter),
      p = tt$p.value,
      ci_low = unname(tt$conf.int[1]),
      ci_high = unname(tt$conf.int[2]),
      n = nrow(d)
    )
  }) %>%
  ungroup() %>%
  mutate(p_formatted = p_format(p))


# The country-level association compares the same valid items in every mean.
country_confidence_item_mask <- confidence_item_level %>%
  filter(condition_name == "mean_confidence", scope == "country") %>%
  mutate(common_valid = is.finite(confidence) & is.finite(mean_abs_error) & is.finite(human_sd),
         exclusion_reason = if_else(common_valid, "included", "missing confidence, absolute error or human SD"))
write_csv(country_confidence_item_mask %>%
  select(model_family, model, dataset_type, country_folder, item, confidence, mean_abs_error,
         human_sd, common_valid, exclusion_reason),
  file.path(out_dir, "CHECK_country_confidence_common_item_mask.csv"))
country_aggregated_confidence <- country_confidence_item_mask %>%
  group_by(model_family, model, dataset_type, country_folder) %>%
  summarise(
    mean_confidence = mean(confidence[common_valid]),
    mean_abs_error = mean(mean_abs_error[common_valid]),
    alignment_accuracy = -mean_abs_error,
    mean_human_sd = mean(human_sd[common_valid]),
    n_items_requested = n_distinct(item), n_items = n_distinct(item[common_valid]),
    n_items_excluded = n_items_requested - n_items,
    excluded_items = paste(sort(unique(item[!common_valid])), collapse = ";"),
    item_mask_policy = "common finite confidence, absolute error and human SD",
    .groups = "drop"
  )

country_confidence_lm_table <- bind_rows(
  country_aggregated_confidence %>%
    group_by(model_family, model, dataset_type) %>%
    group_modify(~ fit_simple_lm_paper(.x, "mean_confidence", "mean_abs_error")) %>%
    ungroup() %>%
    mutate(outcome = "mean_abs_error"),

  country_aggregated_confidence %>%
    group_by(model_family, model, dataset_type) %>%
    group_modify(~ fit_simple_lm_paper(.x, "mean_confidence", "alignment_accuracy")) %>%
    ungroup() %>%
    mutate(outcome = "alignment_accuracy"),

  country_aggregated_confidence %>%
    group_by(model_family, model, dataset_type) %>%
    group_modify(~ fit_simple_lm_paper(.x, "mean_confidence", "mean_human_sd")) %>%
    ungroup() %>%
    mutate(outcome = "mean_human_sd")
) %>%
  mutate(
    predictor = "mean_confidence",
    p_formatted = p_format(p)
  ) %>%
  select(
    model_family, model, dataset_type, predictor, outcome,
    r, b, beta, se, t, df, p, p_formatted, ci_low, ci_high, n
  )

write_csv(
  condition2_mean_lm_table,
  file.path(out_dir, "PAPER_condition2_mean_lm_with_beta_gpt_llama.csv")
)

write_csv(
  condition2_mean_paired_t_table,
  file.path(out_dir, "PAPER_condition2_mean_paired_t_tests_gpt_llama.csv")
)

write_csv(
  country_aggregated_confidence,
  file.path(out_dir, "PAPER_country_aggregated_confidence_item_level_gpt_llama.csv")
)

write_csv(
  country_confidence_lm_table,
  file.path(out_dir, "PAPER_country_aggregated_confidence_lm_gpt_llama.csv")
)

cat("\nCondition2 mean LM table with standardized beta:\n")
print(condition2_mean_lm_table, n = Inf, width = Inf)

cat("\nCondition2 paired t-tests:\n")
print(condition2_mean_paired_t_table, n = Inf, width = Inf)

cat("\nCountry-aggregated confidence LM table:\n")
print(country_confidence_lm_table, n = Inf, width = Inf)


persona_participant_item_confidence_summary <- demographic_participant_item_level %>%
  filter(
    dataset_type == "discrete",
    !is.na(pred_confidence_q2),
    !is.na(abs_error)
  ) %>%
  summarise(
    model_family = first(model_family),
    model = first(model),
    r_conf_abs_error = safe_cor(pred_confidence_q2, abs_error),
    r_conf_alignment_accuracy = safe_cor(pred_confidence_q2, alignment_accuracy),
    mse = mean(sq_error, na.rm = TRUE),
    mae = mean(abs_error, na.rm = TRUE),
    mean_confidence = mean(pred_confidence_q2, na.rm = TRUE),
    n_rows = n(),
    n_participants = n_distinct(participant_uid),
    n_countries = n_distinct(country_folder),
    n_items = n_distinct(item)
  )

persona_participant_item_confidence_lm <- demographic_participant_item_level %>%
  filter(
    dataset_type == "discrete",
    !is.na(pred_confidence_q2),
    !is.na(abs_error)
  ) %>%
  fit_simple_lm_paper(predictor = "pred_confidence_q2", outcome = "abs_error") %>%
  mutate(
    model_family = first(persona_participant_item_confidence_summary$model_family),
    model = first(persona_participant_item_confidence_summary$model),
    predictor = "pred_confidence_q2",
    outcome = "abs_error",
    analysis = "persona_prompting_participant_item_confidence_predicting_absolute_error",
    p_formatted = p_format(p)
  ) %>%
  select(model_family, model, analysis, predictor, outcome, r, b, beta, se, t, df, p, p_formatted, ci_low, ci_high, n)

# Clustered refit of the same regression

issp_cluster_test <- function(fit, covariance, data, label, focal) {
  df <- min(n_distinct(data$participant_uid), n_distinct(data$item)) - 1L
  if (df < 2L) stop("Too few clusters for ", label)
  variances <- diag(covariance)
  eigenvalues <- if (all(is.finite(covariance)))
    eigen((covariance + t(covariance)) / 2, symmetric = TRUE, only.values = TRUE)$values else NA_real_
  eigen_tolerance <- 1e-10 * max(1, abs(eigenvalues), na.rm = TRUE)
  matrix_psd <- all(is.finite(eigenvalues)) && min(eigenvalues) >= -eigen_tolerance
  covariance_audit <- tibble(
    term = rownames(covariance), variance = variances,
    inference_valid = is.finite(variances) & variances > 0,
    focal_variance_valid = inference_valid,
    covariance_psd = matrix_psd, covariance_eigen_tolerance = eigen_tolerance,
    covariance_negative_variances = sum(is.finite(variances) & variances < 0),
    covariance_status = if (matrix_psd) "positive_semidefinite" else "matrix_warning_indefinite_or_nonfinite",
    min_eigenvalue = if (all(is.finite(covariance)))
      min(eigen((covariance + t(covariance)) / 2,
                symmetric = TRUE, only.values = TRUE)$values) else NA_real_,
    reference_df = df,
    inference = "two-way HC0; t with min(cluster counts)-1 df (approximate)"
  )
  write_csv(covariance_audit, file.path(out_dir, paste0("CHECK_cluster_covariance_", label, ".csv")))
  focal_row <- match(focal, covariance_audit$term)
  if (anyNA(focal_row) || any(!covariance_audit$inference_valid[focal_row]))
    stop("Invalid covariance for a focal coefficient in ", label)
  se <- rep(NA_real_, length(variances))
  good <- covariance_audit$inference_valid
  se[good] <- sqrt(variances[good])
  estimates <- stats::coef(fit)[rownames(covariance)]
  statistic <- estimates / se
  ct <- cbind(Estimate = estimates, "Std. Error" = se,
              "t value" = statistic, "Pr(>|t|)" = 2 * stats::pt(-abs(statistic), df))
  attr(ct, "cluster_df") <- df
  attr(ct, "covariance_diagnostics") <- covariance_audit %>%
    select(term, focal_variance_valid, covariance_psd, covariance_eigen_tolerance,
           covariance_negative_variances, covariance_status, min_eigenvalue)
  ct
}

persona_participant_item_confidence_clustered <- NULL
if (issp_have_cluster) {
  .pc <- demographic_participant_item_level %>%
    filter(dataset_type == "discrete", !is.na(pred_confidence_q2), !is.na(abs_error))
  if (nrow(.pc) > 1000) {
    .pcfit <- stats::lm(abs_error ~ pred_confidence_q2, data = .pc)
    .pccl <- try(sandwich::vcovCL(.pcfit, cluster = ~ participant_uid + item, type = "HC0"),
                 silent = TRUE)
    if (!inherits(.pccl, "try-error")) {
      .pcct <- issp_cluster_test(.pcfit, .pccl, .pc, "persona_confidence", "pred_confidence_q2")
      persona_participant_item_confidence_clustered <- tibble(
        model_family = first(.pc$model_family), model = first(.pc$model),
        analysis = "persona_prompting_participant_item_confidence_predicting_absolute_error",
        term = rownames(.pcct), estimate = .pcct[, 1],
        std_error_naive = summary(.pcfit)$coefficients[, 2],
        std_error_clustered = .pcct[, 2],
        t_naive = summary(.pcfit)$coefficients[, 3], t_clustered = .pcct[, 3],
        p_naive = summary(.pcfit)$coefficients[, 4], p_clustered = .pcct[, 4],
        df_cluster = attr(.pcct, "cluster_df"),
        ci_low = .pcct[, 1] - stats::qt(.975, df_cluster) * .pcct[, 2],
        ci_high = .pcct[, 1] + stats::qt(.975, df_cluster) * .pcct[, 2],
        inference = "two-way HC0; t with min(cluster counts)-1 df (approximate)",
        inference_valid = is.finite(.pcct[, 2]),
        n_obs = nrow(.pc), n_participants = n_distinct(.pc$participant_uid),
        n_items = n_distinct(.pc$item),
        clustering = "two-way: country-specific participant UID and item"
      ) %>%
        left_join(attr(.pcct, "covariance_diagnostics"), by = "term") %>%
        mutate(se_inflation_vs_naive = std_error_clustered / std_error_naive)
      write_csv(persona_participant_item_confidence_clustered,
                file.path(out_dir, "PAPER_partE_persona_confidence_clustered_se.csv"))
      cat("\n-- Persona confidence -> absolute error, two-way clustered SEs --\n")
      print(as.data.frame(persona_participant_item_confidence_clustered %>%
        dplyr::select(term, estimate, std_error_naive, std_error_clustered,
                      se_inflation_vs_naive, p_naive, p_clustered) %>%
        mutate(across(where(is.numeric), ~ signif(.x, 4)))))
      issp_audit_record(
        "Part E persona confidence", "two-way clustered SEs on participant and item",
        rows_in = nrow(demographic_participant_item_level), rows_out = nrow(.pc),
        reason = "participant/item dependence requires clustered inference",
        detail = "clusters: country-specific participant UID and item"
      )
    } else {
      warning("vcovCL failed for the persona confidence model; clustered SEs not computed.",
              call. = FALSE, immediate. = TRUE)
    }
  }
}

# Persona directional bias, clustered
persona_participant_item_bias_clustered <- NULL
if (issp_have_cluster) {
  .pb <- demographic_participant_item_level %>%
    filter(dataset_type == "discrete", !is.na(error))
  if (nrow(.pb) > 1000) {
    .pbfit <- stats::lm(error ~ 1, data = .pb)
    .pbcl <- try(sandwich::vcovCL(.pbfit, cluster = ~ participant_uid + item, type = "HC0"),
                 silent = TRUE)
    if (!inherits(.pbcl, "try-error")) {
      .pbct <- issp_cluster_test(.pbfit, .pbcl, .pb, "persona_bias", "(Intercept)")
      .pbt <- stats::t.test(.pb$error)
      persona_participant_item_bias_clustered <- tibble(
        model_family = first(.pb$model_family), model = first(.pb$model),
        analysis = "persona_prompting_participant_item_directional_bias_one_sample",
        term = rownames(.pbct), mean_error = .pbct[, 1],
        std_error_naive = summary(.pbfit)$coefficients[, 2],
        std_error_clustered = .pbct[, 2],
        t_naive = summary(.pbfit)$coefficients[, 3], t_clustered = .pbct[, 3],
        df_naive_onesample = unname(.pbt$parameter),
        p_naive = summary(.pbfit)$coefficients[, 4], p_clustered = .pbct[, 4],
        df_cluster = attr(.pbct, "cluster_df"),
        ci_low = .pbct[, 1] - stats::qt(.975, df_cluster) * .pbct[, 2],
        ci_high = .pbct[, 1] + stats::qt(.975, df_cluster) * .pbct[, 2],
        inference = "two-way HC0; t with min(cluster counts)-1 df (approximate)",
        inference_valid = is.finite(.pbct[, 2]),
        n_obs = nrow(.pb), n_participants = n_distinct(.pb$participant_uid),
        n_items = n_distinct(.pb$item),
        clustering = "two-way: country-specific participant UID and item"
      ) %>%
        left_join(attr(.pbct, "covariance_diagnostics"), by = "term") %>%
        mutate(se_inflation_vs_naive = std_error_clustered / std_error_naive)
      write_csv(persona_participant_item_bias_clustered,
                file.path(out_dir, "PAPER_partE_persona_bias_clustered_se.csv"))
      cat("\n-- Persona directional bias (one-sample), two-way clustered SEs --\n")
      print(as.data.frame(persona_participant_item_bias_clustered %>%
        dplyr::select(mean_error, std_error_naive, std_error_clustered,
                      se_inflation_vs_naive, t_naive, t_clustered,
                      df_naive_onesample, p_naive, p_clustered, n_obs) %>%
        mutate(across(where(is.numeric), ~ signif(.x, 6)))))
      issp_audit_record(
        "Part E persona bias", "two-way clustered SEs on the one-sample error test",
        rows_in = nrow(demographic_participant_item_level), rows_out = nrow(.pb),
        reason = "participant/item dependence requires clustered inference",
        detail = "clusters: country-specific participant UID and item"
      )
    }
  }
}

persona_participant_confidence_accuracy <- demographic_participant_item_level %>%
  filter(
    dataset_type == "discrete",
    !is.na(pred_confidence_q2),
    !is.na(abs_error)
  ) %>%
  group_by(country_folder, respondent_id) %>%
  summarise(
    mean_confidence = mean(pred_confidence_q2, na.rm = TRUE),
    mean_abs_error = mean(abs_error, na.rm = TRUE),
    mse = mean(sq_error, na.rm = TRUE),
    mae = mean(abs_error, na.rm = TRUE),
    r = safe_cor(pred_q1, human_response),
    mean_model = mean(pred_q1, na.rm = TRUE),
    mean_human = mean(human_response, na.rm = TRUE),
    mean_error = mean(error, na.rm = TRUE),
    n_items = n_distinct(item),
    .groups = "drop"
  ) %>%
  filter(n_items >= 30)

persona_country_avg_participant_confidence_accuracy <- persona_participant_confidence_accuracy %>%
  group_by(country_folder) %>%
  summarise(
    mean_participant_confidence = mean(mean_confidence, na.rm = TRUE),
    mean_participant_abs_error = mean(mean_abs_error, na.rm = TRUE),
    mean_participant_mse = mean(mse, na.rm = TRUE),
    mean_participant_mae = mean(mae, na.rm = TRUE),
    mean_participant_r = mean(r, na.rm = TRUE),
    mean_model = mean(mean_model, na.rm = TRUE),
    mean_human = mean(mean_human, na.rm = TRUE),
    mean_error = mean(mean_error, na.rm = TRUE),
    n_participants = n(),
    mean_n_items = mean(n_items, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(mean_participant_abs_error)

persona_country_confidence_participant_balanced_lm <- fit_simple_lm_paper(
  df = persona_country_avg_participant_confidence_accuracy %>%
    dplyr::ungroup(),
  predictor = "mean_participant_confidence",
  outcome = "mean_participant_abs_error"
) %>%
  mutate(
    analysis = "country_mean_participant_confidence_predicting_country_mean_participant_abs_error",
    p_formatted = p_format(p)
  )

persona_country_weighted_confidence_summary <- persona_country_avg_participant_confidence_accuracy %>%
  summarise(
    avg_country_mean_participant_confidence = mean(mean_participant_confidence, na.rm = TRUE),
    min_country_mean_participant_confidence = min(mean_participant_confidence, na.rm = TRUE),
    max_country_mean_participant_confidence = max(mean_participant_confidence, na.rm = TRUE),
    avg_country_mean_participant_abs_error = mean(mean_participant_abs_error, na.rm = TRUE),
    avg_country_mean_participant_mse = mean(mean_participant_mse, na.rm = TRUE),
    avg_country_mean_participant_mae = mean(mean_participant_mae, na.rm = TRUE),
    n_countries = n()
  )

cat("\nPersona prompting participant-item confidence summary:\n")
print(persona_participant_item_confidence_summary, n = Inf, width = Inf)

cat("\nPersona prompting participant-item confidence LM:\n")
print(persona_participant_item_confidence_lm, n = Inf, width = Inf)

cat("\nParticipant-balanced country confidence/accuracy table:\n")
print(persona_country_avg_participant_confidence_accuracy, n = Inf, width = Inf)

cat("\nParticipant-balanced country confidence LM:\n")
print(persona_country_confidence_participant_balanced_lm, n = Inf, width = Inf)

cat("\nCountry-weighted confidence summary:\n")
print(persona_country_weighted_confidence_summary, width = Inf)

write_csv(persona_country_avg_participant_confidence_accuracy, file.path(out_dir, "PAPER_persona_country_avg_participant_confidence_accuracy_llama.csv"))
write_csv(persona_country_confidence_participant_balanced_lm, file.path(out_dir, "PAPER_persona_country_confidence_participant_balanced_lm_llama.csv"))
write_csv(persona_country_weighted_confidence_summary, file.path(out_dir, "PAPER_persona_country_weighted_confidence_summary_llama.csv"))

# Paper tables


cat("\n", strrep("-", 80), "\n")
cat("Creating paper-ready tables\n")
cat(strrep("-", 80), "\n")

method_labels <- c(
  repeated_sampling = "Repeated sampling",
  proportions = "Proportions",
  distribution_mean_sd = "Moments: Mean + SD",
  distribution_full = "Moments: Expanded",
  hybrid_mean_sd = "Hybrid Proportions + Moments",
  demographic_distribution = "Persona Prompting"
)

scope_labels <- c(country = "Country-level", global = "Global")

paper_distribution_table <- issp_distribution_distances %>%
  filter(
    method %in% focal_methods,
    dataset_type == "discrete" | (dataset_type == "non_discrete" & scope == "global")
  ) %>%
  mutate(
    analysis_section = case_when(
      dataset_type == "discrete" ~ "Main analysis: discrete items",
      dataset_type == "non_discrete" ~ "Exploratory analysis: non-discrete items"
    ),
    analysis_order = case_when(
      dataset_type == "discrete" & scope == "country" ~ 1,
      dataset_type == "discrete" & scope == "global" ~ 2,
      dataset_type == "non_discrete" & scope == "global" ~ 3
    ),
    scope_label = recode(scope, !!!scope_labels),
    method_label = recode(method, !!!method_labels),
    method_order = match(method, focal_methods)
  ) %>%
  group_by(model_family, model, analysis_section, analysis_order, scope_label, dataset_type, method, method_label, method_order) %>%
  summarise(
    mean_tvd = mean(tvd, na.rm = TRUE),
    mean_emd = mean(emd, na.rm = TRUE),
    mean_emd_norm = mean(emd_norm, na.rm = TRUE),
    mean_jsd = mean(jsd, na.rm = TRUE),
    n_rows = n(),
    n_items = n_distinct(item),
    n_countries_or_global = n_distinct(country_folder),
    items = paste(sort(unique(item)), collapse = ", "),
    .groups = "drop"
  ) %>%
  arrange(model_family, model, analysis_order, method_order) %>%
  mutate(across(c(mean_tvd, mean_emd, mean_emd_norm, mean_jsd), ~ round(.x, 3))) %>%
  select(
    model_family, model, analysis_section, scope = scope_label, dataset_type,
    method = method_label, mean_tvd, mean_emd, mean_emd_norm, mean_jsd,
    n_rows, n_items, n_countries_or_global, items
  )


paper_best_distribution_method_table <- best_distribution_method_by_model_scope_type %>%
  mutate(
    best_method = recode(as.character(method), !!!method_labels),
    across(c(mean_tvd, mean_emd, mean_emd_norm, mean_jsd), ~ round(.x, 3))
  ) %>%
  select(
    model_family, model, scope, dataset_type, best_method,
    mean_tvd, mean_emd, mean_emd_norm, mean_jsd,
    n_item_country_rows, n_items, n_countries_or_global
  )

paper_mean_judgment_correspondence_table <- condition2_mean_lm_table %>%
  filter(dataset_type == "discrete", scope %in% c("country", "global")) %>%
  left_join(
    confidence_summary_scope_type %>%
      filter(condition_name == "mean_confidence", dataset_type == "discrete") %>%
      select(model_family, model, scope, dataset_type, mse, rmse, mae, n_rows),
    by = c("model_family", "model", "scope", "dataset_type")
  ) %>%
  mutate(
    Model = case_when(
      model_family == "gpt" ~ "GPT-4.1",
      model_family == "llama" ~ "Llama-3.3-70B",
      TRUE ~ model
    ),
    Level = recode(scope, country = "Country", global = "Global")
  ) %>%
  transmute(
    Model,
    Level,
    r = round(r, 3),
    MSE = round(mse, 3),
    MAE = round(mae, 3),
    N = n_rows,
    b = round(b, 3),
    beta = round(beta, 3),
    SE = round(se, 3),
    t = round(t, 2),
    df,
    p = p_formatted,
    ci_low = round(ci_low, 3),
    ci_high = round(ci_high, 3)
  ) %>%
  arrange(Model, Level)

paper_condition2_country_mean_fit <- confidence_item_level %>%
  filter(
    condition_name == "mean_confidence",
    scope == "country",
    dataset_type == "discrete"
  ) %>%
  group_by(model_family, model, country_folder) %>%
  summarise(
    r = safe_cor(pred_mean, human_mean),
    mse = mean(mean_sq_error, na.rm = TRUE),
    rmse = sqrt(mse),
    mae = mean(mean_abs_error, na.rm = TRUE),
    mean_model = mean(pred_mean, na.rm = TRUE),
    mean_human = mean(human_mean, na.rm = TRUE),
    mean_error = mean(mean_error, na.rm = TRUE),
    n_items = n_distinct(item),
    n_rows = n(),
    .groups = "drop"
  ) %>%
  arrange(model_family, model, mse)

paper_condition2_country_mean_fit_best_worst <- bind_rows(
  paper_condition2_country_mean_fit %>%
    group_by(model_family, model) %>%
    slice_min(order_by = mse, n = 5, with_ties = FALSE) %>%
    ungroup() %>%
    mutate(fit_group = "best_fit_by_mse"),
  paper_condition2_country_mean_fit %>%
    group_by(model_family, model) %>%
    slice_max(order_by = mse, n = 5, with_ties = FALSE) %>%
    ungroup() %>%
    mutate(fit_group = "worst_fit_by_mse")
) %>%
  arrange(model_family, model, fit_group, mse)

paper_global_discrete_distribution_table <- paper_distribution_table %>%
  filter(
    analysis_section == "Main analysis: discrete items",
    scope == "Global"
  ) %>%
  mutate(
    Model = case_when(
      model_family == "gpt" ~ "GPT-4.1",
      model_family == "llama" ~ "Llama-3.3-70B",
      TRUE ~ model
    )
  ) %>%
  transmute(
    Model,
    Method = method,
    TVD = mean_tvd,
    EMD = mean_emd,
    JSD = mean_jsd,
    N = n_rows,
    n_items
  )

paper_global_nondiscrete_distribution_table <- issp_nondiscrete_summary %>%
  filter(scope == "global") %>%
  transmute(Model = model, item, unit, Method = method,
            TVD = mean_tvd, EMD = mean_emd, JSD = mean_jsd, N = n_usable)


paper_confidence_compact_table <- bind_rows(
  condition2_confidence_item_lm_table %>%
    filter(dataset_type == "discrete", scope %in% c("country", "global"), outcome %in% c("mean_abs_error", "human_sd")) %>%
    transmute(
      model_family,
      model,
      analysis_level = if_else(scope == "country", "Country-item", "Global item"),
      predictor = "Condition 2 confidence",
      outcome = recode(outcome, mean_abs_error = "Absolute error", human_sd = "Human SD"),
      r, b, beta, se, t, df, p, p_formatted, ci_low, ci_high, n
    ),
  country_confidence_lm_table %>%
    filter(dataset_type == "discrete", outcome %in% c("mean_abs_error", "mean_human_sd")) %>%
    transmute(
      model_family,
      model,
      analysis_level = "Country aggregate",
      predictor = "Condition 2 mean country confidence",
      outcome = recode(outcome, mean_abs_error = "Absolute error", mean_human_sd = "Mean human SD"),
      r, b, beta, se, t, df, p, p_formatted, ci_low, ci_high, n
    ),
  persona_participant_item_confidence_lm %>%
    transmute(
      model_family,
      model,
      analysis_level = "Persona participant-item",
      predictor = "Persona confidence",
      outcome = "Absolute error",
      r, b, beta, se, t, df, p, p_formatted, ci_low, ci_high, n
    ),
  persona_country_confidence_participant_balanced_lm %>%
    mutate(model_family = "llama", model = first(persona_participant_item_confidence_summary$model)) %>%
    transmute(
      model_family,
      model,
      analysis_level = "Persona country aggregate",
      predictor = "Country mean participant confidence",
      outcome = "Country mean participant absolute error",
      r, b, beta, se, t, df, p, p_formatted, ci_low, ci_high, n
    )
) %>%
  mutate(
    Model = case_when(
      model_family == "gpt" ~ "GPT-4.1",
      model_family == "llama" ~ "Llama-3.3-70B",
      TRUE ~ model
    )
  ) %>%
  select(Model, analysis_level, predictor, outcome, r, b, beta, se, t, df, p, p_formatted, ci_low, ci_high, n)

write_csv(paper_distribution_table, file.path(out_dir, "PAPER_distribution_table_discrete_main_non_discrete_exploratory_gpt_llama.csv"))
write_csv(paper_best_distribution_method_table, file.path(out_dir, "PAPER_best_distribution_method_by_model_scope_type_gpt_llama.csv"))
write_csv(paper_mean_judgment_correspondence_table, file.path(out_dir, "CHECK_mean_judgment_correspondence_naive_issp.csv"))
write_csv(paper_condition2_country_mean_fit, file.path(out_dir, "PAPER_condition2_country_mean_fit_gpt_llama.csv"))
write_csv(paper_condition2_country_mean_fit_best_worst, file.path(out_dir, "PAPER_condition2_country_mean_fit_best_worst_gpt_llama.csv"))
write_csv(paper_global_discrete_distribution_table, file.path(out_dir, "PAPER_global_discrete_distribution_table_issp_gpt_llama.csv"))
write_csv(paper_global_nondiscrete_distribution_table, file.path(out_dir, "PAPER_global_nondiscrete_distribution_table_issp_gpt_llama.csv"))
write_csv(paper_confidence_compact_table, file.path(out_dir, "CHECK_confidence_compact_naive_issp.csv"))

cat("\nDiagnostic mean correspondence (ordinary OLS; final table rebuilt later):\n")
print(paper_mean_judgment_correspondence_table, n = Inf, width = Inf)

cat("\nPaper condition2 country mean fit best/worst:\n")
print(paper_condition2_country_mean_fit_best_worst, n = Inf, width = Inf)

cat("\nPaper global discrete distribution table:\n")
print(paper_global_discrete_distribution_table, n = Inf, width = Inf)

cat("\nNaive confidence comparison (final inference is exported later):\n")
print(paper_confidence_compact_table, n = Inf, width = Inf)


cat("\n", strrep("=", 80),
    "\nPART E (ISSP) — EFFECT SIZES, MULTILEVEL MODELS, CORRECTIONS, CONTRASTS\n",
    strrep("=", 80), "\n")

cat("  lme4/lmerTest:", issp_have_lmer, " emmeans:", issp_have_emmeans,
    " MuMIn:", issp_have_mumin, " sandwich/lmtest:", issp_have_cluster,
    " broom.mixed:", issp_have_broom_mixed, "\n")

if (!all(c(
  issp_have_lmer, issp_have_emmeans, issp_have_mumin,
  issp_have_cluster, issp_have_broom_mixed
))) {
  stop(
    "ISSP Part E requires lme4, lmerTest, emmeans, MuMIn, sandwich, lmtest, and broom.mixed; ",
    "install the missing package(s) before running the paper analyses."
  )
}

ISSP_METRICS <- c("tvd", "emd", "jsd")


# effect-size helpers
issp_cohen_d_paired <- function(x, y) {
  d <- x - y
  d <- d[!is.na(d)]
  if (length(d) < 2) return(NA_real_)
  s <- stats::sd(d)
  if (!is.finite(s) || s == 0) return(NA_real_)
  mean(d) / s
}

issp_d_ci <- function(d, n) {
  if (is.na(d) || n < 4) return(c(NA_real_, NA_real_))
  se <- sqrt(1 / n + d^2 / (2 * n))
  c(d - 1.96 * se, d + 1.96 * se)
}

# Cluster-bootstrap percentile CI for a one-sample / paired d_z.
# diffs
issp_d_ci_cluster_boot <- function(diffs, cluster, B = 2000L,
                                   seed = 20260811L) {
  keep <- stats::complete.cases(diffs, cluster)
  diffs <- diffs[keep]; cl <- as.character(cluster)[keep]
  ids <- unique(cl); G <- length(ids)
  if (G < 3L) return(c(NA_real_, NA_real_))
  by_cl <- split(diffs, cl)
  # Reproducible within this helper without resetting the caller's RNG stream.
  had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) old_seed <- get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  on.exit({
    if (had_seed) {
      assign(".Random.seed", old_seed, envir = .GlobalEnv)
    } else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) {
      rm(".Random.seed", envir = .GlobalEnv)
    }
  }, add = TRUE)
  set.seed(seed)
  boots <- replicate(B, {
    v <- unlist(by_cl[sample(ids, G, replace = TRUE)], use.names = FALSE)
    mean(v) / stats::sd(v)
  })
  stats::quantile(boots, c(0.025, 0.975), na.rm = TRUE, names = FALSE)
}


# STRUCTURAL AUDIT BEFORE COMPUTING
cat("\n-- Structural audit of Part E inputs --\n")

issp_dupe_report <- list()

if (exists("issp_distribution_distances")) {
  d1 <- issp_distribution_distances %>%
    count(model_family, model, scope, country_folder, dataset_type, method, item,
          name = "n_records") %>%
    filter(n_records > 1)
  issp_dupe_report[[length(issp_dupe_report) + 1]] <- tibble(
    object = "issp_distribution_distances", duplicated_cells = nrow(d1))
  cat("  issp_distribution_distances duplicated cells:", nrow(d1), "\n")
}

if (exists("confidence_item_level")) {
  d2 <- confidence_item_level %>%
    count(model_family, model, condition_name, scope, country_folder, item,
          name = "n_records") %>%
    filter(n_records > 1)
  issp_dupe_report[[length(issp_dupe_report) + 1]] <- tibble(
    object = "confidence_item_level", duplicated_cells = nrow(d2))
  cat("  confidence_item_level duplicated cells:", nrow(d2), "\n")
}

if (exists("demographic_participant_item_level")) {
  d3 <- demographic_participant_item_level %>%
    count(country_folder, respondent_id, item, name = "n_records") %>%
    filter(n_records > 1)
  issp_dupe_report[[length(issp_dupe_report) + 1]] <- tibble(
    object = "demographic_participant_item_level", duplicated_cells = nrow(d3))
  cat("  persona participant-item duplicated cells:", nrow(d3),
      " total rows:", nrow(demographic_participant_item_level), "\n")
  if (nrow(d3) > 0) {
    cat("  ⚠ The persona join fanned out. Every participant-level SE below is\n")
    cat("    computed on inflated rows until this is resolved.\n")
  }
}

issp_dupe_report <- bind_rows(issp_dupe_report)
if (nrow(issp_dupe_report) > 0) {
  readr::write_csv(issp_dupe_report, file.path(out_dir, "PAPER_partE_input_duplicate_audit.csv"))
  issp_audit_record(
    "Part E structural audit", "check Part E inputs for duplicate cells and join fan-out",
    rows_in = nrow(issp_dupe_report), rows_out = sum(issp_dupe_report$duplicated_cells),
    reason = "check detects duplicate input cells",
    detail = paste(paste0(issp_dupe_report$object, "=", issp_dupe_report$duplicated_cells),
                   collapse = "; ")
  )
  if (any(issp_dupe_report$duplicated_cells > 0L)) {
    stop(
      "Duplicate cells or persona join fan-out found in Part E inputs; ",
      "see PAPER_partE_input_duplicate_audit.csv."
    )
  }
}


# crossed multilevel models
issp_e6_rows <- list()
issp_e6_fit <- list()

issp_fit_crossed <- function(dat, outcome, predictor, label) {
  d <- dat %>%
    dplyr::mutate(.y = .data[[outcome]], .x = .data[[predictor]]) %>%
    dplyr::filter(!is.na(.y), !is.na(.x), !is.na(country_folder), !is.na(item))
  if (nrow(d) < 50 || dplyr::n_distinct(d$country_folder) < 3 ||
      dplyr::n_distinct(d$item) < 3) return(invisible(NULL))

  f <- try(lmerTest::lmer(.y ~ .x + (1 | country_folder) + (1 | item), data = d), silent = TRUE)
  if (inherits(f, "try-error")) { cat("  ⚠ lmer failed:", label, "\n"); return(invisible(NULL)) }
  o <- stats::lm(.y ~ .x, data = d)

  vc <- as.data.frame(lme4::VarCorr(f))
  v_country <- sum(vc$vcov[vc$grp == "country_folder"], na.rm = TRUE)
  v_item    <- sum(vc$vcov[vc$grp == "item"], na.rm = TRUE)
  v_resid   <- vc$vcov[vc$grp == "Residual"][1]
  r2 <- if (issp_have_mumin) {
    tryCatch(MuMIn::r.squaredGLMM(f), error = function(e) matrix(NA_real_, 1, 2))
  } else matrix(NA_real_, 1, 2)

  issp_e6_fit[[length(issp_e6_fit) + 1]] <<- tibble(
    model = label, outcome = outcome, predictor = predictor, !!!as.list(model_fit_diagnostics(f)),
    n_obs = stats::nobs(f), n_countries = dplyr::n_distinct(d$country_folder),
    n_items = dplyr::n_distinct(d$item),
    icc_country = v_country / (v_country + v_item + v_resid),
    icc_item    = v_item / (v_country + v_item + v_resid),
    var_country = v_country, var_item = v_item, var_residual = v_resid,
    r2_marginal = r2[1, 1], r2_conditional = r2[1, 2]
  )
  issp_e6_rows[[length(issp_e6_rows) + 1]] <<- broom.mixed::tidy(
    f, effects = "fixed", conf.int = TRUE) %>%
    dplyr::mutate(!!!as.list(model_fit_diagnostics(f))) %>%
    dplyr::mutate(model = label, outcome = outcome, predictor = predictor,
                  ols_estimate = unname(stats::coef(o)[match(term, names(stats::coef(o)))]),
                  .before = 1)
  cat(sprintf("  %-52s n=%6d  ICC country %.3f  item %.3f\n", label, stats::nobs(f),
              v_country / (v_country + v_item + v_resid),
              v_item / (v_country + v_item + v_resid)))
  invisible(NULL)
}

# Intercept-only crossed fit
issp_fit_crossed_intercept <- function(dat, outcome, label) {
  d <- dat %>%
    dplyr::mutate(.y = .data[[outcome]]) %>%
    dplyr::filter(!is.na(.y), !is.na(country_folder), !is.na(item))
  if (nrow(d) < 50 || dplyr::n_distinct(d$country_folder) < 3 ||
      dplyr::n_distinct(d$item) < 3) {
    cat(sprintf("  SKIPPED (below fit guards): %-46s n=%d countries=%d items=%d\n",
                label, nrow(d), dplyr::n_distinct(d$country_folder),
                dplyr::n_distinct(d$item)))
    return(invisible(NULL))
  }
  f <- try(lmerTest::lmer(.y ~ 1 + (1 | country_folder) + (1 | item), data = d), silent = TRUE)
  if (inherits(f, "try-error")) { cat("  ⚠ lmer failed:", label, "\n"); return(invisible(NULL)) }
  tt <- stats::t.test(d$.y)
  vc <- as.data.frame(lme4::VarCorr(f))
  v_country <- sum(vc$vcov[vc$grp == "country_folder"], na.rm = TRUE)
  v_item    <- sum(vc$vcov[vc$grp == "item"], na.rm = TRUE)
  v_resid   <- vc$vcov[vc$grp == "Residual"][1]
  issp_e6_fit[[length(issp_e6_fit) + 1]] <<- tibble(
    model = label, outcome = outcome, predictor = "(intercept only)", !!!as.list(model_fit_diagnostics(f)),
    n_obs = stats::nobs(f), n_countries = dplyr::n_distinct(d$country_folder),
    n_items = dplyr::n_distinct(d$item),
    icc_country = v_country / (v_country + v_item + v_resid),
    icc_item    = v_item / (v_country + v_item + v_resid),
    var_country = v_country, var_item = v_item, var_residual = v_resid,
    r2_marginal = NA_real_, r2_conditional = NA_real_
  )
  issp_e6_rows[[length(issp_e6_rows) + 1]] <<- broom.mixed::tidy(
    f, effects = "fixed", conf.int = TRUE) %>%
    dplyr::mutate(!!!as.list(model_fit_diagnostics(f))) %>%
    dplyr::mutate(model = label, outcome = outcome, predictor = "(intercept only)",
                  ols_estimate = unname(tt$estimate),
                  paired_t_statistic = unname(tt$statistic),
                  paired_t_df = unname(tt$parameter),
                  paired_t_p = tt$p.value,
                  .before = 1)
  cat(sprintf("  %-52s n=%6d  crossed est %.4f (SE %.4f)  paired-t est %.4f\n",
              label, stats::nobs(f),
              broom.mixed::tidy(f, effects = "fixed")$estimate[1],
              broom.mixed::tidy(f, effects = "fixed")$std.error[1],
              unname(tt$estimate)))
  invisible(NULL)
}

if (issp_have_lmer) {
  cat("\n-- E6 crossed models: (1|country) + (1|item) --\n")
  if (exists("confidence_item_level")) {
    cm <- confidence_item_level %>%
      filter(condition_name == "mean_confidence",
             scope == "country", dataset_type == "discrete")
    for (mdl in sort(unique(cm$model))) {
      issp_fit_crossed(cm %>% filter(model == mdl), "human_mean", "pred_mean",
                       paste0("mean correspondence | ", mdl))
    }
   
    if ("confidence" %in% names(cm)) {
      for (mdl in sort(unique(cm$model))) {
        issp_fit_crossed(cm %>% filter(model == mdl), "mean_abs_error", "confidence",
                         paste0("confidence -> error | ", mdl))
      }
      for (mdl in sort(unique(cm$model))) {
        issp_fit_crossed(cm %>% filter(model == mdl), "human_sd", "confidence",
                         paste0("confidence -> human_sd | ", mdl))
      }
    } else {
      warning("E6: `confidence` column absent from confidence_item_level; ",
              "crossed confidence models skipped.", call. = FALSE, immediate. = TRUE)
    }

    # Directional bias
    for (mdl in sort(unique(cm$model))) {
      issp_fit_crossed_intercept(cm %>% filter(model == mdl), "mean_error",
                                 paste0("directional bias | ", mdl))
    }
    cm_bias_nd <- confidence_item_level %>%
      filter(condition_name == "mean_confidence", scope == "country",
             dataset_type == "non_discrete")
    if (nrow(cm_bias_nd) > 0) {
      for (mdl in sort(unique(cm_bias_nd$model))) {
        issp_fit_crossed_intercept(cm_bias_nd %>% filter(model == mdl), "mean_error",
                                   paste0("directional bias NON-DISCRETE | ", mdl))
      }
    }
  }
}

if (issp_have_lmer && length(issp_e6_fit) > 0) {
  .e6_labels <- vapply(issp_e6_fit, function(x) x$model[1], character(1))
  .e6_expected_kinds <- c("mean correspondence", "confidence -> error",
                          "confidence -> human_sd", "directional bias")
  .e6_missing <- .e6_expected_kinds[
    !vapply(.e6_expected_kinds, function(k) any(startsWith(.e6_labels, k)), logical(1))]
  cat("  E6 crossed fits produced:", length(.e6_labels), "models across",
      length(.e6_expected_kinds) - length(.e6_missing), "of",
      length(.e6_expected_kinds), "expected kinds\n")
  if (length(.e6_missing) > 0) {
    warning("E6 post-condition: no crossed fit produced for: ",
            paste(.e6_missing, collapse = "; "),
            ". A predictor/outcome column name may have drifted.",
            call. = FALSE, immediate. = TRUE)
  }
}

if (length(issp_e6_rows) > 0) {
  issp_e6_coefs <- bind_rows(issp_e6_rows)
  issp_e6_fitstats <- bind_rows(issp_e6_fit)
  readr::write_csv(issp_e6_coefs, file.path(out_dir, "PAPER_partE_crossed_lmer_coefficients.csv"))
  readr::write_csv(issp_e6_fitstats, file.path(out_dir, "PAPER_partE_crossed_lmer_fit_icc.csv"))
  cat("  Wrote", nrow(issp_e6_coefs), "coefficients across", nrow(issp_e6_fitstats), "crossed models\n")

  .cx <- issp_e6_coefs %>%
    left_join(issp_e6_fitstats %>% select(model, n_obs), by = "model") %>%
    mutate(kind = trimws(sub("[|].*$", "", model)),
           crossed_model = trimws(sub("^[^|]*[|]", "", model))) %>%
    filter(term %in% c(".x", "(Intercept)"))

  cat("  D5 key check -- crossed_model values:",
      paste(sort(unique(.cx$crossed_model)), collapse = " | "), "\n")

  .pick <- function(kind_want, term_want) {
    .cx %>% filter(kind == kind_want, term == term_want) %>%
      transmute(model = crossed_model,
                crossed_estimate = estimate, crossed_se = std.error,
                crossed_statistic = statistic, crossed_p = p.value,
                crossed_df = df, crossed_n = n_obs,
                crossed_singular = fit_singular, crossed_convergence_messages = convergence_messages,
                crossed_diagnostic_status = fit_diagnostic_status)
  }
  .d5_check <- function(d, nm) {
    n_ok <- sum(!is.na(d$crossed_estimate))
    cat(sprintf("    %-46s crossed rows landed: %d of %d\n", nm, n_ok, nrow(d)))
    if (n_ok == 0) {
      warning("D5 propagation: no crossed estimate landed in ", nm,
              " -- model keys probably do not match. Table models: ",
              paste(sort(unique(d$model)), collapse = "; "),
              call. = FALSE, immediate. = TRUE)
    }
    d
  }

  for (.tbl in c("condition2_mean_paired_t_table", "condition2_mean_lm_table",
                 "condition2_confidence_item_lm_table")) {
    if (!exists(.tbl)) next
    cat(sprintf("    %-46s table models: %s\n", .tbl,
                paste(sort(unique(get(.tbl)$model)), collapse = " | ")))
  }

  # 1. directional bias -> paired t table
  if (exists("condition2_mean_paired_t_table")) {
    d <- condition2_mean_paired_t_table %>%
      left_join(.pick("directional bias", "(Intercept)"), by = "model") %>%
      mutate(.joinable = scope == "country" & dataset_type == "discrete") %>%
      mutate(across(c(crossed_estimate, crossed_se, crossed_statistic, crossed_p, crossed_df, crossed_n),
                    ~ ifelse(.joinable, .x, NA_real_)),
             crossed_singular = ifelse(.joinable, crossed_singular, NA),
             crossed_convergence_messages = ifelse(.joinable, crossed_convergence_messages, NA_character_),
             crossed_diagnostic_status = ifelse(.joinable, crossed_diagnostic_status, "not_fitted_for_this_scope"),
             crossed_spec = ifelse(.joinable,
               "lmer(mean_error ~ 1 + (1|country_folder) + (1|item))",
               "not fitted: crossed model applies to country-scope discrete only"),
             p_crosses_05 = !is.na(crossed_p) & ((p < .05) != (crossed_p < .05))) %>%
      dplyr::select(-.joinable)
    condition2_mean_paired_t_table <- .d5_check(d, "condition2_mean_paired_t_table")
    write_csv(condition2_mean_paired_t_table,
              file.path(out_dir, "PAPER_condition2_mean_paired_t_tests_gpt_llama.csv"))
  }
  # 2. mean correspondence -> mean lm table
  if (exists("condition2_mean_lm_table")) {
    d <- condition2_mean_lm_table %>%
      left_join(.pick("mean correspondence", ".x"), by = "model") %>%
      mutate(.joinable = scope == "country" & dataset_type == "discrete") %>%
      mutate(across(c(crossed_estimate, crossed_se, crossed_statistic, crossed_p, crossed_df, crossed_n),
                    ~ ifelse(.joinable, .x, NA_real_)),
             crossed_singular = ifelse(.joinable, crossed_singular, NA),
             crossed_convergence_messages = ifelse(.joinable, crossed_convergence_messages, NA_character_),
             crossed_diagnostic_status = ifelse(.joinable, crossed_diagnostic_status, "not_fitted_for_this_scope"),
             crossed_spec = ifelse(.joinable,
               "lmer(human_mean ~ pred_mean + (1|country_folder) + (1|item))",
               "not fitted: crossed model applies to country-scope discrete only"),
             p_crosses_05 = !is.na(crossed_p) & ((p < .05) != (crossed_p < .05))) %>%
      dplyr::select(-.joinable)
    condition2_mean_lm_table <- .d5_check(d, "condition2_mean_lm_table")
    write_csv(condition2_mean_lm_table,
              file.path(out_dir, "PAPER_condition2_mean_lm_with_beta_gpt_llama.csv"))
  }
  # 3. confidence item table
  if (exists("condition2_confidence_item_lm_table")) {
    .err <- .pick("confidence -> error", ".x") %>%
      rename_with(~paste0(.x, "_err"), -model)
    .sdd <- .pick("confidence -> human_sd", ".x") %>%
      rename_with(~paste0(.x, "_sd"), -model)
    d <- condition2_confidence_item_lm_table %>%
      left_join(.err, by = "model") %>% left_join(.sdd, by = "model") %>%
      mutate(
        crossed_estimate = dplyr::case_when(
          outcome == "mean_abs_error"     ~ crossed_estimate_err,
          outcome == "alignment_accuracy" ~ -crossed_estimate_err,
          outcome == "human_sd"           ~ crossed_estimate_sd, TRUE ~ NA_real_),
        crossed_se = dplyr::case_when(
          outcome %in% c("mean_abs_error", "alignment_accuracy") ~ crossed_se_err,
          outcome == "human_sd" ~ crossed_se_sd, TRUE ~ NA_real_),
        crossed_statistic = dplyr::case_when(
          outcome == "mean_abs_error"     ~ crossed_statistic_err,
          outcome == "alignment_accuracy" ~ -crossed_statistic_err,
          outcome == "human_sd"           ~ crossed_statistic_sd, TRUE ~ NA_real_),
        crossed_p = dplyr::case_when(
          outcome %in% c("mean_abs_error", "alignment_accuracy") ~ crossed_p_err,
          outcome == "human_sd" ~ crossed_p_sd, TRUE ~ NA_real_),
        crossed_df = case_when(
          outcome %in% c("mean_abs_error", "alignment_accuracy") ~ crossed_df_err,
          outcome == "human_sd" ~ crossed_df_sd, TRUE ~ NA_real_),
        crossed_singular = if_else(outcome == "human_sd", crossed_singular_sd, crossed_singular_err),
        crossed_convergence_messages = if_else(outcome == "human_sd", crossed_convergence_messages_sd, crossed_convergence_messages_err),
        crossed_diagnostic_status = if_else(outcome == "human_sd", crossed_diagnostic_status_sd, crossed_diagnostic_status_err),
        crossed_n = case_when(
          outcome %in% c("mean_abs_error", "alignment_accuracy") ~ crossed_n_err,
          outcome == "human_sd" ~ crossed_n_sd, TRUE ~ NA_real_)) %>%
      dplyr::select(-ends_with("_err"), -ends_with("_sd")) %>%
      mutate(.joinable = scope == "country" & dataset_type == "discrete") %>%
      mutate(across(c(crossed_estimate, crossed_se, crossed_statistic, crossed_p, crossed_df, crossed_n),
                    ~ ifelse(.joinable, .x, NA_real_)),
             crossed_singular = ifelse(.joinable, crossed_singular, NA),
             crossed_convergence_messages = ifelse(.joinable, crossed_convergence_messages, NA_character_),
             crossed_diagnostic_status = ifelse(.joinable, crossed_diagnostic_status, "not_fitted_for_this_scope"),
             crossed_spec = ifelse(.joinable,
               "lmer(outcome ~ confidence + (1|country_folder) + (1|item))",
               "not fitted: crossed model applies to country-scope discrete only"),
             p_crosses_05 = !is.na(crossed_p) & ((p < .05) != (crossed_p < .05))) %>%
      dplyr::select(-.joinable)
    condition2_confidence_item_lm_table <- .d5_check(d, "condition2_confidence_item_lm_table")
    write_csv(condition2_confidence_item_lm_table,
              file.path(out_dir, "PAPER_condition2_confidence_item_lm_with_beta_gpt_llama.csv"))
  }
}


# Persona covariance robustness
issp_persona_psd_robustness <- function(fit, covariance, data, focal = "pred_q1") {
  # Step 1: check matrix shape, names and finite entries before decomposing it.
  V <- as.matrix(covariance)
  if (!is.numeric(V) || nrow(V) != ncol(V) || !nrow(V) ||
      any(!is.finite(V)) || is.null(rownames(V)) ||
      !identical(rownames(V), colnames(V)) || anyDuplicated(rownames(V))) {
    stop("Persona PSD robustness requires a finite, square, named covariance matrix.")
  }
  if (!all(c("participant_uid", "item") %in% names(data)) ||
      anyNA(data$participant_uid) || anyNA(data$item) ||
      nrow(data) != stats::nobs(fit)) {
    stop("Persona PSD robustness requires complete cluster IDs on the exact fitted rows.")
  }
  beta <- stats::coef(fit)
  if (length(focal) != 1L || is.na(focal) ||
      !(focal %in% rownames(V)) || !(focal %in% names(beta)) ||
      !is.finite(beta[[focal]])) {
    stop("Persona PSD robustness could not identify a finite focal coefficient.")
  }

  # Step 2: retain the primary reference df and all original coefficient estimates.
  n_participants <- length(unique(data$participant_uid))
  n_items <- length(unique(data$item))
  reference_df <- min(n_participants, n_items) - 1L
  if (reference_df < 2L) stop("Too few clusters for persona PSD robustness.")

  # Step 3: a covariance is symmetric. Refuse substantive asymmetry; symmetrize floating-point noise.
  scale_V <- max(1, abs(V))
  if (max(abs(V - t(V))) > 1e-10 * scale_V) {
    stop("Persona PSD robustness covariance is not symmetric within tolerance.")
  }
  V <- (V + t(V)) / 2
  eig <- eigen(V, symmetric = TRUE)
  negative <- eig$values < 0
  tolerance <- 1e-10 * max(1, abs(eig$values))
  V_psd <- V
  if (any(negative)) {
   
    V_psd[] <- crossprod(sqrt(pmax(eig$values, 0)) * t(eig$vectors))
  }
  corrected_eigenvalues <- eigen(V_psd, symmetric = TRUE, only.values = TRUE)$values
  if (min(corrected_eigenvalues) < -tolerance) {
    stop("Persona PSD correction failed the numerical PSD check.")
  }

  # Step 4: use the same estimate and df with the two focal variances
  focal_variances <- c(V[focal, focal], V_psd[focal, focal])
  if (any(!is.finite(focal_variances)) || any(focal_variances <= 0)) {
    stop("Persona PSD robustness requires positive finite focal variances.")
  }
  se <- sqrt(focal_variances)
  estimate <- unname(beta[[focal]])
  statistic <- estimate / se
  p_value <- 2 * stats::pt(-abs(statistic), df = reference_df)
  critical <- stats::qt(.975, df = reference_df)
  result <- data.frame(
    analysis = "persona_participant_item_correspondence",
    term = focal,
    method = c("two_way_HC0_original", "two_way_HC0_PSD_corrected"),
    estimate = estimate,
    std_error_clustered = se,
    t = statistic, df_cluster = reference_df, p_value = p_value,
    ci_low = estimate - critical * se,
    ci_high = estimate + critical * se,
    p_adjustment = "none; sensitivity comparison for the same focal coefficient",
    significant_05_unadjusted = p_value < .05,
    n_obs = stats::nobs(fit), n_participants = n_participants, n_items = n_items,
    clustering = "two-way: country-specific participant UID and item",
    inference = "two-way HC0; t with min(cluster counts)-1 df (approximate)",
    covariance_psd = c(min(eig$values), min(corrected_eigenvalues)) >= -tolerance,
    min_eigenvalue = c(min(eig$values), min(corrected_eigenvalues)),
    covariance_eigen_tolerance = tolerance,
    negative_eigenvalues_before = sum(negative),
    materially_negative_eigenvalues_before = sum(eig$values < -tolerance),
    eigenvalues_clipped = c(0L, sum(negative)),
    correction_applied = c(FALSE, any(negative)),
    covariance_change_frobenius = c(0, sqrt(sum((V_psd - V)^2))),
    se_ratio_to_original = se / se[1],
    p_difference_from_original = p_value - p_value[1],
    same_05_conclusion_as_original = (p_value < .05) == (p_value[1] < .05),
    note = c("original primary covariance; retained for comparison",
             "additional robustness check; fitted model and coefficient unchanged"),
    stringsAsFactors = FALSE
  )
  result
}

if (exists("demographic_participant_item_level") && issp_have_cluster) {
  cat("\n-- E6 persona participant-item model (full data, two-way clustered SEs) --\n")
  pd <- demographic_participant_item_level %>%
    filter(dataset_type == "discrete", !is.na(pred_q1), !is.na(human_response))
  cat("  rows:", nrow(pd), " participants:", n_distinct(pd$participant_uid),
      " items:", n_distinct(pd$item), " countries:", n_distinct(pd$country_folder), "\n")

  if (nrow(pd) > 1000) {
    pfit <- stats::lm(
      human_response ~ pred_q1 + factor(country_folder) + factor(item),
      data = pd
    )
    cl <- try(sandwich::vcovCL(
      pfit, cluster = ~ participant_uid + item, type = "HC0"
    ),
              silent = TRUE)
    if (!inherits(cl, "try-error")) {
      ct <- issp_cluster_test(pfit, cl, pd, "persona_mean", "pred_q1")
      issp_persona_clustered <- tibble(
        term = rownames(ct), estimate = ct[, 1], std_error_clustered = ct[, 2],
        t = ct[, 3], p_value = ct[, 4],
        df_cluster = attr(ct, "cluster_df"),
        ci_low = ct[, 1] - stats::qt(.975, df_cluster) * ct[, 2],
        ci_high = ct[, 1] + stats::qt(.975, df_cluster) * ct[, 2],
        inference = "two-way HC0; t with min(cluster counts)-1 df (approximate)",
        inference_valid = is.finite(ct[, 2]),
        std_error_naive = summary(pfit)$coefficients[, 2],
        n_obs = nrow(pd), n_participants = n_distinct(pd$participant_uid),
        n_items = n_distinct(pd$item),
        clustering = "two-way: country-specific participant UID and item",
        note = "full data, no subsampling; country and item fixed effects"
      ) %>%
        left_join(attr(ct, "covariance_diagnostics"), by = "term") %>%
        mutate(se_inflation_vs_naive = std_error_clustered / std_error_naive)
      readr::write_csv(issp_persona_clustered,
                       file.path(out_dir, "PAPER_partE_persona_clustered_se.csv"))

      issp_persona_covariance_robustness <- issp_persona_psd_robustness(
        fit = pfit, covariance = cl, data = pd, focal = "pred_q1"
      )
      utils::write.csv(
        issp_persona_covariance_robustness,
        file.path(out_dir, "PAPER_partE_persona_covariance_robustness.csv"),
        row.names = FALSE
      )
      cat("\n  Persona correspondence: original versus PSD-corrected covariance:\n")
      print(issp_persona_covariance_robustness[, c(
        "method", "term", "estimate", "std_error_clustered", "df_cluster",
        "ci_low", "ci_high", "p_value", "covariance_psd",
        "se_ratio_to_original", "same_05_conclusion_as_original"
      )], row.names = FALSE)

      cat("  Clustered SE model written. SE inflation vs naive:\n")
      print(as.data.frame(issp_persona_clustered %>%
        dplyr::select(term, estimate, std_error_naive, std_error_clustered,
                      se_inflation_vs_naive) %>%
        mutate(across(where(is.numeric), ~ signif(.x, 4)))))
      issp_audit_record(
        "Part E persona model", "fixed effects with two-way clustered SEs on full data",
        rows_in = nrow(demographic_participant_item_level), rows_out = nrow(pd),
        reason = "use the full analysis sample with country and item fixed effects and standard errors clustered by participant and item",
        detail = "country and item fixed effects; clusters: country-specific participant UID and item"
      )
    } else {
      stop("vcovCL failed for the full-data persona model; clustered SEs were not computed.")
    }
  } else {
    stop("The persona participant-item frame has too few rows for the required full-data model.")
  }
}

issp_e1_contrasts <- NULL
if (issp_have_lmer && issp_have_emmeans && exists("issp_distribution_distances")) {
  cat("\n-- E1 method contrasts (ISSP) --\n")
  ISSP_CORE_METHODS <- c(
    "repeated_sampling",
    "proportions",
    "distribution_mean_sd",
    "distribution_full",
    "hybrid_mean_sd"
  )
  base <- issp_distribution_distances %>%
    filter(
      dataset_type == "discrete", scope == "country",
      method %in% ISSP_CORE_METHODS
    ) %>%
    filter(if_all(all_of(ISSP_METRICS), ~ !is.na(.x)))
  meths <- ISSP_CORE_METHODS
  matched <- base %>%
    group_by(model_family, model, country_folder, item) %>%
    filter(n_distinct(method) == length(meths)) %>%
    ungroup() %>%
    mutate(method = factor(method, levels = meths))

  e1_issp_coverage <- base %>%
    distinct(model_family, model, country_folder, item, method) %>%
    group_by(model_family, model) %>%
    summarise(
      available_method_cells = n(),
      available_country_item_cells = n_distinct(paste(country_folder, item)),
      .groups = "drop"
    ) %>%
    left_join(
      matched %>%
        distinct(model_family, model, country_folder, item) %>%
        count(model_family, model, name = "complete_country_item_cells"),
      by = c("model_family", "model")
    ) %>%
    mutate(complete_country_item_cells = replace_na(complete_country_item_cells, 0L))
  readr::write_csv(
    e1_issp_coverage,
    file.path(out_dir, "CHECK_E1_issp_core_method_coverage.csv")
  )

  if (!setequal(unique(matched$model_family), model_families_to_keep)) {
    stop(
      "E1 matched coverage must retain both GPT and Llama for the five core methods; ",
      "see CHECK_E1_issp_core_method_coverage.csv."
    )
  }
  cat("  methods:", length(meths), " matched rows:", nrow(matched),
      " items:", n_distinct(matched$item), " countries:", n_distinct(matched$country_folder), "\n")

  rows <- list()
  for (mdl in sort(unique(matched$model))) {
    for (met in ISSP_METRICS) {
      d <- matched %>% filter(model == mdl) %>% mutate(.y = .data[[met]])
      if (n_distinct(d$method) < 2) next
      f <- try(lmerTest::lmer(.y ~ method + (1 | item) + (1 | country_folder), data = d),
               silent = TRUE)
      if (inherits(f, "try-error")) next
      emm <- try(emmeans::emmeans(f, ~ method), silent = TRUE)
      if (inherits(emm, "try-error")) next
      normalise_ci_cols <- function(x) {
        if (inherits(x, "try-error")) return(x)
        if (!"lower.CL" %in% names(x) && "asymp.LCL" %in% names(x)) {
          names(x)[names(x) == "asymp.LCL"] <- "lower.CL"
          names(x)[names(x) == "asymp.UCL"] <- "upper.CL"
        }
        x
      }
      ch <- normalise_ci_cols(try(as.data.frame(summary(
        emmeans::contrast(emm, "pairwise", adjust = "holm"), infer = c(TRUE, TRUE))), silent = TRUE))
      cn <- normalise_ci_cols(try(as.data.frame(summary(
        emmeans::contrast(emm, "pairwise", adjust = "none"), infer = c(TRUE, TRUE))), silent = TRUE))
      if (inherits(ch, "try-error") || !"lower.CL" %in% names(ch)) next
      rows[[length(rows) + 1]] <- ch %>%
        mutate(model = mdl, metric = met, !!!as.list(model_fit_diagnostics(f)),
               p_holm = p.value,
               p_raw = if (!inherits(cn, "try-error")) cn$p.value else NA_real_,
               ci_low_simultaneous = lower.CL, ci_high_simultaneous = upper.CL,
               ci_low_unadjusted = if (!inherits(cn, "try-error")) cn$lower.CL else NA_real_,
               ci_high_unadjusted = if (!inherits(cn, "try-error")) cn$upper.CL else NA_real_,
               residual_sd = stats::sigma(f),
               std_contrast_resid_sd = estimate / stats::sigma(f),
               .before = 1)
    }
  }
  if (length(rows) > 0) {
    issp_e1_contrasts <- bind_rows(rows)
    expected_e1_contrasts <- n_distinct(matched$model) *
      length(ISSP_METRICS) * choose(length(meths), 2)
    if (nrow(issp_e1_contrasts) != expected_e1_contrasts) {
      readr::write_csv(
        issp_e1_contrasts,
        file.path(out_dir, "CHECK_E1_incomplete_method_contrasts_issp.csv")
      )
      stop(
        "ISSP E1 produced ", nrow(issp_e1_contrasts), " contrasts; expected ",
        expected_e1_contrasts,
        ". See CHECK_E1_incomplete_method_contrasts_issp.csv."
      )
    }
    readr::write_csv(issp_e1_contrasts, file.path(out_dir, "PAPER_partE_method_contrasts_issp.csv"))
    cat("  contrasts:", nrow(issp_e1_contrasts),
        " significant after Holm:", sum(issp_e1_contrasts$p_holm < .05, na.rm = TRUE), "\n")
    issp_audit_record(
      "Part E ISSP contrasts", "restrict to items where every method produced output",
      rows_in = nrow(base), rows_out = nrow(matched),
      reason = "unmatched items would let a method look better by being scored on an easier subset",
      detail = paste0(length(meths), " core methods required; Persona is reported separately")
    )
  } else {
    stop("ISSP E1 did not produce any method contrasts.")
  }
}



# Holm correction across the ISSP families
issp_prepare_reporting <- function(x, object_name) {
  if (object_name == "condition2_mean_paired_t_table") {
    x <- x %>% mutate(b = mean_difference,
      se = (ci_high - ci_low) / (2 * stats::qt(.975, df)))
  }
  x <- x %>% mutate(
    primary_b = b, primary_se = se, primary_t = t, primary_df = df,
    primary_p = p, primary_ci_low = ci_low, primary_ci_high = ci_high,
    primary_n = n, primary_inference = "ordinary regression / paired test",
    primary_diagnostic_status = "ordinary_model_no_covariance_audit",
    primary_singular = NA, primary_convergence_messages = "",
    covariance_psd = NA, covariance_negative_variances = NA_integer_,
    min_eigenvalue = NA_real_, focal_variance_valid = is.finite(se) & se > 0
  )
  if ("crossed_p" %in% names(x)) {
    use <- x$scope == "country" & x$dataset_type == "discrete"
    if (any(use & (!is.finite(x$crossed_p) | !is.finite(x$crossed_df))))
      stop("Missing crossed inference in ", object_name)
    x$primary_b[use] <- x$crossed_estimate[use]
    x$primary_se[use] <- x$crossed_se[use]
    x$focal_variance_valid[use] <- is.finite(x$primary_se[use]) & x$primary_se[use] > 0
    x$primary_t[use] <- x$crossed_statistic[use]
    x$primary_df[use] <- x$crossed_df[use]
    x$primary_p[use] <- x$crossed_p[use]
    x$primary_n[use] <- x$crossed_n[use]
    q <- stats::qt(.975, x$primary_df[use])
    x$primary_ci_low[use] <- x$primary_b[use] - q * x$primary_se[use]
    x$primary_ci_high[use] <- x$primary_b[use] + q * x$primary_se[use]
    x$primary_inference[use] <- "crossed country/item random intercepts; Satterthwaite"
    x$primary_diagnostic_status[use] <- x$crossed_diagnostic_status[use]
    x$primary_singular[use] <- x$crossed_singular[use]
    x$primary_convergence_messages[use] <- x$crossed_convergence_messages[use]
  } else if (all(c("scope", "dataset_type") %in% names(x)) &&
             any(x$scope == "country" & x$dataset_type == "discrete")) {
    stop("Crossed inference absent in ", object_name)
  }
  if (object_name == "persona_participant_item_confidence_lm") {
    pc <- persona_participant_item_confidence_clustered %>% filter(term == "pred_confidence_q2")
    if (nrow(pc) != 1L || !is.finite(pc$p_clustered))
      stop("Persona clustered confidence inference is unavailable.")
    x <- x %>% mutate(primary_b = pc$estimate, primary_se = pc$std_error_clustered,
      primary_t = pc$t_clustered, primary_df = pc$df_cluster, primary_p = pc$p_clustered,
      primary_ci_low = pc$ci_low, primary_ci_high = pc$ci_high,
      primary_n = pc$n_obs, primary_inference = pc$inference,
      primary_diagnostic_status = pc$covariance_status,
      covariance_psd = pc$covariance_psd, covariance_negative_variances = pc$covariance_negative_variances,
      min_eigenvalue = pc$min_eigenvalue, focal_variance_valid = pc$focal_variance_valid)
  }
  x
}

issp_holm_targets <- tribble(
  ~object, ~family, ~filename,
  "condition2_mean_paired_t_table", "issp_mean_prediction", "PAPER_condition2_mean_paired_t_tests_gpt_llama.csv",
  "condition2_mean_lm_table", "issp_mean_prediction", "PAPER_condition2_mean_lm_with_beta_gpt_llama.csv",
  "condition2_confidence_item_lm_table", "issp_confidence", "PAPER_condition2_confidence_item_lm_with_beta_gpt_llama.csv",
  "country_confidence_lm_table", "issp_confidence", "PAPER_country_aggregated_confidence_lm_gpt_llama.csv",
  "persona_country_confidence_participant_balanced_lm", "issp_persona", "PAPER_persona_country_confidence_participant_balanced_lm_llama.csv",
  "persona_participant_item_confidence_lm", "issp_persona", "PAPER_persona_participant_item_confidence_final.csv"
)

.issp_reporting_env <- environment()
issp_registry <- list()
for (j in seq_len(nrow(issp_holm_targets))) {
  nm <- issp_holm_targets$object[j]
  x <- issp_prepare_reporting(get(nm, envir = .issp_reporting_env, inherits = FALSE), nm)
  assign(nm, x, envir = .issp_reporting_env)
  keys <- intersect(c("model", "scope", "dataset_type", "condition_name", "predictor", "outcome", "term"), names(x))
  keydata <- as.data.frame(x[, keys, drop = FALSE])
  if ("outcome" %in% names(keydata)) {
    keydata$outcome <- as.character(keydata$outcome)
    keydata$outcome[keydata$outcome == "alignment_accuracy"] <- "mean_abs_error"
    keydata$outcome[keydata$outcome == "mean_alignment_accuracy"] <- "mean_abs_error"
  }
  key_text <- if (length(keys)) apply(keydata, 1, paste, collapse = " | ") else rep("", nrow(x))
  hypothesis <- paste(nm, key_text, sep = " | ")
  issp_registry[[j]] <- tibble(object = nm, family = issp_holm_targets$family[j],
    row_index = seq_len(nrow(x)), hypothesis_id = hypothesis,
    p_naive = x$p, p_primary = x$primary_p, inference = x$primary_inference)
}
issp_registry <- bind_rows(issp_registry)
duplicate_hypotheses <- issp_registry %>% group_by(family, hypothesis_id) %>%
  summarise(p_spread = if (all(is.na(p_primary))) 0 else diff(range(p_primary, na.rm = TRUE)), .groups = "drop")
stopifnot(all(duplicate_hypotheses$p_spread < 1e-10))
issp_unique_tests <- issp_registry %>% distinct(family, hypothesis_id, .keep_all = TRUE) %>%
  group_by(family) %>% mutate(
    n_planned = n(), n_tested = sum(!is.na(p_primary)),
    n_in_family = n_tested,
    holm_policy = "Holm over estimable unique hypotheses; NA tests excluded",
    p_holm = p.adjust(p_primary, "holm", n = sum(!is.na(p_primary)))
  ) %>% ungroup()
issp_e3_corrections <- issp_registry %>%
  left_join(issp_unique_tests %>% select(family, hypothesis_id, n_planned, n_tested, n_in_family, holm_policy, p_holm),
            by = c("family", "hypothesis_id")) %>%
  mutate(p_raw = p_primary, sig_raw = p_primary < .05, sig_holm = p_holm < .05,
         flipped_by_correction = sig_raw & !sig_holm)
write_csv(issp_e3_corrections, file.path(out_dir, "PAPER_partE_multiple_comparison_corrections_issp.csv"))
for (j in seq_len(nrow(issp_holm_targets))) {
  nm <- issp_holm_targets$object[j]
  x <- get(nm, envir = .issp_reporting_env, inherits = FALSE) %>% mutate(row_index = row_number()) %>%
    left_join(issp_e3_corrections %>% filter(object == nm) %>%
                select(row_index, hypothesis_id, family, n_planned, n_tested, n_in_family, holm_policy, p_holm), by = "row_index") %>%
    select(-row_index)
  assign(nm, x, envir = .issp_reporting_env)
  write_csv(x, file.path(out_dir, issp_holm_targets$filename[j]))
}
cat("\nISSP Holm families, unique hypotheses and primary inference:\n")
print(issp_unique_tests %>% count(family, inference, name = "n_unique_hypotheses"), n = Inf)

issp_compact_rows <- function(x, level, predictor_label, outcome_label) {
  x %>% transmute(model_family, model, analysis_level = level,
    predictor = predictor_label, outcome = outcome_label, r,
    b = primary_b, beta = if_else(primary_inference == "ordinary regression / paired test", beta, NA_real_),
    se = primary_se, t = primary_t, df = primary_df, p = primary_p,
    p_holm, p_formatted = p_format(primary_p), ci_low = primary_ci_low,
    ci_high = primary_ci_high, n = primary_n, inference = primary_inference,
    hypothesis_id, family, n_planned, n_tested, n_in_family, holm_policy,
    primary_diagnostic_status, primary_singular, primary_convergence_messages,
    covariance_psd, covariance_negative_variances, min_eigenvalue, focal_variance_valid)
}
paper_confidence_compact_table <- bind_rows(
  local({x <- condition2_confidence_item_lm_table %>%
    filter(dataset_type == "discrete", scope %in% c("country", "global"),
           outcome %in% c("mean_abs_error", "human_sd"))
    issp_compact_rows(x, ifelse(x$scope == "country", "Country-item", "Global item"),
      "Condition 2 confidence", recode(x$outcome, mean_abs_error = "Absolute error", human_sd = "Human SD"))}),
  local({x <- country_confidence_lm_table %>% filter(dataset_type == "discrete",
    outcome %in% c("mean_abs_error", "mean_human_sd"))
    issp_compact_rows(x, "Country aggregate", "Condition 2 mean country confidence",
      recode(x$outcome, mean_abs_error = "Absolute error", mean_human_sd = "Mean human SD"))}),
  issp_compact_rows(persona_participant_item_confidence_lm, "Persona participant-item",
                    "Persona confidence", "Absolute error"),
  local({x <- persona_country_confidence_participant_balanced_lm %>%
    mutate(model_family = "llama", model = first(persona_participant_item_confidence_summary$model))
    issp_compact_rows(x, "Persona country aggregate", "Country mean participant confidence",
                      "Country mean participant absolute error")})
) %>% mutate(Model = case_when(model_family == "gpt" ~ "GPT-4.1",
                              model_family == "llama" ~ "Llama-3.3-70B", TRUE ~ model)) %>%
  select(Model, everything(), -model_family, -model)
write_csv(paper_confidence_compact_table,
          file.path(out_dir, "PAPER_confidence_compact_table_issp_gpt_llama.csv"))
cat("\nFinal compact confidence table (selected inference and Holm):\n")
print(paper_confidence_compact_table, n = Inf, width = Inf)

paper_mean_judgment_correspondence_table <- condition2_mean_lm_table %>%
  filter(dataset_type == "discrete", scope %in% c("country", "global")) %>%
  left_join(confidence_summary_scope_type %>%
    filter(condition_name == "mean_confidence", dataset_type == "discrete") %>%
    select(model_family, model, scope, dataset_type, mse, mae),
    by = c("model_family", "model", "scope", "dataset_type")) %>%
  transmute(Model = case_when(model_family == "gpt" ~ "GPT-4.1",
      model_family == "llama" ~ "Llama-3.3-70B", TRUE ~ model),
    Level = recode(scope, country = "Country", global = "Global"),
    r = round(r, 3), MSE = round(mse, 3), MAE = round(mae, 3), N = primary_n,
    b = round(primary_b, 3),
    beta = if_else(primary_inference == "ordinary regression / paired test", round(beta, 3), NA_real_),
    SE = round(primary_se, 3), t = round(primary_t, 2), df = primary_df,
    p = primary_p, p_formatted = p_format(primary_p), p_holm,
    ci_low = round(primary_ci_low, 3), ci_high = round(primary_ci_high, 3),
    n_complete = primary_n, inference = primary_inference,
    hypothesis_id, family, n_planned, n_tested, n_in_family, holm_policy,
    primary_diagnostic_status, primary_singular, primary_convergence_messages,
    covariance_psd, covariance_negative_variances, min_eigenvalue, focal_variance_valid) %>%
  arrange(Model, Level)
write_csv(paper_mean_judgment_correspondence_table,
  file.path(out_dir, "PAPER_mean_judgment_correspondence_table_issp.csv"))
cat("\nFinal paper mean correspondence (selected inference and Holm):\n")
print(paper_mean_judgment_correspondence_table, n = Inf, width = Inf)

# ITEM COVERAGE PER MODEL x METHOD
cat("\n", strrep("=", 80),
    "\nPART C1 — ITEM COVERAGE PER MODEL x METHOD\n", strrep("=", 80), "\n")

c1_source_props <- bind_rows(
  repeated_model_props   %>% mutate(.src = "repeated_sampling"),
  prop_model_props       %>% mutate(.src = "proportions"),
  mean_sd_model_props    %>% mutate(.src = "distribution_mean_sd"),
  full_model_props       %>% mutate(.src = "distribution_full"),
  hybrid_model_props     %>% mutate(.src = "hybrid_mean_sd"),
  demographic_model_props %>% mutate(.src = "demographic_distribution")
) %>%
  filter(model_family %in% model_families_to_keep) %>%
  mutate(dataset_type = issp_dataset_type(item)) %>%
  filter(dataset_type == "discrete")

c1_expected_items <- numeric_discrete_ids
c1_core_methods <- c(
  "repeated_sampling", "proportions", "distribution_mean_sd",
  "distribution_full", "hybrid_mean_sd"
)
c1_model_scopes <- tidyr::crossing(
  c1_source_props %>% distinct(model_family, model),
  scope = c("country", "global")
)

c1_expected_cells <- purrr::pmap_dfr(
  c1_model_scopes,
  function(model_family, model, scope) {
    expected_countries <- if (scope == "country") issp_countries else "Global"
    expected_methods <- c1_core_methods
    if (model_family == "llama") {
      expected_methods <- c(expected_methods, "demographic_distribution")
    }
    tidyr::crossing(
      country_folder = expected_countries,
      item = c1_expected_items,
      method = expected_methods
    ) %>%
      mutate(
        model_family = .env$model_family,
        model = .env$model,
        scope = .env$scope,
        .before = 1
      )
  }
)

c1_source_available <- c1_source_props %>%
  transmute(
    model_family, model, scope, country_folder, item,
    method = .src,
    source_present = TRUE
  ) %>%
  distinct()

c1_usable_available <- issp_distribution_distances %>%
  filter(dataset_type == "discrete", if_all(all_of(ISSP_METRICS), ~ !is.na(.x))) %>%
  transmute(
    model_family, model, scope, country_folder, item, method,
    usable_distance = TRUE
  ) %>%
  distinct()

c1_cell_grid <- c1_expected_cells %>%
  left_join(
    c1_source_available,
    by = c("model_family", "model", "scope", "country_folder", "item", "method")
  ) %>%
  left_join(
    c1_usable_available,
    by = c("model_family", "model", "scope", "country_folder", "item", "method")
  ) %>%
  mutate(
    source_present = replace_na(source_present, FALSE),
    usable_distance = replace_na(usable_distance, FALSE)
  )

c1_item_completeness <- c1_cell_grid %>%
  group_by(model_family, model, scope, method, item) %>%
  summarise(
    source_complete_all_countries = all(source_present),
    usable_complete_all_countries = all(usable_distance),
    .groups = "drop"
  ) %>%
  group_by(model_family, model, scope, method) %>%
  summarise(
    items_source_complete_all_countries = sum(source_complete_all_countries),
    items_usable_complete_all_countries = sum(usable_complete_all_countries),
    .groups = "drop"
  )

c1_coverage <- c1_cell_grid %>%
  group_by(model_family, model, scope, method) %>%
  summarise(
    expected_cells = n(),
    source_cells = sum(source_present),
    usable_cells = sum(usable_distance),
    missing_source_cells = expected_cells - source_cells,
    missing_usable_cells = expected_cells - usable_cells,
    coverage_rate = usable_cells / expected_cells,
    expected_items = n_distinct(item),
    items_with_any_source = n_distinct(item[source_present]),
    items_with_any_usable_distance = n_distinct(item[usable_distance]),
    .groups = "drop"
  ) %>%
  left_join(
    c1_item_completeness,
    by = c("model_family", "model", "scope", "method")
  ) %>%
  arrange(model, scope, method)

write_csv(c1_coverage, file.path(out_dir, "PAPER_C1_item_coverage_by_model_method.csv"))
write_csv(
  c1_coverage,
  file.path(out_dir, "PAPER_C1_cell_coverage_by_model_method.csv")
)
write_csv(
  c1_cell_grid %>% filter(!source_present | !usable_distance),
  file.path(out_dir, "CHECK_C1_missing_cells.csv")
)

cat("\n  Country-item-method cell coverage:\n")
print(as.data.frame(c1_coverage))

c1_common_cells <- c1_cell_grid %>%
  group_by(model_family, model, scope, country_folder, item) %>%
  summarise(
    expected_methods = n(),
    available_methods = sum(usable_distance),
    complete_method_intersection = all(usable_distance),
    .groups = "drop"
  )

c1_intersection <- c1_common_cells %>%
  group_by(model_family, model, scope) %>%
  summarise(
    expected_country_item_cells = n(),
    complete_country_item_cells = sum(complete_method_intersection),
    cells_lost_to_intersection = expected_country_item_cells - complete_country_item_cells,
    .groups = "drop"
  )
write_csv(
  c1_intersection,
  file.path(out_dir, "PAPER_C1_common_cell_intersection.csv")
)
cat("\n  Cost of the intersection:\n")
print(as.data.frame(c1_intersection))

issp_audit_record(
  "C1 cell set", "compare usable rows with the full expected country x item x method grid",
  rows_in = nrow(c1_cell_grid),
  rows_out = sum(c1_cell_grid$usable_distance),
  unmatched_keys = sum(!c1_cell_grid$usable_distance),
  reason = "item-name counts conceal missing country-item-method cells",
  detail = paste0(
    sum(!c1_cell_grid$source_present), " source cells missing; ",
    sum(!c1_cell_grid$usable_distance), " usable distance cells missing"
  )
)

# CROSS-NATIONAL DECOMPOSITION
cat("\n", strrep("=", 80),
    "\nPART C3 — CROSS-NATIONAL DECOMPOSITION\n", strrep("=", 80), "\n")

c3_base <- confidence_item_level %>%
  filter(condition_name == "mean_confidence", scope == "country",
         dataset_type == "discrete",
         !is.na(pred_mean), !is.na(human_mean), !is.na(item), !is.na(country_folder))

cat("  Frame:", n_distinct(c3_base$item), "items x",
    n_distinct(c3_base$country_folder), "countries x",
    n_distinct(c3_base$model), "models;", nrow(c3_base), "rows\n")

c3_variance_one <- function(d, source_label) {
  d <- d %>% filter(!is.na(.value))
  unavailable <- function(status, message) tibble(
    source = source_label,
    n_obs = nrow(d), n_items = n_distinct(d$item), n_countries = n_distinct(d$country_folder),
    var_item = NA_real_, var_country = NA_real_, var_residual = NA_real_,
    singular = NA, convergence_message = NA_character_,
    share_of_item_plus_country = NA_real_, share_of_total = NA_real_,
    fit_status = status, failure_message = message)
  if (nrow(d) < 50) return(unavailable("not_fitted_insufficient_rows", "Fewer than 50 usable observations"))
  if (!issp_have_lmer) return(unavailable("not_fitted_missing_package", "lme4/lmerTest unavailable"))
  f <- try(lme4::lmer(.value ~ 1 + (1 | item) + (1 | country_folder), data = d), silent = TRUE)
  if (inherits(f, "try-error")) return(unavailable("fit_error", as.character(f)))
  vc <- as.data.frame(lme4::VarCorr(f))
  v_item <- sum(vc$vcov[vc$grp == "item"], na.rm = TRUE)
  v_country <- sum(vc$vcov[vc$grp == "country_folder"], na.rm = TRUE)
  v_resid <- vc$vcov[vc$grp == "Residual"][1]
  tibble(
    source = source_label,
    n_obs = nrow(d), n_items = n_distinct(d$item), n_countries = n_distinct(d$country_folder),
    var_item = v_item, var_country = v_country, var_residual = v_resid,
    singular = lme4::isSingular(f),
    convergence_message = paste(f@optinfo$conv$lme4$messages, collapse = "; "),
    share_of_item_plus_country = 100 * v_item / (v_item + v_country),
    share_of_total = 100 * v_item / (v_item + v_country + v_resid),
    fit_status = "fitted; inspect singular and convergence_message",
    failure_message = NA_character_
  )
}

c3_human_frame <- c3_base %>%
  distinct(item, country_folder, human_mean) %>%
  mutate(.value = human_mean)

c3_variance <- bind_rows(
  c3_variance_one(c3_human_frame, "HUMAN"),
  purrr::map_dfr(sort(unique(c3_base$model)), function(m) {
    c3_variance_one(c3_base %>% filter(model == m) %>% mutate(.value = pred_mean), m)
  })
)

write_csv(c3_variance, file.path(out_dir, "PAPER_C3_variance_decomposition.csv"))
cat("\n  Variance decomposition (both denominators reported):\n")
print(as.data.frame(c3_variance %>% mutate(across(where(is.numeric), ~ round(.x, 4)))))

# Correspondence decomposition
c3_crossed_cor_boot <- function(pred, human, item, country, B = 2000L, seed = 20260918L) {
  keep <- is.finite(pred) & is.finite(human) & !is.na(item) & !is.na(country)
  pred <- pred[keep]; human <- human[keep]
  item <- as.character(item[keep]); country <- as.character(country[keep])
  ii <- match(item, sort(unique(item))); cc <- match(country, sort(unique(country)))
  I <- length(unique(ii)); C <- length(unique(cc))
  if (I < 3L || C < 3L) stop("C3 bootstrap needs at least three items and countries.")
  if (anyDuplicated(paste(ii, cc, sep = ":"))) stop("Duplicate item-country cell in C3 bootstrap.")
  wc <- function(x, y, w) {
    keep <- is.finite(x) & is.finite(y) & is.finite(w) & w > 0
    x <- x[keep]; y <- y[keep]; w <- w[keep]
    if (length(x) < 2L) return(NA_real_)
    w <- w / sum(w); x <- x - sum(w * x); y <- y - sum(w * y)
    den <- sqrt(sum(w * x^2) * sum(w * y^2))
    if (!is.finite(den) || den <= 0) NA_real_ else sum(w * x * y) / den
  }
  statistic <- function(iw, cw) {
    denom <- as.numeric(rowsum(cw[cc], ii, reorder = TRUE))
    ip <- as.numeric(rowsum(cw[cc] * pred, ii, reorder = TRUE)) / denom
    ih <- as.numeric(rowsum(cw[cc] * human, ii, reorder = TRUE)) / denom
    w <- iw[ii] * cw[cc]
    c(overall = wc(pred, human, w), between = wc(ip, ih, iw),
      within = wc(pred - ip[ii], human - ih[ii], w))
  }
  had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) old_seed <- get(".Random.seed", envir = .GlobalEnv)
  on.exit({
    if (had_seed) assign(".Random.seed", old_seed, envir = .GlobalEnv)
    else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) rm(".Random.seed", envir = .GlobalEnv)
  }, add = TRUE)
  set.seed(seed)
  point <- statistic(rep(1, I), rep(1, C))
  draws <- replicate(B, statistic(tabulate(sample.int(I, I, replace = TRUE), nbins = I),
                                  tabulate(sample.int(C, C, replace = TRUE), nbins = C)))
  finite <- rowSums(is.finite(draws))
  intervals <- t(apply(draws, 1, function(v) {
    v <- v[is.finite(v)]
    if (length(v) < ceiling(.95 * B)) return(c(NA_real_, NA_real_))
    unname(quantile(v, c(.025, .975)))
  }))
  list(point = point, ci = intervals, n_valid = finite, B = B, n_items = I, n_countries = C)
}

c3_correspondence <- purrr::map_dfr(sort(unique(c3_base$model)), function(m) {
  d <- c3_base %>% filter(model == m)
  b <- c3_crossed_cor_boot(d$pred_mean, d$human_mean, d$item, d$country_folder)
  tibble(model = m,
    r_overall = b$point["overall"], overall_ci_low = b$ci["overall", 1],
    overall_ci_high = b$ci["overall", 2], n_overall = nrow(d),
    r_between_item = b$point["between"], between_ci_low = b$ci["between", 1],
    between_ci_high = b$ci["between", 2], n_between = b$n_items,
    r_within_item = b$point["within"], within_ci_low = b$ci["within", 1],
    within_ci_high = b$ci["within", 2], n_within = nrow(d),
    n_countries = b$n_countries, bootstrap_B = b$B,
    bootstrap_valid_overall = b$n_valid["overall"], bootstrap_valid_between = b$n_valid["between"],
    bootstrap_valid_within = b$n_valid["within"],
    ci_method = "percentile crossed item/country bootstrap; centering recomputed each draw")
})

# Per-item across-country correlations.
c3_per_item <- c3_base %>%
  group_by(model, item) %>%
  summarise(n_countries = n(),
            r = suppressWarnings(stats::cor(pred_mean, human_mean)), .groups = "drop")

c3_per_item_summary <- c3_per_item %>%
  group_by(model) %>%
  summarise(n_items = n(),
            median_r = stats::median(r, na.rm = TRUE),
            q25_r = stats::quantile(r, .25, na.rm = TRUE),
            q75_r = stats::quantile(r, .75, na.rm = TRUE),
            min_r = min(r, na.rm = TRUE), max_r = max(r, na.rm = TRUE),
            .groups = "drop")

c3_correspondence <- c3_correspondence %>%
  left_join(c3_per_item_summary %>%
              dplyr::select(model, median_per_item_r = median_r,
                            per_item_q25 = q25_r, per_item_q75 = q75_r, n_items),
            by = "model")

write_csv(c3_correspondence, file.path(out_dir, "PAPER_C3_correspondence_decomposition.csv"))
write_csv(c3_per_item, file.path(out_dir, "PAPER_C3_per_item_across_country_r.csv"))

cat("\n  Correspondence decomposition:\n")
print(as.data.frame(c3_correspondence %>%
  dplyr::select(model, r_overall, r_between_item, r_within_item,
                median_per_item_r, per_item_q25, per_item_q75, n_items) %>%
  mutate(across(where(is.numeric), ~ round(.x, 4)))))

issp_audit_record(
  "C3 decomposition", "compute variance components and correspondence splits on the country-scope discrete frame",
  rows_in = nrow(c3_base), rows_out = nrow(c3_correspondence),
  reason = "frame is condition_name == mean_confidence, scope == country, dataset_type == discrete",
  detail = paste0(n_distinct(c3_base$item), " items x ",
                  n_distinct(c3_base$country_folder), " countries")
)

c2_base <- confidence_item_level %>%
  filter(condition_name == "mean_confidence", scope == "country",
         dataset_type == "discrete", !is.na(confidence))

c2_item_variation <- c2_base %>%
  group_by(model_family, model, item) %>%
  summarise(n_countries = n_distinct(country_folder),
            n_distinct_confidence = n_distinct(confidence),
            sd_confidence = stats::sd(confidence, na.rm = TRUE),
            .groups = "drop") %>%
  mutate(constant = n_distinct_confidence <= 1)

c2_summary <- c2_item_variation %>%
  group_by(model_family, model) %>%
  summarise(
    n_items = n(),
    n_constant = sum(constant),
    n_non_constant = sum(!constant),
    pct_constant = 100 * mean(constant),
    median_distinct_values = stats::median(n_distinct_confidence),
    median_countries = stats::median(n_countries),
    .groups = "drop"
  ) %>%
  arrange(desc(pct_constant))

write_csv(c2_item_variation, file.path(out_dir, "PAPER_C2_confidence_item_variation.csv"))
write_csv(c2_summary, file.path(out_dir, "PAPER_C2_constant_confidence_summary.csv"))

cat("\n  Confidence variation across countries, by model:\n")
print(as.data.frame(c2_summary %>% mutate(across(where(is.numeric), ~ round(.x, 2)))))

issp_audit_record(
  "C2 constant confidence", "count items with no confidence variation across countries",
  rows_in = nrow(c2_item_variation),
  rows_out = sum(!c2_item_variation$constant),
  reason = "an item with one confidence value across all countries contributes no country-level variation",
  detail = paste(paste0(c2_summary$model, "=", c2_summary$n_constant, "/", c2_summary$n_items),
                 collapse = "; ")
)

# Same crossed specification as the primary confidence/error analysis.
fit_crossed_confidence_paper <- function(dat, predictor, outcome) {
  d <- dat %>% mutate(.x = .data[[predictor]], .y = .data[[outcome]]) %>%
    filter(is.finite(.x), is.finite(.y), !is.na(country_folder), !is.na(item))
  if (!issp_have_lmer || nrow(d) < 50 || n_distinct(d$country_folder) < 3 || n_distinct(d$item) < 3)
    stop("C2 crossed confidence fit does not meet package/cluster/row requirements.")
  f <- lmerTest::lmer(.y ~ .x + (1 | country_folder) + (1 | item), data = d)
  tab <- as.data.frame(summary(f)$coefficients)
  b <- tab[".x", "Estimate"]; se <- tab[".x", "Std. Error"]; df <- tab[".x", "df"]
  msg <- f@optinfo$conv$lme4$messages
  tibble(r = cor(d$.x, d$.y), b = b, beta = NA_real_, se = se,
    t = tab[".x", "t value"], df = df, p = tab[".x", "Pr(>|t|)"],
    ci_low = b - qt(.975, df) * se, ci_high = b + qt(.975, df) * se,
    n = nrow(d), n_items = n_distinct(d$item), n_countries = n_distinct(d$country_folder),
    inference = "crossed country/item random intercepts; Satterthwaite",
    singular = lme4::isSingular(f), convergence_message = if (is.null(msg)) "" else paste(msg, collapse = "; "))
}

c2_nonconstant_keys <- c2_item_variation %>%
  filter(!constant) %>%
  dplyr::select(model_family, model, item)

c2_restricted_lm <- confidence_item_level %>%
  filter(condition_name == "mean_confidence", scope == "country",
         dataset_type == "discrete") %>%
  semi_join(c2_nonconstant_keys, by = c("model_family", "model", "item")) %>%
  group_by(model_family, model, scope, dataset_type) %>%
  group_modify(~ fit_crossed_confidence_paper(.x, predictor = "confidence",
                                     outcome = "mean_abs_error")) %>%
  ungroup() %>%
  mutate(outcome = "mean_abs_error", item_set = "non-constant items only")

c2_full_lm <- confidence_item_level %>%
  filter(condition_name == "mean_confidence", scope == "country",
         dataset_type == "discrete") %>%
  group_by(model_family, model, scope, dataset_type) %>%
  group_modify(~ fit_crossed_confidence_paper(.x, predictor = "confidence",
                                     outcome = "mean_abs_error")) %>%
  ungroup() %>%
  mutate(outcome = "mean_abs_error", item_set = "all items")

c2_primary_check <- c2_full_lm %>%
  left_join(condition2_confidence_item_lm_table %>%
    filter(scope == "country", dataset_type == "discrete", outcome == "mean_abs_error") %>%
    select(model_family, model, primary_b, primary_p, primary_n), by = c("model_family", "model")) %>%
  mutate(agrees_with_primary = is.finite(primary_b) & abs(b - primary_b) < 1e-6 &
    abs(p - primary_p) < 1e-6 & n == primary_n)
write_csv(c2_primary_check, file.path(out_dir, "CHECK_C2_matches_primary.csv"))
if (any(is.na(c2_primary_check$agrees_with_primary) | !c2_primary_check$agrees_with_primary))
  stop("C2 all-item crossed fit does not reproduce the primary estimate; see CHECK_C2_matches_primary.csv.")

c2_lm_comparison <- bind_rows(c2_full_lm, c2_restricted_lm) %>%
  group_by(item_set) %>%
  mutate(p_holm = stats::p.adjust(p, method = "holm")) %>%
  ungroup() %>%
  arrange(model, item_set)

write_csv(c2_lm_comparison, file.path(out_dir, "PAPER_C2_confidence_lm_restricted_vs_full.csv"))

cat("\n  Confidence -> error regression, all items vs non-constant only:\n")
print(as.data.frame(c2_lm_comparison %>%
  dplyr::select(model, item_set, any_of(c("n", "estimate", "beta", "r", "p", "p_holm"))) %>%
  mutate(across(where(is.numeric), ~ signif(.x, 4)))))

issp_audit_record(
  "C2 restricted confidence", "refit confidence models on non-constant items",
  rows_in = nrow(c2_full_lm), rows_out = nrow(c2_restricted_lm),
  reason = "constant items contribute no country-level confidence variation",
  detail = "Holm applied within item_set"
)


.nm_rows <- list()

nm_check <- function(site, expected_n, resolved_n, detail = NA_character_,
                     expect_zero = FALSE) {
  status <- if (is.na(resolved_n)) {
    "EMPTY"
  } else if (expect_zero) {
    if (resolved_n == 0) "ok" else "UNEXPECTED SIZE"
  } else if (resolved_n == 0) {
    "EMPTY"
  } else if (!is.na(expected_n) && resolved_n != expected_n) {
    "UNEXPECTED SIZE"
  } else {
    "ok"
  }
  .nm_rows[[length(.nm_rows) + 1L]] <<- tibble(
    script = "ISSP.R", site = site,
    expected_n = as.integer(expected_n), resolved_n = as.integer(resolved_n),
    status = status, detail = as.character(detail)
  )
  invisible(NULL)
}

if (exists("issp_model_all_gpt")) {
  nm_check("distribution_methods resolves in loaded data",
           length(distribution_methods),
           n_distinct(issp_model_all_gpt$method_raw[
             issp_model_all_gpt$method_raw %in% distribution_methods]),
           paste(distribution_methods, collapse = "; "))
  nm_check("extract_method_from_name: no 'other' labels", 0L,
           sum(issp_model_all_gpt$method_raw == "other"),
           "any 'other' means a filename pattern failed to match",
           expect_zero = TRUE)
}
if (exists("expected_item_ids") && exists("issp_model_all_gpt")) {
  nm_check("collected fixed-category items present in GPT distribution data",
           expected_n_collected_discrete,
           sum(unique(issp_model_all_gpt$item) %in% expected_item_ids),
           "non-discrete items are loaded from a separate file")
  nm_check("item_meta total items", expected_n_total, length(expected_item_ids),
           "36 discrete + 2 non-discrete")
}
if (exists("model_families_to_keep") && exists("confidence_item_level")) {
  nm_check("model_families_to_keep resolves",
           length(model_families_to_keep),
           n_distinct(confidence_item_level$model_family))
}
if (exists("focal_methods") && exists("issp_distribution_distances")) {
  nm_check("focal_methods resolve in distances",
           NA_integer_,
           n_distinct(issp_distribution_distances$method[
             issp_distribution_distances$method %in% focal_methods]),
           paste(focal_methods, collapse = "; "))
}
if (exists("issp_countries")) {
  nm_check("country folders discovered", 32L, length(issp_countries))
}
if (exists("global_files")) {
  nm_check("global files loaded after exclusions", 7L, length(global_files),
           paste(basename(global_files), collapse = "; "))
}
nm_check("Holm reporting objects found", nrow(issp_holm_targets),
         n_distinct(issp_registry$object), "one selected inference per hypothesis")

issp_name_match_audit <- bind_rows(.nm_rows)
readr::write_csv(issp_name_match_audit, file.path(out_dir, "PAPER_name_match_audit_issp.csv"))
print(as.data.frame(issp_name_match_audit))
n_bad <- sum(issp_name_match_audit$status != "ok")
cat("\n  Sites checked:", nrow(issp_name_match_audit),
    "  problems:", n_bad, "\n")
if (n_bad > 0) {
  cat("  ⚠ Review these before trusting downstream numbers:\n")
  print(as.data.frame(issp_name_match_audit %>% filter(status != "ok")))
}

# Population SD of a discrete distribution over response bins
e2_sd_from_bins <- function(bin, p) {
  keep <- !is.na(bin) & !is.na(p) & is.finite(p) & p > 0
  if (!any(keep)) return(NA_real_)
  b <- as.numeric(bin[keep]); w <- as.numeric(p[keep])
  if (sum(w) <= 0) return(NA_real_)
  w <- w / sum(w)
  mu <- sum(w * b)
  sqrt(sum(w * (b - mu)^2))
}

e2_items <- item_meta %>%
  filter(dataset_type == "discrete", item %in% expected_item_ids) %>%
  select(item) %>%
  left_join(item_ranges %>% select(item, scale_min, scale_max, range_source), by = "item") %>%
  mutate(
    scale_width = scale_max - scale_min,
    n_bins = scale_width + 1,
    range_is_fallback = grepl("fallback", range_source, fixed = TRUE),
    sensitivity_v54_v55 = item %in% c("v54", "v55")
  )

cat("\n-- Response-scale widths across the discrete items --\n")
cat("  items:", nrow(e2_items), "\n")
print(as.data.frame(e2_items %>% count(scale_min, scale_max, scale_width, n_bins,
                                       name = "n_items") %>% arrange(scale_width)))
cat("  distinct widths:", paste(sort(unique(e2_items$scale_width)), collapse = ", "), "\n")
cat("  items with a human-observed fallback range:",
    paste(sort(e2_items$item[e2_items$range_is_fallback]), collapse = ", "), "\n")

e2_human_binned <- issp_human_props_all %>%
  filter(scope == "global", item %in% e2_items$item) %>%
  group_by(item) %>%
  summarise(human_sd_binned = e2_sd_from_bins(bin, human_prop),
            human_n_total = max(human_n_total, na.rm = TRUE), .groups = "drop")

e2_human <- e2_items %>%
  left_join(e2_human_binned, by = "item") %>%
  left_join(
    issp_human_stats_all %>%
      filter(scope == "global") %>%
      select(item, human_sd_empirical = human_sd, human_n),
    by = "item"
  )

cat("\n-- Human SD, binned vs empirical (sanity check on the estimator) --\n")
cat("  max |binned - empirical| across items:",
    round(max(abs(e2_human$human_sd_binned - e2_human$human_sd_empirical), na.rm = TRUE), 5), "\n")
cat("  correlation:", round(safe_cor(e2_human$human_sd_binned, e2_human$human_sd_empirical), 5), "\n")

e2_implied <- all_model_props %>%
  filter(scope == "global", dataset_type == "discrete",
         item %in% e2_items$item, method %in% focal_methods) %>%
  group_by(model_family, model, method, item) %>%
  summarise(implied_sd = e2_sd_from_bins(bin, model_prop), .groups = "drop")

cat("\n-- Method coverage at global scope (discrete) --\n")
print(as.data.frame(e2_implied %>% count(model_family, method, name = "n_items")))

e2_persona_present <- "demographic_distribution" %in% unique(e2_implied$method)
cat("\n  Persona Prompting (demographic_distribution) bin distributions at global scope: ",
    if (e2_persona_present) "PRESENT -- reported as a row." else
      "ABSENT -- no row can be produced.", "\n")
if (e2_persona_present) {
  cat("  items covered by Persona Prompting:",
      sum(e2_implied$method == "demographic_distribution"), "\n")

  e2_persona_country_spread <- all_model_props %>%
    filter(method == "demographic_distribution", scope == "country",
           dataset_type == "discrete", item %in% e2_items$item) %>%
    group_by(country_folder, item) %>%
    summarise(country_mean = sum(bin * model_prop, na.rm = TRUE), .groups = "drop") %>%
    group_by(item) %>%
    summarise(between_country_sd = stats::sd(country_mean, na.rm = TRUE),
              n_countries = dplyr::n(), .groups = "drop")

  cat("\n  Between-country SD of the persona item mean (the variance the pooled\n")
  cat("  global row absorbs), across", nrow(e2_persona_country_spread), "items:\n")
  cat("    mean:", round(mean(e2_persona_country_spread$between_country_sd, na.rm = TRUE), 4),
      " median:", round(median(e2_persona_country_spread$between_country_sd, na.rm = TRUE), 4),
      " max:", round(max(e2_persona_country_spread$between_country_sd, na.rm = TRUE), 4), "\n")
}

e2_per_item <- e2_implied %>%
  inner_join(e2_human, by = "item") %>%
  mutate(
    implied_sd_norm  = implied_sd / scale_width,
    human_sd_norm    = human_sd_binned / scale_width,
    sd_error         = implied_sd - human_sd_binned,
    sd_error_norm    = implied_sd_norm - human_sd_norm,

    sd_recovery_ratio = dplyr::if_else(
      is.finite(human_sd_norm) & human_sd_norm > 0,
      implied_sd_norm / human_sd_norm,
      NA_real_
    ),
    Model  = recode(model_family, !!!model_labels_issp, .default = model),
    Method = recode(method, !!!method_labels_issp, .default = method),
    # Prompting has no global elicitation, so its global row is a
    # pool of country-level persona responses.
    global_construction = if_else(
      method == "demographic_distribution",
      "pooled_from_country_personas",
      "directly_elicited_at_global_scope"
    )
  )

# Summary per model x method
e2_summary <- e2_per_item %>%
  group_by(model_family, model, Model, method, Method, global_construction) %>%
  summarise(
    n_items = n_distinct(item),

    mean_implied_sd_norm = mean(implied_sd_norm, na.rm = TRUE),
    mean_human_sd_norm   = mean(human_sd_norm, na.rm = TRUE),
    bias_norm            = mean(sd_error_norm, na.rm = TRUE),
    mae_norm             = mean(abs(sd_error_norm), na.rm = TRUE),
    rmse_norm            = sqrt(mean(sd_error_norm^2, na.rm = TRUE)),
    r_norm               = safe_cor(implied_sd_norm, human_sd_norm),

    n_items_ratio        = sum(!is.na(sd_recovery_ratio)),
    mean_of_item_ratios  = mean(sd_recovery_ratio, na.rm = TRUE),
    median_item_ratio    = median(sd_recovery_ratio, na.rm = TRUE),
    sd_of_item_ratios    = stats::sd(sd_recovery_ratio, na.rm = TRUE),
    ratio_of_means_norm  = mean(implied_sd_norm, na.rm = TRUE) /
                           mean(human_sd_norm, na.rm = TRUE),
    ratio_of_means_raw   = mean(implied_sd, na.rm = TRUE) /
                           mean(human_sd_binned, na.rm = TRUE),

    mean_implied_sd_raw  = mean(implied_sd, na.rm = TRUE),
    mean_human_sd_raw    = mean(human_sd_binned, na.rm = TRUE),
    bias_raw             = mean(sd_error, na.rm = TRUE),
    mae_raw              = mean(abs(sd_error), na.rm = TRUE),
    rmse_raw             = sqrt(mean(sd_error^2, na.rm = TRUE)),
    r_raw                = safe_cor(implied_sd, human_sd_binned),

    .groups = "drop"
  ) %>%
  mutate(r_inflation_raw_minus_norm = r_raw - r_norm) %>%
  arrange(Model, Method)

cat("\n-- PRIMARY: width-normalised implied SD vs human SD (global, 36 numeric discrete items) --\n")
print(as.data.frame(e2_summary %>%
  select(Model, Method, global_construction, n_items, mean_implied_sd_norm,
         mean_human_sd_norm, bias_norm, mae_norm, rmse_norm, r_norm) %>%
  mutate(across(where(is.numeric), ~ round(.x, 4)))))

cat("\n-- SECONDARY: raw SDs, pooled across six scale widths --\n")
print(as.data.frame(e2_summary %>%
  select(Model, Method, mean_implied_sd_raw, mean_human_sd_raw,
         bias_raw, mae_raw, rmse_raw, r_raw, r_inflation_raw_minus_norm) %>%
  mutate(across(where(is.numeric), ~ round(.x, 4)))))

cat("\n-- SD RECOVERY RATIO (implied / human), width-normalised --\n")
print(as.data.frame(e2_summary %>%
  select(Model, Method, n_items_ratio, mean_of_item_ratios, median_item_ratio,
         sd_of_item_ratios, ratio_of_means_norm, ratio_of_means_raw) %>%
  mutate(across(where(is.numeric), ~ round(.x, 4)))))


write_csv(e2_per_item %>%
            select(Model, Method, model_family, model, method, item,
                   scale_min, scale_max, scale_width, range_source, range_is_fallback, sensitivity_v54_v55,
                   implied_sd, human_sd_binned, human_sd_empirical, human_n,
                   implied_sd_norm, human_sd_norm, sd_error, sd_error_norm,
                   sd_recovery_ratio, global_construction),
          file.path(out_dir, "PAPER_E2_implied_sd_per_item_issp_global.csv"))
write_csv(e2_summary,
          file.path(out_dir, "PAPER_E2_implied_sd_vs_human_sd_issp_global.csv"))

issp_audit_record(
  "task4_implied_sd",
  "implied SD vs human SD, 36 numeric discrete items, global scope only",
  rows_in  = nrow(e2_implied),
  rows_out = nrow(e2_per_item),
  keys_in  = nrow(e2_items),
  keys_out = n_distinct(e2_per_item$item),
  reason = "width-normalized statistics compare discrete items with different response-scale widths",
  detail = paste0(
    "model x method rows: ", nrow(e2_summary),
    "; persona present: ", e2_persona_present,
    "; range-fallback items: ", sum(e2_items$range_is_fallback)
  )
)

cat("\n", strrep("=", 80), "\n")
cat("END TASK 4\n")
cat(strrep("=", 80), "\n")


# Cohen's d helpers

cat("\n", strrep("=", 80), "\n")
cat("TASK 5: Cohen's d attached to the existing t-tests\n")
cat(strrep("=", 80), "\n")

stopifnot(exists("issp_cohen_d_paired"), exists("issp_d_ci"))

d5_ci_lo <- function(d, n) issp_d_ci(d, n)[1]
d5_ci_hi <- function(d, n) issp_d_ci(d, n)[2]

#directional bias
d5_condition2_d <- confidence_item_level %>%
  filter(condition_name == "mean_confidence") %>%
  group_by(model_family, model, scope, dataset_type) %>%
  group_modify(~ {
    d <- .x %>% filter(complete.cases(pred_mean, human_mean))
    if (nrow(d) < 3) {
      # Same columns as the populated branch, so group_modify binds a
      # consistent frame rather than relying on NA-fill for missing names.
      return(tibble(cohens_d = NA_real_, d_ci_low = NA_real_,
                    d_ci_high = NA_real_,
                    d_ci_low_naive = NA_real_, d_ci_high_naive = NA_real_,
                    d_n = nrow(d), d_n_item_clusters = NA_integer_))
    }
    dd <- issp_cohen_d_paired(d$pred_mean, d$human_mean)
    di <- d$pred_mean - d$human_mean

    ci <- issp_d_ci_cluster_boot(di, d$item)
    tibble(cohens_d = dd,
           d_ci_low  = ci[1],
           d_ci_high = ci[2],
           d_ci_low_naive  = d5_ci_lo(dd, nrow(d)),
           d_ci_high_naive = d5_ci_hi(dd, nrow(d)),
           d_n = nrow(d),
           d_n_item_clusters = dplyr::n_distinct(d$item))
  }) %>%
  ungroup() %>%

  mutate(d_variant = "d_z (paired)",

         d_ci_basis = dplyr::if_else(
           !is.na(d_n_item_clusters) & d_n_item_clusters >= 3,
           "cluster bootstrap over items; conditional on observed countries",
           "not estimable: <3 item clusters; use *_naive columns"))

d5_condition2_augmented <- condition2_mean_paired_t_table %>%
  left_join(d5_condition2_d,
            by = c("model_family", "model", "scope", "dataset_type"))

cat("\n-- TEST 1: condition2 directional bias (paired), d alongside t and p --\n")
print(as.data.frame(d5_condition2_augmented %>%
  select(model_family, model, scope, dataset_type, mean_difference,
         primary_b, primary_t, primary_df, primary_p, p_holm, primary_inference,
         cohens_d, d_ci_low, d_ci_high, d_variant, primary_n) %>%
  mutate(across(where(is.numeric), ~ round(.x, 4)))))

write_csv(d5_condition2_augmented,
          file.path(out_dir, "PAPER_condition2_mean_paired_t_tests_with_d_issp.csv"))

# persona directional bias
d5_persona_bias_augmented <- NULL
if (exists("persona_participant_item_bias_clustered") &&
    !is.null(persona_participant_item_bias_clustered) &&
    exists("demographic_participant_item_level")) {

  .d5pb <- demographic_participant_item_level %>%
    filter(dataset_type == "discrete", !is.na(error))

  d5_persona_d <- issp_cohen_d_paired(.d5pb$error, rep(0, nrow(.d5pb)))

  # CI SAMPLE SIZE
  d5_persona_n_participants <- dplyr::n_distinct(.d5pb$participant_uid)

  .d5pb_participant <- .d5pb %>%
    group_by(participant_uid) %>%
    summarise(participant_mean_error = mean(error, na.rm = TRUE), .groups = "drop")

  d5_persona_d_participant <- issp_cohen_d_paired(
    .d5pb_participant$participant_mean_error,
    rep(0, nrow(.d5pb_participant))
  )

  d5_persona_bias_augmented <- persona_participant_item_bias_clustered %>%
    mutate(
      cohens_d           = d5_persona_d_participant,
      d_ci_low           = d5_ci_lo(d5_persona_d_participant, nrow(.d5pb_participant)),
      d_ci_high          = d5_ci_hi(d5_persona_d_participant, nrow(.d5pb_participant)),
      cohens_d_rowlevel  = d5_persona_d,
      d_variant  = "d_z (one-sample vs 0) on participant mean errors; conditional on these items",
      d_n_rows           = nrow(.d5pb),
      d_n_participants   = nrow(.d5pb_participant),
      d_ci_n_clusters    = d5_persona_n_participants,
      d_ci_basis = "standard d_z CI across participant means; does not generalize across sampled items"
    )

  cat("\n-- TEST 2: persona directional bias (one-sample), d alongside t and p --\n")
  cat("   rows:", nrow(.d5pb),
      "| participants (units for d and its CI, conditional on these items):",
      nrow(.d5pb_participant), "\n")
  cat("   The d interval is conditional on the observed items; the clustered\n",
      "  raw-bias test also accounts for item dependence.\n")
  print(as.data.frame(d5_persona_bias_augmented %>%
    select(term, mean_error, t_naive, t_clustered, p_naive, p_clustered,
           cohens_d, cohens_d_rowlevel, d_ci_low, d_ci_high,
           d_n_rows, d_n_participants) %>%
    mutate(across(where(is.numeric), ~ round(.x, 4)))))

  write_csv(d5_persona_bias_augmented,
            file.path(out_dir, "PAPER_partE_persona_bias_with_d_issp.csv"))
} else {
  warning("TASK 5 TEST 2: persona bias source objects unavailable -- Cohen's d NOT attached.",
          call. = FALSE, immediate. = TRUE)
}

# crossed-model directional bias
d5_crossed_augmented <- NULL
if (exists("issp_e6_rows") && length(issp_e6_rows) > 0 && exists("cm")) {

  d5_crossed_src <- bind_rows(
    cm %>% filter(!is.na(mean_error)) %>%
      mutate(.d5_scope = "discrete_country"),
    if (exists("cm_bias_nd")) {
      cm_bias_nd %>% filter(!is.na(mean_error)) %>%
        mutate(.d5_scope = "non_discrete")
    } else tibble()
  )

  d5_crossed_augmented <- d5_crossed_src %>%
    group_by(model, .d5_scope) %>%
    summarise(
      n_obs = dplyr::n(),
      cohens_d        = issp_cohen_d_paired(mean_error, rep(0, dplyr::n())),
      mean_error_mean = mean(mean_error, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    left_join(

      d5_crossed_src %>%
        group_by(model, .d5_scope) %>%
        group_modify(~ {
          ci <- issp_d_ci_cluster_boot(.x$mean_error, .x$item)
          tibble(d_ci_low = ci[1], d_ci_high = ci[2],
                 d_n_item_clusters = dplyr::n_distinct(.x$item))
        }) %>%
        ungroup(),
      by = c("model", ".d5_scope")
    ) %>%
    mutate(
      d_ci_low_naive  = purrr::map2_dbl(cohens_d, n_obs, d5_ci_lo),
      d_ci_high_naive = purrr::map2_dbl(cohens_d, n_obs, d5_ci_hi),
      d_variant = "d_z (one-sample vs 0) on OLS differences; not the crossed-model SE",
      d_ci_basis = dplyr::if_else(
        !is.na(d_n_item_clusters) & d_n_item_clusters >= 3,
        "cluster bootstrap over items; conditional on observed countries",
        "not estimable: <3 item clusters; use *_naive columns")
    )

  cat("\n-- TEST 3: crossed-model directional bias, d on the OLS differences --\n")
  print(as.data.frame(d5_crossed_augmented %>%
    mutate(across(where(is.numeric), ~ round(.x, 4)))))

  write_csv(d5_crossed_augmented,
            file.path(out_dir, "PAPER_partE_crossed_bias_with_d_issp.csv"))
} else {
  warning("TASK 5 TEST 3: crossed-model source objects (issp_e6_rows / cm) unavailable -- Cohen's d NOT attached.",
          call. = FALSE, immediate. = TRUE)
}

issp_audit_record(
  "task5_effect_sizes",
  "attach Cohen's d_z to the existing paired and one-sample t-tests",
  rows_in  = nrow(condition2_mean_paired_t_table),
  rows_out = nrow(d5_condition2_augmented),
  reason = "attach paired/one-sample effect sizes",
  detail = paste0(
    "tests augmented: condition2 paired",
    if (!is.null(d5_persona_bias_augmented)) ", persona one-sample" else "",
    if (!is.null(d5_crossed_augmented)) ", crossed one-sample" else ""
  )
)

cat("\n", strrep("=", 80), "\n")
cat("END TASK 5\n")
cat(strrep("=", 80), "\n")

# Audit table of filters, joins, and exclusions.
cat("\n-- Audit table of filters, joins, and exclusions --\n")
write_issp_audit_table()

