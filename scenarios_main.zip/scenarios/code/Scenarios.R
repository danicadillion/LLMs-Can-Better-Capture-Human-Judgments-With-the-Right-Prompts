
# Libraries and console settings
library(jsonlite); library(readr); library(dplyr); library(tidyr)
library(purrr); library(stringr); library(tibble); library(broom)
library(ggplot2); library(gridExtra); library(truncnorm); library(clubSandwich)

options(tibble.print_max = Inf, tibble.print_min = Inf, tibble.width = Inf)

# raw model-output file numeric prompt IDs
CONFIDENCE_PROMPT_ID <- "3"
DISTRIBUTION_PROMPT_ID <- "5"
SD_ONLY_PROMPT_ID <- "7"
REPEATED_RATING_PROMPT_ID <- "1"


.analysis_script_dir <- local({
  script <- NULL
  for (frame in sys.frames()) {
    if (!is.null(frame$ofile)) script <- frame$ofile
  }
  if (is.null(script)) {
    arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
    if (length(arg)) script <- sub("^--file=", "", arg[1])
  }
  if (is.null(script)) getwd() else dirname(normalizePath(script, mustWork = FALSE))
})
base_dir <- Sys.getenv("SCEN_BASE_DIR", unset = "")
if (!nzchar(base_dir)) {
  candidates <- unique(c(
    file.path(.analysis_script_dir, "..", "data"),
    file.path(.analysis_script_dir, "data"),
    file.path(getwd(), "scenarios", "data"),
    file.path(getwd(), "data"),
    file.path(getwd(), "..", "data")
  ))
  candidates <- candidates[file.exists(file.path(candidates, "Scenarios_Survey.csv"))]
  if (!length(candidates)) {
    stop("Cannot locate scenarios/data. Set SCEN_BASE_DIR to the data folder.")
  }
  base_dir <- candidates[1]
}
base_dir <- normalizePath(base_dir, mustWork = TRUE)
if (!file.exists(file.path(base_dir, "Scenarios_Survey.csv"))) {
  stop("Required input Scenarios_Survey.csv is missing from ", base_dir)
}
cat("scenarios data directory:", base_dir, "\n")

path_confidence_files <- c(
  "gpt-5.jsonl"        = file.path(base_dir, "gpt-5.jsonl"),
  "gpt-4o-mini.jsonl" = file.path(base_dir, "gpt-4o-mini.jsonl"),
  "gpt-3.5-turbo.txt" = file.path(base_dir, "gpt-3.5-turbo.txt"),
  "qwen_inputs_prompt3_temp0_1rep.jsonl"   = file.path(base_dir, "qwen_inputs_prompt3_temp0_1rep.jsonl"),
  "gptoss_inputs_prompt3_temp0_1rep_v3.jsonl" = file.path(base_dir, "gptoss_inputs_prompt3_temp0_1rep_v3.jsonl")
)

path_distribution_main <- file.path(base_dir, "prompt5_nollama.jsonl")
path_distribution_qwen <- file.path(base_dir, "prompt5_qwen.jsonl")

path_distribution_gptoss <- file.path(base_dir, "gptoss_phaseA_prompts5_6_temp0_v2.jsonl")

path_sd_only_api  <- file.path(base_dir, "prompt7_api.jsonl")
path_sd_only_qwen <- file.path(base_dir, "qwen_prompt7.jsonl")

path_sd_only_gptoss <- file.path(base_dir, "inputs_gptoss_phaseA_prompts1to7_temp0_enriched.jsonl")

path_repeated_500 <- file.path(
  base_dir,
  "prompt-4-5-6-500sampl",
  "run_machineB_prompt4_trapi_gpt5_500sampl-full.jsonl"
)

path_repeated_500_qwen <- file.path(
  base_dir,
  "rate_qwen32B_temp1_500reps_enriched.jsonl"
)

path_repeated_500_gpt4omini <- file.path(
  base_dir,
  "gpt4omini_reworded_prompt8_temp1_500reps.jsonl"
)

path_repeated_500_gpt35 <- file.path(
  base_dir,
  "gpt35turbo_openai_reworded_prompt8_temp1_500reps.jsonl"
)

path_repeated_500_gptoss <- file.path(
  base_dir,
  "inputs_gptoss_phaseB_temp1_500reps_enriched_topped500.jsonl"
)

# Human ratings and clarity/confusion ratings for the moral scenarios.
path_human_csv <- file.path(
  base_dir,
  "Scenarios_Survey.csv"
)

path_rerun_missing <- file.path(
  base_dir,
  "rerun_all_merged.jsonl"
)

path_demographic_boost <- file.path(base_dir, "Demographic_Groups.csv")

demographics_dir <- Sys.getenv(
  "SCEN_DEMOGRAPHICS_DIR",
  unset = file.path(base_dir, "demographics_data")
)

path_sd_only_gpt35 <- file.path(
  base_dir,
  "rerun_gpt-35-turbo_1106_prompt7.jsonl"
)

path_sd_adjudication <- file.path(
  base_dir,
  "prompt7_sd_analysis_decisions.xlsx"
)

# All generated tables and figures are written here.
.default_output_root <- if (tolower(basename(base_dir)) == "data") dirname(base_dir) else base_dir
out_dir <- Sys.getenv("SCEN_OUT_DIR", unset = file.path(.default_output_root, "results_output"))
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
# Record the run start so output audits can ignore files from earlier runs.
.scen_run_started <- Sys.time() - 5

# Audit log
# Every consequential filter, join, and exclusion records rows in/out, unmatched
# keys, and the reason, so the audit table in out_dir explains any row-count
# change without needing the console transcript.
.audit_env <- new.env(parent = emptyenv())
.audit_env$rows <- list()

audit_record <- function(step, operation, rows_in = NA_integer_, rows_out = NA_integer_,
                         keys_in = NA_integer_, keys_out = NA_integer_,
                         unmatched_keys = NA_integer_, reason = NA_character_,
                         detail = NA_character_) {
  .audit_env$rows[[length(.audit_env$rows) + 1L]] <- tibble::tibble(
    script         = "Scenarios.R",
    step           = as.character(step),
    operation      = as.character(operation),
    rows_in        = as.integer(rows_in),
    rows_out       = as.integer(rows_out),
    rows_delta     = as.integer(rows_out) - as.integer(rows_in),
    keys_in        = as.integer(keys_in),
    keys_out       = as.integer(keys_out),
    unmatched_keys = as.integer(unmatched_keys),
    reason         = as.character(reason),
    detail         = as.character(detail)
  )
  invisible(NULL)
}

write_audit_table <- function(path = file.path(out_dir, "audit_filters_joins_exclusions.csv")) {
  if (length(.audit_env$rows) == 0) {
    cat("  Audit log is empty; nothing written.\n")
    return(invisible(NULL))
  }
  tbl <- dplyr::bind_rows(.audit_env$rows)
  write.csv(tbl, path, row.names = FALSE)
  cat("  Audit table:", nrow(tbl), "steps ->", path, "\n")
  invisible(tbl)
}


# Diagnostics accompany estimates
model_fit_diagnostics <- function(fit) {
  messages <- unlist(fit@optinfo$conv$lme4$messages, use.names = FALSE)
  code <- fit@optinfo$conv$opt
  if (is.null(code)) code <- 0L
  h <- fit@optinfo$derivs$Hessian
  eig <- if (!is.null(h) && all(is.finite(h)))
    min(eigen((h + t(h)) / 2, symmetric = TRUE, only.values = TRUE)$values) else NA_real_
  singular <- lme4::isSingular(fit)
  tibble(fit_singular = singular, optimizer_code = paste(code, collapse = ";"),
    convergence_messages = paste(messages, collapse = "; "),
    hessian_min_eigenvalue = eig,
    fit_diagnostic_status = if (any(code != 0) || length(messages)) "convergence_warning" else
      if (singular) "singular" else "no_reported_warning")
}

# General helper functions
# These functions standardize model outputs, parse JSON-like text, and compute distance metrics.
clamp_scale <- function(x, lo = -4, hi = 4) pmax(lo, pmin(hi, round(x)))

num <- function(v) {
  if (is.null(v) || length(v) == 0) return(NA_real_)
  suppressWarnings(as.numeric(v))
}

# Moral rating extraction
RATING_SCALE_MIN <- -4
RATING_SCALE_MAX <- 4

# Draw-count floor for repeated-sampling cells.
REPEATED_MIN_DRAWS     <- 280L
REPEATED_NOMINAL_DRAWS <- 500L

# The confidence-prompt inputs submit these four scenarios twice (see the
# duplicate-conflict block).
REPEATED_DOUBLE_SUBMITTED_SCENARIOS <- c("148_new", "148_old", "428_new", "428_old")

# Unicode escapes keep PCRE patterns explicitly UTF-8 even when R parses this
# source under LC_CTYPE=C. Do not replace them with visually identical literals.
SCALAR_NUMBER_PATTERN <- "[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?"
normalize_scalar_format <- function(x) {
  x <- enc2utf8(as.character(x))
  x <- gsub("[\u2212\u2013]", "-", x, perl = TRUE)
  # Markdown sometimes escapes a decimal point: 1\\.20 means 1.20.
  x <- gsub("(?<=[0-9])\\\\\\.(?=[0-9])", ".", x, perl = TRUE)
  # Explicit spacing before a decimal point is typographic, not a new token.
  gsub("(?<=[0-9])[ \\t\u00a0\u202f]+\\.(?=[0-9])", ".", x, perl = TRUE)
}
clean_extracted_num <- function(x) {
  if (length(x) != 1L || is.na(x)) return(NA_real_)
  x <- trimws(normalize_scalar_format(x))
  # This function receives one complete scalar field. A decimal point is
  # mandatory for digit-continuation recovery: "1 2" is never 12.
  interrupted_decimal <- "^[+-]?[[:space:]]*(?:[0-9]+[[:space:]]*\\.[[:space:]]*[0-9]+(?:[[:space:]]+[0-9]+)*|\\.[[:space:]]*[0-9]+(?:[[:space:]]+[0-9]+)*)(?:[eE][+-]?[0-9]+)?$"
  if (grepl(interrupted_decimal, x, perl = TRUE)) x <- gsub("[[:space:]]", "", x)
  x <- gsub("^([+-])[[:space:]\u00a0\u202f]+(?=[0-9.])", "\\1", x, perl = TRUE)
  if (!grepl(paste0("^", SCALAR_NUMBER_PATTERN, "$"), x, perl = TRUE)) return(NA_real_)
  value <- suppressWarnings(as.numeric(x))
  if (is.finite(value)) value else NA_real_
}

.rating_anchor_patterns <- local({
  NUM <- "([+-]?(?:\\d+(?:[ \\t]*\\.(?:[\\s]*\\d+)?)?|\\.[\\s]*\\d+)(?:[eE][+-]?\\d+)?)(?![\\p{L}\\p{N}_]|[\\s*`]*(?:[-\u2013]\\s*year|years?\\b|(?:am|pm)\\b))"
  FMT <- "[\\s*`_]*"
  VERB <- "\\b(?:I\\s+(?:would\\s+)?rate|I['\u2019]d\\s+rate)\\b"
  DIRECT_TAIL <- paste0("\\s+",
    "(?:(?:it|(?:this|that|the)(?:\\s+described)?\\s+(?:scenario|situation|action|act|behaviou?r)|Person\\s+X['\u2019]s\\s+(?:choice|action|behaviou?r)|this|that)\\s*)?",
    "(?:(?:as|at)\\s*[:=]?\\s*)?", FMT,
    "(?:(?:about|around|roughly|approximately)\\b\\s*[:=]?\\s*|\u2248\\s*)?(?:a\\s+)?",
    FMT, "[:=]?", FMT, NUM)
  DIRECT <- paste0(VERB, DIRECT_TAIL)
  CLAUSE <- paste0(VERB, "[^\\r\\n]{0,600}?\\bas\\s*[:=]?", FMT,
    "(?:(?:about|around|roughly|approximately)\\b\\s*[:=]?\\s*)?(?:a\\s+)?", FMT, NUM)
  MOD <- "(?:(?:best|ethically|therefore|thus|reasonably|generally|typically|likely|clearly|probably|plausibly|tentatively|roughly|approximately|about|around)\\b\\s*)*"
  SUBJECT <- "(?:this|that|it|(?:this|that|the|such)(?:\\s+described)?\\s+(?:scenario|situation|action|act|behaviou?r|conduct)|such\\s+an?\\s+act)"
  AFMT <- paste0(FMT,"(?:[~\u2248\u2192]",FMT,")?")
  PAREN <- "(?:[ \\t*`]*\\([^()\\r\\n]{0,180}\\)[ \\t*`]*)?"
  SCALE <- "(?:given|provided|described|your|ethical|ethics|moral|requested|stated|specified|rating|[-+0-9.()=* \\t]|extremely|unethical|neutral|ethical|to|from|through|being|where|and|with|is)+"
  c(
    contextual_heading_rating = paste0("(?m)^[ \\t*`#>]*(?:(?:a|plausible|averaged|ethical|moral|overall|reasonable)\\s+)*rating,[^\\r\\n:;!?0-9]{1,160}:",AFMT,NUM),
    rate_it_modifier = paste0("\\brate\\s+(?:it|this|the\\s+scenario)\\s+(?:(?:as|at)\\s+)?",MOD,AFMT,NUM),
    balance_assignment = paste0("\\bI\\s+would\\s+balance[^\\r\\n:;!?0-9]{1,120}\\bgive\\s+(?:it|this\\s+scenario)",AFMT,NUM),
    classify_approximation = paste0("\\bI\\s+would\\s+classify\\s+(?:this|it)\\s+as[^\\r\\n0-9!?]{1,160}\\b(?:roughly|around|about)",AFMT,NUM),
    scenario_end_assignment = paste0("\\b",SUBJECT,"\\s+would\\s+fall\\s+at\\s+the\\s+(?:extreme|most)\\s+(?:un)?ethical\\s+end:",AFMT,NUM),
    rating_symbol = paste0("\\brating",FMT,"[\u2248\u2192]",AFMT,NUM),
    personal_assess_conclusion = paste0("\\bI(?:['\u2019]d|\\s+would)\\s+(?:assess|classify)\\s+(?:this|it)[^\\r\\n0-9:;!?]{1,160}:",AFMT,NUM),
    rating_explained_block = paste0("\\brating",AFMT,":",AFMT,"(?:considering|given|under|without)\\b[^\\r\\n0-9:;!?]{1,220}:",AFMT,NUM),
    rating_qualified_passive = paste0("\\b(?:be|is)\\s+",MOD,"rated\\s+(?:around|about|as|at)",AFMT,MOD,AFMT,NUM),
    approximate_conclusion = paste0("\\b(?:this|that)\\s+(?:would|might)\\s+",MOD,
      "(?:fall|correspond)[^\\r\\n0-9:;!?]{1,110}(?:[:,]|\\b(?:around|perhaps)\\b)",AFMT,NUM),
    assumed_scenario_estimate = paste0("\\b(?:scenario|act)\\b[^\\r\\n0-9:;!?]{0,150}\\s+(?:could|would|might)\\s+be\\s+considered\\s+as",AFMT,MOD,AFMT,NUM),
    qualified_averaged_conclusion = paste0("\\b(?:the\\s+)?(?:middle\\s+ground|result|rough\\s+midpoint)\\s+(?:is|would\\s+be|might\\s+be)",AFMT,MOD,AFMT,NUM),
    neutral_midpoint_assignment = paste0("\\bI\\s+place\\s+the",AFMT,"neutral\\s+midpoint",AFMT,"at",AFMT,NUM),
    balanced_view_assignment = paste0("\\b(?:balanced\\s+average|neutral[^\\r\\n]{0,8}\\s+position)\\b[^\\r\\n0-9!?]{0,230}(?:place\\s+it\\s+near|landing\\s+around)",AFMT,NUM),
    scenario_looks_like = paste0("\\b",SUBJECT,"\\s+looks\\s+like\\s+a",AFMT,NUM),
    scale_assignment_qualitative = paste0("\\bI\\s+would\\s+rate\\s+(?:this|it)\\s+as",AFMT,
      "(?:extremely|very|moderately)\\s+(?:un)?ethical",AFMT,",?\\s*i\\.e\\.,?",AFMT,NUM),
    scenario_modal_value = paste0("\\b",SUBJECT,"\\s+(?:would|could|might|should)\\s+",MOD,"be(?:\\s+at)?",AFMT,MOD,AFMT,"[:=]?",AFMT,NUM),
    ethical_value = paste0("\\b(?:ethical|moral)\\s+value",AFMT,":",AFMT,NUM),
    default_neutral = paste0("\\bdefaulting\\s+to\\s+neutrality[^\\r\\n:;!?0-9]{0,100}:",AFMT,NUM),
    rating_qualitative_field = paste0("\\b(?:ethical\\s+)?rating",AFMT,":",AFMT,
      "(?:neutral|(?:un)?ethical)[^\\r\\n0-9:;!?]{0,100}?(?:[\u2192\u2014:]|[ \\t]-[ \\t])",AFMT,NUM),
    collective_rating = paste0("\\bwe\\s+(?:might|would|could)\\s+rate\\s+(?:this|it|the\\s+scenario)\\s*",MOD,AFMT,"[:=]?",AFMT,NUM),
    rated_qualitative_conclusion = paste0("\\b(?:be|is)\\s+rated\\s+(?:as|at)\\s+[^\\r\\n0-9:;!?]{1,100}:",AFMT,NUM),
    scale_answer_label = paste0("(?m)^[ \\t*`#>]*scale",PAREN,AFMT,":",AFMT,NUM),
    rated_value_label = paste0("(?m)^[ \\t*`#>]*rated\\s+(?:(?:ethical|moral)\\s+)?value",AFMT,":",AFMT,NUM),
    first_person_direct = paste0("\\bI(?:['\u2019](?:d|ll)|\\s+(?:would|might|will))\\s+",MOD,
      "(?:assign|give|rate|score|put|place|estimate|say)\\s*(?:(?:it|this(?:\\s+scenario)?|that)\\s+)?(?:a\\s+(?:cautious\\s+)?)?",MOD,AFMT,"[:=]?",AFMT,NUM),
    causal_placement = paste0("\\b(?:that|this)\\s+would\\s+place\\s+(?:it|this|the\\s+scenario)\\s+at",AFMT,"[:=]?",AFMT,NUM),
    qualitative_numeric = paste0("\\b(?:ethical\\s+(?:evaluation|assessment)|this|it)\\s+(?:is|would\\s+be)",AFMT,MOD,
      "(?:ethically\\s+)?",AFMT,"(?:neutral|(?:un)?ethical)",AFMT,",?\\s*which\\s+would\\s+be",AFMT,":",AFMT,NUM),
    neutral_rated = paste0("\\b(?:ethically\\s+)?(?:neutral|(?:un)?ethical)",AFMT,",\\s*rated\\s+as",AFMT,":",AFMT,NUM),
    assessment_label = paste0("(?m)^[ \\t*`#>]*(?:(?:my|overall|final|weighted|balanced|ethical|moral|ethics)\\s+){1,3}(?:assessment|evaluation|judgment)",AFMT,":",AFMT,NUM),
    assumption_answer = paste0("(?m)^[ \\t*`#>]*(?:given|under|assuming|without)\\s+(?:(?:the|this|that|these|those|only|other|narrow)\\s+)?[^\\r\\n:;!?0-9]{0,100}(?:assumptions?|interpretation|circumstances|action|harm|context|details|above)[^\\r\\n:;!?0-9]{0,60}:",AFMT,NUM),
    rating_scale_qualified = paste0("\\b(?:rating|score|placement)\\b[^\\r\\n:;!?]{0,100}?\\bscale\\b\\s+(?:would|could|might|should)(?:\\s+likely)?\\s+be",AFMT,MOD,AFMT,"[:=]?",AFMT,NUM),
    result_assignment = paste0("(?m)^[ \\t*`#>]*(?:final\\s+)?(?:result|final\\s+assessment|value)",AFMT,"[:=]",AFMT,NUM),
    qualified_rating_context = paste0("\\b(?:rating|score|estimate|placement|assessment|judgment|interpretation|approximation|value)\\b",
      "(?:[ \\t*`]*\\([^()\\r\\n]{0,150}\\)|[^0-9.!?;:=\\r\\n]){0,130}?",
      "(?:[:=]|\\b(?:is|would\\s+(?:(?:likely|therefore|clearly)\\s+)?be|could\\s+be|might\\s+(?:therefore\\s+)?be|should\\s+be|around|about)\\b)",AFMT,MOD,AFMT,"[:=]?",AFMT,"(?:[~\u2248]\\s*)?",NUM),
    first_person_placement = paste0("\\bI(?:['\u2019](?:d|ll)|\\s+(?:would|might|will))\\s+",MOD,
      "(?:ethically\\s+)?(?:place|put|score|estimate|classify|approximate|rate|assign|give|judge|assess)\\s+[^\\r\\n0-9:;!?]{0,160}?(?:\\b(?:as|at|around|about)\\b|:)",AFMT,MOD,AFMT,"[:=]?",AFMT,NUM),
    subject_is_rating = paste0("\\b",SUBJECT,"\\s+is",AFMT,NUM),
    display_rating = paste0("\\b(?:rating|score)",AFMT,":",AFMT,"\\\\\\[",AFMT,NUM,AFMT,"\\\\\\]"),
    scale_conclusion = paste0("\\b(?:on|using)\\s+(?:(?:the|a|your|this)\\s+)?[^\\r\\n:;!?]{0,100}?\\bscale\\b[^\\r\\n:;!?]{0,200}:", AFMT,
      "(?:(?:(?:very|extremely|strongly|moderately|slightly)\\s+)?(?:unethical|ethical|neutral)",FMT,"(?:[:=\u2192])",AFMT,")?",NUM),
    rated_assignment = paste0("\\b(?:be|is|was)",AFMT,MOD,"(?:rated|ranked|scored|assessed)\\s+(?:(?:on\\s+the\\s+(?:ethical\\s+)?scale\\s+)?(?:as|at)\\s+)?",MOD,AFMT,"[:=]?",AFMT,NUM),
    qualitative_conclusion = paste0("\\bI\\s+(?:(?:would|might)\\s+)?",MOD,"(?:rate|judge|give|assign|assess|place)\\b[^\\r\\n0-9:;!?]{0,200}:",AFMT,NUM),
    described_assignment = paste0("\\bI\\s+(?:(?:would|might)\\s+)?",MOD,"(?:rate|judge)\\s+[^\\r\\n0-9:;!?]{1,150}?\\s+(?:as|at|around)",AFMT,MOD,AFMT,"[:=]?",AFMT,NUM),
    rating_for_scenario = paste0("\\brating\\s+(?:for|of)\\s+[^\\r\\n:;!?0-9]{1,160}?\\s+(?:would|could|might|should)\\s+be",AFMT,MOD,AFMT,"[:=]?",AFMT,NUM),
    qualified_assignment = paste0("\\b(?:(?:ethical|ethics|moral|ethicality)\\s+)?rating", AFMT, PAREN,
      "(?:\\s+(?:on|for)\\s+(?:the\\s+)?(?:given|provided|stated|requested|described|your|[-+0-9 ]+)(?:\\s+(?:ethical|ethics|moral))?\\s+scale)?",
      "[ \\t*`]*(?:[:=]|\\b(?:is|would\\s+be|might\\s+be|could\\s+be|should\\s+be)\\b)", AFMT,
      MOD, AFMT, "[:=]?", AFMT, "(?:(?:very|extremely|strongly|moderately)\\s+(?:negative|positive|(?:un)?ethical)[ \\t]*:)?", AFMT, NUM),
    scenario_assignment = paste0("\\b", SUBJECT, "\\s+(?:(?:would|should|could|might|can|is)\\s+)?", MOD,
      "(?:be\\s+)?(?:rate[ds]?|rank(?:ed)?|scores?|judged|merit|fall(?:s)?|lands?|placed)\\s*(?:(?:as|at|around|about)\\s*)?[:=]?", AFMT, MOD, AFMT, "[:=]?", AFMT, "(?:a\\s+)?", AFMT, NUM),
    explicit_judgment = paste0("\\bI\\s+(?:(?:would|can)\\s+)?", MOD,
      "(?:rate|judge|assess)\\s+(?:", SUBJECT, ")\\s+(?:as|at)\\s*[:=]?", AFMT, MOD, AFMT, "[:=]?", AFMT, NUM),
    scale_assignment = paste0("(?m)\\bon\\s+(?:(?:the|a)\\s+)?(?:",SCALE,")\\s*scale(?:\\s+(?:provided|described))?", AFMT, PAREN,
      "[ \\t]*[:,]", AFMT, "(?:",SUBJECT,"\\s+(?:(?:would|could|should)\\s+)?",MOD,
      "(?:be(?:\\s+considered)?|is|rates?\\s+(?:as|at))\\s*[:=]?",AFMT,")?", NUM),
    final_answer = paste0("\\b(?:final|rounded)\\s+(?:answer|rating|score|value|assessment)", FMT, "[:=]?", FMT, NUM),
    rate_label = paste0("\\brate[ds]?", FMT, "[:=]", FMT, NUM),
    tentative_rating = paste0("\\brating\\s+(?:might|could)\\s+be\\s*[:=]?", FMT, NUM),
    could_be_rated = paste0("\\b(?:this(?:\\s+(?:scenario|action|behaviou?r))?|it|the\\s+(?:scenario|action|behaviou?r))\\s+could\\s+be\\s+rated\\s*(?:as\\s*)?[:=]?", FMT, NUM),
    ethics_about = paste0("\\bethics(?:\\s+of\\s+(?:this|the)\\s+(?:action|scenario|behaviou?r))?\\s+at\\s+(?:about|around|approximately)\\s*", FMT, NUM),
    rating_label = paste0("\\b(?:ethics\\s+|ethical\\s+|moral\\s+)?rating\\}?", FMT, "[:=]", FMT, NUM),
    rating_bold = paste0("\\*\\*\\s*(?:ethics\\s+|ethical\\s+|moral\\s+)?rating\\s*\\*\\*", FMT, NUM),
    answer_label = paste0("\\banswer", FMT, "[:=]", FMT, NUM),
    my_rating_is = paste0("\\b(?:my|the)\\s+rating\\s+(?:is|would\\s+be)\\s*[:=]?", FMT, NUM),
    rating_verb = paste0("(?:", DIRECT, "|", CLAUSE, ")"),
    qualitative_rating = paste0(
      "\\b(?:I\\s+(?:would\\s+)?rate|I['\u2019]d\\s+rate)\\s+(?:it|(?:this|that|the)(?:\\s+(?:scenario|action))?)\\s+as\\s+", FMT,
      "(?:slightly|fairly|mildly|moderately|strongly|highly|extremely|very)\\s+(?:un)?ethical", FMT,
      "(?:[:,]\\s*(?:(?:at|perhaps|about|around)\\s*)?|\\(\\s*~?\\s*)", FMT, NUM),
    assigned_rating = paste0("\\bI(?:\\s+(?:would\\s+)?|['\u2019]d\\s+)(?:give|assign|assess|place)\\s*",
      "(?:(?:it|this(?:\\s+(?:scenario|action))?|the\\s+scenario)\\s+)?(?:a\\s+)?",
      "(?:(?:rating|score)\\s*(?:of|as|[:=])?\\s*)?(?:(?:at|as)\\s+)?",
      "(?:(?:approximately|about|around)\\s+)?[:=]?", FMT, NUM),
    expressed_rating = paste0("\\bI['\u2019]ll\\s+express\\s+as\\s*:", FMT, NUM),
    rating_passive = paste0("\\bwould\\s+(?:(?:generally|likely|clearly|typically)\\s+)?(?:be\\s+)?rate[ds]?\\b", DIRECT_TAIL),
    rating_of = paste0("\\brating\\s+of", FMT, NUM),
    rate_it_as = paste0("\\brate\\s+(?:it|this|that|the\\s+scenario)\\s+(?:as|at)\\s*[:=]?", FMT, NUM),
    # A generic "maximum score of 4" in explanatory prose is not an answer.
    # Accept score labels at the beginning of a line, or explicit assignments.
    score_label = paste0("(?m)^[\\t *>`-]*(?:(?:my|overall|ethics|ethical|ethicality|moral|proposed|reasonable|reasoned|estimated|tentative|rated|approximate|provisional|final|blended|composite|balanced|evaluation|a|value)\\s+){0,4}score\\s*(?:[:=]|\\bis\\b|\\bof\\b)", FMT, NUM),
    score_verb = paste0("\\b(?:this(?:\\s+(?:scenario|action|act))?|that|the\\s+scenario)\\s+(?:would|should|could)\\s+(?:(?:clearly|likely|generally)\\s+)?(?:score\\s*[:=]?|merit\\s+a\\s+score\\s+of)", FMT, NUM),
    warranted_score = paste0("\\bwarranting\\s+a\\s+score\\s+of", FMT, NUM),
    score_bold = paste0("(?m)^[\\t *>`]*score", FMT, "\\*\\*", FMT, "[:=]?", FMT, NUM),
    boxed = paste0("\\\\boxed\\{\\s*", NUM, "\\s*\\}"),
    qualified_rating = paste0("(?m)^[\\t *>`-]*(?:a\\s+)?(?:reasonable|tentative|overall|possible|approximate)\\s+rating\\s+(?:is|would\\s+be)\\s*[:=]?", FMT, NUM),
    # Endpoints are answers only when explicitly assigned to this scenario,
    # not when merely mentioned as possible values of the response scale.
    endpoint_assignment = paste0("\\b(?:would\\s+(?:clearly\\s+)?(?:merit|rate\\s+at)|would\\s+be\\s+(?:near|at)|warrants?|merits?)\\s+(?:the\\s+)?(?:lowest|highest|minimum|maximum)(?:\\s+(?:possible|ethical|moral)){0,2}\\s+(?:rating|score)\\s*[:=]", FMT, NUM)
  )
})

leading_rating_wrapper <- function(field) {
  read_wrapper <- function(v) {
    m <- regexpr("^\\\\(?:boxed|text|mathbf|mathrm)[[:space:]]*\\{", v, perl=TRUE)
    if (m[1] < 0L) return(list(found=FALSE))
    opening <- attr(m, "match.length")
    chars <- strsplit(v, "", fixed=TRUE)[[1]]
    depth <- 1L; closing <- opening
    while (depth > 0L && closing < length(chars)) {
      closing <- closing + 1L
      if (chars[closing] == "{") depth <- depth + 1L
      if (chars[closing] == "}") depth <- depth - 1L
    }
    if (depth != 0L) return(list(found=TRUE, closed=FALSE))
    list(found=TRUE, closed=TRUE,
         payload=substr(v, opening+1L, closing-1L),
         rest=substring(v, closing+1L))
  }
  probe <- sub("^[\\s]*```(?:latex|tex|math)?[ \\t]*\\r?\\n", "", field,
               ignore.case=TRUE, perl=TRUE)
  probe <- sub("^[\\s*`$]*", "", probe, perl=TRUE)
  for (opener in c("\\[", "\\(")) {
    if (startsWith(probe, opener)) {
      closer <- if(opener == "\\[") "\\]" else "\\)"
      probe <- trimws(substring(probe, 3L))
      if (!grepl("^\\\\(?:boxed|text|mathbf|mathrm)[[:space:]]*\\{", probe, perl=TRUE)) {
        at <- regexpr(closer, probe, fixed=TRUE)[1]
        if(at < 0L) return(list(found=TRUE, value=NA_real_))
        payload <- trimws(substr(probe,1L,at-1L))
        rest <- substring(probe,at+nchar(closer))
        value <- clean_extracted_num(payload)
        completed <- paste0("^",SCALAR_NUMBER_PATTERN,"(?:\\s*[-+*/^]\\s*",
          SCALAR_NUMBER_PATTERN,")+\\s*=\\s*(",SCALAR_NUMBER_PATTERN,")$")
        if(!is.finite(value) && grepl(completed,payload,perl=TRUE) &&
           grepl("(?im)^[ \\t*`]*(?:answer|rating|score)[ \\t*`]*[:=]",rest,perl=TRUE))
          value <- clean_extracted_num(sub(completed,"\\1",payload,perl=TRUE))
        return(list(found=TRUE, value=value, rest=rest))
      }
    }
  }
  outer <- read_wrapper(probe)
  if (!outer$found) return(list(found=FALSE))
  if (!outer$closed) return(list(found=TRUE, value=NA_real_))
  payload <- trimws(outer$payload)
  text_wrapper <- grepl("^\\\\(?:text|mathbf|mathrm)[[:space:]]*\\{", probe, perl=TRUE)
  label <- grepl("^(?:(?:ethical|ethicality|ethics|moral)[[:space:]]+)?(?:rating|score|answer)[[:space:]]*[:=]?$",
                 payload, ignore.case=TRUE, perl=TRUE)
  inside_connector <- label && grepl("[:=]$",payload)
  descriptor <- grepl("^(?:(?:slightly|moderately|mildly|strongly|extremely|very|somewhat|highly|fairly)[[:space:]]+)*(?:(?:un)?ethical|neutral)[ \\t\u2014\u2013-]*$",
                      payload, ignore.case=TRUE, perl=TRUE)
  connector <- "^[[:space:]]*(?:=|:|\\\\approx|\u2248)[[:space:]]*"
  if (text_wrapper && ((label && (inside_connector || grepl(connector, outer$rest, perl=TRUE))) || descriptor)) {
    after <- if (label && !inside_connector) sub(connector, "", outer$rest, perl=TRUE) else outer$rest
    scalar_match <- regexpr(paste0("^[\\s*`]*", SCALAR_NUMBER_PATTERN,
      "(?=[ \\t*`]*(?:[\\r\\n]|$|\\\\\\]|\\\\\\)|\\$))"), after, perl=TRUE)
    if (scalar_match[1] < 0L) return(list(found=TRUE, value=NA_real_))
    scalar_text <- sub("^[\\s*`]*", "", regmatches(after, scalar_match), perl=TRUE)
    payload <- scalar_text
    outer$rest <- substring(after, attr(scalar_match, "match.length")+1L)
  }
  repeat {
    inner <- read_wrapper(payload)
    if (!inner$found) break
    if (!inner$closed || nzchar(trimws(inner$rest)))
      return(list(found=TRUE, value=NA_real_))
    payload <- trimws(inner$payload)
  }
  # Remove closing display delimiters while preserving line breaks. 
  rest <- outer$rest
  repeat {
    cleaned <- sub("^([\\s*`]*)(?:\\\\\\]|\\\\\\)|\\$\\$?)([\\s*`]*)", "\\1\\2", rest, perl=TRUE)
    if (identical(cleaned, rest)) break
    rest <- cleaned
  }
  list(found=TRUE, value=clean_extracted_num(payload), rest=rest)
}

extract_rating <- function(x, .resolve_final_fields = TRUE) {
  x <- gsub("[\u2212\u2013]", "-", as.character(x), perl = TRUE)
  x <- gsub("\\p{Zs}", " ", x, perl = TRUE)
  x <- normalize_scalar_format(x)
  x <- gsub(paste0("(?<![[:alnum:]_])_(",SCALAR_NUMBER_PATTERN,")_(?![[:alnum:]_])"),"\\1",x,perl=TRUE)
  x <- gsub("[\u2010\u2011](?=[ \\t]*[0-9.])","-",x,perl=TRUE)
  x <- gsub(paste0("\\\\{1,2}(?:text|mathbf|mathrm)[{][ \\t]*(",SCALAR_NUMBER_PATTERN,")[ \\t]*[}]"),"\\1",x,perl=TRUE)
  for (delimiters in list(c("[(]","[)]"),c("[[]","[]]"))) {
    scalar_math <- paste0("\\\\{1,2}",delimiters[1],"[\\s]*(",SCALAR_NUMBER_PATTERN,")[\\s]*\\\\{1,2}",delimiters[2])
    x <- gsub(scalar_math,"\\1",x,perl=TRUE)
  }
  out <- rep(NA_real_, length(x)); src <- rep(NA_character_, length(x))
  in_range <- function(v) is.finite(v) & v >= RATING_SCALE_MIN & v <= RATING_SCALE_MAX
  bare_pattern <- paste0("^[\\s*`]*(", SCALAR_NUMBER_PATTERN, ")[\\s*`]*$")
  bare_rows <- which(!is.na(x) & grepl(bare_pattern, x, perl = TRUE))
  bare <- suppressWarnings(as.numeric(sub(bare_pattern, "\\1", x[bare_rows], perl = TRUE)))
  out[bare_rows] <- ifelse(in_range(bare), bare, NA_real_)
  src[bare_rows] <- ifelse(in_range(bare), "bare", "out_of_range_bare")
  for (row in setdiff(which(!is.na(x)), bare_rows)) {
    text <- x[row]
    # Multiple complete numeric lines are one answer only when every line
    # agrees. 
    numeric_lines <- trimws(strsplit(text, "[\\r\\n]", perl=TRUE)[[1]])
    numeric_lines <- numeric_lines[nzchar(numeric_lines)]
    if (length(numeric_lines) > 1L &&
        all(grepl(paste0("^", SCALAR_NUMBER_PATTERN, "$"), numeric_lines, perl=TRUE))) {
      line_values <- vapply(numeric_lines, clean_extracted_num, numeric(1))
      if (all(in_range(line_values)) && length(unique(line_values)) == 1L) {
        out[row] <- line_values[1]; src[row] <- "identical_complete_numeric_lines"
      } else src[row] <- "conflicting_or_invalid_numeric_lines"
      next
    }
    # Only an explicit replacement directive supersedes previous final blocks.
    correction <- gregexpr("(?im)^[ \\t*`]*(?:correction|corrected answer|replacement answer)\\s*[:=][ \\t*`]*", text, perl = TRUE)[[1]]
    replaced <- correction[1] > 0L
    if (replaced) text <- paste0("Answer: ", substring(text, tail(correction, 1) + tail(attr(correction, "match.length"), 1)))
    final_fields <- gregexpr(paste0(
      "\\b(?:final|rounded)\\s+(?:answer|rating|score|value|assessment)\\b(?:\\s+under\\s+(?:the\\s+)?assumption\\s+of\\s+[^\\r\\n:;=0-9]{1,100})?[ \\t*`]*(?:\\([^\\r\\n()]*\\)[ \\t*`]*)?(?:[:=]|\\bis\\b)[ \\t*`]*|",
      "(?m)^[ \\t*`#>]*(?:final|rounded)\\s+(?:answer|rating|score|value|assessment)\\b(?![ \\t*`]*\\?)(?:\\s+under\\s+(?:the\\s+)?assumption\\s+of\\s+[^\\r\\n:;=0-9]{1,100})?[ \\t*`]*(?:\\([^\\r\\n()]*\\)[ \\t*`]*)?(?:(?:[:=]|\\bis\\b)[ \\t*`]*)?"), text,
                             ignore.case = TRUE, perl = TRUE)[[1]]
    if (.resolve_final_fields && final_fields[1] > 0L) {
      starts <- final_fields + attr(final_fields, "match.length")
      stops <- c(final_fields[-1] - 1L, nchar(text))
      vals <- vapply(seq_along(starts), function(j) {
        raw_field <- substr(text, starts[j], stops[j])
        field <- trimws(raw_field)
        field <- sub("^([+-])[[:space:]]+(?=[0-9.])", "\\1", field, perl=TRUE)
        starts_on_newline <- grepl("^[ \\t*`]*\\r?\\n", raw_field, perl=TRUE)
        # An inline "> 2"
        # is not rewritten into a point estimate.
        if (starts_on_newline)
          field <- gsub("(?m)^[ \\t]*>[ \\t]+", "", field, perl=TRUE)
        lines <- strsplit(field, "[\\r\\n]", perl=TRUE)[[1]]
        if (!length(lines)) return(NA_real_)
        first <- trimws(lines[1])
        first_plain <- sub("^[ \\t*`#>]*", "", first, perl=TRUE)
        reasoning_list <- starts_on_newline &&
          grepl("^(?:[0-9]+[.)]|[-+])[ \\t]+[[:alpha:]]", first_plain, perl=TRUE)
        if (grepl("^(?:unavailable|unknown|undefined|invalid|not\\s+(?:available|applicable|provided)|no\\s+(?:answer|rating|score)|(?:I\\s+)?(?:cannot|can't|unable\\s+to))\\b|^(?:none|null|n/?a)[ \\t.*`]*$",
                  first_plain, ignore.case=TRUE, perl=TRUE)) return(NA_real_)
        if (!reasoning_list && grepl("^[+0-9.-]", first_plain) &&
            !is.finite(extract_rating(paste0("Final answer: ", first), .resolve_final_fields=FALSE)$rating[1])) return(NA_real_)
        wrapped <- leading_rating_wrapper(field)
        if (wrapped$found) {
          if (!in_range(wrapped$value)) return(NA_real_)
          field <- paste0("\\boxed{", sprintf("%.17g", wrapped$value), "}", wrapped$rest)
        }
        field <- gsub(paste0("\\\\(?:mathbf|mathrm|text)\\{[ \\t]*(", SCALAR_NUMBER_PATTERN, ")[ \\t]*\\}"), "\\\\boxed{\\1}", field, perl=TRUE)
        prefix <- if (starts_on_newline) "Final answer:\n" else "Final answer: "
        extract_rating(paste0(prefix, trimws(field)), .resolve_final_fields=FALSE)$rating[1]
      }, numeric(1))
      if (all(in_range(vals)) && length(unique(vals)) == 1L) {
        out[row] <- vals[1]
        src[row] <- paste0(if (replaced) "explicit_replacement__" else "", "final_answer")
      } else src[row] <- "invalid_or_conflicting_explicit_final"
      next
    }
    values_all <- numeric(); rules_all <- character(); invalid_all <- logical(); explicit_new_all <- logical()
    for (nm in names(.rating_anchor_patterns)) {
      loc <- gregexec(.rating_anchor_patterns[[nm]], text, ignore.case = TRUE, perl = TRUE)[[1]]
      m <- regmatches(text, list(loc))[[1]]
      if (!is.matrix(m)) next
      starts <- loc[1, ]; ends <- starts + attr(loc, "match.length")[1, ] - 1L
      prefix <- substring(text, pmax(1L, starts - 90L), pmax(0L, starts - 1L))
      suffix <- substring(text, ends + 1L, ends + 100L)
      excluded <- grepl("\\b(?:maximum|minimum|highest|lowest|confidence|certainty)\\s+(?:possible\\s+)?(?:(?:moral|ethical)\\s+)?$", prefix, ignore.case = TRUE, perl = TRUE) |
        grepl("^[\\s*`]*(?:\\(\\s*)?(?:confidence|certainty)\\b", suffix, ignore.case = TRUE, perl = TRUE) |
        grepl("\\brate\\s+(?:(?:my|the)\\s+)?(?:confidence|certainty)\\b", m[1, ], ignore.case = TRUE, perl = TRUE)
      plain_prefix <- gsub("[*`\u201c\u201d]", "", prefix, perl = TRUE)
      excluded <- excluded |
        grepl("(?:did\\s+not|didn['\u2019]t|would\\s+not|wouldn['\u2019]t|not|don['\u2019]t)\\s*$", plain_prefix, ignore.case = TRUE, perl = TRUE) |
        (nm == "rating_of" & grepl("\\b(?:maximum|minimum|highest|lowest|extrem(?:e|ely)|most\\s+(?:un)?ethical|severe|worst|top)\\b[[:alpha:] \\t\"'\u2018\u2019-]{0,40}$", plain_prefix, ignore.case = TRUE, perl = TRUE)) |
        grepl("\\bprevents?\\s+(?:a\\s+)?$", plain_prefix, ignore.case = TRUE, perl = TRUE)
      if (nm == "rating_of") excluded <- excluded |
        grepl("^[\\s*`]*(?:would\\s+be|is)\\s+reserved\\b", suffix, ignore.case = TRUE, perl = TRUE)
      if (nm == "rate_it_as") excluded <- excluded |
        grepl("\\b(?:some\\s+people|others)\\s+(?:might|would|could)\\s*$", plain_prefix, ignore.case = TRUE, perl = TRUE)
      if (nm == "rating_passive") excluded <- excluded |
        grepl("\\b(?:intentional\\s+harm|more\\s+serious\\s+(?:unethical\\s+)?acts?(?:\\s+that)?|which)\\s*$", plain_prefix, ignore.case = TRUE, perl = TRUE)
      if (nm %in% c("tentative_rating","qualified_assignment")) excluded <- excluded |
        grepl("\\bwhile\\s+(?:the\\s+)?(?:full\\s+)?(?:ethical\\s+)?$", plain_prefix, ignore.case = TRUE, perl = TRUE) |
        grepl("\\b(?:cultures|countries)\\b[^.\\n]{0,80}$", plain_prefix, ignore.case = TRUE, perl = TRUE)
      if (nm == "qualified_assignment") excluded <- excluded |
        grepl("\\bif\\b[^.\\r\\n]{0,100}$", plain_prefix, ignore.case=TRUE, perl=TRUE)
      if (nm %in% c("qualified_assignment","scenario_assignment","explicit_judgment",
          "scale_assignment","scale_conclusion","rated_assignment","qualitative_conclusion",
          "described_assignment","rating_for_scenario","qualified_rating_context",
          "first_person_placement","subject_is_rating","display_rating","result_assignment",
          "assumption_answer","rating_scale_qualified","assessment_label","scale_answer_label",
          "rated_value_label","first_person_direct","causal_placement","qualitative_numeric","neutral_rated",
          "scenario_modal_value","ethical_value","default_neutral","rating_qualitative_field",
          "collective_rating","rated_qualitative_conclusion","rating_symbol","personal_assess_conclusion",
          "rating_explained_block","rating_qualified_passive","approximate_conclusion","assumed_scenario_estimate",
          "qualified_averaged_conclusion","neutral_midpoint_assignment","balanced_view_assignment",
          "scenario_looks_like","scale_assignment_qualitative","contextual_heading_rating",
          "rate_it_modifier","balance_assignment","classify_approximation","scenario_end_assignment")) {
        excluded <- excluded | (grepl("\\b(?:view|perspective|standpoint|framework)\\b[^.\\r\\n]{0,100}$",plain_prefix,ignore.case=TRUE,perl=TRUE) & !grepl("\\b(?:neutral|balanced|overall)\\s+standpoint\\b",plain_prefix,ignore.case=TRUE,perl=TRUE))
        excluded <- excluded | grepl("\\b(?:would\\s+you\\s+like\\s+me\\s+to\\s+assume[^?]{0,100}\\bor\\b[^?]{0,100}interpretation|which\\s+(?:case|scenario|interpretation)|(?:could|can)\\s+you\\s+clarify)\\b[^?]{0,150}\\?",substring(text,ends+1L),ignore.case=TRUE,perl=TRUE)
      }
      if (nm == "qualified_rating_context") excluded <- excluded |
        grepl("\\b(?:drop|shift|change|move|fall|rise|increase|decrease)\\b",m[1,],ignore.case=TRUE,perl=TRUE)
      if (nm %in% c("scale_conclusion","scale_assignment","scale_answer_label")) excluded <- excluded |
        grepl("^[\\s*`]*(?:=|\u2192|\\([^\\r\\n)]{0,100}\\)[\\s*`]*[\u2192-]+[\\s*`]*[+0-9])",suffix,perl=TRUE)
      excluded <- excluded | (grepl("[\\r\\n]", m[1, ], perl=TRUE) & grepl("^[.)][ \\t*`]+[[:alpha:]]", suffix))
      excluded <- excluded | (grepl("[\\r\\n]", m[1, ], perl=TRUE) &
        grepl("[0-9]\\.$", m[1, ], perl = TRUE) & grepl("^[ \\t*`]+[[:alpha:]]", suffix))
      bad <- grepl("^[\\s*`]*(?:[+*/=^\u00d7\u00f7][\\s*`]*[+-]?(?:[0-9]|\\.[0-9])|-[ \\t]*[0-9]|\\.[\\s.]*[0-9.]|[0-9])", suffix, perl = TRUE) |
        grepl("^[\\s*`.,;]*(?:or\\b|alternatively\\b|to\\s+[+-]?[0-9])", suffix, ignore.case = TRUE, perl = TRUE)
      if (nm %in% c("rating_label","qualified_assignment","qualified_rating_context") &&
          grepl("\\b(?:ethical|unethical|moral|ethics)\\b",text,ignore.case=TRUE,perl=TRUE)) {
        out_of_four <- grepl("^[\\s*`]*[/][ \\t]*4[ \\t*`]*(?:[\\r\\n]|$)",suffix,perl=TRUE)
        bad[out_of_four] <- FALSE
      }
      bad <- bad | grepl("^\\.[ \\t]*[eE]", suffix, perl = TRUE) |
        (grepl("\\.$", m[1, ], perl = TRUE) & grepl("^\\.", suffix, perl = TRUE))
      for (j in which(!excluded)) {
        captures <- m[-1, j]; captures <- captures[!is.na(captures) & nzchar(captures)]
        vals <- unique(vapply(captures, clean_extracted_num, numeric(1)))
        val <- if (length(vals) == 1L) vals else NA_real_
        values_all <- c(values_all, val); rules_all <- c(rules_all, nm)
        invalid_all <- c(invalid_all, bad[j] || !is.finite(val))
        direct_scenario <- nm %in% c("scenario_assignment", "scenario_modal_value") &&
          grepl("^(?:this|the)\\s+(?:scenario|situation|action|act|behaviou?r)\\b", m[1,j], ignore.case=TRUE, perl=TRUE)
        direct_person <- nm == "first_person_placement" && !bad[j] &&
          !grepl("\\b(?:not|but|though)\\b",m[1,j],ignore.case=TRUE,perl=TRUE) &&
          !grepl("^[ \\t*`]+[[:alpha:]]", suffix[j], perl=TRUE)
        explicit_new_all <- c(explicit_new_all, direct_scenario || direct_person)
      }
    }
    if (!length(values_all)) next
    weak <- rules_all %in% c("rating_qualified_passive", "rated_assignment",
      "scale_assignment", "scale_conclusion", "scale_answer_label",
      "qualified_rating_context", "scenario_modal_value", "scenario_assignment",
      "rate_it_modifier", "first_person_placement") & !explicit_new_all
    unresolved_choice <- grepl(
      "\\b(?:would\\s+you\\s+like\\s+me\\s+to\\s+assume[^?]{0,180}\\bor\\b|do\\s+you\\s+want\\s+me\\s+to\\s+rate[^?]{0,180}\\bor\\s+keep\\b)[^?]{0,180}\\?",
      text, ignore.case=TRUE, perl=TRUE)
    if (any(!weak & in_range(values_all) & !invalid_all) && !unresolved_choice) {
      values_all <- values_all[!weak]; invalid_all <- invalid_all[!weak]
      rules_all <- rules_all[!weak]
    }
    final <- rules_all %in% c("final_answer","expressed_rating","result_assignment")
    use <- if (any(final)) final else (in_range(values_all) | invalid_all)
    if (!any(use)) { src[row] <- "out_of_range_anchors"; next }
    vals <- unique(values_all[use])
    if (any(invalid_all[use]) || length(vals) != 1L) {
      src[row] <- "ambiguous_or_invalid_anchors"; next
    }
    if (!in_range(vals)) { src[row] <- "out_of_range_final_answer"; next }
    out[row] <- vals
    src[row] <- paste0(if (replaced) "explicit_replacement__" else "", rules_all[which(use)[1]])
  }
  list(rating = out, source = src)
}
write_rating_parse_audit <- function(parsed, label) {
  safe_label <- stringr::str_replace_all(label, "[^A-Za-z0-9]+", "_")
  summary <- parsed %>%
    group_by(across(any_of(c("model_name", "input_id"))), rating_rule) %>%
    summarise(n_responses = n(), n_accepted = sum(!is.na(rating)),
              n_missing = sum(is.na(rating)), .groups = "drop") %>%
    mutate(stage = "before removing missing parses and before the draw cap")
  readr::write_csv(summary,
    file.path(out_dir, paste0("CHECK_rating_parser_summary_", safe_label, ".csv")))
  readr::write_csv(
    parsed %>% filter(is.na(rating_rule) | rating_rule != "bare") %>%
      select(any_of(c("input_id", "model_name", "temperature", "prompt_id",
        "prompt_src_basename", "sequence", "replicate_index", "group_index",
        "rating", "rating_rule", "output_seq"))),
    file.path(out_dir, paste0("CHECK_rating_prose_parses_", safe_label, ".csv")))
}

# Standardize model labels for distribution shape before using them in downstream code.
clean_distribution_shape <- function(x) {
  raw <- as.character(x)
  raw[is.na(x) | !nzchar(stringr::str_trim(raw))] <- NA_character_

  spaced <- raw %>%
    stringr::str_to_lower() %>%
    stringr::str_replace_all("[^a-z]+", " ") %>%
    stringr::str_squish()

  compact <- spaced %>%
    stringr::str_replace_all("[^a-z]", "")

  bimodal_pat <- "bimodal|bimonal|bimodel|bimodall|twomodes|twopeaks|doublepeaked"
  unimodal_pat <- "unimodal|unimonal|unimodel|unimodall|onemode|onepeak|singlemode|singlepeaked"

  has_bimodal <- stringr::str_detect(compact, bimodal_pat)
  has_unimodal <- stringr::str_detect(compact, unimodal_pat)

  negated_bimodal <- stringr::str_detect(
    spaced,
    stringr::regex(
      "\\b(no|not|isn t|isnt|is not|cannot be|can t be|cant be)\\b.{0,30}\\b(bi\\s*modal|bimodal|two\\s+modes|two\\s+peaks|double\\s+peaked)\\b|\\b(no evidence of|lack of|without)\\b.{0,30}\\b(bimodality|bimodal|two\\s+peaks|two\\s+modes)\\b",
      ignore_case = TRUE
    )
  )

  negated_unimodal <- stringr::str_detect(
    spaced,
    stringr::regex(
      "\\b(no|not|isn t|isnt|is not|cannot be|can t be|cant be)\\b.{0,30}\\b(uni\\s*modal|unimodal|one\\s+mode|one\\s+peak|single\\s+peaked)\\b|\\b(no evidence of|lack of|without)\\b.{0,30}\\b(unimodality|unimodal|one\\s+peak|one\\s+mode)\\b",
      ignore_case = TRUE
    )
  )

  has_bimodal <- has_bimodal & !negated_bimodal
  has_unimodal <- has_unimodal & !negated_unimodal

  first_bi <- stringr::str_locate(compact, bimodal_pat)[, 1]
  first_uni <- stringr::str_locate(compact, unimodal_pat)[, 1]

  dplyr::case_when(
    is.na(compact) ~ NA_character_,
    negated_bimodal & !has_unimodal ~ "unimodal",
    negated_unimodal & !has_bimodal ~ "bimodal",
    has_bimodal & !has_unimodal ~ "bimodal",
    has_unimodal & !has_bimodal ~ "unimodal",
    has_bimodal & has_unimodal & first_bi < first_uni ~ "bimodal",
    has_bimodal & has_unimodal & first_uni < first_bi ~ "unimodal",
    compact %in% c("bi", "bimode", "bimod") ~ "bimodal",
    compact %in% c("uni", "unimode", "unimod") ~ "unimodal",
    TRUE ~ compact
  )
}

safe_get <- function(obj, key) {
  if (is.list(obj) && key %in% names(obj)) obj[[key]] else NULL
}

strip_fences <- function(x) {
  x <- str_replace_all(x, "^\\s*```[a-zA-Z]*\\s*", "")
  x <- str_replace_all(x, "\\s*```\\s*$", "")
  str_trim(x)
}

extract_braces <- function(x) {
  if (!str_detect(x, "\\{")) return(x)
  s <- str_locate_all(x, fixed("{"))[[1]]
  e <- str_locate_all(x, fixed("}"))[[1]]
  if (nrow(s) == 0 || nrow(e) == 0) return(x)
  substr(x, s[1, 1], e[nrow(e), 2])
}

parse_json_safe <- function(x) {
  tryCatch(fromJSON(x, simplifyVector = TRUE), error = function(e) NULL)
}


# Distribution-distance metrics used to compare model-implied and empirical human distributions.
tvd_dist <- function(p, q) {
  p <- as.numeric(p); q <- as.numeric(q)
  if (length(p) != length(q)) return(NA_real_)
  if (anyNA(p) || anyNA(q)) return(NA_real_)
  if (sum(p) <= 0 || sum(q) <= 0) return(NA_real_)
  p <- p / sum(p)
  q <- q / sum(q)
  0.5 * sum(abs(p - q))
}

emd_1d <- function(p, q) {
  p <- as.numeric(p); q <- as.numeric(q)
  if (length(p) != length(q)) return(NA_real_)
  if (anyNA(p) || anyNA(q)) return(NA_real_)
  if (sum(p) <= 0 || sum(q) <= 0) return(NA_real_)
  p <- p / sum(p)
  q <- q / sum(q)
  sum(abs(cumsum(p) - cumsum(q)))
}

jsd <- function(p, q) {
  p <- as.numeric(p); q <- as.numeric(q)
  if (length(p) != length(q)) return(NA_real_)
  if (anyNA(p) || anyNA(q)) return(NA_real_)
  if (sum(p) <= 0 || sum(q) <= 0) return(NA_real_)
  eps <- 1e-10
  p <- p + eps; q <- q + eps
  p <- p / sum(p); q <- q / sum(q)
  m <- 0.5 * (p + q)
  sqrt(0.5 * sum(p * log(p / m)) + 0.5 * sum(q * log(q / m)))
}


# Scenario IDs are classified as the current study's original/reworded scenarios or the Schroeder comparison set.
classify_scenario <- function(id) {
  case_when(
    str_detect(id, "^\\d+_new$")   ~ "present_paper_new",
    str_detect(id, "^\\d+_old$")   ~ "present_paper_old",
    str_detect(id, "^Schroeder_new_") ~ "Schroeder_new",
    str_detect(id, "^Schroeder_old_") ~ "Schroeder_old",
    TRUE                           ~ "other"
  )
}

# Model identity normalization
MODEL_NAME_CANONICAL <- c(
  "gpt-3.5-turbo-1106" = "gpt-35-turbo_1106",
  "gpt-3.5-turbo_1106" = "gpt-35-turbo_1106",
  "gpt-35-turbo-1106"  = "gpt-35-turbo_1106"
)

normalize_model_name <- function(x) {
  x0 <- as.character(x)
  hit <- !is.na(x0) & x0 %in% names(MODEL_NAME_CANONICAL)
  x0[hit] <- unname(MODEL_NAME_CANONICAL[x0[hit]])
  x0
}

canonical_scenario_id <- function(x) {
  x0 <- as.character(x)
  x0 <- stringr::str_trim(x0)
  x0 <- stringr::str_replace_all(x0, "\\\\", "/")
  
  direct <- stringr::str_extract(x0, "\\d+_(?:new|old)")
  
  n_id <- stringr::str_match(
    x0, "(?:^|[^A-Za-z])n_(\\d+)(?:_|$)"
  )[, 2]
  o_id <- stringr::str_match(
    x0, "(?:^|[^A-Za-z])o_(\\d+)(?:_|$)"
  )[, 2]
  
  out <- dplyr::case_when(
    !is.na(direct) ~ direct,
    !is.na(n_id) ~ paste0(n_id, "_new"),
    !is.na(o_id) ~ paste0(o_id, "_old"),
    TRUE ~ x0
  )
  
  stringr::str_replace(out, "^X(?=\\d)", "")
}

PRESENT_PAPER_SCENARIO_TYPES <- c("present_paper_new", "present_paper_old")
SCHROEDER_SCENARIO_TYPES <- c("Schroeder_new", "Schroeder_old")
WORDING_SCENARIO_TYPES <- c(PRESENT_PAPER_SCENARIO_TYPES, SCHROEDER_SCENARIO_TYPES)

make_scenario_version <- function(scenario_type) {
  case_when(
    scenario_type %in% c("present_paper_new", "Schroeder_new") ~ "new",
    scenario_type %in% c("present_paper_old", "Schroeder_old") ~ "old",
    TRUE ~ NA_character_
  )
}

safe_cor <- function(x, y) {
  if (sum(complete.cases(x, y)) < 3) return(NA_real_)
  cor(x, y, use = "complete.obs")
}

cohen_d_ind <- function(x, y) {
  x <- x[!is.na(x)]
  y <- y[!is.na(y)]

  nx <- length(x)
  ny <- length(y)

  if (nx < 2 || ny < 2) return(NA_real_)

  sx <- sd(x)
  sy <- sd(y)

  pooled_sd <- sqrt(((nx - 1) * sx^2 + (ny - 1) * sy^2) / (nx + ny - 2))

  if (is.na(pooled_sd) || pooled_sd == 0) return(NA_real_)

  (mean(x) - mean(y)) / pooled_sd
}

cohen_d_paired <- function(x, y) {
  mean(x - y, na.rm = TRUE) / sd(x - y, na.rm = TRUE)
}


# Human scenario data
# Convert Qualtrics-style wide columns into long-format moral ratings and confusion ratings.
validate_human_moral_rows <- function(x, sample_label,
                                      audit_prefix = "CHECK_invalid_raw_ratings") {
  x$raw_num <- suppressWarnings(as.numeric(as.character(x$raw)))
  invalid <- !is.finite(x$raw_num) | x$raw_num < 1 | x$raw_num > 9 |
    x$raw_num != round(x$raw_num)
  safe_sample <- gsub("[^A-Za-z0-9]+", "_", sample_label)
  audit_path <- file.path(out_dir, paste0(audit_prefix, "_", safe_sample, ".csv"))
  utils::write.csv(x[invalid, , drop = FALSE], audit_path, row.names = FALSE)
  if (any(invalid)) stop("Invalid human moral ratings before rescaling in ",
    sample_label, "; inspect ", audit_path,
    ". If these are export metadata rows, identify and remove them explicitly.")
  x
}

people <- read.csv(path_human_csv, stringsAsFactors = FALSE)

moral_cols <- names(people)[
  str_detect(names(people), "_moral$") |
    (str_detect(names(people), "^t_[no]_") & str_detect(names(people), "_m$")) |
    str_detect(names(people), "^Schroeder_(new|old)_.*_m$")
]

map_col_to_id <- function(colname) {
  case_when(
    str_detect(colname, "^n_\\d+_moral$") ~
      paste0(str_match(colname, "^n_(\\d+)_moral$")[, 2], "_new"),

    str_detect(colname, "^o_\\d+_moral$") ~
      paste0(str_match(colname, "^o_(\\d+)_moral$")[, 2], "_old"),

    str_detect(colname, "^X?\\d+_(new|old)_moral$") ~
      str_replace(str_replace(colname, "_moral$", ""), "^X", ""),

    str_detect(colname, "^t_n_.*_m$") ~
      paste0("Schroeder_new_", str_replace(colname, "^t_n_(.*)_m$", "\\1")),

    str_detect(colname, "^t_o_.*_m$") ~
      paste0("Schroeder_old_", str_replace(colname, "^t_o_(.*)_m$", "\\1")),

    str_detect(colname, "^Schroeder_(new|old)_.*_m$") ~
      str_replace(colname, "_m$", ""),

    TRUE ~ NA_character_
  )
}

human_long <- people %>%
  dplyr::select(all_of(moral_cols)) %>%
  mutate(respondent_id = row_number()) %>%
  pivot_longer(-respondent_id, names_to = "colname", values_to = "raw") %>%
  filter(!is.na(raw), trimws(as.character(raw)) != "") %>%
  validate_human_moral_rows("main") %>%
  mutate(input_id = map_col_to_id(colname), human_y = raw_num - 5) %>%
  filter(!is.na(input_id), !is.na(human_y)) %>%
  dplyr::select(respondent_id, input_id, human_y, raw_num)

human_long <- human_long %>% dplyr::select(-raw_num)

cat("Total human_long:", nrow(human_long), "obs across",
    n_distinct(human_long$input_id), "scenarios\n")

confuse_cols <- names(people)[
  str_detect(names(people), "_confuse$") |
    (str_detect(names(people), "^t_[no]_") & str_detect(names(people), "_c$")) |
    str_detect(names(people), "^Schroeder_(new|old)_.*_c$")
]

map_confuse_to_id <- function(colname) {
  case_when(
    str_detect(colname, "^n_\\d+_confuse$") ~
      paste0(str_match(colname, "^n_(\\d+)_confuse$")[, 2], "_new"),

    str_detect(colname, "^o_\\d+_confuse$") ~
      paste0(str_match(colname, "^o_(\\d+)_confuse$")[, 2], "_old"),

    str_detect(colname, "^X?\\d+_(new|old)_confuse$") ~
      str_replace(str_replace(colname, "_confuse$", ""), "^X", ""),

    str_detect(colname, "^t_n_.*_c$") ~
      paste0("Schroeder_new_", str_replace(colname, "^t_n_(.*)_c$", "\\1")),

    str_detect(colname, "^t_o_.*_c$") ~
      paste0("Schroeder_old_", str_replace(colname, "^t_o_(.*)_c$", "\\1")),

    str_detect(colname, "^Schroeder_(new|old)_.*_c$") ~
      str_replace(colname, "_c$", ""),

    TRUE ~ NA_character_
  )
}

human_confuse <- people %>%
  dplyr::select(all_of(confuse_cols)) %>%
  mutate(respondent_id = row_number()) %>%
  pivot_longer(-respondent_id, names_to = "colname", values_to = "raw") %>%
  filter(!is.na(raw) & raw != "") %>%
  mutate(
    input_id = map_confuse_to_id(colname),
    confusion = suppressWarnings(as.numeric(raw))
  ) %>%
  filter(!is.na(input_id), !is.na(confusion)) %>%
  dplyr::select(respondent_id, input_id, confusion)


# Shared original scenarios
# A small set of original scenarios was rated under Schroeder names; copy those rows to the matching current-study IDs.
schroeder_to_present_paper_old_map <- tribble(
  ~schroeder_id,                ~present_paper_id,
  "Schroeder_old_cancer",       "1_old",
  "Schroeder_old_childrencar",  "41_old",
  "Schroeder_old_coat",         "150_old",
  "Schroeder_old_frienddebt",   "216_old",
  "Schroeder_old_debris",       "280_old",
  "Schroeder_old_marathon",     "320_old"
)

cat("\n── Duplicating Schroeder_old → present_paper_old ──\n")

src_check <- schroeder_to_present_paper_old_map %>%
  mutate(
    in_moral   = schroeder_id %in% human_long$input_id,
    in_confuse = schroeder_id %in% human_confuse$input_id
  )
cat("\nSource ID presence check:\n")
print(src_check)

missing_src <- src_check %>% filter(!in_moral | !in_confuse)
if (nrow(missing_src) > 0) {
  stop("Some Schroeder_old source IDs missing from human data. ",
       "Check column-name mapping :\n",
       paste(missing_src$schroeder_id, collapse = ", "))
}

dest_check <- schroeder_to_present_paper_old_map %>%
  mutate(
    moral_n_existing   = map_int(present_paper_id, ~ sum(human_long$input_id    == .x)),
    confuse_n_existing = map_int(present_paper_id, ~ sum(human_confuse$input_id == .x))
  )
cat("\nDestination ID existing-data check (should all be 0):\n")
print(dest_check)

conflicts <- dest_check %>%
  filter(moral_n_existing > 0 | confuse_n_existing > 0)
if (nrow(conflicts) > 0) {
  stop("Destination present_paper_old IDs ALREADY have respondent data. ",
       "Copying would produce duplicate respondents. ",
       "Check whether the mapping should be _old (not _new):\n",
       paste(conflicts$present_paper_id, collapse = ", "))
}

copy_moral <- human_long %>%
  inner_join(schroeder_to_present_paper_old_map, by = c("input_id" = "schroeder_id")) %>%
  mutate(input_id = present_paper_id) %>%
  dplyr::select(respondent_id, input_id, human_y)

copy_confuse <- human_confuse %>%
  inner_join(schroeder_to_present_paper_old_map, by = c("input_id" = "schroeder_id")) %>%
  mutate(input_id = present_paper_id) %>%
  dplyr::select(respondent_id, input_id, confusion)

cat("\nRows being added:\n")
cat("  Moral:    ", nrow(copy_moral),    "rows across",
    n_distinct(copy_moral$input_id),    "scenarios\n")
cat("  Confusion:", nrow(copy_confuse),  "rows across",
    n_distinct(copy_confuse$input_id),  "scenarios\n")

human_long    <- bind_rows(human_long,    copy_moral)
human_confuse <- bind_rows(human_confuse, copy_confuse)

human_confuse_means <- human_confuse %>%
  group_by(input_id) %>%
  summarise(
    mean_confusion = mean(confusion, na.rm = TRUE),
    sd_confusion = sd(confusion, na.rm = TRUE),
    n_confuse = n(),
    .groups = "drop"
  )

cat("\nConfusion scenarios after duplication:\n")
human_confuse_means %>%
  mutate(scenario_type = classify_scenario(input_id)) %>%
  count(scenario_type, name = "n_scenarios") %>%
  print(n = Inf)

cat("\nTransferred present_paper_old confusion IDs:\n")
human_confuse_means %>%
  filter(input_id %in% schroeder_to_present_paper_old_map$present_paper_id) %>%
  arrange(input_id) %>%
  print(n = Inf, width = Inf)

cat("\nAfter duplication:\n")
cat("  human_long total rows:   ", nrow(human_long),    "\n")
cat("  human_confuse total rows:", nrow(human_confuse), "\n")

cat("\nPer-ID confirmation:\n")
verify <- bind_rows(
  human_long %>%
    filter(input_id %in% c(schroeder_to_present_paper_old_map$schroeder_id,
                           schroeder_to_present_paper_old_map$present_paper_id)) %>%
    count(input_id, name = "n_moral"),
  human_confuse %>%
    filter(input_id %in% c(schroeder_to_present_paper_old_map$schroeder_id,
                           schroeder_to_present_paper_old_map$present_paper_id)) %>%
    count(input_id, name = "n_confuse")
) %>%
  group_by(input_id) %>%
  summarise(across(everything(), ~ sum(.x, na.rm = TRUE)), .groups = "drop") %>%
  arrange(input_id)
print(verify, n = Inf)


# Human summary objects used throughout the analyses
# `human_stats` stores item means/SDs, and `human_props` stores empirical bin proportions.
human_stats <- human_long %>%
  group_by(input_id) %>%
  summarise(human_mean = mean(human_y, na.rm = TRUE),
            human_sd = sd(human_y, na.rm = TRUE),
            human_n = n(), .groups = "drop") %>%
  mutate(scenario_type = classify_scenario(input_id))

human_props <- human_long %>%
  count(input_id, human_y, name = "n") %>%
  group_by(input_id) %>%
  complete(human_y = -4:4, fill = list(n = 0)) %>%
  mutate(human_prop = n / sum(n)) %>%
  ungroup() %>%
  mutate(bin = factor(human_y, levels = -4:4)) %>%
  dplyr::select(input_id, bin, human_prop)

scenarios_with_humans_all <- unique(human_stats$input_id)
scenarios_with_humans <- human_stats %>%
  filter(scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES) %>%
  pull(input_id) %>%
  unique()
wording_scenarios_with_humans <- human_stats %>%
  filter(scenario_type %in% WORDING_SCENARIO_TYPES) %>%
  pull(input_id) %>%
  unique()

cat("Scenarios with human data, all types:", length(scenarios_with_humans_all), "\n")
cat("  by type, all:\n")
print(table(classify_scenario(scenarios_with_humans_all)))
cat("Scenarios used in default analyses (PRESENT PAPER only):", length(scenarios_with_humans), "\n")
print(table(classify_scenario(scenarios_with_humans)))
cat("Scenarios used in wording-sensitivity analyses (PRESENT PAPER + Schroeder):", length(wording_scenarios_with_humans), "\n")
print(table(classify_scenario(wording_scenarios_with_humans)))


# Model output readers
# These readers handle standard JSONL outputs and fallback line parsing for older text files.
read_model_jsonl <- function(path) {
  if (!file.exists(path)) { cat("  ⚠ Not found:", path, "\n"); return(NULL) }
  lines <- base::readLines(path, warn = FALSE)
  cat("    (", length(lines), "lines)\n")
  ex <- function(line, key) {
    pat <- paste0('"', key, '"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"')
    m <- regmatches(line, regexec(pat, line, perl = TRUE))[[1]]
    if (length(m) >= 2) return(m[2])
    pat2 <- paste0('"', key, '"\\s*:\\s*([0-9.eE+-]+|null)')
    m2 <- regmatches(line, regexec(pat2, line, perl = TRUE))[[1]]
    if (length(m2) >= 2) return(m2[2])
    NA_character_
  }
  tibble(
    input_id = vapply(lines, ex, character(1), key = "input_id", USE.NAMES = FALSE),
    prompt_id = vapply(lines, ex, character(1), key = "prompt_id", USE.NAMES = FALSE),
    model_name = vapply(lines, ex, character(1), key = "model_name", USE.NAMES = FALSE),
    temperature = vapply(lines, ex, character(1), key = "temperature", USE.NAMES = FALSE),
    replicate_index = vapply(lines, ex, character(1), key = "replicate_index", USE.NAMES = FALSE),
    sequence = vapply(lines, ex, character(1), key = "sequence", USE.NAMES = FALSE),
    output_seq = vapply(lines, ex, character(1), key = "output_seq", USE.NAMES = FALSE)
  ) %>%
    mutate(input_id = canonical_scenario_id(input_id))
}

empty_model_rows <- function() {
  tibble(
    input_id = character(),
    prompt_id = character(),
    model_name = character(),
    temperature = character(),
    replicate_index = character(),
    sequence = character(),
    output_seq = character()
  )
}

# Some model-output files store output_seq (or trace) as a nested JSON object rather
# than as a JSON string. jsonlite::stream_in expands those into data.frame/list
# columns, which as.character() cannot coerce. Re-serialize them back to JSON text so
# the downstream parsers, which expect a character payload, keep working unchanged.
flatten_json_col <- function(col) {
  if (is.data.frame(col)) {
    vapply(
      seq_len(nrow(col)),
      function(i) as.character(jsonlite::toJSON(
        as.list(col[i, , drop = FALSE]), auto_unbox = TRUE, na = "null"
      )),
      character(1)
    )
  } else if (is.list(col)) {
    vapply(
      col,
      function(v) if (is.null(v) || (is.atomic(v) && length(v) == 1 && is.na(v))) {
        NA_character_
      } else {
        as.character(jsonlite::toJSON(v, auto_unbox = TRUE, na = "null"))
      },
      character(1)
    )
  } else {
    col
  }
}

standardize_model_rows <- function(x) {
  if (is.null(x) || !is.data.frame(x) || nrow(x) == 0) {
    return(empty_model_rows())
  }
  x <- as_tibble(x)
  needed <- names(empty_model_rows())
  for (nm in names(x)) {
    x[[nm]] <- flatten_json_col(x[[nm]])
  }
  for (nm in needed) {
    if (!nm %in% names(x)) x[[nm]] <- NA_character_
  }
  x %>%
    mutate(across(all_of(needed), as.character)) %>%
    mutate(
      input_id = canonical_scenario_id(input_id),
      model_name = normalize_model_name(model_name)
    ) %>%
    dplyr::select(all_of(needed), everything())
}

read_model_file_safe <- function(path, label = basename(path)) {
  if (!file.exists(path)) {
    cat("  ⚠ Not found:", label, "→", path, "\n")
    return(empty_model_rows())
  }
  cat("  Loading:", label, "\n")
  out <- tryCatch(
    jsonlite::stream_in(file(path), verbose = FALSE),
    error = function(e) {
      cat("    stream_in failed; trying line parser\n")
      read_model_jsonl(path)
    }
  )
  out <- standardize_model_rows(out)
  cat("    Rows:", nrow(out), "\n")
  out
}


# Confidence prompt: model moral rating, expected confusion, expected variability, SD, and confidence
cat("\n── Loading confidence-prompt files ──\n")
confidence_raw_list <- list()
for (i in seq_along(path_confidence_files)) {
  cat("  Loading:", basename(path_confidence_files[i]), "\n")
  confidence_raw_list[[i]] <- tryCatch(read_model_jsonl(path_confidence_files[i]),
                               error = function(e) { cat("    ERROR:", e$message, "\n"); NULL })
}
# Bind against an empty typed frame so the expected columns exist even when every
# confidence file is missing; otherwise downstream filters fail with an opaque
# "object 'prompt_id' not found" instead of naming the files that are absent.
scenario_raw_all <- bind_rows(empty_model_rows(), purrr::compact(confidence_raw_list)) %>%
  standardize_model_rows()

if (nrow(scenario_raw_all) == 0) {
  stop(
    "No confidence-prompt rows loaded. Expected these files under SCEN_BASE_DIR:\n  ",
    paste(path_confidence_files, collapse = "\n  "),
    "\nSet SCEN_BASE_DIR to the folder holding the model-output files."
  )
}
cat("  Total:", nrow(scenario_raw_all), "rows,", paste(unique(scenario_raw_all$model_name), collapse=", "), "\n")

confidence_raw <- scenario_raw_all %>%
  filter(as.character(prompt_id) == CONFIDENCE_PROMPT_ID, as.character(temperature) == "0")


# Parse the confidence prompt answers from a JSON object returned by the model.
parse_confidence_output <- function(txt) {
  base <- tibble(conf_model_moral_rating=NA_real_, confusion_estimate=NA_real_, variation_estimate=NA_real_,
                 sd_estimate=NA_real_, rating_confidence=NA_real_)
  if (is.na(txt) || !nzchar(str_trim(txt))) return(base)
  s <- txt
  s <- str_replace_all(s, "\\\\n", "\n"); s <- str_replace_all(s, "\\\\t", "\t")
  s <- str_replace_all(s, '\\\\"', '"'); s <- str_replace_all(s, "\\\\\\\\", "\\\\")
  s <- strip_fences(s); s <- extract_braces(s)
  obj <- parse_json_safe(s)
  if (is.null(obj) || !is.list(obj)) return(base)
  tibble(conf_model_moral_rating=num(safe_get(obj,"Answer to Q1")), confusion_estimate=num(safe_get(obj,"Answer to Q2")),
         variation_estimate=num(safe_get(obj,"Answer to Q3")), sd_estimate=num(safe_get(obj,"Answer to Q4")),
         rating_confidence=num(safe_get(obj,"Answer to Q5")))
}

parsed_confidence <- purrr::map_dfr(confidence_raw$output_seq, parse_confidence_output)
confidence_estimates_all <- bind_cols(
  confidence_raw %>% dplyr::select(input_id, model_name),
  parsed_confidence
) %>%
  mutate(.ingest_ord = dplyr::row_number())

confidence_value_cols <- setdiff(names(parsed_confidence), ".ingest_ord")
confidence_duplicate_conflicts <- confidence_estimates_all %>%
  group_by(model_name, input_id) %>%
  summarise(
    across(
      all_of(confidence_value_cols),
      ~ n_distinct(.x[!is.na(.x)]),
      .names = "n_distinct_{.col}"
    ),
    n_rows = n(),
    .groups = "drop"
  ) %>%
  filter(if_any(starts_with("n_distinct_"), ~ .x > 1L))

if (nrow(confidence_duplicate_conflicts) > 0) {
  conflict_check_file <- file.path(out_dir, "CHECK_confidence_duplicate_conflicts.csv")
  readr::write_csv(confidence_duplicate_conflicts, conflict_check_file)
  warning(
    "Conflicting duplicate confidence-prompt rows for ",
    nrow(confidence_duplicate_conflicts),
    " model x scenario cells; resolved by deterministic take-first. Recorded in ",
    conflict_check_file,
    call. = FALSE, immediate. = TRUE
  )
}

confidence_estimates <- confidence_estimates_all %>%
  arrange(input_id, model_name, .ingest_ord) %>%
  group_by(model_name, input_id) %>%
  slice(1) %>%
  ungroup() %>%
  dplyr::select(-.ingest_ord)

CONFIDENCE_EXPECTED_MODELS <- c(
  "gpt-35-turbo_1106",
  "gpt-4o-mini_2024-07-18",
  "gpt-5-chat_2025-08-07",
  "gpt-oss-20b",
  "qwen-3-32B"
)
if (!setequal(unique(confidence_estimates$model_name), CONFIDENCE_EXPECTED_MODELS)) {
  stop(
    "Confidence-prompt inputs must resolve to the exact five focal models. Found: ",
    paste(sort(unique(confidence_estimates$model_name)), collapse = "; ")
  )
}

CONFIDENCE_FULL_COVERAGE_MODELS <- c("qwen-3-32B", "gpt-oss-20b")
confidence_full_coverage <- confidence_estimates %>%
  filter(model_name %in% CONFIDENCE_FULL_COVERAGE_MODELS) %>%
  mutate(all_five_parsed = if_all(all_of(confidence_value_cols), ~ !is.na(.x))) %>%
  group_by(model_name) %>%
  summarise(
    n_scenarios = n_distinct(input_id),
    n_all_five_parsed = n_distinct(input_id[all_five_parsed]),
    .groups = "drop"
  ) %>%
  tidyr::complete(
    model_name = CONFIDENCE_FULL_COVERAGE_MODELS,
    fill = list(n_scenarios = 0L, n_all_five_parsed = 0L)
  )
readr::write_csv(
  confidence_full_coverage,
  file.path(out_dir, "CHECK_confidence_full_coverage.csv")
)
if (any(confidence_full_coverage$n_scenarios != 205L |
        confidence_full_coverage$n_all_five_parsed != 205L)) {
  stop(
    "Qwen and gpt-oss confidence coverage must each contain 205 scenarios with all five answers parsed; ",
    "see CHECK_confidence_full_coverage.csv."
  )
}

cat("\n── Confidence-prompt parse rates ──\n")
confidence_estimates %>% group_by(model_name) %>%
  summarise(n=n(), parsed=sum(!is.na(conf_model_moral_rating)), .groups="drop") %>% print()

parse_rating_numeric <- function(x) {
  extract_rating(x)$rating
}


# extract stochastic single-rating rows used for repeated sampling.
repeated_sampling_from_raw <- scenario_raw_all %>%
  filter(as.character(prompt_id) == REPEATED_RATING_PROMPT_ID, as.character(temperature) == "1") %>%
  mutate(
    input_id = canonical_scenario_id(input_id),
    rating = parse_rating_numeric(output_seq)
  ) %>%
  filter(!is.na(rating)) %>%
  dplyr::select(input_id, model_name, rating)

cat("\n── Repeated sampling (temp=1):", nrow(repeated_sampling_from_raw), "rows ──\n")


# Load the main 500 repetition repeated sampling run.
rep500 <- NULL
if (file.exists(path_repeated_500)) {
  cat("\n── Loading 500-sample repeated sampling ──\n")
  rep500_raw <- jsonlite::stream_in(file(path_repeated_500), verbose = FALSE) %>%
    as_tibble()
  cat("  Lines:", nrow(rep500_raw), "\n")

  n_all <- nrow(rep500_raw)

  rep500_t1 <- rep500_raw %>% filter(as.character(temperature) == "1")
  audit_record(
    "A2 rep500 GPT-5", "filter temperature == 1",
    rows_in = n_all, rows_out = nrow(rep500_t1),
    reason = "temperature-0 rows are not repeated-sampling draws",
    detail = basename(path_repeated_500)
  )
  cat("  Temperature-1 rows:", nrow(rep500_t1),
      "(dropped", n_all - nrow(rep500_t1), "at temperature 0)\n")

  rep500_extracted <- extract_rating(rep500_t1$output_seq)
  rep500_parsed <- rep500_t1 %>%
    mutate(
      rating      = rep500_extracted$rating,
      rating_rule = rep500_extracted$source
    )

  readr::write_csv(
    rep500_parsed %>% select(any_of(c("input_id", "model_name", "sequence",
      "replicate_index", "rating", "rating_rule", "output_seq"))),
    file.path(out_dir, "CHECK_gpt5_repeated_ratings_all.csv"))
  write_rating_parse_audit(rep500_parsed, "main_GPT5")
  cat("  Rating extraction rule:\n")
  print(rep500_parsed %>% count(rating_rule, sort = TRUE) %>% as.data.frame())

  n_unparsed <- sum(is.na(rep500_parsed$rating))
  audit_record(
    "A2 rep500 GPT-5", "drop unparseable outputs",
    rows_in = nrow(rep500_parsed), rows_out = nrow(rep500_parsed) - n_unparsed,
    reason = "no unambiguous in-scale rating recovered by the explicit-answer parser",
    detail = basename(path_repeated_500)
  )

  if (n_unparsed > 0) {
    unparsed_check_file <- file.path(out_dir, "CHECK_gpt5_repeated_unparsed_outputs.csv")
    readr::write_csv(
      rep500_parsed %>%
        filter(is.na(rating)) %>%
        dplyr::select(any_of(c(
          "input_id", "model_name", "sequence", "replicate_index",
          "output_seq", "rating_rule"
        ))),
      unparsed_check_file
    )
    # Missing parses include refusals, truncated answers, ambiguous ratings,
    # and unsupported formats. Retain the raw text for inspection
    warning(
      "GPT-5 repeated-sampling unparsed outputs: ", n_unparsed, " of ",
      nrow(rep500_parsed), " temperature-1 draws have no accepted parse (",
      sprintf("%.2f%%", 100 * n_unparsed / nrow(rep500_parsed)),
      "); recorded in ", unparsed_check_file,
      call. = FALSE, immediate. = TRUE
    )
    cat(sprintf("  Unparsed outputs: %d of %d draws (%.2f%%) have no accepted rating\n",
                n_unparsed, nrow(rep500_parsed),
                100 * n_unparsed / nrow(rep500_parsed)))
  }

  rep500_ok <- rep500_parsed %>%
    filter(!is.na(rating)) %>%
    mutate(
      input_id = canonical_scenario_id(input_id),
      model_name = normalize_model_name(model_name)
    )

  n_before_cap <- nrow(rep500_ok)
  rep500 <- rep500_ok %>%
    arrange(input_id, suppressWarnings(as.numeric(sequence)),
            suppressWarnings(as.numeric(replicate_index))) %>%
    group_by(input_id) %>%
    slice_head(n = 500) %>%
    ungroup() %>%
    dplyr::select(input_id, model_name, rating)

  audit_record(
    "A2 rep500 GPT-5", "cap over-covered scenarios at 500 draws",
    rows_in = n_before_cap, rows_out = nrow(rep500),
    keys_in = n_distinct(rep500_ok$input_id), keys_out = n_distinct(rep500$input_id),
    reason = "148_new, 148_old, 428_new, 428_old were sampled twice (two batches of replicate_index 1..500)",
    detail = "ordered by sequence then replicate_index, first 500 kept"
  )

  cat("  Parsed:", nrow(rep500), "rows,", n_distinct(rep500$input_id), "scenarios\n")
}


load_repeated_500 <- function(path, label, step) {
  if (!file.exists(path)) {
    cat("  ⚠ Not found:", label, "→", path, "\n")
    return(NULL)
  }
  cat("\n── Loading 500-sample repeated sampling:", label, "──\n")
  raw <- read_model_file_safe(path, basename(path))
  n_all <- nrow(raw)

  t1 <- raw %>% filter(as.character(temperature) == "1")
  audit_record(
    step, "filter temperature == 1",
    rows_in = n_all, rows_out = nrow(t1),
    reason = "temperature-0 rows are not repeated-sampling draws",
    detail = basename(path)
  )

  ext <- extract_rating(t1$output_seq)
  parsed <- t1 %>% mutate(rating = ext$rating, rating_rule = ext$source)
  write_rating_parse_audit(parsed, paste0("main_", label))
  n_bad <- sum(is.na(parsed$rating))
  audit_record(
    step, "drop unparseable outputs",
    rows_in = nrow(parsed), rows_out = nrow(parsed) - n_bad,
    reason = "no in-scale rating recoverable from the output",
    detail = basename(path)
  )

  if (n_bad > 0) {
    safe_label <- stringr::str_replace_all(label, "[^A-Za-z0-9]+", "_")
    check_file <- paste0("CHECK_repeated_unparsed_", safe_label, ".csv")
    readr::write_csv(
      parsed %>%
        filter(is.na(rating)) %>%
        dplyr::select(any_of(c(
          "input_id", "model_name", "sequence", "replicate_index",
          "output_seq", "rating_rule"
        ))),
      file.path(out_dir, check_file)
    )
    warning(
      label, " repeated-sampling non-response: ", n_bad, " of ", nrow(parsed),
      " temperature-1 draws have no accepted parse (",
      sprintf("%.2f%%", 100 * n_bad / nrow(parsed)),
      "); recorded in ", check_file,
      call. = FALSE, immediate. = TRUE
    )
    cat(sprintf("  Unparsed outputs: %d of %d draws (%.2f%%) have no accepted rating -> %s\n",
                n_bad, nrow(parsed), 100 * n_bad / nrow(parsed), check_file))
  }

  ok <- parsed %>%
    filter(!is.na(rating)) %>%
    mutate(model_name = normalize_model_name(model_name))
  
  n_before_cap <- nrow(ok)
  out <- ok %>%
    arrange(input_id, suppressWarnings(as.numeric(sequence)),
            suppressWarnings(as.numeric(replicate_index))) %>%
    group_by(input_id) %>%
    slice_head(n = 500) %>%
    ungroup() %>%
    dplyr::select(input_id, model_name, rating)

  audit_record(
    step, "cap over-covered scenarios at 500 draws",
    rows_in = n_before_cap, rows_out = nrow(out),
    keys_in = n_distinct(ok$input_id), keys_out = n_distinct(out$input_id),
    reason = "scenarios sampled in two batches of replicate_index 1..500",
    detail = "ordered by sequence then replicate_index, first 500 kept"
  )

  cat("  Parsed", label, "500-rep:", nrow(out),
      "rows,", n_distinct(out$input_id), "scenarios,",
      "model:", paste(unique(out$model_name), collapse = ", "), "\n")
  out
}

rep500_qwen <- load_repeated_500(
  path_repeated_500_qwen, "Qwen", "A1 rep500 Qwen"
)

rep500_gpt4omini <- load_repeated_500(
  path_repeated_500_gpt4omini, "GPT-4o-mini", "A1 rep500 GPT-4o-mini"
)

rep500_gpt35 <- load_repeated_500(
  path_repeated_500_gpt35, "GPT-3.5", "A1 rep500 GPT-3.5"
)

rep500_gptoss <- load_repeated_500(
  path_repeated_500_gptoss, "gpt-oss", "A4 rep500 gpt-oss"
)

for (extra in list(rep500_qwen, rep500_gpt4omini, rep500_gpt35, rep500_gptoss)) {
  if (!is.null(extra) && nrow(extra) > 0) {
    rep500 <- if (is.null(rep500)) extra else bind_rows(rep500, extra)
  }
}

if (!is.null(rep500) && nrow(rep500) > 0) {
  REPEATED_EXPECTED_MODELS <- c(
    "gpt-35-turbo_1106",
    "gpt-4o-mini_2024-07-18",
    "gpt-5-chat_2025-08-07",
    "gpt-oss-20b",
    "qwen-3-32B"
  )
  rep500_draw_coverage <- rep500 %>%
    count(model_name, input_id, name = "draws") %>%
    mutate(
      double_submission_artifact = input_id %in% REPEATED_DOUBLE_SUBMITTED_SCENARIOS,
      below_floor   = draws < REPEATED_MIN_DRAWS,
      below_nominal = draws < REPEATED_NOMINAL_DRAWS
    )
  rep500_expected_coverage <- tibble::tribble(
    ~model_name,                  ~expected_scenarios,
    "gpt-35-turbo_1106",         145L,
    "gpt-4o-mini_2024-07-18",    145L,
    "gpt-5-chat_2025-08-07",     205L,
    "gpt-oss-20b",               205L,
    "qwen-3-32B",                145L
  )
  rep500_model_coverage <- rep500_draw_coverage %>%
    group_by(model_name) %>%
    summarise(
      scenarios = n(),
      min_draws = min(draws),
      median_draws = stats::median(draws),
      max_draws = max(draws),
      n_below_floor = sum(below_floor),
      n_below_nominal = sum(below_nominal),
      .groups = "drop"
    ) %>%
    right_join(rep500_expected_coverage, by = "model_name")
  rep500_bad_draws <- rep500_draw_coverage %>%
    filter(below_floor | draws > REPEATED_NOMINAL_DRAWS)
  rep500_models_found <- sort(unique(rep500$model_name))
  readr::write_csv(
    rep500_draw_coverage,
    file.path(out_dir, "CHECK_repeated_500_coverage.csv")
  )
  readr::write_csv(
    rep500_model_coverage,
    file.path(out_dir, "CHECK_repeated_500_model_summary.csv")
  )
  # Tier 2 (warn): at or above the floor but short of nominal 500.
  if (any(rep500_draw_coverage$below_nominal & !rep500_draw_coverage$below_floor)) {
    short <- rep500_draw_coverage %>% filter(below_nominal, !below_floor)
    warning(
      "Repeated sampling: ", nrow(short), " of ", nrow(rep500_draw_coverage),
      " model x scenario cells are below the nominal ", REPEATED_NOMINAL_DRAWS,
      " draws but at or above the ", REPEATED_MIN_DRAWS, " floor (min ",
      min(short$draws), ", median ", stats::median(short$draws), ", max ",
      max(short$draws), "); see CHECK_repeated_500_coverage.csv.",
      call. = FALSE, immediate. = TRUE
    )
    cat(sprintf("  Draw shortfall: %d of %d cells in [%d, %d) draws (min %d, median %g, max %d)\n",
                nrow(short), nrow(rep500_draw_coverage), REPEATED_MIN_DRAWS,
                REPEATED_NOMINAL_DRAWS, min(short$draws),
                stats::median(short$draws), max(short$draws)))
  }
  # Tier 1 (stop): below the floor, wrong model set, or wrong scenario coverage.
  if (!setequal(rep500_models_found, REPEATED_EXPECTED_MODELS) ||
      nrow(rep500_bad_draws) > 0 ||
      any(rep500_model_coverage$scenarios != rep500_model_coverage$expected_scenarios)) {
    stop(
      "Repeated-sampling inputs do not match the documented five-model scenario coverage, ",
      "or a cell falls below the ", REPEATED_MIN_DRAWS, "-draw floor; ",
      "see CHECK_repeated_500_coverage.csv."
    )
  }

  cat("  Combined rep500 sources:", nrow(rep500), "rows across",
      n_distinct(rep500$model_name), "models,",
      n_distinct(rep500$input_id), "scenarios\n")
  cat("  Draws per scenario by model:\n")
  print(
    rep500 %>%
      count(model_name, input_id, name = "draws") %>%
      group_by(model_name) %>%
      summarise(
        scenarios = n(),
        min_draws = min(draws),
        median_draws = median(draws),
        max_draws = max(draws),
        .groups = "drop"
      ) %>%
      as.data.frame()
  )
} else {
  stop("No valid 500-repetition repeated-sampling rows were loaded.")
}


# Distribution prompt: predicted human mean, SD, expanded moments, and response-bin proportions
cat("\n── Loading distribution-prompt files ──\n")

distribution_main_base <- read_model_file_safe(
  path_distribution_main,
  basename(path_distribution_main)
)

rerun_distribution <- empty_model_rows()
rerun_distribution_qwen <- empty_model_rows()
if (file.exists(path_rerun_missing)) {
  rerun_raw <- read_model_file_safe(path_rerun_missing, "rerun_all_merged.jsonl")
  rerun_distribution_all <- rerun_raw %>% filter(as.character(prompt_id) == DISTRIBUTION_PROMPT_ID)
  rerun_distribution      <- rerun_distribution_all %>% filter(as.character(model_name) != "qwen-3-32B")
  rerun_distribution_qwen <- rerun_distribution_all %>% filter(as.character(model_name) == "qwen-3-32B")
  cat("  + rerun-missing distribution-prompt (non-Qwen):", nrow(rerun_distribution), "rows from",
      paste(unique(rerun_distribution$model_name), collapse = ", "), "\n")
  cat("  + rerun-missing distribution-prompt (Qwen, deferred to robust parser):",
      nrow(rerun_distribution_qwen), "rows\n")
} else {
  cat("  ⚠ Not found: rerun_all_merged.jsonl →", path_rerun_missing, "\n")
}

n_main_before_gptoss <- nrow(distribution_main_base)
distribution_main_base <- distribution_main_base %>%
  filter(!(as.character(model_name) == "gpt-oss-20b" &
             as.character(prompt_id) %in% c("5", "6")))
audit_record(
  "A3 gpt-oss distribution", "exclude truncated gpt-oss prompt 5/6 rows from prompt5_nollama.jsonl",
  rows_in = n_main_before_gptoss, rows_out = nrow(distribution_main_base),
  reason = "outputs empty or cut off mid-JSON; no record carries all nine probability bins",
  detail = basename(path_distribution_main)
)
cat("  - gpt-oss prompt 5/6 rows dropped from", basename(path_distribution_main), ":",
    n_main_before_gptoss - nrow(distribution_main_base), "\n")

distribution_gptoss <- empty_model_rows()
distribution_gptoss_prompt6 <- empty_model_rows()
if (file.exists(path_distribution_gptoss)) {
  distribution_gptoss_all <- read_model_file_safe(
    path_distribution_gptoss, basename(path_distribution_gptoss)
  ) %>%
    mutate(model_name = normalize_model_name(model_name))
  
  distribution_gptoss <- distribution_gptoss_all %>%
    filter(as.character(prompt_id) == DISTRIBUTION_PROMPT_ID)
  distribution_gptoss_prompt6 <- distribution_gptoss_all %>%
    filter(as.character(prompt_id) == "6")

  cat("  + gpt-oss replacement rows:", nrow(distribution_gptoss_all), "total ->",
      nrow(distribution_gptoss), "prompt-5 rows used,",
      nrow(distribution_gptoss_prompt6), "prompt-6 rows held aside,",
      n_distinct(distribution_gptoss$input_id), "scenarios\n")
  audit_record(
    "A3 gpt-oss distribution", "load replacement file, restrict to prompt 5",
    rows_in = nrow(distribution_gptoss_all), rows_out = nrow(distribution_gptoss),
    keys_in = n_distinct(distribution_gptoss_all$input_id),
    keys_out = n_distinct(distribution_gptoss$input_id),
    reason = "all other models supply distribution estimates from prompt 5 (Q8 carries the nine bins); prompt 6 is a different Proportions elicitation",
    detail = basename(path_distribution_gptoss)
  )
} else {
  cat("  ⚠ Not found:", basename(path_distribution_gptoss), "\n")
}

distribution_main_raw <- bind_rows(
  distribution_main_base, rerun_distribution, distribution_gptoss
)

dist_dupe_cells <- distribution_main_raw %>%
  count(model_name, input_id, prompt_id, name = "n_records") %>%
  filter(n_records > 1)
gptoss_dupe_cells <- dist_dupe_cells %>% filter(model_name == "gpt-oss-20b")

cat("  Distribution-prompt cells supplied more than once:", nrow(dist_dupe_cells),
    "(expected: rerun_all_merged re-supplies failed parses; resolved by best-parse dedup)\n")
if (nrow(dist_dupe_cells) > 0) {
  print(dist_dupe_cells %>% count(model_name, name = "cells") %>% as.data.frame())
}
if (nrow(gptoss_dupe_cells) > 0) {
  cat("  ⚠ gpt-oss replacement collides with another source in",
      nrow(gptoss_dupe_cells), "cells\n")
} else {
  cat("  ✓ gpt-oss replacement fills only cells vacated by the excluded rows.\n")
}
audit_record(
  "A3 gpt-oss distribution", "check duplicate distribution-prompt cells",
  rows_in = nrow(distribution_main_raw), rows_out = nrow(distribution_main_raw),
  unmatched_keys = nrow(dist_dupe_cells),
  reason = "rerun overlap is intentional and dedup-resolved; gpt-oss collisions would not be",
  detail = paste0(nrow(dist_dupe_cells), " duplicated cells, ",
                  nrow(gptoss_dupe_cells), " involving gpt-oss")
)

if (nrow(distribution_main_raw) == 0) {
  stop(
    "No non-Qwen distribution-prompt rows loaded. Check path_distribution_main and path_rerun_missing:\n",
    "  path_distribution_main = ", path_distribution_main, "\n",
    "  path_rerun_missing = ", path_rerun_missing
  )
}
cat("  Main + rerun distribution-prompt rows:", nrow(distribution_main_raw), "\n")
cat("  Models:", paste(unique(distribution_main_raw$model_name), collapse = ", "), "\n")

get_bin_probabilities <- function(bin_probability_object) {
  keys <- as.character(-4:4)
  p <- rep(NA_real_, 9)
  names(p) <- keys
  if (is.null(bin_probability_object)) return(p)

  if (is.character(bin_probability_object) && length(bin_probability_object)==1 && str_detect(bin_probability_object,"\\{")) {
    parsed_bin_probabilities <- parse_json_safe(bin_probability_object)
    if (!is.null(parsed_bin_probabilities)) bin_probability_object <- parsed_bin_probabilities
  }

  bin_probability_values <- tryCatch(unlist(bin_probability_object, use.names=TRUE), error = function(e) bin_probability_object)

  if (!is.null(names(bin_probability_values)) && any(nzchar(names(bin_probability_values)))) {
    for (k in keys) {
      if (k %in% names(bin_probability_values)) p[k] <- num(bin_probability_values[[k]])
    }

    if (any(is.na(p))) return(rep(NA_real_, 9))

    return(p)
  }

  if (length(bin_probability_values)==9) {
    p[] <- suppressWarnings(as.numeric(bin_probability_values))
    if (any(is.na(p))) return(rep(NA_real_, 9))
    return(p)
  }

  p
}

normalize_bin_probabilities <- function(p) {
  p <- suppressWarnings(as.numeric(p))
  if (length(p) != 9 || any(is.na(p)) || any(p < 0)) {
    return(rep(NA_real_, 9))
  }
  s <- sum(p)

  if (!is.finite(s) || s <= 0) {
    return(rep(NA_real_, 9))
  }
  p / s
}

get_peak_info <- function(peak_object) {
  out <- list(loc1 = NA_real_, w1 = NA_real_, loc2 = NA_real_, w2 = NA_real_)
  finish <- function(status, count=NA_integer_) {
    attr(out,"parse_status") <- status
    attr(out,"reported_peak_count") <- count
    out
  }
  if (is.null(peak_object) || (is.character(peak_object) && length(peak_object)==1L &&
      (is.na(peak_object) || !nzchar(trimws(peak_object)) || peak_object == "N/A"))) return(finish("missing_or_not_applicable"))

  if (is.character(peak_object) && length(peak_object)==1) {
    original <- peak_object
    peak_object <- parse_json_safe(original)
    if (is.null(peak_object)) {
      text <- normalize_scalar_format(original)
      number <- paste0("(",SCALAR_NUMBER_PATTERN,")")
      labelled <- paste0("\\bPeak\\s*(?:[0-9]+\\s*)?(?::|\\bat\\b)\\s*",
        "(?:location\\s*=\\s*)?(?:(?:around|approximately)\\s+)?",number,
        "\\s*(?:\\(\\s*|with\\s*~?\\s*|,\\s*weight\\s*=\\s*)",number,
        "\\s*%\\s*\\)?(?:\\s*of\\s+respondents)?")
      tuple <- paste0("\\(\\s*",number,"\\s*,\\s*",number,"\\s*%\\s*\\)")
      pattern <- if(grepl("\\bPeak\\s*(?:[0-9]+\\s*)?(?::|at\\b)",text,ignore.case=TRUE,perl=TRUE)) labelled else tuple
      pos <- gregexec(pattern,text,ignore.case=TRUE,perl=TRUE)[[1]]
      hits <- regmatches(text,list(pos))[[1]]
      if(!is.matrix(hits)) return(finish("unrecognized_text"))
      n <- ncol(hits)
      if(n > 2L) return(finish("unsupported_text_more_than_two_peaks",n))
      if(n != 2L) return(finish("incomplete_text_peak_pair",n))
      ids <- sub("(?i)^Peak\\s*([0-9]+).*","\\1",hits[1,],perl=TRUE)
      ids <- ids[grepl("^[0-9]+$",ids)]
      if(length(ids) && (length(ids)!=2L || !setequal(ids,c("1","2"))))
        return(finish("conflicting_text_peak_labels",n))
      remainder <- text
      for(k in rev(seq_len(n))) {
        a <- pos[1,k]; b <- a+attr(pos,"match.length")[1,k]
        remainder <- paste0(substr(remainder,1L,a-1L),substring(remainder,b))
      }
      remainder <- sub("(?i)remaining\\s+(?:respondents\\s+spread\\s+between\\s+peaks|[0-9]+(?:\\.[0-9]+)?%\\s+spread\\s+across\\s+[+0-9., \\t-]+)\\s*$","",remainder,perl=TRUE)
      if(nzchar(gsub("[[:space:],;\\[\\]]","",remainder,perl=TRUE)))
        return(finish("unresolved_text_peak_content",n))
      loc <- vapply(hits[2,],clean_extracted_num,numeric(1))
      weight <- vapply(hits[3,],clean_extracted_num,numeric(1))/100
      if(any(!is.finite(c(loc,weight))) || any(loc < RATING_SCALE_MIN | loc > RATING_SCALE_MAX) ||
         any(weight < 0 | weight > 1) || sum(weight)<=0 || sum(weight)>1+1e-10)
        return(finish("invalid_text_peak_values",n))
      out <- list(loc1=loc[1],w1=weight[1],loc2=loc[2],w2=weight[2])
      return(finish("parsed_text_percentages",n))
    }
  }

  count <- NA_integer_
  if (is.data.frame(peak_object)) {
    count <- nrow(peak_object)
    if (nrow(peak_object) >= 1) { out$loc1 <- num(peak_object$location[1]); out$w1 <- num(peak_object$weight[1]) }
    if (nrow(peak_object) >= 2) { out$loc2 <- num(peak_object$location[2]); out$w2 <- num(peak_object$weight[2]) }
  } else if (is.list(peak_object)) {
    count <- length(peak_object)
    if (length(peak_object) >= 1 && is.list(peak_object[[1]])) {
      out$loc1 <- num(peak_object[[1]]$location); out$w1 <- num(peak_object[[1]]$weight)
    }
    if (length(peak_object) >= 2 && is.list(peak_object[[2]])) {
      out$loc2 <- num(peak_object[[2]]$location); out$w2 <- num(peak_object[[2]]$weight)
    }
  }
  finish(if(is.finite(count) && count>2L) "legacy_structured_first_two_of_more" else "structured_object",count)
}

moment_question_diagnostic <- function(mean, q4, q5) {
  stopifnot(length(mean) == length(q4), length(mean) == length(q5))
  keep <- is.finite(mean) & is.finite(q4) & is.finite(q5)
  x <- mean[keep]; a <- q4[keep]; b <- q5[keep]
  correlation <- function(y, method) {
    if (length(x) < 3L || length(unique(x)) < 2L || length(unique(y)) < 2L) return(NA_real_)
    stats::cor(x, y, method = method)
  }
  data.frame(n_rows = length(mean), n_complete = sum(keep),
    r_mean_Q4 = correlation(a, "pearson"), r_mean_Q5 = correlation(b, "pearson"),
    rho_mean_Q4 = correlation(a, "spearman"), rho_mean_Q5 = correlation(b, "spearman"))
}

parse_distribution_output <- function(txt) {
  base <- tibble(distribution_model_rating=NA_real_, distribution_human_mean=NA_real_, distribution_human_sd=NA_real_,
                 distribution_skewness=NA_real_, distribution_excess_kurtosis=NA_real_, distribution_shape=NA_character_,
                 peak1_location=NA_real_, peak1_weight=NA_real_, peak2_location=NA_real_, peak2_weight=NA_real_,
                 p_m4=NA_real_, p_m3=NA_real_, p_m2=NA_real_, p_m1=NA_real_,
                 p_0=NA_real_, p_1=NA_real_, p_2=NA_real_, p_3=NA_real_, p_4=NA_real_)
  if (is.na(txt) || !nzchar(txt)) return(base)
  s <- strip_fences(txt)
  if (str_detect(s, "^[-+]?\\d+(?:\\.\\d+)?$"))
    return(base %>% mutate(distribution_model_rating = as.numeric(s)))
  obj <- parse_json_safe(extract_braces(s))
  if (is.null(obj) || !is.list(obj)) return(base)
  for(key in unique(names(obj)[duplicated(names(obj))])) {
    at <- which(names(obj)==key)
    agree <- all(vapply(at[-1],function(k)identical(obj[[k]],obj[[at[1]]]),logical(1)))
    if(!agree) for(k in at) obj[k] <- list(NULL)
  }
  distribution_shape_value <- safe_get(obj,"Answer to Q6")
  if (length(distribution_shape_value)==0) distribution_shape_value <- NA_character_ else distribution_shape_value <- as.character(distribution_shape_value)
  distribution_shape_value <- clean_distribution_shape(distribution_shape_value)
  peaks <- get_peak_info(safe_get(obj,"Answer to Q7"))
  p <- get_bin_probabilities(safe_get(obj,"Answer to Q8"))
  tibble(distribution_model_rating=num(safe_get(obj,"Answer to Q1")), distribution_human_mean=num(safe_get(obj,"Answer to Q2")),
         distribution_human_sd=num(safe_get(obj,"Answer to Q3")), distribution_skewness=num(safe_get(obj,"Answer to Q5")),
         distribution_excess_kurtosis=num(safe_get(obj,"Answer to Q4")), distribution_shape=distribution_shape_value,
         peak1_location=peaks$loc1, peak1_weight=peaks$w1, peak2_location=peaks$loc2, peak2_weight=peaks$w2,
         p_m4=p["-4"],p_m3=p["-3"],p_m2=p["-2"],p_m1=p["-1"],
         p_0=p["0"],p_1=p["1"],p_2=p["2"],p_3=p["3"],p_4=p["4"])
}

parsed_distribution_main <- purrr::map_dfr(distribution_main_raw$output_seq, parse_distribution_output)
distribution_main <- bind_cols(distribution_main_raw %>% dplyr::select(-any_of(c("trace","output_seq"))), parsed_distribution_main)


expanded_main_peak_audit <- purrr::map_dfr(seq_len(nrow(distribution_main_raw)),function(j) {
  raw <- distribution_main_raw$output_seq[j]
  obj <- parse_json_safe(extract_braces(strip_fences(raw)))
  peak <- safe_get(obj,"Answer to Q7")
  parsed <- get_peak_info(peak)
  tibble(source_row=j, input_id=distribution_main_raw$input_id[j],
    model_name=distribution_main_raw$model_name[j],
    raw_q7=as.character(jsonlite::toJSON(peak,auto_unbox=TRUE,null="null")),
    parse_status=attr(parsed,"parse_status"),reported_peak_count=attr(parsed,"reported_peak_count"))
})
write.csv(expanded_main_peak_audit,file.path(out_dir,"CHECK_expanded_main_peak_parsing.csv"),row.names=FALSE)

distribution_qwen_raw <- read_model_file_safe(path_distribution_qwen, "prompt5_qwen.jsonl")

if (exists("rerun_distribution_qwen") && nrow(rerun_distribution_qwen) > 0) {
  cat("  + appending", nrow(rerun_distribution_qwen),
      "qwen-3-32B rerun rows to Qwen distribution-prompt raw\n")
  distribution_qwen_raw <- bind_rows(distribution_qwen_raw, rerun_distribution_qwen)
}

clean_qwen_text <- function(txt) {
  s <- as.character(txt)
  if (length(s) != 1L || is.na(s) || !nzchar(s)) return(NA_character_)
  s <- strip_fences(s)
  s <- stringr::str_replace_all(s, "\\\\n", "\n")
  s <- stringr::str_replace_all(s, "\\\\t", "\t")
  s <- stringr::str_replace_all(s, '\\\\"', '"')
  s <- stringr::str_replace_all(s, "\t", " ")
  normalize_scalar_format(s)
}

last_regex_capture <- function(m) {
  if (is.null(m) || ncol(m) < 2) return(NA_character_)
  vals <- m[1, -1]
  vals <- vals[!is.na(vals)]
  if (length(vals) == 0) NA_character_ else vals[length(vals)]
}

normalize_qwen_json_keys <- function(s) {
  s %>%
    stringr::str_replace_all("\\t", " ") %>%
    normalize_scalar_format() %>%
    stringr::str_replace_all(
      '"\\s*Answers?\\s*[_\\. ,]*to\\s*[_\\. ,]*[qQ]\\s*[_/]?\\s*(\\d+)\\s*"',
      '"Answer to Q\\1"'
    ) %>%
    stringr::str_replace_all(
      '"\\s*Answer\\s*[_\\. ,]*to\\s*[_\\. ,]*[qQ]\\s*[_/]?\\s*(\\d+)\\s*"',
      '"Answer to Q\\1"'
    ) %>%
    stringr::str_replace_all(
      '"\\s*Answer\\s*[_\\. ,]*(?:for|of|on|at|by|in)\\s*[_\\. ,]*[qQ]\\s*[_/]?\\s*(\\d+)\\s*"',
      '"Answer to Q\\1"'
    ) %>%
    stringr::str_replace_all(
      '"\\s*Answerto\\s*[_\\. ,]*[qQ]\\s*[_/]?\\s*(\\d+)\\s*"',
      '"Answer to Q\\1"'
    ) %>%
    stringr::str_replace_all(
      '"\\s*[qQ]\\s*[_/]?\\s*(\\d+)\\s*"',
      '"Answer to Q\\1"'
    )
}


scalar_matches <- function(x, pattern) {
  hits <- regmatches(x, gregexpr(pattern, x, perl = TRUE))[[1]]
  if (!length(hits)) return(numeric())
  suppressWarnings(as.numeric(sub(pattern, "\\1", hits, perl = TRUE)))
}

extract_qwen_num <- function(s, q) {
  if (length(s) != 1L || is.na(s) || !nzchar(s)) return(NA_real_)
  # Find the question header first, then read its WHOLE value. Quoted values
  # may contain line breaks; unquoted values end at a field/line delimiter.
  header <- paste0("(?:^|[,\\{\\n\\r])\\s*['\"]?[^:=\\n\\r\\{\\},]*[qQ]\\s*[_/\\. ]*\\s*", q,
    "(?![0-9])[^:=\\n\\r\\{\\},]*['\"]?\\s*[:=]\\s*")
  at <- gregexpr(header, s, perl = TRUE, ignore.case = TRUE)[[1]]
  if (at[1] < 0L) return(NA_real_)
  starts <- at + attr(at, "match.length")
  values <- vapply(starts, function(start) {
    tail <- substring(s, start)
    quote <- substr(tail, 1, 1)
    if (quote %in% c("'", '"')) {
      rest <- substring(tail, 2)
      end <- regexpr(quote, rest, fixed = TRUE)[1]
      if (end < 0L) return(NA_real_)
      field <- substr(rest, 1, end - 1L)
      # A second scalar after the closing quote is not a field delimiter.
      after <- substring(rest, end + 1L)
      if (grepl("^[ \\t]*[0-9.+-]", after, perl = TRUE)) return(NA_real_)
    } else {
      end <- regexpr("[,}]|[\\r\\n](?=\\s*[A-Za-z\"'])", tail, perl = TRUE)[1]
      field <- if (end < 0L) tail else substr(tail, 1, end - 1L)
      if (end > 0L && grepl("[.]\\s*$", field, perl = TRUE) &&
          grepl("^\\s*[0-9]", substring(tail, end), perl = TRUE)) return(NA_real_)
    }
    field <- sub(paste0("^\\s*(?:Answers?\\s+to\\s+)?Q\\s*[_/]?\\s*", q,
                        "\\s*[:=]\\s*"), "", field, ignore.case = TRUE, perl = TRUE)
    clean_extracted_num(field)
  }, numeric(1))
  if (any(!is.finite(values)) || length(unique(values)) != 1L) NA_real_ else values[1]
}

extract_qwen_string <- function(s, q) {
  if (is.na(s) || !nzchar(s)) return(NA_character_)

  pats <- c(
    paste0(
      "(?:^|[,\\{\\n\\r])\\s*['\"]?[^:=\\n\\r\\{\\},]*[qQ]\\s*[_/\\. ]*\\s*", q,
      "[^:=\\n\\r\\{\\},]*['\"]?\\s*[:=]\\s*['\"]?\\s*([^\",\\n\\r\\}]+)"
    ),
    paste0(
      "\\b[qQ]\\s*", q, "\\s*[:=]\\s*['\"]?\\s*([^\",\\n\\r\\}]+)"
    ),
    paste0(
      "Answers?\\s*[_\\. ]*(?:to|for|of|on|at|by|in)?\\s*[_\\. ]*[qQ]\\s*[_/]?\\s*", q,
      "\\s*[:=]\\s*['\"]?\\s*([^\",\\n\\r\\}]+)"
    )
  )

  for (pat in pats) {
    m <- stringr::str_match(
      s,
      stringr::regex(pat, ignore_case = TRUE, dotall = TRUE)
    )
    v <- last_regex_capture(m)
    if (!is.na(v)) {
      return(
        v %>%
          stringr::str_replace_all('["\\}]', "") %>%
          stringr::str_trim()
      )
    }
  }

  NA_character_
}

extract_qwen_peak_info_regex <- function(s) {
  out <- list(loc1 = NA_real_, w1 = NA_real_, loc2 = NA_real_, w2 = NA_real_)
  if (is.na(s) || !nzchar(s)) return(out)

  loc7 <- stringr::str_locate(
    s,
    stringr::regex(
      "Answer[^\\n\\r\\{\\}]*[qQ]\\s*7|Answers?[^\\n\\r\\{\\}]*[qQ]\\s*7|\\b[qQ]\\s*7\\b",
      ignore_case = TRUE
    )
  )

  if (any(is.na(loc7))) return(out)

  loc8 <- stringr::str_locate(
    substr(s, loc7[2] + 1, nchar(s)),
    stringr::regex(
      "Answer[^\\n\\r\\{\\}]*[qQ]\\s*8|Answers?[^\\n\\r\\{\\}]*[qQ]\\s*8|\\b[qQ]\\s*8\\b",
      ignore_case = TRUE
    )
  )

  end_pos <- if (any(is.na(loc8))) {
    min(nchar(s), loc7[2] + 1000)
  } else {
    loc7[2] + loc8[1] - 1
  }

  seg <- substr(s, loc7[1], end_pos)

  locs <- stringr::str_match_all(
    seg,
    stringr::regex("location['\"]?\\s*[:=]\\s*['\"]?\\s*(-?\\s*\\d+(?:\\s*\\.\\s*\\d+)?)",
                   ignore_case = TRUE)
  )[[1]]

  wts <- stringr::str_match_all(
    seg,
    stringr::regex("weight['\"]?\\s*[:=]\\s*['\"]?\\s*(\\d+(?:\\s*\\.\\s*\\d+)?)",
                   ignore_case = TRUE)
  )[[1]]

  loc_vals <- if (nrow(locs) > 0) vapply(locs[, 2], clean_extracted_num, numeric(1)) else numeric()
  wt_vals  <- if (nrow(wts) > 0)  vapply(wts[, 2],  clean_extracted_num, numeric(1)) else numeric()

  if (length(loc_vals) >= 1) out$loc1 <- loc_vals[1]
  if (length(wt_vals)  >= 1) out$w1   <- wt_vals[1]
  if (length(loc_vals) >= 2) out$loc2 <- loc_vals[2]
  if (length(wt_vals)  >= 2) out$w2   <- wt_vals[2]

  out
}

extract_qwen_bin_probabilities_regex <- function(s) {
  keys <- as.character(-4:4)
  missing <- stats::setNames(rep(NA_real_, length(keys)), keys)
  if (is.na(s) || !nzchar(s)) return(missing)

  loc <- stringr::str_locate(
    s,
    stringr::regex(
      "Answer[^\\n\\r\\{\\}]*[qQ]\\s*8|Answers?[^\\n\\r\\{\\}]*[qQ]\\s*8|\\b[qQ]\\s*8\\b",
      ignore_case = TRUE
    )
  )
  if (any(is.na(loc))) return(missing)
  tail_txt <- substr(s, loc[2] + 1, min(nchar(s), loc[2] + 4000))
  tail_txt <- stringr::str_replace_all(tail_txt, "\\\\.", ".")

  # Read one Q8 object only. Complete bin answers may be recoverable even when
  # an outer JSON wrapper is malformed, but missing bins are never inferred.
  end <- stringr::str_locate(tail_txt, stringr::fixed("}"))[1, 1]
  if (!is.na(end)) tail_txt <- substr(tail_txt, 1, end)
  number <- "[+-]?\\s*(?:\\d+(?:\\s*\\.\\s*\\d*)?|\\.\\s*\\d+)(?:[eE][+-]?\\d+)?"
  pair_pattern <- paste0(
    "(?:^|[,{;\\r\\n])\\s*['\"]?\\s*([+-]?\\s*\\d+)\\s*['\"]?\\s*[:=]\\s*",
    "['\"]?\\s*(", number, ")\\s*['\"]?(?=\\s*(?:[,;}\\r\\n]|$))"
  )
  pairs <- stringr::str_match_all(tail_txt, pair_pattern)[[1]]

  if (nrow(pairs) > 0L) {
    parsed_keys <- suppressWarnings(as.integer(
      stringr::str_remove_all(pairs[, 2], "\\s+")
    ))
    values <- suppressWarnings(as.numeric(
      stringr::str_remove_all(pairs[, 3], "\\s+")
    ))
    # Matching the entire signed key prevents +1 from matching inside -1.
    # Duplicate keys, incomplete vectors and negative probabilities are invalid.
    if (nrow(pairs) != 9L || anyNA(parsed_keys) || anyDuplicated(parsed_keys) ||
        !setequal(parsed_keys, -4:4) || any(!is.finite(values)) ||
        any(values < 0) || !is.finite(sum(values)) || sum(values) <= 0) {
      return(missing)
    }
    return(stats::setNames(values[match(-4:4, parsed_keys)], keys))
  }

  # A genuinely unkeyed answer must be an explicit nine-entry array, in -4:4
  # order. Do not take arbitrary numbers from prose or a broken keyed object.
  if (stringr::str_detect(tail_txt, stringr::fixed("{"))) return(missing)
  array <- stringr::str_match(tail_txt, "\\[([^\\[\\]]*)\\]")[1, 2]
  if (is.na(array)) return(missing)
  entries <- stringr::str_split(array, ",", simplify = FALSE)[[1]]
  entries <- stringr::str_trim(entries)
  entries <- stringr::str_replace(entries, "^['\"](.*)['\"]$", "\\1")
  entries <- stringr::str_trim(entries)
  if (length(entries) != 9L ||
      !all(stringr::str_detect(entries, paste0("^(?:", number, ")$")))) {
    return(missing)
  }
  values <- suppressWarnings(as.numeric(stringr::str_remove_all(entries, "\\s+")))
  if (any(!is.finite(values)) || any(values < 0) ||
      !is.finite(sum(values)) || sum(values) <= 0) return(missing)
  stats::setNames(values, keys)
}

extract_qwen_fractional_bins <- function(s) {
  keys <- as.character(-4:4)
  missing <- stats::setNames(rep(NA_real_,9L),keys)
  if (is.na(s) || !nzchar(s)) return(missing)
  loc <- stringr::str_locate(s,stringr::regex(
    "Answer[^\\n\\r\\{\\}]*[qQ]\\s*8|Answers?[^\\n\\r\\{\\}]*[qQ]\\s*8|\\b[qQ]\\s*8\\b",ignore_case=TRUE))
  if (anyNA(loc)) return(missing)
  tail_txt <- substr(s,loc[2]+1L,min(nchar(s),loc[2]+4000L))
  tail_txt <- stringr::str_replace_all(tail_txt,"\\\\.",".")
  end <- stringr::str_locate(tail_txt,stringr::fixed("}"))[1,1]
  if (!is.na(end)) tail_txt <- substr(tail_txt,1L,end)
  # Capture the complete delimited field. A malformed value cannot vanish
  # and leave nine apparently valid matches from a duplicate-key object.
  pat <- "(?:^|[,{;\\r\\n])\\s*['\"]?\\s*([+-]?\\s*\\d+)\\s*['\"]?\\s*[:=]\\s*([^,;}\\r\\n]+)"
  pairs <- stringr::str_match_all(tail_txt,pat)[[1]]
  if (nrow(pairs)) {
    k <- suppressWarnings(as.integer(gsub("\\s+","",pairs[,2],perl=TRUE)))
    if (nrow(pairs)!=9L || anyNA(k) || anyDuplicated(k) || !setequal(k,-4:4)) return(missing)
    fields <- trimws(pairs[,3]); fields <- sub("^(['\"])(.*)\\1$","\\2",fields,perl=TRUE)
    values <- vapply(fields,clean_extracted_num,numeric(1));values <- values[match(-4:4,k)]
  } else {
    if (grepl("{",tail_txt,fixed=TRUE)) return(missing)
    a <- stringr::str_match(tail_txt,"\\[([^\\[\\]]*)\\]")[1,2]
    if (is.na(a)) return(missing)
    fields <- trimws(strsplit(a,",",fixed=TRUE)[[1]])
    if (length(fields)!=9L) return(missing)
    fields <- sub("^(['\"])(.*)\\1$","\\2",fields,perl=TRUE)
    values <- vapply(fields,clean_extracted_num,numeric(1))
  }
  if (any(!is.finite(values)) || any(values<0 | values>1) || sum(values)<=0) return(missing)
  stats::setNames(values,keys)
}


# Qwen outputs used less consistent formatting, so this parser combines JSON parsing with regex fallback extraction.
parse_qwen_distribution_output <- function(txt) {
  base <- tibble(
    distribution_model_rating = NA_real_, distribution_human_mean = NA_real_, distribution_human_sd = NA_real_,
    distribution_skewness = NA_real_, distribution_excess_kurtosis = NA_real_,
    distribution_shape = NA_character_,
    peak1_location = NA_real_, peak1_weight = NA_real_,
    peak2_location = NA_real_, peak2_weight = NA_real_,
    p_m4 = NA_real_, p_m3 = NA_real_, p_m2 = NA_real_, p_m1 = NA_real_,
    p_0 = NA_real_, p_1 = NA_real_, p_2 = NA_real_, p_3 = NA_real_, p_4 = NA_real_
  )

  if (is.na(txt) || !nzchar(txt)) return(base)

  raw_json <- extract_braces(strip_fences(txt))
  obj <- parse_json_safe(raw_json)
  s <- clean_qwen_text(txt)
  if (!is.null(obj) && is.list(obj)) {
    names(obj) <- vapply(names(obj), function(key) {
      key <- normalize_qwen_json_keys(paste0('"', key, '"'))
      substr(key, 2L, nchar(key) - 1L)
    }, character(1))
  } else {
    obj <- parse_json_safe(normalize_qwen_json_keys(extract_braces(s)))
  }

  if (!is.null(obj) && is.list(obj) && anyDuplicated(names(obj))) obj <- NULL

  if (!is.null(obj) && is.list(obj)) {
    distribution_shape_value <- safe_get(obj, "Answer to Q6")
    if (length(distribution_shape_value) == 0) distribution_shape_value <- NA_character_ else distribution_shape_value <- as.character(distribution_shape_value)
    distribution_shape_value <- clean_distribution_shape(distribution_shape_value)

    peaks <- get_peak_info(safe_get(obj, "Answer to Q7"))
    p <- get_bin_probabilities(safe_get(obj, "Answer to Q8"))

    out <- tibble(
      distribution_model_rating = clean_extracted_num(safe_get(obj, "Answer to Q1")),
      distribution_human_mean = clean_extracted_num(safe_get(obj, "Answer to Q2")),
      distribution_human_sd = clean_extracted_num(safe_get(obj, "Answer to Q3")),
      distribution_skewness = clean_extracted_num(safe_get(obj, "Answer to Q5")),
      distribution_excess_kurtosis = clean_extracted_num(safe_get(obj, "Answer to Q4")),
      distribution_shape = distribution_shape_value,
      peak1_location = peaks$loc1,
      peak1_weight = peaks$w1,
      peak2_location = peaks$loc2,
      peak2_weight = peaks$w2,
      p_m4 = p["-4"], p_m3 = p["-3"], p_m2 = p["-2"], p_m1 = p["-1"],
      p_0 = p["0"], p_1 = p["1"], p_2 = p["2"], p_3 = p["3"], p_4 = p["4"]
    )
  } else {
    out <- base
  }

  if (is.na(out$distribution_model_rating)) out$distribution_model_rating <- extract_qwen_num(s, 1)
  if (is.na(out$distribution_human_mean)) out$distribution_human_mean <- extract_qwen_num(s, 2)
  if (is.na(out$distribution_human_sd)) out$distribution_human_sd <- extract_qwen_num(s, 3)
  if (is.na(out$distribution_skewness)) out$distribution_skewness <- extract_qwen_num(s, 5)
  if (is.na(out$distribution_excess_kurtosis)) out$distribution_excess_kurtosis <- extract_qwen_num(s, 4)

  if (is.na(out$distribution_shape)) {
    out$distribution_shape <- clean_distribution_shape(extract_qwen_string(s, 6))
  }

  peak_regex <- extract_qwen_peak_info_regex(s)
  if (is.na(out$peak1_location)) out$peak1_location <- peak_regex$loc1
  if (is.na(out$peak1_weight))   out$peak1_weight   <- peak_regex$w1
  if (is.na(out$peak2_location)) out$peak2_location <- peak_regex$loc2
  if (is.na(out$peak2_weight))   out$peak2_weight   <- peak_regex$w2

  bin_probability_cols_local <- c("p_m4", "p_m3", "p_m2", "p_m1", "p_0", "p_1", "p_2", "p_3", "p_4")
  current_p <- as.numeric(out[1, bin_probability_cols_local])

  if (any(is.na(current_p))) {
    p2 <- extract_qwen_bin_probabilities_regex(s)
    if (anyNA(p2)) p2 <- extract_qwen_fractional_bins(s)
    out$p_m4 <- p2["-4"]
    out$p_m3 <- p2["-3"]
    out$p_m2 <- p2["-2"]
    out$p_m1 <- p2["-1"]
    out$p_0  <- p2["0"]
    out$p_1  <- p2["1"]
    out$p_2  <- p2["2"]
    out$p_3  <- p2["3"]
    out$p_4  <- p2["4"]
  }

  out
}

parsed_distribution_qwen <- purrr::map_dfr(distribution_qwen_raw$output_seq, parse_qwen_distribution_output)

qwen_probability_parse_audit <- bind_cols(
  distribution_qwen_raw %>% select(input_id, model_name, output_seq),
  parsed_distribution_qwen %>% select(p_m4:p_4)
) %>%
  mutate(
    probabilities_complete = if_all(p_m4:p_4, ~ is.finite(.x)),
    probabilities_nonnegative = if_all(p_m4:p_4, ~ is.finite(.x) & .x >= 0),
    probability_sum = rowSums(as.data.frame(select(., p_m4:p_4))),
    probabilities_usable = probabilities_complete & probabilities_nonnegative &
      is.finite(probability_sum) & probability_sum > 0
  )
write.csv(qwen_probability_parse_audit,
          file.path(out_dir, "CHECK_qwen_probabilities_parsed.csv"), row.names = FALSE)

distribution_qwen <- bind_cols(
  distribution_qwen_raw %>% dplyr::select(-any_of(c("trace", "output_seq"))),
  parsed_distribution_qwen
)

bin_probability_cols <- c("p_m4", "p_m3", "p_m2", "p_m1", "p_0", "p_1", "p_2", "p_3", "p_4")


.dist_rows_all <- bind_rows(distribution_main, distribution_qwen) %>%
  mutate(
    input_id = canonical_scenario_id(input_id),
    distribution_shape = clean_distribution_shape(distribution_shape),
    bin_probabilities_complete = stats::complete.cases(dplyr::select(., dplyr::all_of(bin_probability_cols))),
    bin_probability_sum = rowSums(dplyr::select(., dplyr::all_of(bin_probability_cols)), na.rm = FALSE),
    # A usable probability vector must be complete, finite, nonnegative and have positive total mass.
    bin_probability_min = do.call(pmin, c(dplyr::select(., dplyr::all_of(bin_probability_cols)), na.rm = FALSE)),
    bin_probabilities_valid = bin_probabilities_complete & is.finite(bin_probability_sum) &
      bin_probability_sum > 0 & !is.na(bin_probability_min) & bin_probability_min >= 0,
    parse_score =
      as.integer(!is.na(distribution_human_mean)) * 100 +
      as.integer(bin_probabilities_valid) * 50 +
      as.integer(!is.na(distribution_human_sd)) * 10 +
      as.integer(!is.na(distribution_skewness)) * 5 +
      as.integer(!is.na(distribution_excess_kurtosis)) * 5 +
      as.integer(!is.na(distribution_model_rating)) * 1
  )

distribution_estimates <- .dist_rows_all %>%
  arrange(
    model_name,
    input_id,
    desc(parse_score),
    desc(!is.na(distribution_human_mean)),
    desc(bin_probabilities_valid)
  ) %>%
  group_by(model_name, input_id) %>%
  slice(1) %>%
  ungroup() %>%
  dplyr::select(-parse_score)

cat("  Distribution prompt:", nrow(distribution_estimates), "rows (deduped, best-parse row retained)\n")

.dist_probs_lost <- .dist_rows_all %>%
  group_by(model_name, input_id) %>%
  summarise(n_candidate_rows = n(),
            any_valid_probs = any(bin_probabilities_valid),
            any_valid_mean = any(!is.na(distribution_human_mean)),
            any_valid_sd = any(!is.na(distribution_human_sd)),
            any_valid_skew = any(!is.na(distribution_skewness)),
            any_valid_kurt = any(!is.na(distribution_excess_kurtosis)),
            .groups = "drop") %>%
  left_join(distribution_estimates %>%
              dplyr::select(model_name, input_id,
                            selected_probs_valid = bin_probabilities_valid,
                            selected_mean = distribution_human_mean,
                            selected_sd = distribution_human_sd,
                            selected_skew = distribution_skewness,
                            selected_kurt = distribution_excess_kurtosis),
            by = c("model_name", "input_id")) %>%
  mutate(
    lost_probs = any_valid_probs & !selected_probs_valid,
    lost_mean = any_valid_mean & is.na(selected_mean),
    lost_sd = any_valid_sd & is.na(selected_sd),
    lost_skew = any_valid_skew & is.na(selected_skew),
    lost_kurt = any_valid_kurt & is.na(selected_kurt)
  ) %>%
  filter(lost_probs | lost_mean | lost_sd | lost_skew | lost_kurt)
cat("  Cells where valid bin probabilities were lost to single-row selection:",
    sum(.dist_probs_lost$lost_probs), "\n")
cat("  Cells where a mean/SD/skew/kurtosis value was lost to single-row selection:",
    sum(.dist_probs_lost$lost_mean | .dist_probs_lost$lost_sd |
        .dist_probs_lost$lost_skew | .dist_probs_lost$lost_kurt), "\n")
if (nrow(.dist_probs_lost) > 0) {
  write.csv(.dist_probs_lost,
            file.path(out_dir, "CHECK_distribution_probs_lost_to_selection.csv"),
            row.names = FALSE)
}


# SD-only prompt readers and parser
# The SD-only prompt is used as the SD estimate in the primary Mean + SD and Hybrid distribution methods.
read_jsonl_lines <- function(path) {
  lines <- readr::read_lines(path)
  tibble(
    line_num = seq_along(lines),
    raw_line = lines
  ) %>%
    mutate(
      parsed = purrr::map(raw_line, ~ tryCatch(
        jsonlite::fromJSON(.x, simplifyVector = FALSE),
        error = function(e) NULL
      )),
      parsed_ok = !purrr::map_lgl(parsed, is.null)
    )
}

safe_get_chr <- function(obj, key) {
  val <- safe_get(obj, key)
  if (is.null(val) || length(val) == 0) return(NA_character_)
  as.character(val[[1]])
}

# Extract an SD from JSON, labeled text, or a single numeric answer.
parse_sd_only_output <- function(txt) {
  cleaned <- if (length(txt) == 1L && !is.na(txt)) normalize_scalar_format(txt) else NA_character_
  json_candidate <- NA_character_
  finish <- function(values, method) {
    values <- unique(values)
    if (!length(values)) return(list(sd = NA_real_, parse_method = method,
      cleaned = cleaned, json_candidate = json_candidate))
    if (length(values) != 1L || !is.finite(values) || values < 0) {
      method <- if (length(values) > 1L) paste0("ambiguous_", method) else paste0("invalid_", method)
      values <- NA_real_
    }
    list(sd = as.numeric(values), parse_method = method,
         cleaned = cleaned, json_candidate = json_candidate)
  }
  if (is.na(cleaned) || !nzchar(trimws(cleaned))) return(finish(numeric(), "empty"))
  cleaned <- trimws(gsub("(?s)^\\s*```[A-Za-z]*\\s*|\\s*```\\s*$", "", cleaned, perl = TRUE))
  first <- regexpr("{", cleaned, fixed = TRUE)[1]
  ends <- gregexpr("}", cleaned, fixed = TRUE)[[1]]
  if (first > 0 && any(ends > first)) json_candidate <- substr(cleaned, first, max(ends))
  for (candidate in unique(c(cleaned, json_candidate))) {
    if (is.na(candidate)) next
    obj <- tryCatch(jsonlite::fromJSON(candidate, simplifyVector = TRUE), error = function(e) NULL)
    if (!is.null(obj) && is.list(obj)) {
      keys <- which(names(obj) %in% c("Q7", "q7", "sd", "SD", "std", "std_dev", "standard_deviation", "standard_deviation_estimate", "Q1_SD_estimate"))
      if (length(keys)) {
        values <- vapply(keys, function(key) {
          raw <- obj[[key]]
          if (length(raw) != 1L) return(NA_real_)
          raw <- normalize_scalar_format(raw)
          if (!grepl(paste0("^\\s*", SCALAR_NUMBER_PATTERN, "\\s*$"), raw, perl = TRUE)) return(NA_real_)
          suppressWarnings(as.numeric(raw))
        }, numeric(1))
        return(finish(values, "json_sd_field"))
      }
    }
  }
  strip_answer_markup <- function(z) {
    for (mark in c("***", "___", "**", "__", "*", "_", "`", "$")) {
      literal <- paste0("\\Q", mark, "\\E")
      pattern <- paste0("(?<![[:alnum:]_*`$])", literal,
        "(?=\\S)([^\\r\\n]*?\\S|\\S)", literal, "(?![_*`$])")
      at <- gregexpr(pattern, z, perl=TRUE)[[1]]
      if (at[1] < 0L) next
      widths <- attr(at,"match.length")
      for (k in rev(seq_along(at))) {
        before <- substr(z,1L,at[k]-1L)
        after <- substring(z,at[k]+widths[k])
        body <- substr(z,at[k]+nchar(mark),at[k]+widths[k]-nchar(mark)-1L)
        numeric_body <- grepl("^[+-]?[0-9.eE+-]+$",body,perl=TRUE)
        decimal_continuation <-
          (grepl("^[+-]?[0-9]+$",body) && grepl("^[.][0-9]",after)) ||
          (grepl("^[+-]?[0-9]+[.]$",body) && grepl("^[0-9]",after)) ||
          (grepl("^[.][0-9]+$",body) && grepl("[0-9]$",before))
        if (numeric_body && !decimal_continuation &&
            (grepl("[0-9)][ \\t]*$",before,perl=TRUE) ||
             grepl("^[ \\t]*(?:[0-9]|[.]\\d|[(][ \\t]*[0-9.+-])",after,perl=TRUE))) next
        z <- paste0(before,body,after)
      }
    }
    z
  }
  number <- paste0("(", SCALAR_NUMBER_PATTERN, ")(?![A-Za-z0-9_]|\\.[0-9.]|(?<=\\.)\\.)")
  prose <- normalize_scalar_format(strip_answer_markup(cleaned))
  prose <- gsub("\\\\(?:text|mathrm|mathbf)\\s*\\{([^{}]*)\\}", "\\1", prose, perl = TRUE)
  prose <- gsub("\\\\(?:approx|simeq)\\b", "\u2248", prose, perl = TRUE)
  prose <- gsub("\u2250", "\u2248", prose, fixed=TRUE)
  prose <- gsub("\\\\[][()]", " ", prose, perl = TRUE)
  prose <- gsub("(?m)^\\s*>\\s*", "", prose, perl = TRUE)
  prose <- gsub("[\u2705\U0001f449]", "", prose, perl = TRUE)
  prose <- gsub("(?m)^[ \\t]*#+[ \\t]*", "", prose, perl = TRUE)
  replacements <- gregexpr("(?im)^[ \\t]*(?:correction|corrected answer|replacement answer)\\s*[:=][ \\t]*",prose,perl=TRUE)[[1]]
  if(replacements[1]>0L) {
    k <- length(replacements)
    prose <- paste0("Final answer: ",substring(prose,replacements[k]+attr(replacements,"match.length")[k]))
  }
  answer_matches <- function(pattern, text = prose, strict = FALSE) {
    pos <- gregexpr(pattern, text, perl = TRUE)[[1]]
    if (pos[1] < 0L) return(numeric())
    hits <- regmatches(text, list(pos))[[1]]
    tails <- substring(text, pos + attr(pos, "match.length"))
    calculation_tail <- grepl("^\\s*(?:[*/+^=\u00d7\u00f7]|[(]\\s*[0-9.+-]|\\b(?:x|times|divided\\s+by)\\b|\\\\(?:times|div|cdot)\\b)",
                              tails, perl = TRUE, ignore.case = TRUE)
    invalid_tail <- calculation_tail | grepl("^\\s*(?:to\\b|or\\b|[-\u2013]\\s*[0-9.])", tails, perl=TRUE, ignore.case=TRUE)
    values <- suppressWarnings(as.numeric(sub(pattern, "\\1", hits, perl = TRUE)))
    invalid_context <- grepl("(?i)\\b(?:squared|variance|computed|formula|range|between|depends|factors|calculate|estimating|assuming)\\b", hits, perl = TRUE)
    invalid_context <- invalid_context |
      grepl("\\n\\s*[0-9]+\\.[[:space:]]*$", hits, perl = TRUE) |
      grepl("[(]\\s*[~\u2248]", hits, perl = TRUE) |
      grepl("^\\s*%", tails, perl = TRUE)
    if (any(!invalid_context & grepl("^\\s*or\\b", tails, perl = TRUE, ignore.case = TRUE)))
      return(c(-Inf, Inf))
    unresolved_calculation <- any(calculation_tail & !invalid_context)
    values <- values[!invalid_tail & !invalid_context]
    if (strict && unresolved_calculation) values <- c(values,NA_real_)
    values
  }
  approx <- "(?:(?:approximately|approx\\.?|about|around|roughly|estimated\\s+at)\\s*|[~\u2248]\\s*)?\\s*:?\\s*"
  heading_core <- "(?:final\\s+(?:answer|(?:best\\s+)?estimate)|best\\s+estimate|answer)(?:\\s+is)?(?:\\s*\\([^0-9\\n]{0,80}\\))?\\s*[:=]\\s*"
  final_heading <- paste0("(?i)\\b", heading_core, approx, number)
  boxed_pattern <- paste0("\\\\boxed\\s*\\{\\s*", number, "\\s*\\}")
  boxed <- answer_matches(boxed_pattern)
  label <- "(?:standard\\s+dev(?:iation|iatio|ation|ision|iance)s?|std\\.?\\s*(?:dev(?:iation)?\\.?)?|sd|q7)"
  qualifier <- "[^0-9.\\n\\r!?;:=~\u2248]{0,120}?"
  separator <- "\\s*(?::|=|[~\u2248]|\\b(?:is|was|of|at|about|around)\\b|\\b(?:would|could|might|should|can|to)\\s+be\\b)\\s*"
  labelled <- paste0("\\b", label, qualifier, separator, approx, number)
  headings <- gregexpr(paste0("(?i)\\b",heading_core), prose, perl = TRUE)[[1]]
  if (headings[1] > 0L) {
    block <- substring(prose, headings[1L])
    corrections <- gregexpr("(?i)\\bor\\s+better\\s+yet\\s*[:=]\\s*", block, perl = TRUE)[[1]]
    correction <- tail(corrections, 1L)
    method <- "final_block_answer"
    if (correction > 0L) {
      block <- substring(block,correction+tail(attr(corrections,"match.length"),1L))
      method <- "explicit_final_replacement"
    }
    no_answer <- "(?:unavailable|unknown|undefined|invalid|not\\s+(?:available|applicable|provided)|no\\s+(?:answer|estimate)|none|null|n/?a)\\b"
    if(grepl(paste0("(?i)(?:^|",heading_core,")\\s*",no_answer),block,perl=TRUE))
      return(finish(NA_real_,"unavailable_final_answer"))
    standalone <- scalar_matches(block, paste0("(?m)^[ \\t]*", number, "[ \\t]*$"))
    labelled_final <- answer_matches(paste0("(?im)(?:^|;)\\s*",
      "(?:", heading_core, ")?",
      "(?:(?:estimated|best\\s+estimate\\s+of)\\s+)?", labelled), text = block, strict=TRUE)
    rounded_final <- answer_matches(paste0("(?i)\\bmost\\s+likely\\s+rounded\\s+to\\s*", number), text=block,strict=TRUE)
    point_final <- answer_matches(paste0("(?i)\\b(?:(?:a\\s+)?good\\s+point\\s+estimate\\s+is|",
      "(?:a\\s+)?reasonable\\s+rounded\\s+estimate\\s+is|best\\s+estimate\\s+being)\\s*",number),text=block,strict=TRUE)
    final_values <- c(answer_matches(final_heading,text=block,strict=TRUE), standalone,
      labelled_final, rounded_final, point_final, answer_matches(boxed_pattern,text=block,strict=TRUE),
      answer_matches(paste0("(?i)\\b",label,"\\s*[:=]\\s*",approx,number),text=block,strict=TRUE))
    if (correction > 0L) final_values <- c(final_values,
      answer_matches(paste0("(?i)^\\s*",approx,number),text=block,strict=TRUE))
    if (length(final_values)) return(finish(final_values,method))
    prose <- block
    boxed <- answer_matches(boxed_pattern,text=prose)
  }
  if (length(boxed)) return(finish(boxed, "boxed_answer"))
  final_clause <- paste0("(?i)\\b(?:thus|therefore|hence|so,|best\\s+estimate|in\\s+conclusion|for\\s+(?:a\\s+rounded\\s+estimate|the\\s+sake)|let['\u2019]s\\s+say|final\\s+(?:answer|estimate))",
                         "[^0-9.!?;]{0,160}?", labelled)
  values <- answer_matches(final_clause)
  if (length(values)) return(finish(values, "concluding_sd_answer"))
  separate_line <- paste0("(?im)\\b", label, "[^\\n\\r]{0,220}?",
    "\\b(?:(?:would|could|might|should|to)\\s+be|is)\\b[ \\t]*",
    "(?:(?:approximately|about|around)[ \\t]*)?:?[ \\t]*\\n\\s*", number, "[ \\t]*(?=\\r?$)")
  values <- answer_matches(separate_line)
  if (length(values)) return(finish(values, "separate_line_sd_answer"))
  values <- answer_matches(paste0("(?i)", labelled))
  if (length(values)) return(finish(values, "labelled_answer"))
  formula_answer <- scalar_matches(prose, paste0("(?i)(?:\\bSD\\b|\\\\sigma)\\s*[:=]\\s*",
    "\\\\sqrt\\s*\\{[0-9.eE+ -]+\\}\\s*(?:[\u2248]|=)\\s*", number))
  if (length(formula_answer)) return(finish(formula_answer, "explicit_sd_formula_answer"))
  bare <- trimws(gsub("^[>\\s]+|[\\s]+$", "", prose, perl = TRUE))
  if (!grepl("[.][.]", bare) && grepl(paste0("^", SCALAR_NUMBER_PATTERN, "[.]?$"), bare, perl = TRUE))
    return(finish(as.numeric(sub("[.]$", "", bare)), "single_number"))
  finish(numeric(), "no_unambiguous_sd_answer")
}

read_jsonl_lines_safe <- function(path, label = basename(path)) {
  if (!file.exists(path)) {
    cat("  ⚠ Not found:", label, "→", path, "\n")
    return(tibble(line_num = integer(), raw_line = character(), parsed = list(), parsed_ok = logical(), source_file = character()))
  }
  read_jsonl_lines(path) %>% mutate(source_file = label)
}


# Load and parse SD-only files.
sd_only_api_raw <- read_jsonl_lines_safe(path_sd_only_api, basename(path_sd_only_api))
sd_only_qwen_raw <- read_jsonl_lines_safe(path_sd_only_qwen, basename(path_sd_only_qwen))
sd_only_gpt35_raw <- read_jsonl_lines_safe(path_sd_only_gpt35, basename(path_sd_only_gpt35))

sd_only_rerun_raw <- read_jsonl_lines_safe(path_rerun_missing, basename(path_rerun_missing))

# Retain only SD-prompt rows from the multiprompt gpt-oss file.
sd_only_gptoss_raw <- read_jsonl_lines_safe(
  path_sd_only_gptoss, basename(path_sd_only_gptoss)
)

sd_only_raw_all <- bind_rows(
  sd_only_api_raw, sd_only_qwen_raw, sd_only_gpt35_raw,
  sd_only_rerun_raw, sd_only_gptoss_raw
)

cat("\n── SD-only raw load ──\n")
sd_only_raw_all %>%
  group_by(source_file) %>%
  summarise(
    n_lines = n(),
    n_parsed_ok = sum(parsed_ok),
    n_parsed_fail = sum(!parsed_ok),
    .groups = "drop"
  ) %>%
  print()

sd_only_source_files <- c(
  basename(path_sd_only_api),
  basename(path_sd_only_qwen),
  basename(path_sd_only_gpt35)
)

sd_only_flat <- sd_only_raw_all %>%
  filter(parsed_ok) %>%
  mutate(
    input_id   = canonical_scenario_id(purrr::map_chr(parsed, ~ safe_get_chr(.x, "input_id"))),
    model_name = normalize_model_name(purrr::map_chr(parsed, ~ safe_get_chr(.x, "model_name"))),
    prompt_id  = purrr::map_chr(parsed, ~ safe_get_chr(.x, "prompt_id")),
    output_seq = purrr::map_chr(parsed, ~ safe_get_chr(.x, "output_seq"))
  ) %>%
  filter(
    as.character(prompt_id) == SD_ONLY_PROMPT_ID |
      (
        source_file %in% sd_only_source_files &
          (is.na(prompt_id) | prompt_id == "")
      )
  )

audit_record(
  "A3 gpt-oss SD-only", "keep prompt 7 only from the gpt-oss phase A file",
  rows_in = nrow(sd_only_gptoss_raw),
  rows_out = sum(sd_only_flat$source_file == basename(path_sd_only_gptoss)),
  reason = "prompts 5 and 6 in this file are the truncated run replaced by the v2 file; prompt 3 is superseded by the new confidence file",
  detail = basename(path_sd_only_gptoss)
)
cat("  gpt-oss SD-only rows kept:",
    sum(sd_only_flat$source_file == basename(path_sd_only_gptoss)),
    "of", nrow(sd_only_gptoss_raw), "\n")

sd_only_parsed <- sd_only_flat %>%
  mutate(parsed_sd = purrr::map(output_seq, parse_sd_only_output)) %>%
  mutate(
    sd_only_value        = purrr::map_dbl(parsed_sd, "sd"),
    parse_method = purrr::map_chr(parsed_sd, "parse_method"),
    cleaned      = purrr::map_chr(parsed_sd, "cleaned"),
    json_txt     = purrr::map_chr(parsed_sd, "json_candidate"),
    sd_ok        = !is.na(sd_only_value)
  )

# Retain every response and parser decision before source selection/adjudication.
write_csv(sd_only_parsed %>% select(-parsed_sd),
          file.path(out_dir, "CHECK_sd_parser_all_raw_responses.csv"))

sd_only_estimates <- sd_only_parsed %>%
  filter(!is.na(input_id), !is.na(model_name)) %>%
  group_by(input_id, model_name) %>%
  # Keep the selected response and its source metadata together for the raw-output audit.
  arrange(dplyr::desc(sd_ok), .by_group = TRUE) %>%
  summarise(
    sd_only_value = dplyr::first(sd_only_value),
    sd_only_parse_method = dplyr::first(parse_method),
    source_file = dplyr::first(source_file),
    line_num = dplyr::first(line_num),
    .groups = "drop"
  )

# Present-paper model × scenario cells with suspicious parsed SDs were
# manually checked against the raw model response. Parser errors are
# corrected to the SD actually stated by the model.

sd_adjudication <- readxl::read_excel(
  path_sd_adjudication,
  sheet = "Analysis SD decisions"
) %>%
  transmute(
    input_id = canonical_scenario_id(as.character(input_id)),
    model_name = normalize_model_name(as.character(model_name)),
    source_file = as.character(source_file),
    line_num = as.integer(line_num),
    audited_raw = as.character(raw_output),
    original_parser_sd = as.numeric(original_parser_sd),
    adjudicated_sd = as.numeric(final_sd_for_analysis),
    issue_type = stringr::str_trim(as.character(issue_type)),
    decision_note = as.character(decision_note)
  )

# Basic safeguards: this audit should contain exactly the 56 flagged
# present-paper cells and one row per model × scenario.
if (nrow(sd_adjudication) != 56L) {
  stop(
    "Expected 56 SD-adjudication rows, found ",
    nrow(sd_adjudication),
    ". Check the adjudication spreadsheet."
  )
}

if (anyDuplicated(sd_adjudication[c("input_id", "model_name")])) {
  stop("Duplicate input_id × model_name cells in SD adjudication spreadsheet.")
}

expected_sd_issue_types <- c(
  "Parsing error", "Model output error — preserve",
  "Incomplete model output", "Malformed model output"
)
if (any(is.na(sd_adjudication$issue_type) | !nzchar(sd_adjudication$issue_type))) {
  stop("Blank issue_type in SD adjudication spreadsheet.")
}
unexpected_sd_issue_types <- setdiff(unique(sd_adjudication$issue_type), expected_sd_issue_types)
if (length(unexpected_sd_issue_types)) {
  stop("Unrecognized SD adjudication issue_type: ",
       paste(unexpected_sd_issue_types, collapse = "; "))
}
if (any(is.na(sd_adjudication$input_id) | !nzchar(sd_adjudication$input_id)) ||
    any(is.na(sd_adjudication$model_name) | !nzchar(sd_adjudication$model_name))) {
  stop("Missing input_id or model_name in SD adjudication spreadsheet.")
}

if (any(!grepl("^\\d+_(old|new)$", sd_adjudication$input_id))) {
  stop("SD adjudication spreadsheet contains non-present-paper scenario IDs.")
}

# Check that every adjudicated cell exists in the current selected SD data.
missing_adjudication_cells <- sd_adjudication %>%
  anti_join(
    sd_only_estimates %>%
      distinct(input_id, model_name),
    by = c("input_id", "model_name")
  )

if (nrow(missing_adjudication_cells) > 0) {
  print(missing_adjudication_cells, n = Inf, width = Inf)
  stop("Some adjudicated SD cells are absent from sd_only_estimates.")
}

# Workbook XML preserves CRLF while JSON readers return LF. Normalize only this
# transport representation; all other characters must match the recorded response.
same_adjudicated_response <- function(a, b) {
  !is.na(a) & !is.na(b) & gsub("\r\n", "\n", a, fixed = TRUE) == gsub("\r\n", "\n", b, fixed = TRUE)
}

sd_adjudication_sources <- sd_adjudication %>%
  left_join(sd_only_parsed %>% select(input_id, model_name, source_file, line_num,
                                     output_seq, sd_only_value, parse_method),
    by = c("input_id", "model_name", "source_file", "line_num")) %>%
  mutate(source_identity_verified = same_adjudicated_response(output_seq, audited_raw))
write_csv(sd_adjudication_sources, file.path(out_dir, "CHECK_sd_adjudication_source_identity.csv"))
if (nrow(sd_adjudication_sources) != nrow(sd_adjudication) ||
    any(is.na(sd_adjudication_sources$source_identity_verified) | !sd_adjudication_sources$source_identity_verified))
  stop("The recorded SD-adjudication source no longer matches its exact raw response; review source-identity audit.")
sd_only_estimates <- bind_rows(
  sd_only_estimates %>% anti_join(sd_adjudication, by = c("input_id", "model_name")),
  sd_adjudication_sources %>% transmute(input_id, model_name, sd_only_value,
    sd_only_parse_method = parse_method, source_file, line_num)
)

# Apply the adjudicated model × scenario values.

sd_only_estimates <- sd_only_estimates %>%
  left_join(
    sd_adjudication %>% select(-source_file, -line_num, -audited_raw),
    by = c("input_id", "model_name")
  ) %>%
  mutate(
    has_sd_adjudication = !is.na(issue_type),
    
    # Preserve original values for provenance.
    sd_only_value_pre_adjudication = sd_only_value,
    sd_only_parse_method_pre_adjudication = sd_only_parse_method,
    
    sd_only_value = if_else(
      has_sd_adjudication,
      adjudicated_sd,
      sd_only_value
    ),
    
    sd_only_parse_method = case_when(
      !has_sd_adjudication ~ sd_only_parse_method,
      
      issue_type == "Parsing error" ~
        "manual_raw_output_correction",
      
      issue_type == "Model output error — preserve" ~
        "manual_verified_model_value",
      
      issue_type == "Incomplete model output" ~
        "manual_verified_missing",
      
      issue_type == "Malformed model output" ~
        "manual_typo_adjudication",
      
      TRUE ~ "manual_raw_output_adjudication"
    ),
    
    sd_only_adjudication_issue = if_else(
      has_sd_adjudication,
      issue_type,
      NA_character_
    ),
    
    sd_only_adjudication_note = if_else(
      has_sd_adjudication,
      decision_note,
      NA_character_
    )
  ) %>%
  select(
    -original_parser_sd,
    -adjudicated_sd,
    -issue_type,
    -decision_note,
    -has_sd_adjudication
  )

# Export exactly what was applied for reproducibility.
sd_adjudication_applied <- sd_only_estimates %>%
  filter(!is.na(sd_only_adjudication_issue)) %>%
  select(
    input_id,
    model_name,
    source_file,
    sd_only_value_pre_adjudication,
    sd_only_value,
    sd_only_parse_method_pre_adjudication,
    sd_only_parse_method,
    sd_only_adjudication_issue,
    sd_only_adjudication_note
  ) %>%
  arrange(model_name, input_id)

if (nrow(sd_adjudication_applied) != nrow(sd_adjudication)) {
  stop("Not every SD adjudication row was applied exactly once.")
}

write.csv(
  sd_adjudication_applied,
  file.path(out_dir, "CHECK_sd_only_adjudications_applied.csv"),
  row.names = FALSE
)

sd_adjudication_summary <- sd_adjudication_applied %>%
  group_by(model_name, sd_only_adjudication_issue) %>%
  summarise(
    n_reviewed_cells = n(),
    n_changed_values = sum(!(
      (is.na(sd_only_value_pre_adjudication) & is.na(sd_only_value)) |
      dplyr::coalesce(dplyr::near(sd_only_value_pre_adjudication, sd_only_value), FALSE)
    )),
    n_final_missing = sum(is.na(sd_only_value)),
    n_final_finite_positive = sum(is.finite(sd_only_value) & sd_only_value > 0),
    .groups = "drop"
  )
write.csv(sd_adjudication_summary,
          file.path(out_dir, "CHECK_sd_only_adjudication_summary.csv"), row.names = FALSE)

cat("\n── Standalone SD manual adjudications applied ──\n")
sd_adjudication_applied %>%
  count(sd_only_adjudication_issue) %>%
  print(n = Inf)

cat("Total adjudicated cells:", nrow(sd_adjudication_applied), "\n")

.sd_only_validity_diag <- sd_only_estimates %>%
  filter(!is.na(sd_only_value), !is.finite(sd_only_value) | sd_only_value <= 0) %>%
  left_join(
    sd_only_parsed %>%
      filter(!is.na(input_id), !is.na(model_name)) %>%
      group_by(input_id, model_name) %>%
      summarise(any_finite_positive_sd = any(sd_ok & is.finite(sd_only_value) &
                                               sd_only_value > 0),
                .groups = "drop"),
    by = c("input_id", "model_name")
  )
cat("\n  SD-only cells with a selected nonpositive/non-finite SD:",
    nrow(.sd_only_validity_diag),
    "( of which rescuable by a later valid row:",
    sum(.sd_only_validity_diag$any_finite_positive_sd, na.rm = TRUE), ")\n")
if (nrow(.sd_only_validity_diag) > 0) {
  write.csv(.sd_only_validity_diag,
            file.path(out_dir, "CHECK_sd_only_invalid_selected.csv"),
            row.names = FALSE)
}

cat("\n── SD-only parsed summary by model ──\n")
sd_only_parsed %>%
  group_by(source_file, model_name) %>%
  summarise(
    n_rows = n(),
    n_sd_ok = sum(sd_ok, na.rm = TRUE),
    n_unique_input_ids = n_distinct(input_id[!is.na(input_id)]),
    .groups = "drop"
  ) %>%
  arrange(source_file, desc(n_sd_ok)) %>%
  print(n = 100)

cat("\n── SD-only parse methods ──\n")
sd_only_parsed %>%
  count(source_file, model_name, parse_method, sort = TRUE) %>%
  print(n = 200)

cat("\n── SD-only final usable rows ──\n")
sd_only_estimates %>%
  count(model_name, source_file, name = "n_input_ids_with_any_sd") %>%
  arrange(desc(n_input_ids_with_any_sd)) %>%
  print(n = 100)


# Mean, SD, and distributional fit analyses
# These analyses compare model-predicted human means, SDs, and full distributions against empirical human data.
cat("\n", strrep("=",70), "\nDISTRIBUTIONS\n", strrep("=",70), "\n")

gpt_confidence_models <- c(
  "gpt-35-turbo_1106",
  "gpt-4o-mini_2024-07-18",
  "gpt-5-chat_2025-08-07",
  "gpt-oss-20b",
  "qwen-3-32B"
)

qwen_distribution_models <- character()

select_primary_scenario_mean_source <- function(df) {
  df %>%
    filter(
      (
        model_name %in% gpt_confidence_models &
          source == "confidence_prompt_model_rating"
      ) |
        (
          model_name %in% qwen_distribution_models &
            source == "distribution_prompt_human_mean"
        )
    )
}

model_means_distribution <- distribution_estimates %>%
  filter(input_id %in% scenarios_with_humans, !is.na(distribution_human_mean)) %>%
  dplyr::select(input_id, model_name, pred_mean=distribution_human_mean) %>%
  mutate(source = "distribution_prompt_human_mean")

model_means_confidence <- confidence_estimates %>%
  filter(input_id %in% scenarios_with_humans, !is.na(conf_model_moral_rating)) %>%
  dplyr::select(input_id, model_name, pred_mean=conf_model_moral_rating) %>%
  mutate(source = "confidence_prompt_model_rating")

model_means_all_available <- bind_rows(
  model_means_distribution,
  model_means_confidence
) %>%
  mutate(
    prompt_measure = recode(
      source,
      "confidence_prompt_model_rating" = "Confidence prompt own judgment",
      "distribution_prompt_human_mean" = "Distribution prompt predicted human mean",
      .default = source
    )
  )

cat("\n── Available model mean sources ──\n")
model_means_all_available %>%
  count(model_name, source, prompt_measure, name = "n_rows") %>%
  arrange(model_name, source) %>%
  print(n = Inf, width = Inf)

model_means_primary <- select_primary_scenario_mean_source(model_means_all_available)

cat("\n── Selected model mean source for average-judgment analyses ──\n")
model_means_primary %>%
  count(model_name, source, prompt_measure, name = "n_rows") %>%
  arrange(model_name, source) %>%
  print(n = Inf, width = Inf)

mean_comparison <- model_means_primary %>%
  inner_join(
    human_stats %>% dplyr::select(input_id, human_mean),
    by = "input_id"
  ) %>%
  group_by(model_name, source, prompt_measure) %>%
  summarise(
    r = safe_cor(pred_mean, human_mean),
    mse = mean((pred_mean - human_mean)^2, na.rm = TRUE),
    mae = mean(abs(pred_mean - human_mean), na.rm = TRUE),
    n = n_distinct(input_id),
    .groups = "drop"
  ) %>%
  arrange(source, desc(r))

cat("\n── Model Mean vs Human Mean, primary selected source ──\n")
print(mean_comparison, n = Inf, width = Inf)

# Compare GPT-5's predicted human mean with its own rating
gpt5_mean_prompt_pairs <- distribution_estimates %>%
  filter(model_name == "gpt-5-chat_2025-08-07",
         input_id %in% scenarios_with_humans) %>%
  select(input_id, model_name, predicted_human_mean = distribution_human_mean) %>%
  inner_join(
    confidence_estimates %>%
      filter(model_name == "gpt-5-chat_2025-08-07") %>%
      select(input_id, model_name, own_rating = conf_model_moral_rating),
    by = c("input_id", "model_name")
  ) %>%
  inner_join(human_stats %>% select(input_id, human_mean), by = "input_id") %>%
  filter(is.finite(predicted_human_mean), is.finite(own_rating), is.finite(human_mean)) %>%
  mutate(
    abs_error_predicted_mean = abs(predicted_human_mean - human_mean),
    abs_error_own_rating = abs(own_rating - human_mean),
    improvement = abs_error_own_rating - abs_error_predicted_mean
  )

if (anyDuplicated(gpt5_mean_prompt_pairs$input_id)) {
  stop("GPT-5 paired mean comparison contains duplicate scenarios.")
}
summarize_gpt5_mean_comparison <- function(d) {
  n_pairs <- nrow(d)
  diff_sd <- if (n_pairs > 1L) stats::sd(d$improvement) else NA_real_
  estimable <- n_pairs > 1L && is.finite(diff_sd) && diff_sd > 0
  tt <- if (estimable) stats::t.test(d$improvement, mu = 0) else NULL
  tibble(
    model_name = "gpt-5-chat_2025-08-07",
    comparison = "own-rating absolute error minus predicted-human-mean absolute error",
    n_pairs = n_pairs,
    mae_predicted_human_mean = if (n_pairs) mean(d$abs_error_predicted_mean) else NA_real_,
    mae_own_rating = if (n_pairs) mean(d$abs_error_own_rating) else NA_real_,
    mean_improvement = if (n_pairs) mean(d$improvement) else NA_real_,
    se = if (estimable) diff_sd / sqrt(n_pairs) else NA_real_,
    t = if (estimable) unname(tt$statistic) else NA_real_,
    df = if (estimable) unname(tt$parameter) else NA_real_,
    p = if (estimable) tt$p.value else NA_real_,
    ci_low = if (estimable) unname(tt$conf.int[1]) else NA_real_,
    ci_high = if (estimable) unname(tt$conf.int[2]) else NA_real_,
    dz = if (estimable) mean(d$improvement) / diff_sd else NA_real_,
    test_status = if (estimable) "paired t test" else "insufficient pairs or zero difference variance"
  )
}
gpt5_mean_prompt_comparison <- summarize_gpt5_mean_comparison(gpt5_mean_prompt_pairs)
write.csv(gpt5_mean_prompt_pairs,
          file.path(out_dir, "table_gpt5_stated_mean_vs_own_rating_by_item.csv"), row.names = FALSE)
write.csv(gpt5_mean_prompt_comparison,
          file.path(out_dir, "table_gpt5_stated_mean_vs_own_rating.csv"), row.names = FALSE)
cat("\nGPT-5 predicted human mean versus own rating (paired items):\n")
print(gpt5_mean_prompt_comparison, width = Inf)


robustness <- model_means_primary %>%
  inner_join(
    human_stats %>% dplyr::select(input_id, human_mean, scenario_type),
    by = "input_id"
  ) %>%
  filter(scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES) %>%
  mutate(scenario_version = make_scenario_version(scenario_type)) %>%
  group_by(model_name, source, prompt_measure, scenario_version) %>%
  summarise(
    r = safe_cor(pred_mean, human_mean),
    mse = mean((pred_mean - human_mean)^2, na.rm = TRUE),
    mae = mean(abs(pred_mean - human_mean), na.rm = TRUE),
    n_scenarios = n_distinct(input_id),
    .groups = "drop"
  ) %>%
  arrange(source, model_name, scenario_version)

cat("\n── Mean-judgment fit by PRESENT PAPER old/new scenarios, primary selected source ──\n")
print(robustness, n = Inf, width = Inf)


# Standard deviation fit across direct SD prompts, confidence prompt SD estimates, and repeated sampling.
sd_distribution_prompt <- distribution_estimates %>% filter(input_id %in% scenarios_with_humans, !is.na(distribution_human_sd)) %>%
  dplyr::select(input_id, model_name, pred_sd=distribution_human_sd) %>% mutate(source="distribution_prompt_sd")
sd_only_value <- sd_only_estimates %>% filter(input_id %in% scenarios_with_humans, !is.na(sd_only_value)) %>%
  dplyr::select(input_id, model_name, pred_sd=sd_only_value) %>% mutate(source="sd_only_prompt")
sd_confidence_prompt <- confidence_estimates %>% filter(input_id %in% scenarios_with_humans, !is.na(sd_estimate)) %>%
  dplyr::select(input_id, model_name, pred_sd=sd_estimate) %>% mutate(source="confidence_prompt_sd")

sd_rep_temp1 <- repeated_sampling_from_raw %>%
  filter(input_id %in% scenarios_with_humans) %>%
  group_by(input_id, model_name) %>%
  summarise(pred_sd = sd(clamp_scale(rating), na.rm = TRUE),
            n_reps = n(), .groups = "drop") %>%
  filter(n_reps >= 3)

sd_rep500 <- NULL
if (!is.null(rep500)) {
  sd_rep500 <- rep500 %>%
    filter(input_id %in% scenarios_with_humans) %>%
    group_by(input_id, model_name) %>%
    summarise(pred_sd = sd(clamp_scale(rating), na.rm = TRUE),
              n_reps = n(), .groups = "drop")
}

sd_repeated <- bind_rows(
  if (!is.null(sd_rep500)) sd_rep500 else NULL,
  sd_rep_temp1
) %>%
  arrange(input_id, model_name) %>%
  group_by(input_id, model_name) %>%
  slice(1) %>%
  ungroup() %>%
  dplyr::select(input_id, model_name, pred_sd) %>%
  mutate(source = "Repeated_sampling")

sd_all <- bind_rows(sd_distribution_prompt, sd_only_value, sd_confidence_prompt, sd_repeated)

sd_comparison <- sd_all %>%
  inner_join(human_stats %>% dplyr::select(input_id, human_sd), by = "input_id") %>%
  group_by(model_name, source) %>%
  summarise(
    r_sd = safe_cor(pred_sd, human_sd),
    mse = mean((pred_sd - human_sd)^2, na.rm = TRUE),
    n = n_distinct(input_id),
    .groups = "drop"
  ) %>%
  arrange(source, desc(r_sd))

cat("\n── SD Comparison ──\n")
print(sd_comparison, n=50)


# Convert model estimates into discrete simulated response distributions on the -4 to 4 scale.
n_sim <- 1000; set.seed(42)

point_mass_probs <- function(mu, bins) {
  if (length(mu) != 1L || !is.finite(mu) || !length(bins) ||
      any(!is.finite(bins)) || anyDuplicated(bins)) return(NULL)
  hit <- which(abs(bins - mu) <= 1e-8)
  if (length(hit) != 1L) return(NULL)
  p <- numeric(length(bins)); p[hit] <- 1
  p
}

zero_sd_status <- function(mu, sigma, bins, skew = NA_real_, kurt = NA_real_) {
  if (!is.finite(sigma) || sigma != 0) return("not_zero_sd")
  if (is.null(point_mass_probs(mu, bins))) return("zero_sd_mean_off_grid")
  if (is.finite(skew) || is.finite(kurt)) return("zero_sd_undefined_shape_targets")
  "zero_sd_point_mass"
}

r_trunc_normal <- function(n, mu, sd) {
  if (!is.finite(mu) || !is.finite(sd) || sd < 0) return(rep(NA_integer_, n))
  if (sd == 0) {
    p <- point_mass_probs(mu, -4:4)
    return(if (is.null(p)) rep(NA_integer_, n) else rep((-4:4)[which(p == 1)], n))
  }
  clamp_scale(rtruncnorm(n, a=-4, b=4, mean=mu, sd=sd))
}

r_from_q8 <- function(n, probs) {
  probs <- normalize_bin_probabilities(probs)
  if (all(is.na(probs))) return(rep(NA_integer_, n))
  sample(-4:4, size = n, replace = TRUE, prob = probs)
}


# Hybrid distributions average direct bin probabilities with the Mean + SD distribution.
HYBRID_MEAN_SD_WEIGHT <- 0.5

r_hybrid <- function(n, probs, mu, sd, weight = HYBRID_MEAN_SD_WEIGHT) {
  probs <- normalize_bin_probabilities(probs)
  if (!is.finite(mu) || !is.finite(sd) || sd < 0) return(r_from_q8(n, probs))
  if (all(is.na(probs))) return(r_trunc_normal(n, mu, sd))

  np <- if (sd == 0) point_mass_probs(mu, -4:4) else dnorm(-4:4, mean = mu, sd = sd)
  if (is.null(np)) return(r_from_q8(n, probs))

  # When a model reports a mean far outside the -4..4 scale, every bin density
  # underflows to exactly zero and np/sum(np) becomes NaN, which makes sample()
  # fail with "NA in probability vector". Fall back to the proportions component
  # alone.
  if (!all(is.finite(np)) || sum(np) <= 0) {
    return(r_from_q8(n, probs))
  }
  np <- np / sum(np)

  blend <- weight * np + (1 - weight) * probs
  if (!all(is.finite(blend)) || sum(blend) <= 0) {
    return(r_from_q8(n, probs))
  }

  sample(-4:4, size = n, replace = TRUE, prob = blend)
}

softmax_probs <- function(z) {
  z <- z - max(z, na.rm = TRUE)
  ez <- exp(z)
  ez / sum(ez)
}

discrete_moments_from_probs <- function(p, bins = -4:4) {
  p <- as.numeric(p)
  bins <- as.numeric(bins)

  mu <- sum(p * bins)
  var <- sum(p * (bins - mu)^2)
  sd <- sqrt(var)

  if (!is.finite(sd) || sd <= 0) {
    return(list(
      mean = mu,
      sd = sd,
      skew = NA_real_,
      kurt = NA_real_
    ))
  }

  z <- (bins - mu) / sd

  list(
    mean = mu,
    sd = sd,
    skew = sum(p * z^3),
    kurt = sum(p * z^4) - 3
  )
}

# Floor bimodal starting probabilities so optimization can move mass away from the initial peaks. The normal-density initialization uses its separate floor.
MOMENT_SEED_FLOOR <- local({
  raw <- Sys.getenv("SCEN_MOMENT_SEED_FLOOR", unset = "")
  v <- if (nzchar(raw)) suppressWarnings(as.numeric(raw)) else 1e-2
  if (is.na(v) || !is.finite(v) || v < 0 || v >= 1) {
    stop("SCEN_MOMENT_SEED_FLOOR must be a finite number in [0, 1). Got: ", raw)
  }
  v
})
cat("MOMENT_SEED_FLOOR =", format(MOMENT_SEED_FLOOR, scientific = TRUE), "\n")

make_start_probs_for_full <- function(
    bins = -4:4,
    target_mean,
    target_sd,
    peaks,
    loc1,
    w1,
    loc2,
    w2
) {
  bins <- as.numeric(bins)

  shape <- clean_distribution_shape(peaks)

  if (
    !is.na(shape) &&
    shape == "bimodal" &&
    !is.na(loc1) &&
    !is.na(loc2)
  ) {
    peak_bins <- clamp_scale(c(loc1, loc2), lo = min(bins), hi = max(bins))

    if (!is.na(w1) && !is.na(w2) && is.finite(w1) && is.finite(w2) && (w1 + w2) > 0) {
      peak_weights <- c(w1, w2) / sum(c(w1, w2))
    } else {
      peak_weights <- c(0.5, 0.5)
    }

    start_p <- rep(0, length(bins))
    for (i in seq_along(peak_bins)) {
      idx <- which(bins == peak_bins[i])
      if (length(idx) == 1) {
        start_p[idx] <- start_p[idx] + peak_weights[i]
      }
    }

    if (sum(start_p) > 0) {
      start_p <- start_p / sum(start_p)
      start_p <- pmax(start_p, MOMENT_SEED_FLOOR)
      return(start_p / sum(start_p))
    }
  }

  start_p <- stats::dnorm(bins, mean = target_mean, sd = target_sd)

  if (any(!is.finite(start_p)) || sum(start_p) <= 0) {
    start_p <- rep(1 / length(bins), length(bins))
  } else {
    start_p <- start_p / sum(start_p)
  }

  start_p <- pmax(start_p, .Machine$double.eps)
  start_p / sum(start_p)
}

moment_feasibility_small_support <- function(bins, mu, sigma, skew = NA_real_, kurt = NA_real_) {
  bins <- as.numeric(bins)
  if (length(bins) > 9L) return(list(status = "not_assessed_large_support", p = NULL))
  if (length(bins) < 2L || any(!is.finite(bins)) || anyDuplicated(bins) ||
      !is.finite(mu) || !is.finite(sigma) || sigma <= 0)
    return(list(status = "not_assessed_invalid_or_degenerate", p = NULL))
  center <- mean(range(bins)); width <- diff(range(bins))
  x <- (bins - center) / width; a <- (mu - center) / width; v <- (sigma / width)^2
  powers <- c(0L, 1L, 2L); target <- c(1, a, a^2 + v)
  if (is.finite(skew)) {
    powers <- c(powers, 3L); target <- c(target, a^3 + 3*a*v + skew*v^1.5)
  }
  if (is.finite(kurt)) {
    # Fourth raw moment requires the central third moment
    if (!is.finite(skew)) return(list(status = "not_assessed_kurtosis_without_skew", p = NULL))
    powers <- c(powers, 4L)
    target <- c(target, a^4 + 6*a^2*v + 4*a*skew*v^1.5 + (kurt+3)*v^2)
  }
  A <- t(vapply(powers, function(k) x^k, numeric(length(x))))
  subsets <- combn(seq_along(x), min(nrow(A), length(x)), simplify = FALSE)
  total <- numeric(length(x)); n_vertices <- 0L; vertices <- list()
  for (idx in subsets) {
    w <- tryCatch(qr.solve(A[, idx, drop = FALSE], target, tol = 1e-12), error = function(e) NULL)
    if (is.null(w) || any(!is.finite(w)) || min(w) < -1e-10) next
    p <- numeric(length(x)); p[idx] <- pmax(w, 0)
    if (max(abs(drop(A %*% p) - target)) > 1e-9 || sum(p) <= 0) next
    total <- total + p / sum(p); n_vertices <- n_vertices + 1L
    vertices[[n_vertices]] <- p / sum(p)
  }
  if (!n_vertices) return(list(status = "infeasible_on_discrete_support", p = NULL))
  list(status = "feasible_on_discrete_support", p = total / sum(total), vertices = do.call(cbind, vertices))
}

moment_reconstruction_error <- function(p, bins, mu, sigma, skew = NA_real_, kurt = NA_real_) {
  m <- discrete_moments_from_probs(p, bins)
  residual <- c(m$mean - mu, m$sd - sigma,
    if (is.finite(skew)) m$skew - skew,
    if (is.finite(kurt)) m$kurt - kurt)
  if (any(!is.finite(residual))) Inf else max(abs(residual))
}

MOMENT_ACCURACY_TOL <- 1e-4

maxent_moment_distribution <- function(bins, mu, sigma, skew = NA_real_, kurt = NA_real_) {
  failure <- function(status) list(status=status, p=NULL, max_moment_error=NA_real_, entropy=NA_real_, optimality_gap=NA_real_)
  if (is.finite(sigma) && sigma == 0) {
    if (zero_sd_status(mu,sigma,bins,skew,kurt) != "zero_sd_point_mass") return(failure("invalid_zero_sd"))
    p <- point_mass_probs(mu,bins)
    return(list(status="exact_point_mass",p=p,max_moment_error=0,entropy=0,optimality_gap=0))
  }
  f <- moment_feasibility_small_support(bins,mu,sigma,skew,kurt)
  if (is.null(f$p)) return(failure(f$status))
  V <- f$vertices
  active <- which(rowSums(V) > 0)
  pa <- f$p[active]
  degree <- if(is.finite(kurt)) 4L else if(is.finite(skew)) 3L else 2L
  C <- outer(0:degree,bins[active],function(power,x) x^power)
  C <- C/sqrt(rowSums(C^2))
  decomposition <- qr(t(C),tol=1e-10)
  Q <- qr.Q(decomposition,complete=TRUE)
  gap <- 0
  if(decomposition$rank < length(active)) {
    X <- Q[,seq.int(2L,decomposition$rank),drop=FALSE]
    target <- drop(crossprod(X,pa)); lambda <- rep(0,ncol(X))
    evaluate <- function(lambda) {
      eta <- drop(X %*% lambda); offset <- max(eta)
      probs <- exp(eta-offset); probs <- probs/sum(probs)
      list(p=probs,value=offset+log(sum(exp(eta-offset)))-sum(target*lambda))
    }
    converged <- FALSE
    for(iter in seq_len(200L)) {
      state <- evaluate(lambda); mean_x <- drop(crossprod(X,state$p))
      gradient <- mean_x-target
      if(max(abs(gradient)) <= 1e-12) {converged <- TRUE;break}
      centered <- sweep(X,2,mean_x)
      hessian <- crossprod(centered,centered*state$p)
      eigen_h <- eigen(hessian,symmetric=TRUE)
      step <- -drop(eigen_h$vectors %*% (crossprod(eigen_h$vectors,gradient)/pmax(eigen_h$values,1e-15)))
      direction <- sum(gradient*step); alpha <- 1; accepted <- FALSE
      for(backtrack in seq_len(80L)) {
        proposal <- lambda+alpha*step
        if(evaluate(proposal)$value <= state$value+1e-4*alpha*direction+1e-15) {
          lambda <- proposal;accepted <- TRUE;break
        }
        alpha <- alpha/2
      }
      if(!accepted) return(failure("maxent_optimizer_failed"))
    }
    if(!converged) return(failure("maxent_optimizer_failed"))
    pa <- state$p
    gap <- abs(state$value + sum(pa[pa>0]*log(pa[pa>0])))
    if(!is.finite(gap) || gap>1e-7) return(failure("maxent_optimality_failed"))
  }
  p <- numeric(length(bins)); p[active] <- pa
  error <- moment_reconstruction_error(p,bins,mu,sigma,skew,kurt)
  if (!is.finite(error) || error > MOMENT_ACCURACY_TOL) return(failure("maxent_moment_accuracy_failed"))
  list(status="maximum_entropy_exact_moments",p=p,max_moment_error=error,
    entropy=-sum(p[p>0]*log(p[p>0])), optimality_gap=gap)
}


fit_discrete_moment_distribution <- function(
    bins = -4:4,
    target_mean,
    target_sd,
    target_skew = NA_real_,
    target_kurt = NA_real_,
    peaks = NA_character_,
    loc1 = NA_real_,
    w1 = NA_real_,
    loc2 = NA_real_,
    w2 = NA_real_,
    return_diagnostics = FALSE
) {
  bins <- as.numeric(bins)
  target_mean <- as.numeric(target_mean)
  target_sd <- as.numeric(target_sd)
  target_skew <- as.numeric(target_skew)
  target_kurt <- as.numeric(target_kurt)


  shape <- clean_distribution_shape(peaks)
  valid_target <- length(bins) >= 2L && all(is.finite(bins)) &&
    is.finite(target_mean) && is.finite(target_sd) && target_sd >= 0
  diag <- tibble(
    shape_raw = as.character(peaks), shape_clean = shape,
    peak1_location = as.numeric(loc1), peak1_weight = as.numeric(w1),
    peak2_location = as.numeric(loc2), peak2_weight = as.numeric(w2),
    target_mean = target_mean, target_sd = target_sd,
    target_skew = target_skew, target_kurt = target_kurt,
    seed_floor = MOMENT_SEED_FLOOR, optimizer_maxit = 5000L,
    took_bimodal_branch = !is.na(shape) && shape == "bimodal" &&
      is.finite(loc1) && is.finite(loc2),
    fit_status = "invalid_target", selected_start = NA_character_,
    moment_feasibility = NA_character_, max_moment_error = NA_real_,
    reconstruction_accurate = FALSE,
    feasibility_flags = NA_character_, min_seed_p = NA_real_,
    obj_start = NA_real_, obj_end = NA_real_, obj_flat_start = NA_real_,
    ratio_to_flat = NA_real_, convergence = NA_integer_,
    flat_convergence = NA_integer_, selected_loss = NA_real_,
    fitted_mean = NA_real_, fitted_sd = NA_real_,
    fitted_skew = NA_real_, fitted_kurt = NA_real_, fitted = NA_character_
  )
  attempts <- tibble(start = character(), convergence = integer(),
                     loss = numeric(), valid = logical(), message = character())
  finish <- function(fit) {
    if (return_diagnostics) list(fit = fit, diagnostics = diag, attempts = attempts)
    else fit
  }
  if (!valid_target) return(finish(NULL))
  if (target_sd == 0) {
    status <- zero_sd_status(target_mean, target_sd, bins, target_skew, target_kurt)
    if (identical(shape, "bimodal")) status <- "zero_sd_incompatible_bimodal_shape"
    diag$feasibility_flags <- status
    if (status != "zero_sd_point_mass") return(finish(NULL))
    p <- point_mass_probs(target_mean, bins)
    diag$fit_status <- "exact_point_mass"
    diag$selected_start <- "not_needed"
    diag$selected_loss <- 0
    diag$max_moment_error <- 0; diag$reconstruction_accurate <- TRUE
    diag$moment_feasibility <- "exact_point_mass"
    diag$fitted_mean <- sum(p * bins); diag$fitted_sd <- 0
    diag$fitted <- paste(sprintf("%.12g", p), collapse = ";")
    return(finish(tibble(bin = as.integer(bins), model_prop = p)))
  }

  flags <- character()
  lo <- min(bins); hi <- max(bins)
  if (target_mean < lo || target_mean > hi) flags <- c(flags, "mean_outside_support")
  if (target_mean >= lo && target_mean <= hi &&
      target_sd^2 > (target_mean - lo) * (hi - target_mean) + 1e-8)
    flags <- c(flags, "variance_exceeds_support_bound")
  if (is.finite(target_kurt) && target_kurt < -2 - 1e-8)
    flags <- c(flags, "excess_kurtosis_below_minus_two")
  if (is.finite(target_kurt) && is.finite(target_skew) &&
      target_kurt < target_skew^2 - 2 - 1e-8)
    flags <- c(flags, "skew_kurtosis_incompatible")
  diag$feasibility_flags <- if (length(flags)) paste(flags, collapse = ";") else
    "none_detected_not_a_full_feasibility_test"
  use_skew <- !is.na(target_skew) && is.finite(target_skew)
  use_kurt <- !is.na(target_kurt) && is.finite(target_kurt)

  scale_width <- max(bins) - min(bins)

  start_p <- make_start_probs_for_full(
    bins = bins,
    target_mean = target_mean,
    target_sd = target_sd,
    peaks = peaks,
    loc1 = loc1,
    w1 = w1,
    loc2 = loc2,
    w2 = w2
  )

  start_z <- log(start_p)

  objective <- function(z) {
    p <- softmax_probs(z)
    m <- discrete_moments_from_probs(p, bins)
    if (!is.finite(m$mean) || !is.finite(m$sd) ||
        (use_skew && !is.finite(m$skew)) ||
        (use_kurt && !is.finite(m$kurt))) return(1e100)

    loss <- 0

    loss <- loss + ((m$mean - target_mean) / scale_width)^2
    loss <- loss + ((m$sd - target_sd) / scale_width)^2

    if (use_skew && !is.na(m$skew) && is.finite(m$skew)) {
      loss <- loss + (m$skew - target_skew)^2
    }

    if (use_kurt && !is.na(m$kurt) && is.finite(m$kurt)) {
      loss <- loss + (m$kurt - target_kurt)^2
    }

    loss
  }


  starts <- list(initial = start_z, uniform = rep(0, length(bins)))
  fits <- lapply(starts, function(z) tryCatch(
    stats::optim(z, objective, method = "BFGS", control = list(maxit = 5000, reltol = 1e-12)),
    error = function(e) e))
  valid <- vapply(fits, function(f) !inherits(f, "error") &&
    isTRUE(f$convergence == 0) && all(is.finite(f$par)) &&
    is.finite(f$value) && f$value < 1e99, logical(1))
  attempts <- purrr::imap_dfr(fits, function(f, nm) tibble(
    start = nm, convergence = if (inherits(f, "error")) NA_integer_ else f$convergence,
    loss = if (inherits(f, "error")) NA_real_ else f$value,
    valid = unname(valid[nm]),
    message = if (inherits(f, "error")) conditionMessage(f) else
      if (is.null(f$message)) "" else as.character(f$message)
  ))
  diag$min_seed_p <- min(start_p)
  diag$obj_start <- objective(start_z)
  diag$obj_end <- attempts$loss[1]
  diag$obj_flat_start <- attempts$loss[2]
  diag$convergence <- attempts$convergence[1]
  diag$flat_convergence <- attempts$convergence[2]
  diag$ratio_to_flat <- if (all(valid) && attempts$loss[2] > 0)
    attempts$loss[1] / attempts$loss[2] else NA_real_
  feasibility <- moment_feasibility_small_support(bins, target_mean, target_sd, target_skew, target_kurt)
  diag$moment_feasibility <- feasibility$status
  if (any(valid)) {
    winner <- which(valid)[which.min(attempts$loss[valid])]
    p <- softmax_probs(fits[[winner]]$par)
    diag$selected_start <- names(starts)[winner]
    diag$selected_loss <- fits[[winner]]$value
  } else p <- rep(NA_real_, length(bins))
  if (!is.null(feasibility$p) &&
      moment_reconstruction_error(p, bins, target_mean, target_sd, target_skew, target_kurt) > MOMENT_ACCURACY_TOL &&
      moment_reconstruction_error(feasibility$p, bins, target_mean, target_sd, target_skew, target_kurt) <= MOMENT_ACCURACY_TOL) {
    p <- feasibility$p
    diag$selected_start <- "exact_feasible_repair"
    diag$selected_loss <- objective(log(p))
  }
  if (any(!is.finite(p))) {
    diag$fit_status <- "truncated_normal_fallback"
    return(finish(NULL))
  }
  m <- discrete_moments_from_probs(p, bins)
  diag$max_moment_error <- moment_reconstruction_error(p, bins, target_mean, target_sd, target_skew, target_kurt)
  diag$reconstruction_accurate <- diag$max_moment_error <= MOMENT_ACCURACY_TOL
  diag$fit_status <- if (identical(diag$selected_start, "exact_feasible_repair")) "exact_feasible_repair" else
    if (diag$reconstruction_accurate) "converged_moment_fit" else "converged_approximation"
  diag$fitted_mean <- m$mean; diag$fitted_sd <- m$sd
  diag$fitted_skew <- m$skew; diag$fitted_kurt <- m$kurt
  diag$fitted <- paste(sprintf("%.12g", p), collapse = ";")
  finish(tibble(bin = as.integer(bins), model_prop = as.numeric(p)))
}

SCEN_MOMENT_FALLBACK <- new.env(parent = emptyenv())
SCEN_MOMENT_FALLBACK$rows <- list()

sample_discrete_moment_distribution <- function(
    n,
    mu,
    sd,
    skewness,
    kurtosis,
    peaks,
    loc1,
    w1,
    loc2,
    w2,
    input_id = NA_character_,
    model_name = NA_character_
) {
  result <- fit_discrete_moment_distribution(
    bins = -4:4,
    target_mean = mu,
    target_sd = sd,
    target_skew = skewness,
    target_kurt = kurtosis,
    peaks = peaks,
    loc1 = loc1,
    w1 = w1,
    loc2 = loc2,
    w2 = w2,
    return_diagnostics = TRUE
  )
  fit <- result$fit
  A84_DIAG$rows[[length(A84_DIAG$rows) + 1L]] <- result$diagnostics %>%
    mutate(input_id = as.character(input_id), model_name = as.character(model_name), .before = 1)
  A84_DIAG$attempts[[length(A84_DIAG$attempts) + 1L]] <- result$attempts %>%
    mutate(input_id = rep(as.character(input_id), n()),
           model_name = rep(as.character(model_name), n()), .before = 1)
  if (result$diagnostics$fit_status == "invalid_target") return(rep(NA_integer_, n))

  if (is.null(fit) || nrow(fit) == 0 || any(is.na(fit$model_prop))) {
    SCEN_MOMENT_FALLBACK$rows[[length(SCEN_MOMENT_FALLBACK$rows) + 1L]] <- tibble(
      input_id = as.character(input_id),
      model_name = as.character(model_name),
      target_mean = as.numeric(mu), target_sd = as.numeric(sd),
      target_skew = as.numeric(skewness), target_kurt = as.numeric(kurtosis),
      reason = if (is.null(fit)) "fit_null_or_nonconverged" else "fit_invalid_probs"
    )
    return(r_trunc_normal(n, mu, sd))
  }

  sample(
    fit$bin,
    size = n,
    replace = TRUE,
    prob = fit$model_prop / sum(fit$model_prop)
  )
}

r_full <- function(n, mu, sd, skewness, kurtosis, peaks, loc1, w1, loc2, w2,
                   input_id = NA_character_, model_name = NA_character_) {
  mu <- as.numeric(mu)
  sd <- as.numeric(sd)
  skewness <- as.numeric(skewness)
  kurtosis <- as.numeric(kurtosis)
  loc1 <- as.numeric(loc1)
  loc2 <- as.numeric(loc2)
  w1 <- as.numeric(w1)
  w2 <- as.numeric(w2)
  peaks <- clean_distribution_shape(peaks)

  sample_discrete_moment_distribution(
    n = n,
    mu = mu,
    sd = sd,
    skewness = skewness,
    kurtosis = kurtosis,
    peaks = peaks,
    loc1 = loc1,
    w1 = w1,
    loc2 = loc2,
    w2 = w2,
    input_id = input_id,
    model_name = model_name
  )
}

check_discrete_full_fit <- function(
    mean = 0,
    sd = 1,
    skewness = 0,
    kurtosis = 0,
    peaks = NA_character_,
    loc1 = NA_real_,
    w1 = NA_real_,
    loc2 = NA_real_,
    w2 = NA_real_
) {
  fit <- fit_discrete_moment_distribution(
    bins = -4:4,
    target_mean = mean,
    target_sd = sd,
    target_skew = skewness,
    target_kurt = kurtosis,
    peaks = peaks,
    loc1 = loc1,
    w1 = w1,
    loc2 = loc2,
    w2 = w2
  )

  if (is.null(fit)) {
    return(tibble(
      target_mean = mean,
      target_sd = sd,
      target_skew = skewness,
      target_kurt = kurtosis,
      fitted_mean = NA_real_,
      fitted_sd = NA_real_,
      fitted_skew = NA_real_,
      fitted_kurt = NA_real_
    ))
  }

  m <- discrete_moments_from_probs(fit$model_prop, fit$bin)

  tibble(
    target_mean = mean,
    target_sd = sd,
    target_skew = skewness,
    target_kurt = kurtosis,
    fitted_mean = m$mean,
    fitted_sd = m$sd,
    fitted_skew = m$skew,
    fitted_kurt = m$kurt
  )
}

cat("\n── Discrete moment matching check for distribution_full ──\n")
print(check_discrete_full_fit(mean = 0, sd = 1, skewness = 0, kurtosis = 0), n = Inf)

A84_DIAG <- new.env(parent = emptyenv())
A84_DIAG$rows <- list()
A84_DIAG$attempts <- list()

model_sim_seed <- function(mn) sum(utf8ToInt(paste(sort(mn), collapse = "|"))) + 42L

generate_sims <- function(df_model) {
  mn <- unique(df_model$model_name)
  cat("  Simulating:", mn, "(", nrow(df_model), ")\n")

  set.seed(model_sim_seed(mn))

  s1 <- df_model %>%
    transmute(
      input_id, model_name,
      sim = purrr::map2(distribution_human_mean, sd_for_mean_sd, ~ r_trunc_normal(n_sim, .x, .y))
    ) %>%
    mutate(method = "distribution_mean_sd") %>%
    unnest_longer(sim, values_to = "y", indices_to = "draw")

  s2 <- df_model %>%
    mutate(
      probs = purrr::pmap(
        list(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4),
        function(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4) {
          c(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4)
        }
      ),
      sim = purrr::map(probs, ~ r_from_q8(n_sim, .x))
    ) %>%
    transmute(input_id, model_name, method = "direct_proportions", sim) %>%
    unnest_longer(sim, values_to = "y", indices_to = "draw")

  s3 <- df_model %>%
    mutate(
      probs = purrr::pmap(
        list(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4),
        function(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4) {
          c(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4)
        }
      ),
      sim = purrr::pmap(
        list(probs, distribution_human_mean, sd_for_mean_sd),
        function(probs, mu, sd) r_hybrid(n_sim, probs, mu, sd)
      )
    ) %>%
    transmute(input_id, model_name, method = "hybrid_proportions_mean_sd", sim) %>%
    unnest_longer(sim, values_to = "y", indices_to = "draw")

  s4 <- df_model %>%
    mutate(
      sim = purrr::pmap(
        list(
          distribution_human_mean,
          distribution_human_sd,
          distribution_skewness,
          distribution_excess_kurtosis,
          distribution_shape,
          peak1_location, peak1_weight, peak2_location, peak2_weight,
          input_id, model_name
        ),
        function(mu, sd, skew, kurt, peaks, l1, w1, l2, w2, iid, mn) {
          r_full(n_sim, mu, sd, skew, kurt, peaks, l1, w1, l2, w2,
                 input_id = iid, model_name = mn)
        }
      )
    ) %>%
    transmute(input_id, model_name, method = "distribution_full", sim) %>%
    unnest_longer(sim, values_to = "y", indices_to = "draw")

  bind_rows(s1, s2, s3, s4)
}


# Generate simulated responses for each distributional method.
cat("\n── Generating simulations ──\n")

distribution_estimates_for_sims <- distribution_estimates %>%
  filter(input_id %in% scenarios_with_humans) %>%
  group_by(model_name, input_id) %>%
  slice(1) %>%
  ungroup() %>%
  left_join(
    sd_only_estimates %>%
      dplyr::select(input_id, model_name, sd_only_value),
    by = c("input_id", "model_name")
  ) %>%
  mutate(
    sd_for_mean_sd = sd_only_value
  )

scen_moment_question_values <- distribution_estimates_for_sims %>%
  transmute(model_name, input_id, target_mean = distribution_human_mean,
            Q4 = distribution_excess_kurtosis, Q5 = distribution_skewness)
scen_moment_question_summary <- scen_moment_question_values %>%
  group_by(model_name) %>%
  group_modify(~ moment_question_diagnostic(.x$target_mean, .x$Q4, .x$Q5)) %>%
  ungroup() %>%
  mutate(frame = "deduplicated human-covered simulation inputs",
         current_mapping = "Q4=excess kurtosis (Fisher); Q5=skewness",
         prompt_source = "user-supplied prompt 5 (2).docx")
write.csv(scen_moment_question_values,
          file.path(out_dir, "CHECK_moment_question_values.csv"), row.names = FALSE)
write.csv(scen_moment_question_summary,
          file.path(out_dir, "CHECK_moment_question_correlations.csv"), row.names = FALSE)
cat("\n  Q4/Q5 response diagnostic (Q4=excess kurtosis; Q5=skewness):\n")
print(as.data.frame(scen_moment_question_summary))

cat("\n── SD source check for Mean + SD / Hybrid ──\n")
distribution_estimates_for_sims %>%
  group_by(model_name) %>%
  summarise(
    n_rows = n(),
    n_with_sd_only_estimate = sum(!is.na(sd_for_mean_sd)),
    n_missing_sd_only_estimate = sum(is.na(sd_for_mean_sd)),
    .groups = "drop"
  ) %>%
  print(n = Inf)

scen_zero_sd_inputs <- bind_rows(
  distribution_estimates_for_sims %>% transmute(input_id, model_name,
    method = "distribution_mean_sd / hybrid component", mu = distribution_human_mean,
    sigma = sd_for_mean_sd, skew = NA_real_, kurt = NA_real_, shape = NA_character_),
  distribution_estimates_for_sims %>% transmute(input_id, model_name,
    method = "distribution_full", mu = distribution_human_mean,
    sigma = distribution_human_sd, skew = distribution_skewness,
    kurt = distribution_excess_kurtosis, shape = clean_distribution_shape(distribution_shape))
) %>% filter(is.finite(sigma), sigma == 0) %>%
  mutate(status = purrr::pmap_chr(list(mu, sigma, skew, kurt),
    function(mu, sigma, skew, kurt) zero_sd_status(mu, sigma, -4:4, skew, kurt)),
    status = if_else(method == "distribution_full" & !is.na(shape) & shape == "bimodal",
      "zero_sd_incompatible_bimodal_shape", status),
    handling = if_else(status == "zero_sd_point_mass", "retain exact point mass",
      "omit invalid component; Hybrid may retain its proportions component"))
write_csv(scen_zero_sd_inputs, file.path(out_dir, "CHECK_zero_sd_inputs.csv"))

model_simulation_seeds <- distribution_estimates_for_sims %>%
  distinct(model_name) %>%
  mutate(seed = purrr::map_int(model_name, model_sim_seed))
if (anyDuplicated(model_simulation_seeds$seed)) {
  stop("Two model names produce the same simulation seed; assign distinct seeds before running.")
}
write.csv(model_simulation_seeds,
          file.path(out_dir, "CHECK_model_simulation_seeds.csv"), row.names = FALSE)

distribution_model_splits <- group_split(distribution_estimates_for_sims, model_name)
sims_list <- list()
for (i in seq_along(distribution_model_splits)) sims_list[[i]] <- generate_sims(distribution_model_splits[[i]])
sims_all <- bind_rows(sims_list)

scen_moment_fallback_cells <- bind_rows(SCEN_MOMENT_FALLBACK$rows)
if (!nrow(scen_moment_fallback_cells)) scen_moment_fallback_cells <- tibble(
  input_id = character(), model_name = character(), target_mean = numeric(),
  target_sd = numeric(), target_skew = numeric(), target_kurt = numeric(), reason = character())
scen_moment_fallback_cells <- distinct(scen_moment_fallback_cells, input_id, model_name, .keep_all = TRUE)
write.csv(scen_moment_fallback_cells,
          file.path(out_dir, "CHECK_scen_moment_fitter_fallback_cells.csv"), row.names = FALSE)
a84_diag <- bind_rows(A84_DIAG$rows)
write.csv(a84_diag, file.path(out_dir, "DIAG_a84_expanded_cell_fits.csv"), row.names = FALSE)
write.csv(bind_rows(A84_DIAG$attempts),
          file.path(out_dir, "CHECK_expanded_optimizer_attempts.csv"), row.names = FALSE)
scen_expanded_status_summary <- a84_diag %>% count(model_name, fit_status, selected_start, name = "n_cells")
write.csv(scen_expanded_status_summary,
          file.path(out_dir, "CHECK_expanded_status_summary.csv"), row.names = FALSE)
cat("\nExpanded reconstruction status (Monte Carlo retained):\n")
print(scen_expanded_status_summary, n = Inf)
cat("Truncated-normal fallback cells:", nrow(scen_moment_fallback_cells), "\n")

rep_temp1_sim <- repeated_sampling_from_raw %>%
  filter(input_id %in% scenarios_with_humans) %>%
  mutate(y = clamp_scale(rating)) %>%
  dplyr::select(input_id, model_name, y)

rep500_sim <- NULL
if (!is.null(rep500)) {
  rep500_sim <- rep500 %>%
    filter(input_id %in% scenarios_with_humans) %>%
    mutate(y = clamp_scale(rating)) %>%
    dplyr::select(input_id, model_name, y)
}

if (!is.null(rep500_sim)) {
  rep500_keys <- rep500_sim %>% distinct(input_id, model_name)
  rep_fallback_used <- anti_join(
    rep_temp1_sim, rep500_keys, by = c("input_id", "model_name")
  )

  cat("\n── Repeated-sampling source check ──\n")
  cat("  500-rep rows:", nrow(rep500_sim),
      "covering", nrow(rep500_keys), "model x scenario cells\n")
  cat("  9-draw prompt-1 fallback rows contributed:", nrow(rep_fallback_used), "\n")
  if (nrow(rep_fallback_used) > 0) {
    fallback_coverage <- rep_fallback_used %>%
      count(model_name, input_id, name = "draws")
    readr::write_csv(
      fallback_coverage,
      file.path(out_dir, "CHECK_repeated_sampling_fallback_cells.csv")
    )
    stop(
      "Nine-draw prompt-1 fallback is still being used for ",
      nrow(fallback_coverage),
      " model x scenario cells; see CHECK_repeated_sampling_fallback_cells.csv."
    )
  } else {
    cat("  ✓ No fallback rows: every model x scenario cell comes from a 500-repetition file.\n")
  }

  audit_record(
    "A1 repeated sampling", "anti-join 9-draw prompt-1 fallback onto 500-rep coverage",
    rows_in = nrow(rep_temp1_sim), rows_out = nrow(rep_fallback_used),
    keys_in = n_distinct(paste(rep_temp1_sim$model_name, rep_temp1_sim$input_id)),
    keys_out = n_distinct(paste(rep_fallback_used$model_name, rep_fallback_used$input_id)),
    reason = "prompt-1 temperature-1 ratings used only where no 500-repetition file covers the cell",
    detail = "rows_out is the fallback contribution; 0 means the 500-rep files fully cover the design"
  )

  repeated_sampling_sim <- bind_rows(rep500_sim, rep_fallback_used)
} else {
  repeated_sampling_sim <- rep_temp1_sim
}

repeated_sampling_sim <- repeated_sampling_sim %>%
  group_by(input_id, model_name) %>%
  mutate(draw = row_number()) %>%
  ungroup() %>%
  mutate(method = "Repeated_sampling") %>%
  dplyr::select(input_id, model_name, method, y, draw)

sims_all <- bind_rows(sims_all, repeated_sampling_sim)

cat(
  "Total sim rows:", nrow(sims_all),
  ", Methods:", paste(unique(sims_all$method), collapse = ", "), "\n"
)

sim_props <- sims_all %>%
  mutate(y = clamp_scale(as.numeric(y))) %>%
  filter(!is.na(y)) %>%
  count(input_id, model_name, method, y, name = "n") %>%
  group_by(input_id, model_name, method) %>%
  complete(y = -4:4, fill = list(n = 0)) %>%
  mutate(sim_prop = n / sum(n)) %>%
  ungroup() %>%
  mutate(bin = factor(y, levels = -4:4)) %>%
  dplyr::select(input_id, model_name, method, bin, sim_prop)


# Integrate the bounded normal over response bins for Mean + SD. Hybrid averages those bin masses with direct probabilities.
analytic_mean_sd_bins <- function(mu, sd) {
  if (!is.finite(mu) || !is.finite(sd) || sd < 0) return(rep(NA_real_, 9))
  if (sd == 0) {
    p <- point_mass_probs(mu, -4:4)
    return(if (is.null(p)) rep(NA_real_, 9) else p)
  }
  lo <- pmax(-4, (-4:4) - 0.5)
  hi <- pmin(4, (-4:4) + 0.5)
  p <- truncnorm::ptruncnorm(hi, a = -4, b = 4, mean = mu, sd = sd) -
       truncnorm::ptruncnorm(lo, a = -4, b = 4, mean = mu, sd = sd)
  if (!all(is.finite(p)) || sum(p, na.rm = TRUE) <= 0) return(rep(NA_real_, 9))
  p / sum(p)
}

analytic_hybrid_bins <- function(probs, mu, sd, weight = HYBRID_MEAN_SD_WEIGHT) {
  probs <- normalize_bin_probabilities(probs)
  ns <- analytic_mean_sd_bins(mu, sd)
  if (all(is.na(ns))) return(probs)
  if (all(is.na(probs))) return(ns)
  blend <- weight * ns + (1 - weight) * probs
  if (!all(is.finite(blend)) || sum(blend) <= 0) return(probs)
  blend / sum(blend)
}

analytic_source <- distribution_estimates_for_sims %>%
  filter(input_id %in% scenarios_with_humans)

analytic_mean_sd_rows <- analytic_source %>%
  mutate(p = purrr::map2(distribution_human_mean, sd_for_mean_sd, analytic_mean_sd_bins)) %>%
  filter(purrr::map_lgl(p, ~ !all(is.na(.x)))) %>%
  transmute(input_id, model_name, method = "distribution_mean_sd", p) %>%
  tidyr::unnest_longer(p, values_to = "sim_prop", indices_to = "bin_idx") %>%
  mutate(bin = factor((-4:4)[bin_idx], levels = -4:4)) %>%
  dplyr::select(input_id, model_name, method, bin, sim_prop)

normal_parameter_drift <- analytic_mean_sd_rows %>%
  mutate(bin_value = as.numeric(as.character(bin))) %>% group_by(input_id, model_name) %>%
  summarise(achieved_mean = sum(bin_value * sim_prop),
    achieved_sd = sqrt(sum((bin_value - achieved_mean)^2 * sim_prop)), .groups = "drop") %>%
  left_join(analytic_source %>% select(input_id, model_name,
    parent_mean = distribution_human_mean, parent_sd = sd_for_mean_sd), by = c("input_id", "model_name")) %>%
  mutate(mean_drift = achieved_mean - parent_mean, sd_drift = achieved_sd - parent_sd,
    interpretation = "elicited values are untruncated normal parameters; bounded/discrete moments need not match")
write.csv(normal_parameter_drift, file.path(out_dir, "CHECK_mean_sd_parent_parameter_drift.csv"), row.names = FALSE)

analytic_hybrid_rows <- analytic_source %>%
  mutate(
    probs = purrr::pmap(
      list(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4),
      function(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4) {
        c(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4)
      }
    )
  ) %>%
  mutate(p = purrr::pmap(
    list(probs, distribution_human_mean, sd_for_mean_sd),
    function(bp, mu, sd) analytic_hybrid_bins(bp, mu, sd)
  )) %>%
  filter(purrr::map_lgl(p, ~ !all(is.na(.x)))) %>%
  transmute(input_id, model_name, method = "hybrid_proportions_mean_sd", p) %>%
  tidyr::unnest_longer(p, values_to = "sim_prop", indices_to = "bin_idx") %>%
  mutate(bin = factor((-4:4)[bin_idx], levels = -4:4)) %>%
  dplyr::select(input_id, model_name, method, bin, sim_prop)

# Keep the Monte Carlo versions for the robustness comparison
sim_props_mc_mean_sd_hybrid <- sim_props %>%
  filter(method %in% c("distribution_mean_sd", "hybrid_proportions_mean_sd"))

sim_props <- sim_props %>%
  filter(!method %in% c("distribution_mean_sd", "hybrid_proportions_mean_sd")) %>%
  bind_rows(analytic_mean_sd_rows, analytic_hybrid_rows)

cat("\n── Analytic conversion for Mean + SD and Hybrid ──\n")
cat("  Monte Carlo rows replaced:", nrow(sim_props_mc_mean_sd_hybrid), "\n")
cat("  Analytic rows inserted:  ",
    nrow(analytic_mean_sd_rows) + nrow(analytic_hybrid_rows), "\n")
cat("  Mean + SD cells:", n_distinct(paste(analytic_mean_sd_rows$model_name,
                                           analytic_mean_sd_rows$input_id)),
    " Hybrid cells:", n_distinct(paste(analytic_hybrid_rows$model_name,
                                       analytic_hybrid_rows$input_id)), "\n")
audit_record(
  "Analytic Mean+SD / Hybrid", "replace Monte Carlo bin estimates with closed-form probabilities",
  rows_in = nrow(sim_props_mc_mean_sd_hybrid),
  rows_out = nrow(analytic_mean_sd_rows) + nrow(analytic_hybrid_rows),
  reason = "removes Monte Carlo noise from these methods entirely rather than shrinking it; also makes Hybrid blend the actual Mean + SD distribution instead of dnorm point densities",
  detail = "truncated-normal CDF differences over the clamp_scale bin edges"
)

direct_proportions_negative_rows <- distribution_estimates %>%
  filter(
    input_id %in% scenarios_with_humans,
    !if_any(c(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4), is.na),
    if_any(c(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4), ~ .x < 0)
  )
cat("  Direct-proportions rows excluded for a negative bin probability:",
    nrow(direct_proportions_negative_rows), "\n")

direct_proportions_analytic_rows <- distribution_estimates %>%
  filter(
    input_id %in% scenarios_with_humans,
    !if_any(c(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4), is.na),
    !if_any(c(p_m4, p_m3, p_m2, p_m1, p_0, p_1, p_2, p_3, p_4), ~ .x < 0)
  ) %>%
  dplyr::select(input_id, model_name, p_m4:p_4) %>%
  pivot_longer(p_m4:p_4, names_to = "bin_name", values_to = "raw_prob") %>%
  mutate(
    bin = factor(
      recode(
        bin_name,
        "p_m4" = "-4", "p_m3" = "-3", "p_m2" = "-2", "p_m1" = "-1",
        "p_0" = "0", "p_1" = "1", "p_2" = "2", "p_3" = "3", "p_4" = "4"
      ),
      levels = -4:4
    ),
    method = "direct_proportions_analytic"
  ) %>%
  group_by(input_id, model_name, method) %>%
  mutate(
    prob_sum = sum(raw_prob, na.rm = TRUE),
    sim_prop = dplyr::if_else(is.finite(prob_sum) & prob_sum > 0,
                              raw_prob / prob_sum,
                              NA_real_)
  ) %>%
  ungroup() %>%
  filter(!is.na(sim_prop)) %>%
  dplyr::select(input_id, model_name, method, bin, sim_prop)

sim_props <- bind_rows(sim_props, direct_proportions_analytic_rows)
cat(
  "  Added direct_proportions_analytic:", nrow(direct_proportions_analytic_rows), "rows (",
  n_distinct(direct_proportions_analytic_rows$input_id), "scenarios )\n"
)

.scen_fullfit_qc <- sim_props %>%
  filter(method == "distribution_full") %>%
  group_by(model_name, input_id) %>%
  summarise(
    fit_mean = sum(as.numeric(as.character(bin)) * sim_prop),
    fit_sd = sqrt(pmax(sum(sim_prop * (as.numeric(as.character(bin)) - fit_mean)^2), 0)),
    fit_skew = ifelse(fit_sd > 0,
                      sum(sim_prop * ((as.numeric(as.character(bin)) - fit_mean) / fit_sd)^3), NA_real_),
    fit_kurt = ifelse(fit_sd > 0,
                      sum(sim_prop * ((as.numeric(as.character(bin)) - fit_mean) / fit_sd)^4) - 3, NA_real_),
    .groups = "drop"
  ) %>%
  inner_join(
    distribution_estimates %>%
      dplyr::select(model_name, input_id,
                    target_mean = distribution_human_mean,
                    target_sd = distribution_human_sd,
                    target_skew = distribution_skewness,
                    target_kurt = distribution_excess_kurtosis),
    by = c("model_name", "input_id")
  ) %>%
  mutate(resid_mean = fit_mean - target_mean,
         resid_sd = fit_sd - target_sd,
         resid_skew = fit_skew - target_skew,
         resid_kurt = fit_kurt - target_kurt)

if (nrow(.scen_fullfit_qc) > 0) {
  cat("  Moments: Expanded simulated moment residuals (include Monte Carlo variation):\n")
  print(as.data.frame(.scen_fullfit_qc %>%
    group_by(model_name) %>%
    summarise(n = n(),
              mean_p50 = stats::median(abs(resid_mean), na.rm = TRUE),
              mean_p95 = stats::quantile(abs(resid_mean), .95, na.rm = TRUE),
              sd_p50 = stats::median(abs(resid_sd), na.rm = TRUE),
              sd_p95 = stats::quantile(abs(resid_sd), .95, na.rm = TRUE),
              .groups = "drop") %>%
    mutate(across(where(is.numeric), ~ round(.x, 3)))))
  write.csv(.scen_fullfit_qc, file.path(out_dir, "CHECK_moment_fit_quality_scenarios.csv"),
            row.names = FALSE)
}


scen_exact_fit_quality <- a84_diag %>%
  mutate(resid_mean = fitted_mean - target_mean, resid_sd = fitted_sd - target_sd,
         resid_skew = fitted_skew - target_skew, resid_kurt = fitted_kurt - target_kurt)
write.csv(scen_exact_fit_quality, file.path(out_dir, "CHECK_expanded_exact_moment_quality.csv"), row.names = FALSE)

# Stated human mean (distribution prompt) versus own rating (confidence prompt),
stated_mean_pairs_all <- distribution_estimates %>%
  filter(input_id %in% scenarios_with_humans) %>%
  select(input_id, model_name, predicted_human_mean = distribution_human_mean) %>%
  inner_join(
    confidence_estimates %>%
      select(input_id, model_name, own_rating = conf_model_moral_rating),
    by = c("input_id", "model_name")
  ) %>%
  inner_join(human_stats %>% select(input_id, human_mean), by = "input_id") %>%
  filter(model_name %in% CONFIDENCE_EXPECTED_MODELS,
         is.finite(predicted_human_mean), is.finite(own_rating), is.finite(human_mean)) %>%
  mutate(
    abs_error_predicted_mean = abs(predicted_human_mean - human_mean),
    abs_error_own_rating = abs(own_rating - human_mean),
    improvement = abs_error_own_rating - abs_error_predicted_mean,
    in_expanded_fit = paste(model_name, input_id) %in%
      paste(.scen_fullfit_qc$model_name, .scen_fullfit_qc$input_id)
  )
if (anyDuplicated(stated_mean_pairs_all[c("model_name", "input_id")])) {
  stop("Stated-mean comparison contains duplicate model x scenario pairs.")
}

stated_mean_test_one <- function(d) {
  n_pairs <- nrow(d)
  diff_sd <- if (n_pairs > 1L) stats::sd(d$improvement) else NA_real_
  estimable <- n_pairs > 1L && is.finite(diff_sd) && diff_sd > 0
  tt <- if (estimable) stats::t.test(d$improvement, mu = 0) else NULL
  tibble(
    n_pairs = n_pairs,
    mae_predicted_human_mean = if (n_pairs) mean(d$abs_error_predicted_mean) else NA_real_,
    mae_own_rating = if (n_pairs) mean(d$abs_error_own_rating) else NA_real_,
    mean_improvement = if (n_pairs) mean(d$improvement) else NA_real_,
    se = if (estimable) diff_sd / sqrt(n_pairs) else NA_real_,
    t = if (estimable) unname(tt$statistic) else NA_real_,
    df = if (estimable) unname(tt$parameter) else NA_real_,
    p = if (estimable) tt$p.value else NA_real_,
    ci_low = if (estimable) unname(tt$conf.int[1]) else NA_real_,
    ci_high = if (estimable) unname(tt$conf.int[2]) else NA_real_,
    dz = if (estimable) mean(d$improvement) / diff_sd else NA_real_
  )
}

stated_mean_tests_fivemodel <- bind_rows(
  stated_mean_pairs_all %>% mutate(frame = "all_finite_pairs"),
  stated_mean_pairs_all %>% filter(in_expanded_fit) %>% mutate(frame = "expanded_fit_cells")
) %>%
  group_by(frame, model_name) %>%
  group_modify(~ stated_mean_test_one(.x)) %>%
  ungroup() %>%
  group_by(frame) %>%
  mutate(p_holm = stats::p.adjust(p, method = "holm"), n_family_tests = n()) %>%
  ungroup() %>%
  arrange(frame, model_name)

write.csv(stated_mean_pairs_all,
          file.path(out_dir, "table_stated_mean_vs_own_rating_fivemodel_by_item.csv"), row.names = FALSE)
write.csv(stated_mean_tests_fivemodel,
          file.path(out_dir, "table_stated_mean_vs_own_rating_fivemodel.csv"), row.names = FALSE)
cat("\nStated human mean versus own rating, five models (Holm within frame):\n")
print(as.data.frame(stated_mean_tests_fivemodel %>%
                      mutate(across(where(is.numeric), ~ signif(.x, 5)))), row.names = FALSE)


# Compute item-level TVD, EMD, and JSD between each model-implied distribution and the human distribution.
joined_props <- human_props %>%
  inner_join(sim_props, by = c("input_id", "bin"))

PRIMARY_PROPORTIONS_METHOD <- if (
  "direct_proportions_analytic" %in% unique(sim_props$method)
) {
  "direct_proportions_analytic"
} else {
  "direct_proportions"
}
PRIMARY_DISTRIBUTION_METHODS <- c(
  "Repeated_sampling",
  "distribution_mean_sd",
  "distribution_full",
  "hybrid_proportions_mean_sd",
  PRIMARY_PROPORTIONS_METHOD
)

dist_by_scenario <- joined_props %>%
  arrange(input_id, model_name, method, bin) %>%
  group_by(input_id, model_name, method) %>%
  summarise(
    tvd = tvd_dist(human_prop, sim_prop),
    emd = emd_1d(human_prop, sim_prop),
    jsd = jsd(human_prop, sim_prop),
    .groups = "drop"
  ) %>%
  mutate(
    scenario_type = classify_scenario(input_id),
    scenario_version = make_scenario_version(scenario_type)
  ) %>%
  filter(
    scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES,
    method %in% PRIMARY_DISTRIBUTION_METHODS
  )

.scen_entropy_diag <- list(); .scen_entropy_probs <- list()
for (.j in seq_len(nrow(a84_diag))) {
  .r <- a84_diag[.j, ]
  .a <- tryCatch(
    maxent_moment_distribution(-4:4,.r$target_mean,.r$target_sd,.r$target_skew,.r$target_kurt),
    error = function(e) list(status="maxent_exception_failed",p=NULL,
      max_moment_error=NA_real_,entropy=NA_real_,optimality_gap=NA_real_,
      failure_message=conditionMessage(e)))
  .scen_entropy_diag[[.j]] <- tibble(model_name=.r$model_name,input_id=.r$input_id,
    primary_fit_status=.r$fit_status,primary_selected_start=.r$selected_start,
    alternative_status=.a$status,max_moment_error=.a$max_moment_error,entropy=.a$entropy, entropy_optimality_gap=.a$optimality_gap,
    failure_message=if (is.null(.a$failure_message)) NA_character_ else .a$failure_message)
  .primary <- suppressWarnings(as.numeric(strsplit(if (is.na(.r$fitted)) "" else .r$fitted, ";",fixed=TRUE)[[1]]))
  if (.a$status %in% c("maximum_entropy_exact_moments","exact_point_mass") &&
      !is.null(.a$p) && length(.primary)==9L && all(is.finite(.primary))) {
    .scen_entropy_probs[[.j]] <- bind_rows(
      tibble(reconstruction="primary_fitted_probabilities",bin=factor(-4:4,levels=-4:4),p=.primary),
      tibble(reconstruction="maximum_entropy",bin=factor(-4:4,levels=-4:4),p=.a$p)) %>%
      mutate(model_name=.r$model_name,input_id=.r$input_id)
  }
}
scen_entropy_diagnostics <- bind_rows(
  tibble(model_name=character(),input_id=character(),primary_fit_status=character(),
    primary_selected_start=character(),alternative_status=character(),
    max_moment_error=double(),entropy=double(),entropy_optimality_gap=double(),
    failure_message=character()), .scen_entropy_diag)
write_csv(scen_entropy_diagnostics,file.path(out_dir,"CHECK_expanded_maxent_diagnostics_scenarios.csv"))
# Preserve the failure list and continue all primary analyses at their full coverage.
scen_entropy_failures <- scen_entropy_diagnostics %>% filter(grepl("failed$",alternative_status))
write_csv(scen_entropy_failures,file.path(out_dir,"CHECK_expanded_maxent_failed_cells_scenarios.csv"))
scen_entropy_run_status <- tibble(
  analysis="expanded_maximum_entropy_sensitivity",
  n_target_cells=nrow(scen_entropy_diagnostics),
  n_alternative_available=sum(scen_entropy_diagnostics$alternative_status %in%
    c("maximum_entropy_exact_moments","exact_point_mass")),
  n_solver_failed=nrow(scen_entropy_failures)) %>%
  mutate(n_other_unavailable=n_target_cells-n_alternative_available-n_solver_failed,
    sensitivity_status=case_when(n_alternative_available==0L ~ "unavailable",
      n_solver_failed>0L ~ "partial_solver_failures", TRUE ~ "completed_on_available_targets"))
write_csv(scen_entropy_run_status,file.path(out_dir,"CHECK_expanded_maxent_run_status_scenarios.csv"))
if (nrow(scen_entropy_failures))
  warning("Expanded maximum-entropy sensitivity: ",nrow(scen_entropy_failures),
    " failed cell(s); excluded only from this sensitivity. Primary analyses continue. ",
    "See CHECK_expanded_maxent_failed_cells_scenarios.csv.",call.=FALSE,immediate.=TRUE)
scen_entropy_coverage <- scen_entropy_diagnostics %>% group_by(model_name) %>%
  summarise(n_target_cells=n(),n_primary_repaired=sum(primary_selected_start=="exact_feasible_repair",na.rm=TRUE),
    repair_rate=n_primary_repaired/n_target_cells,
    n_alternative_available=sum(alternative_status %in% c("maximum_entropy_exact_moments","exact_point_mass")),
    n_solver_failed=sum(grepl("failed$",alternative_status)),.groups="drop") %>%
  mutate(n_other_unavailable=n_target_cells-n_alternative_available-n_solver_failed,
    sensitivity_status=case_when(n_alternative_available==0L ~ "unavailable",
      n_solver_failed>0L ~ "partial_solver_failures", TRUE ~ "completed_on_available_targets"))
write_csv(scen_entropy_coverage,file.path(out_dir,"CHECK_expanded_repair_and_maxent_coverage_scenarios.csv"))
# Typed empty exports also handle a run with no successful alternative fits.
scen_entropy_distances <- tibble(model_name=character(),input_id=character(),
  reconstruction=character(),tvd=double(),emd=double(),jsd=double())
if (length(.scen_entropy_probs)) scen_entropy_distances <- bind_rows(.scen_entropy_probs) %>%
  inner_join(human_props,by=c("input_id","bin")) %>%
  group_by(model_name,input_id,reconstruction) %>%
  summarise(tvd=tvd_dist(p,human_prop),emd=emd_1d(p,human_prop),jsd=jsd(p,human_prop),.groups="drop")
write_csv(scen_entropy_distances,file.path(out_dir,"table_expanded_reconstruction_sensitivity_cells.csv"))
.scen_entropy_keys <- scen_entropy_distances %>% distinct(model_name,input_id)
.scen_entropy_comparisons <- dist_by_scenario %>%
  semi_join(.scen_entropy_keys,by=c("model_name","input_id")) %>%
  filter(method %in% PRIMARY_DISTRIBUTION_METHODS,if_all(c(tvd,emd,jsd),is.finite)) %>%
  group_by(model_name,input_id) %>% filter(n_distinct(method)==length(PRIMARY_DISTRIBUTION_METHODS)) %>% ungroup()
scen_entropy_comparison <- bind_rows(lapply(c("primary_fitted_probabilities","maximum_entropy"),function(reconstruction_name) {
  bind_rows(.scen_entropy_comparisons %>% filter(method != "distribution_full") %>% select(model_name,input_id,method,tvd,emd,jsd),
    scen_entropy_distances %>% filter(reconstruction==reconstruction_name) %>%
      semi_join(.scen_entropy_comparisons %>% distinct(model_name,input_id),by=c("model_name","input_id")) %>%
      mutate(method="distribution_full") %>% select(model_name,input_id,method,tvd,emd,jsd)) %>%
    mutate(reconstruction=reconstruction_name)
})) %>% group_by(model_name,reconstruction,method) %>%
  summarise(n_cells=n(),across(c(tvd,emd,jsd),mean),.groups="drop") %>%
  group_by(model_name,reconstruction) %>% mutate(rank_tvd=min_rank(tvd),rank_emd=min_rank(emd),rank_jsd=min_rank(jsd)) %>% ungroup()
scen_entropy_comparison <- scen_entropy_comparison %>%
  left_join(scen_entropy_coverage %>% select(model_name,n_target_cells,
    n_alternative_available,n_solver_failed,n_other_unavailable,sensitivity_status),by="model_name")
write_csv(scen_entropy_comparison,file.path(out_dir,"table_expanded_reconstruction_sensitivity_method_comparison.csv"))

dist_summary <- dist_by_scenario %>%
  group_by(model_name, method) %>%
  summarise(
    across(c(tvd, emd, jsd), list(mean = ~ mean(.x, na.rm = TRUE))),
    n = n_distinct(input_id),
    .groups = "drop"
  ) %>%
  arrange(model_name, emd_mean)

cat("\n── Distribution Summary ──\n")
print(dist_summary, n = 80)

# Descriptive improvement over Repeated Sampling using each method's available
# primary scenarios. Positive values favor the best distributional method.
distribution_metric_means <- dist_summary %>%
  pivot_longer(c(tvd_mean, emd_mean, jsd_mean), names_to = "metric", values_to = "distance") %>%
  mutate(metric = sub("_mean$", "", metric)) %>%
  filter(is.finite(distance))
distribution_method_margins <- distribution_metric_means %>%
  filter(method != "Repeated_sampling") %>%
  arrange(model_name, metric, distance, method) %>%
  group_by(model_name, metric) %>%
  slice_head(n = 1L) %>%
  ungroup() %>%
  rename(best_distribution_method = method, best_distribution_distance = distance,
         n_best_distribution = n) %>%
  inner_join(
    distribution_metric_means %>% filter(method == "Repeated_sampling") %>%
      select(model_name, metric, repeated_sampling_distance = distance, n_repeated = n),
    by = c("model_name", "metric")
  ) %>%
  mutate(
    reduction_vs_repeated = repeated_sampling_distance - best_distribution_distance,
    comparison_basis = "each method's available primary scenarios; descriptive, not a paired test"
  )
write.csv(distribution_method_margins,
          file.path(out_dir, "table_distribution_method_margins.csv"), row.names = FALSE)

dist_by_method <- dist_by_scenario %>%
  group_by(method) %>%
  summarise(
    across(c(tvd, emd, jsd), ~ mean(.x, na.rm = TRUE)),
    n = n(),
    .groups = "drop"
  ) %>%
  arrange(emd)

cat("\n── By Method (pooled) ──\n")
print(dist_by_method)


# COVERAGE DIAGNOSTICS
qwen_parsed_items <- dist_by_scenario %>%
  filter(model_name == "qwen-3-32B", method == PRIMARY_PROPORTIONS_METHOD, !is.na(emd)) %>%
  pull(input_id) %>% unique()

qwen_all_items <- dist_by_scenario %>%
  filter(model_name == "qwen-3-32B") %>%
  pull(input_id) %>% unique()

qwen_item_flag <- tibble(input_id = qwen_all_items) %>%
  mutate(proportions_parsed = input_id %in% qwen_parsed_items)

cat("\n── Qwen coverage diagnostic (1): is the parsed subset non-random? ──\n")
cat("  Items with Qwen proportions parsed:", sum(qwen_item_flag$proportions_parsed),
    " not parsed:", sum(!qwen_item_flag$proportions_parsed), "\n")

qwen_ref_methods <- c("Repeated_sampling", "distribution_mean_sd", "distribution_full")
qwen_coverage_bias <- dist_by_scenario %>%
  filter(model_name == "qwen-3-32B", method %in% qwen_ref_methods) %>%
  inner_join(qwen_item_flag, by = "input_id") %>%
  group_by(method, proportions_parsed) %>%
  summarise(n_items = n(), mean_tvd = mean(tvd, na.rm = TRUE),
            mean_emd = mean(emd, na.rm = TRUE), mean_jsd = mean(jsd, na.rm = TRUE),
            .groups = "drop")

qwen_coverage_bias_tests <- dist_by_scenario %>%
  filter(model_name == "qwen-3-32B", method %in% qwen_ref_methods) %>%
  inner_join(qwen_item_flag, by = "input_id") %>%
  group_by(method) %>%
  group_modify(function(x, key) {
    a <- x$emd[x$proportions_parsed]; b <- x$emd[!x$proportions_parsed]
    if (length(a) < 3 || length(b) < 3) return(tibble())
    tt <- stats::t.test(a, b)
    tibble(n_parsed = length(a), n_unparsed = length(b),
           mean_emd_parsed = mean(a, na.rm = TRUE),
           mean_emd_unparsed = mean(b, na.rm = TRUE),
           mean_diff = mean(a, na.rm = TRUE) - mean(b, na.rm = TRUE),
           ci_low = tt$conf.int[1], ci_high = tt$conf.int[2],
           t = unname(tt$statistic), df = unname(tt$parameter), p_raw = tt$p.value,
           d = cohen_d_ind(a, b))
  }) %>%
  ungroup() %>%
  mutate(p_holm = stats::p.adjust(p_raw, method = "holm"))

qwen_coverage_human <- qwen_item_flag %>%
  inner_join(human_stats %>% dplyr::select(input_id, human_sd), by = "input_id") %>%
  left_join(human_confuse_means %>% dplyr::select(input_id, mean_confusion), by = "input_id")

qwen_coverage_human_tests <- bind_rows(
  local({
    a <- qwen_coverage_human$human_sd[qwen_coverage_human$proportions_parsed]
    b <- qwen_coverage_human$human_sd[!qwen_coverage_human$proportions_parsed]
    tt <- stats::t.test(a, b)
    tibble(outcome = "human_sd", n_parsed = sum(!is.na(a)), n_unparsed = sum(!is.na(b)),
           mean_parsed = mean(a, na.rm = TRUE), mean_unparsed = mean(b, na.rm = TRUE),
           mean_diff = mean(a, na.rm = TRUE) - mean(b, na.rm = TRUE),
           ci_low = tt$conf.int[1], ci_high = tt$conf.int[2],
           t = unname(tt$statistic), df = unname(tt$parameter), p_raw = tt$p.value,
           d = cohen_d_ind(a, b))
  }),
  local({
    a <- qwen_coverage_human$mean_confusion[qwen_coverage_human$proportions_parsed]
    b <- qwen_coverage_human$mean_confusion[!qwen_coverage_human$proportions_parsed]
    tt <- stats::t.test(a, b)
    tibble(outcome = "mean_confusion", n_parsed = sum(!is.na(a)), n_unparsed = sum(!is.na(b)),
           mean_parsed = mean(a, na.rm = TRUE), mean_unparsed = mean(b, na.rm = TRUE),
           mean_diff = mean(a, na.rm = TRUE) - mean(b, na.rm = TRUE),
           ci_low = tt$conf.int[1], ci_high = tt$conf.int[2],
           t = unname(tt$statistic), df = unname(tt$parameter), p_raw = tt$p.value,
           d = cohen_d_ind(a, b))
  })
) %>%
  mutate(p_holm = stats::p.adjust(p_raw, method = "holm"))

write.csv(qwen_coverage_bias, file.path(out_dir, "table_qwen_coverage_bias_by_method.csv"), row.names = FALSE)
write.csv(qwen_coverage_bias_tests, file.path(out_dir, "table_qwen_coverage_bias_tests.csv"), row.names = FALSE)
write.csv(qwen_coverage_human_tests, file.path(out_dir, "table_qwen_coverage_human_tests.csv"), row.names = FALSE)

cat("\n  Full-coverage Qwen methods on parsed vs unparsed items:\n")
print(as.data.frame(qwen_coverage_bias %>% mutate(across(where(is.numeric), ~ round(.x, 4)))))
cat("\n  Tests (EMD, parsed minus unparsed), Holm within this block:\n")
print(as.data.frame(qwen_coverage_bias_tests %>% mutate(across(where(is.numeric), ~ round(.x, 4)))))
cat("\n  Human side, same two item sets:\n")
print(as.data.frame(qwen_coverage_human_tests %>% mutate(across(where(is.numeric), ~ round(.x, 4)))))

audit_record(
  "Qwen coverage diagnostic", "compare parsed vs unparsed item sets within Qwen",
  rows_in = length(qwen_all_items), rows_out = length(qwen_parsed_items),
  reason = "tests whether Qwen's direct-proportions coverage is non-random rather than dropping the model",
  detail = paste0(sum(qwen_coverage_bias_tests$p_holm < .05, na.rm = TRUE),
                  " of ", nrow(qwen_coverage_bias_tests),
                  " full-coverage methods differ across the two item sets")
)


#Common matched item set across all models and methods.
matched_items_all <- dist_by_scenario %>%
  filter(!is.na(tvd), !is.na(emd), !is.na(jsd)) %>%
  distinct(input_id, model_name, method) %>%
  count(input_id, name = "n_cells") %>%
  filter(n_cells == n_distinct(dist_by_scenario$model_name) *
                    n_distinct(dist_by_scenario$method)) %>%
  pull(input_id)

cat("\n── Qwen coverage diagnostic (2): common matched item set ──\n")
cat("  Items where EVERY model x method produced usable output:",
    length(matched_items_all), "of", n_distinct(dist_by_scenario$input_id), "\n")

dist_by_method_matched <- dist_by_scenario %>%
  filter(input_id %in% matched_items_all) %>%
  group_by(method) %>%
  summarise(across(c(tvd, emd, jsd), ~ mean(.x, na.rm = TRUE)),
            n = n(), n_items = n_distinct(input_id), .groups = "drop") %>%
  mutate(rank_tvd = rank(tvd), rank_emd = rank(emd), rank_jsd = rank(jsd),
         basis = "Matched items (primary)") %>%
  arrange(tvd)

dist_by_method_fullcov <- dist_by_method %>%
  mutate(n_items = NA_integer_,
         rank_tvd = rank(tvd), rank_emd = rank(emd), rank_jsd = rank(jsd),
         basis = "Full coverage (secondary)")

dist_by_method_matched_vs_full <- bind_rows(
  dist_by_method_matched,
  dist_by_method_fullcov %>% dplyr::select(any_of(names(dist_by_method_matched)))
)

write.csv(dist_by_method_matched_vs_full,
          file.path(out_dir, "table_dist_by_method_matched_vs_full_coverage.csv"),
          row.names = FALSE)

cat("\n  Pooled method metrics on MATCHED items (primary):\n")
print(as.data.frame(dist_by_method_matched %>% mutate(across(where(is.numeric), ~ round(.x, 4)))))

matched_rank_shift <- dist_by_method_matched_vs_full %>%
  dplyr::select(basis, method, rank_tvd, rank_emd, rank_jsd) %>%
  tidyr::pivot_longer(starts_with("rank_"), names_to = "metric", values_to = "rank") %>%
  tidyr::pivot_wider(names_from = basis, values_from = rank) %>%
  mutate(rank_changed = `Matched items (primary)` != `Full coverage (secondary)`)

cat("\n  Ranking positions differing between matched and full-coverage bases:",
    sum(matched_rank_shift$rank_changed, na.rm = TRUE), "of", nrow(matched_rank_shift), "\n")
if (any(matched_rank_shift$rank_changed, na.rm = TRUE)) {
  print(as.data.frame(matched_rank_shift %>% filter(rank_changed)))
}

audit_record(
  "Matched item set", "restrict pooled method metrics to items usable for every model x method",
  rows_in = n_distinct(dist_by_scenario$input_id), rows_out = length(matched_items_all),
  reason = "removes coverage differences as a driver of pooled method ranks for all models",
  detail = paste0(sum(matched_rank_shift$rank_changed, na.rm = TRUE), " rank positions differ from full coverage")
)


# Per-model ranks
dist_ranks_by_model <- dist_by_scenario %>%
  filter(input_id %in% matched_items_all) %>%
  group_by(model_name, method) %>%
  summarise(across(c(tvd, emd, jsd), ~ mean(.x, na.rm = TRUE)),
            n_items = n_distinct(input_id), .groups = "drop") %>%
  group_by(model_name) %>%
  mutate(rank_tvd = rank(tvd), rank_emd = rank(emd), rank_jsd = rank(jsd)) %>%
  ungroup() %>%
  arrange(model_name, emd)

write.csv(dist_ranks_by_model,
          file.path(out_dir, "table_dist_ranks_by_model_matched.csv"), row.names = FALSE)

cat("\n── Qwen coverage diagnostic (3): per-model EMD ranks on matched items ──\n")
print(as.data.frame(
  dist_ranks_by_model %>%
    dplyr::select(model_name, method, emd, rank_emd) %>%
    mutate(emd = round(emd, 4)) %>%
    arrange(model_name, rank_emd)
))

prop_vs_rep <- dist_ranks_by_model %>%
  filter(method %in% c("direct_proportions", "direct_proportions_analytic", "Repeated_sampling")) %>%
  dplyr::select(model_name, method, emd) %>%
  tidyr::pivot_wider(names_from = method, values_from = emd) %>%
  mutate(
    proportions_worse_than_repeated =
      direct_proportions_analytic > Repeated_sampling
  )
cat("\n  Per model: is direct proportions WORSE than repeated sampling on EMD?\n")
print(as.data.frame(prop_vs_rep %>% mutate(across(where(is.numeric), ~ round(.x, 4)))))



# Pooled method ranking with and without Qwen (retained as a secondary check)
dist_by_method_rankings <- bind_rows(
  dist_by_scenario %>% mutate(subset = "All models"),
  dist_by_scenario %>% filter(model_name != "qwen-3-32B") %>% mutate(subset = "Excluding Qwen")
) %>%
  group_by(subset, method) %>%
  summarise(across(c(tvd, emd, jsd), ~ mean(.x, na.rm = TRUE)),
            n = n(), n_items = n_distinct(input_id), .groups = "drop") %>%
  group_by(subset) %>%
  mutate(rank_tvd = rank(tvd), rank_emd = rank(emd), rank_jsd = rank(jsd)) %>%
  ungroup() %>%
  arrange(subset, tvd)

write.csv(dist_by_method_rankings,
          file.path(out_dir, "table_dist_by_method_with_without_qwen.csv"),
          row.names = FALSE)

cat("\n── By Method: all models vs excluding Qwen (available cells) ──\n")
print(as.data.frame(
  dist_by_method_rankings %>%
    mutate(across(c(tvd, emd, jsd), ~ round(.x, 4)))
))

e_rank_shift <- dist_by_method_rankings %>%
  dplyr::select(subset, method, rank_tvd, rank_emd, rank_jsd) %>%
  tidyr::pivot_longer(starts_with("rank_"), names_to = "metric", values_to = "rank") %>%
  tidyr::pivot_wider(names_from = subset, values_from = rank) %>%
  mutate(rank_changed = `All models` != `Excluding Qwen`)

cat("\n  Method-ranking positions that change when Qwen is dropped:",
    sum(e_rank_shift$rank_changed, na.rm = TRUE), "of", nrow(e_rank_shift), "\n")
if (any(e_rank_shift$rank_changed, na.rm = TRUE)) {
  print(as.data.frame(e_rank_shift %>% filter(rank_changed)))
} else {
  cat("  ✓ Ordering is identical on all three metrics with and without Qwen.\n")
}

audit_record(
  "Qwen coverage sensitivity", "recompute pooled method table excluding Qwen",
  rows_in = nrow(dist_by_scenario),
  rows_out = sum(dist_by_scenario$model_name != "qwen-3-32B"),
  reason = "Qwen retains only 73 of 144 items in the matched comparison; pooled ranking should not silently depend on it",
  detail = paste0(sum(e_rank_shift$rank_changed, na.rm = TRUE), " ranking positions change")
)


# Robustness check: analytic (primary) versus Monte Carlo for Mean + SD and Hybrid

mc_dist_by_scenario <- human_props %>%
  inner_join(sim_props_mc_mean_sd_hybrid, by = c("input_id", "bin")) %>%
  arrange(input_id, model_name, method, bin) %>%
  group_by(input_id, model_name, method) %>%
  summarise(
    tvd = tvd_dist(human_prop, sim_prop),
    emd = emd_1d(human_prop, sim_prop),
    jsd = jsd(human_prop, sim_prop),
    .groups = "drop"
  ) %>%
  mutate(scenario_type = classify_scenario(input_id)) %>%
  filter(scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES)

analytic_vs_mc <- bind_rows(
  dist_by_scenario %>%
    filter(method %in% c("distribution_mean_sd", "hybrid_proportions_mean_sd")) %>%
    mutate(estimator = "analytic"),
  mc_dist_by_scenario %>% mutate(estimator = "monte_carlo")
) %>%
  group_by(model_name, method, estimator) %>%
  summarise(across(c(tvd, emd, jsd), ~ mean(.x, na.rm = TRUE)),
            n = n_distinct(input_id), .groups = "drop") %>%
  tidyr::pivot_wider(names_from = estimator, values_from = c(tvd, emd, jsd, n)) %>%
  mutate(
    delta_tvd = tvd_analytic - tvd_monte_carlo,
    delta_emd = emd_analytic - emd_monte_carlo,
    delta_jsd = jsd_analytic - jsd_monte_carlo
  ) %>%
  arrange(method, model_name)

write.csv(analytic_vs_mc,
          file.path(out_dir, "table_analytic_vs_monte_carlo_mean_sd_hybrid.csv"),
          row.names = FALSE)

cat("\n── Analytic (primary) vs Monte Carlo (robustness), Mean + SD and Hybrid ──\n")
print(as.data.frame(
  analytic_vs_mc %>%
    dplyr::select(model_name, method, tvd_analytic, tvd_monte_carlo, delta_tvd,
                  delta_emd, delta_jsd, n_analytic) %>%
    mutate(across(where(is.numeric), ~ round(.x, 5)))
))

dist_by_type <- dist_by_scenario %>%
  group_by(model_name, method, scenario_type) %>%
  summarise(
    mean_TVD = mean(tvd, na.rm = TRUE),
    mean_EMD = mean(emd, na.rm = TRUE),
    n = n(),
    .groups = "drop"
  ) %>%
  arrange(model_name, method, scenario_type)

cat("\n── By Scenario Type ──\n")
print(dist_by_type, n = Inf, width = Inf)


writeup_models_focal <- c(
  "gpt-35-turbo_1106",
  "gpt-4o-mini_2024-07-18",
  "gpt-5-chat_2025-08-07",
  "gpt-oss-20b",
  "qwen-3-32B"
)

model_labels <- c(
  "gpt-35-turbo_1106"      = "GPT-3.5",
  "gpt-4o-mini_2024-07-18" = "GPT-4o-mini",
  "gpt-5-chat_2025-08-07"  = "GPT-5",
  "gpt-oss-20b"            = "GPT-OSS-20B",
  "qwen-3-32B"             = "Qwen-3-32B"
)

focal_distribution_methods <- PRIMARY_DISTRIBUTION_METHODS

distribution_method_labels <- c(
  "Repeated_sampling"    = "Repeated sampling",
  "distribution_mean_sd" = "Mean + SD",
  "distribution_full"    = "Moments: Expanded",
  "hybrid_proportions_mean_sd"    = "Hybrid Proportions + Moments",
  "direct_proportions_analytic"      = "Proportions",
  "direct_proportions"             = "Proportions"
)

scenario_version_labels <- c("old" = "Original", "new" = "Reworded")
relabel_scenario_version <- function(df) {
  if ("scenario_version" %in% names(df)) {
    df$scenario_version <- dplyr::recode(as.character(df$scenario_version),
                                         !!!scenario_version_labels)
  }
  df
}

present_paper_focal_pooled_distribution_methods <- dist_by_scenario %>%
  filter(
    model_name %in% writeup_models_focal,
    method %in% focal_distribution_methods,
    scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES
  ) %>%
  mutate(
    method_label = recode(method, !!!distribution_method_labels, .default = method)
  ) %>%
  group_by(method_label) %>%
  summarise(
    TVD = mean(tvd, na.rm = TRUE),
    EMD = mean(emd, na.rm = TRUE),
    JSD = mean(jsd, na.rm = TRUE),
    n_model_scenarios = n(),
    n_unique_scenarios = n_distinct(input_id),
    n_models = n_distinct(model_name),
    .groups = "drop"
  ) %>%
  mutate(
    best_TVD = TVD == min(TVD, na.rm = TRUE),
    best_EMD = EMD == min(EMD, na.rm = TRUE),
    best_JSD = JSD == min(JSD, na.rm = TRUE)
  ) %>%
  arrange(EMD)

cat("
── PRESENT PAPER scenarios only: focal-model distribution methods pooled across old + new ──
")
print(
  present_paper_focal_pooled_distribution_methods %>%
    mutate(across(c(TVD, EMD, JSD), ~ round(.x, 3))),
  n = Inf,
  width = Inf
)

present_paper_focal_old_new_methods <- dist_by_scenario %>%
  filter(
    model_name %in% writeup_models_focal,
    method %in% focal_distribution_methods,
    scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES
  ) %>%
  mutate(
    scenario_version = factor(scenario_version, levels = c("old", "new")),
    model_label = recode(model_name, !!!model_labels, .default = model_name),
    method_label = recode(method, !!!distribution_method_labels, .default = method)
  ) %>%
  group_by(scenario_version, method_label) %>%
  summarise(
    TVD = mean(tvd, na.rm = TRUE),
    EMD = mean(emd, na.rm = TRUE),
    JSD = mean(jsd, na.rm = TRUE),
    n_model_scenarios = n(),
    n_unique_scenarios = n_distinct(input_id),
    n_models = n_distinct(model_name),
    .groups = "drop"
  ) %>%
  group_by(scenario_version) %>%
  mutate(
    best_TVD = TVD == min(TVD, na.rm = TRUE),
    best_EMD = EMD == min(EMD, na.rm = TRUE),
    best_JSD = JSD == min(JSD, na.rm = TRUE)
  ) %>%
  ungroup() %>%
  arrange(scenario_version, EMD)

cat("\n── PRESENT PAPER scenarios only: focal-model distribution methods, old vs new ──\n")
print(
  present_paper_focal_old_new_methods %>%
    mutate(across(c(TVD, EMD, JSD), ~ round(.x, 3))),
  n = Inf,
  width = Inf
)

present_paper_focal_old_new_methods_paper <- present_paper_focal_old_new_methods %>%
  mutate(
    TVD = round(TVD, 3),
    EMD = round(EMD, 3),
    JSD = round(JSD, 3),
    best_by = purrr::pmap_chr(
      list(best_TVD, best_EMD, best_JSD),
      function(is_tvd, is_emd, is_jsd) {
        paste(
          c(
            if (isTRUE(is_tvd)) "TVD",
            if (isTRUE(is_emd)) "EMD",
            if (isTRUE(is_jsd)) "JSD"
          ),
          collapse = ", "
        )
      }
    )
  ) %>%
  dplyr::select(
    scenario_version,
    method = method_label,
    TVD,
    EMD,
    JSD,
    n_unique_scenarios,
    n_models,
    best_by
  )

cat("\n── Paper-ready table: PRESENT PAPER scenarios only, old vs new ──\n")
print(present_paper_focal_old_new_methods_paper, n = Inf, width = Inf)

present_paper_focal_old_new_best <- present_paper_focal_old_new_methods %>%
  group_by(scenario_version) %>%
  summarise(
    best_TVD_method = method_label[which.min(TVD)],
    best_TVD = min(TVD, na.rm = TRUE),
    best_EMD_method = method_label[which.min(EMD)],
    best_EMD = min(EMD, na.rm = TRUE),
    best_JSD_method = method_label[which.min(JSD)],
    best_JSD = min(JSD, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(across(c(best_TVD, best_EMD, best_JSD), ~ round(.x, 3)))

cat("\n── Best distribution methods: PRESENT PAPER scenarios only, old vs new ──\n")
print(present_paper_focal_old_new_best, n = Inf, width = Inf)

present_paper_focal_old_new_by_model <- dist_by_scenario %>%
  filter(
    model_name %in% writeup_models_focal,
    method %in% focal_distribution_methods,
    scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES
  ) %>%
  mutate(
    scenario_version = factor(scenario_version, levels = c("old", "new")),
    model_label = recode(model_name, !!!model_labels, .default = model_name),
    method_label = recode(method, !!!distribution_method_labels, .default = method)
  ) %>%
  group_by(model_label, scenario_version, method_label) %>%
  summarise(
    TVD = mean(tvd, na.rm = TRUE),
    EMD = mean(emd, na.rm = TRUE),
    JSD = mean(jsd, na.rm = TRUE),
    n_scenarios = n_distinct(input_id),
    .groups = "drop"
  ) %>%
  group_by(model_label, scenario_version) %>%
  mutate(
    best_TVD = TVD == min(TVD, na.rm = TRUE),
    best_EMD = EMD == min(EMD, na.rm = TRUE),
    best_JSD = JSD == min(JSD, na.rm = TRUE)
  ) %>%
  ungroup() %>%
  arrange(model_label, scenario_version, EMD)

cat("\n── PRESENT PAPER scenarios only: distribution methods by focal model and old/new ──\n")
print(
  present_paper_focal_old_new_by_model %>%
    mutate(across(c(TVD, EMD, JSD), ~ round(.x, 3))),
  n = Inf,
  width = Inf
)

present_paper_focal_best_emd_by_model <- present_paper_focal_old_new_by_model %>%
  group_by(model_label, scenario_version) %>%
  slice_min(order_by = EMD, n = 1, with_ties = FALSE) %>%
  ungroup() %>%
  transmute(
    model_label,
    scenario_version,
    best_EMD_method = method_label,
    best_EMD = round(EMD, 3),
    TVD = round(TVD, 3),
    JSD = round(JSD, 3),
    n_scenarios
  ) %>%
  arrange(model_label, scenario_version)

cat("\n── Best EMD method by focal model: OUR old vs new scenarios ──\n")
print(present_paper_focal_best_emd_by_model, n = Inf, width = Inf)


save_figure_pdf_checked <- function(filename, plot, width, height, diagnostic_path, prefer_cairo = TRUE) {
  pdf_complete <- function(path) {
    tryCatch({
      size <- file.info(path)$size
      if (is.na(size) || size < 1000) return(FALSE)
      con <- file(path, "rb"); on.exit(close(con))
      header <- rawToChar(readBin(con, "raw", n = 5L))
      seek(con, where = max(0, size - 64), origin = "start")
      tail <- readBin(con, "raw", n = 64L)
      identical(header, "%PDF-") && any(vapply(seq_len(max(0L, length(tail) - 4L)),
        function(i) identical(tail[i:(i + 4L)], charToRaw("%%EOF")), logical(1)))
    }, error = function(e) FALSE)
  }
  attempts <- list(); created <- FALSE
  for (device_name in if (prefer_cairo) c("cairo_pdf", "pdf") else "pdf") {
    temporary <- tempfile(pattern = ".figure_pdf_", tmpdir = dirname(filename), fileext = ".pdf")
    warnings_seen <- character(); failure <- ""
    devices_before <- grDevices::dev.list()
    tryCatch(withCallingHandlers({
      if (device_name == "cairo_pdf") {
        if (!isTRUE(capabilities("cairo"))) stop("Cairo capability is unavailable")
        ggsave(filename = temporary, plot = plot, width = width, height = height,
          device = grDevices::cairo_pdf)
      } else {
        ggsave(filename = temporary, plot = plot, width = width, height = height,
          device = grDevices::pdf, useDingbats = FALSE)
      }
    }, warning = function(w) {
      warnings_seen <<- c(warnings_seen, conditionMessage(w))
      invokeRestart("muffleWarning")
    }), error = function(e) { failure <<- conditionMessage(e) })
    # Close only devices opened by this attempt, including an interrupted save.
    for (device_id in setdiff(grDevices::dev.list(), devices_before))
      try(grDevices::dev.off(device_id), silent = TRUE)
    valid <- !nzchar(failure) && pdf_complete(temporary)
    if (!valid && !nzchar(failure)) failure <- "No complete nonempty PDF was produced"
    if (valid) {
      tryCatch({
        if (!file.copy(temporary, filename, overwrite = TRUE)) stop("Could not save the validated PDF")
        if (!pdf_complete(filename) ||
            !identical(unname(tools::md5sum(temporary)), unname(tools::md5sum(filename))))
          stop("Saved PDF did not match the validated temporary PDF")
        created <- TRUE
      }, error = function(e) { failure <<- conditionMessage(e) })
    }
    attempts[[length(attempts) + 1L]] <- data.frame(
      file = basename(filename), device = device_name,
      status = if (created) "created_and_checked" else "failed",
      bytes = if (created) file.info(filename)$size else NA_real_,
      error = failure, warnings = paste(unique(warnings_seen), collapse = " | "),
      stringsAsFactors = FALSE)
    unlink(temporary)
    if (created) break
  }
  diagnostics <- do.call(rbind, attempts)
  diagnostics$created_this_call <- created
  tryCatch(write.csv(diagnostics, diagnostic_path, row.names = FALSE),
    error = function(e) message("PDF diagnostic could not be saved: ", conditionMessage(e)))
  if (created) {
    message("PDF saved and checked (", device_name, "): ", filename)
    if (nrow(diagnostics) > 1L) message("Cairo failed; used the standard R PDF device. See ", diagnostic_path)
    if (any(nzchar(diagnostics$warnings))) message("PDF device warnings were recorded in ", diagnostic_path)
  } else {
    message("WARNING: PDF export failed; PNG export and analyses continue. Any existing PDF is stale. See ", diagnostic_path)
    message(paste(diagnostics$device, diagnostics$error, sep = ": ", collapse = "\n"))
  }
  invisible(created)
}

welch_compare <- function(dat, outcome, g1, g2) {
  x <- dat %>% filter(scenario_type == g1) %>% pull({{ outcome }})
  y <- dat %>% filter(scenario_type == g2) %>% pull({{ outcome }})
  tt <- t.test(x, y)
  tibble(
    outcome = rlang::as_name(rlang::ensym(outcome)),
    comparison = paste(g1, "vs", g2),
    mean_g1 = mean(x, na.rm = TRUE),
    mean_g2 = mean(y, na.rm = TRUE),
    t = unname(tt$statistic),
    df = unname(tt$parameter),
    p = tt$p.value,
    ci_low = tt$conf.int[1],
    ci_high = tt$conf.int[2],
    d = cohen_d_ind(x, y),
    n_g1 = sum(!is.na(x)),
    n_g2 = sum(!is.na(y))
  )
}


# Human-rated confusion by scenario source and version.
confuse_by_type <- human_confuse_means %>%
  mutate(
    scenario_type = classify_scenario(input_id),
    scenario_version = make_scenario_version(scenario_type),
    scenario_source = case_when(
      scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES ~ "present_paper",
      scenario_type %in% SCHROEDER_SCENARIO_TYPES ~ "Schroeder",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(scenario_type %in% WORDING_SCENARIO_TYPES)

shared_present_paper_old_ids <- schroeder_to_present_paper_old_map$present_paper_id
confuse_by_type_no_shared_present_paper_dup <- confuse_by_type %>%
  filter(!(scenario_type == "present_paper_old" & input_id %in% shared_present_paper_old_ids))

cat("\n── Confusion by scenario type: present_paper + Schroeder ──\n")
wording_confusion_summary <- confuse_by_type %>%
  group_by(scenario_type, scenario_source, scenario_version) %>%
  summarise(
    avg_confusion = mean(mean_confusion, na.rm = TRUE),
    sd_avg_confusion = sd(mean_confusion, na.rm = TRUE),
    n_scenarios = n(),
    .groups = "drop"
  ) %>%
  arrange(scenario_source, scenario_version, scenario_type)
print(wording_confusion_summary, n = Inf, width = Inf)

cat("\n── Planned pairwise tests: confusion ──\n")
wording_confusion_pairwise <- bind_rows(
  welch_compare(confuse_by_type, mean_confusion, "Schroeder_new", "present_paper_new"),
  welch_compare(confuse_by_type, mean_confusion, "Schroeder_new", "present_paper_old"),
  welch_compare(confuse_by_type, mean_confusion, "Schroeder_new", "Schroeder_old")
) %>%
  mutate(p_holm = p.adjust(p, method = "holm"))
print(wording_confusion_pairwise, n = Inf, width = Inf)

confuse_paired_schroeder <- confuse_by_type %>%
  filter(scenario_type %in% SCHROEDER_SCENARIO_TYPES) %>%
  mutate(
    base = str_replace(input_id, "^Schroeder_(new|old)_", ""),
    cond = ifelse(str_detect(input_id, "Schroeder_new_"), "new", "old")
  ) %>%
  dplyr::select(base, cond, mean_confusion) %>%
  pivot_wider(names_from = cond, values_from = mean_confusion) %>%
  filter(!is.na(new) & !is.na(old))

if (nrow(confuse_paired_schroeder) > 2) {
  tp_confuse_schroeder <- t.test(confuse_paired_schroeder$new,
                              confuse_paired_schroeder$old,
                              paired = TRUE)
  d_confuse_schroeder <- cohen_d_paired(confuse_paired_schroeder$new,
                                     confuse_paired_schroeder$old)
  wording_confusion_paired_schroeder <- tibble(
    outcome = "mean_confusion",
    comparison = "Schroeder_new vs Schroeder_old, paired",
    mean_new = mean(confuse_paired_schroeder$new, na.rm = TRUE),
    mean_old = mean(confuse_paired_schroeder$old, na.rm = TRUE),
    mean_diff_new_minus_old = mean(confuse_paired_schroeder$new - confuse_paired_schroeder$old, na.rm = TRUE),
    t = unname(tp_confuse_schroeder$statistic),
    df = unname(tp_confuse_schroeder$parameter),
    p = tp_confuse_schroeder$p.value,
    ci_low = tp_confuse_schroeder$conf.int[1],
    ci_high = tp_confuse_schroeder$conf.int[2],
    dz = d_confuse_schroeder,
    n_pairs = nrow(confuse_paired_schroeder)
  )
  cat("\nPaired Schroeder confusion, new vs old:\n")
  print(wording_confusion_paired_schroeder, n = Inf, width = Inf)
}

present_paper_c <- confuse_by_type %>%
  filter(scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES) %>%
  pull(mean_confusion)
schroeder_c <- confuse_by_type %>%
  filter(scenario_type %in% SCHROEDER_SCENARIO_TYPES) %>%
  pull(mean_confusion)
if (length(present_paper_c) > 2 && length(schroeder_c) > 2) {
  tp_confuse_present_paper_schroeder <- t.test(schroeder_c, present_paper_c)
  wording_confusion_collapsed <- tibble(
    outcome = "mean_confusion",
    comparison = "Schroeder vs present_paper, collapsed old/new",
    mean_present_paper = mean(present_paper_c, na.rm = TRUE),
    mean_Schroeder = mean(schroeder_c, na.rm = TRUE),
    t = unname(tp_confuse_present_paper_schroeder$statistic),
    df = unname(tp_confuse_present_paper_schroeder$parameter),
    p = tp_confuse_present_paper_schroeder$p.value,
    ci_low = tp_confuse_present_paper_schroeder$conf.int[1],
    ci_high = tp_confuse_present_paper_schroeder$conf.int[2],
    d_Schroeder_minus_present_paper = cohen_d_ind(schroeder_c, present_paper_c),
    n_present_paper = sum(!is.na(present_paper_c)),
    n_Schroeder = sum(!is.na(schroeder_c))
  )
  cat("\nCollapsed Schroeder vs present_paper confusion:\n")
  print(wording_confusion_collapsed, n = Inf, width = Inf)
}

wording_confusion_pairwise_no_shared_present_paper_dup <- bind_rows(
  welch_compare(confuse_by_type_no_shared_present_paper_dup, mean_confusion, "Schroeder_new", "present_paper_new"),
  welch_compare(confuse_by_type_no_shared_present_paper_dup, mean_confusion, "Schroeder_new", "present_paper_old"),
  welch_compare(confuse_by_type_no_shared_present_paper_dup, mean_confusion, "Schroeder_new", "Schroeder_old")
) %>%
  mutate(p_holm = p.adjust(p, method = "holm"))
cat("
Sensitivity pairwise confusion tests excluding copied present_paper_old duplicates:
")
print(wording_confusion_pairwise_no_shared_present_paper_dup, n = Inf, width = Inf)

present_paper_c_no_shared <- confuse_by_type_no_shared_present_paper_dup %>%
  filter(scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES) %>%
  pull(mean_confusion)
schroeder_c_no_shared <- confuse_by_type_no_shared_present_paper_dup %>%
  filter(scenario_type %in% SCHROEDER_SCENARIO_TYPES) %>%
  pull(mean_confusion)
if (length(present_paper_c_no_shared) > 2 && length(schroeder_c_no_shared) > 2) {
  tp_confuse_present_paper_schroeder_no_shared <- t.test(schroeder_c_no_shared, present_paper_c_no_shared)
  wording_confusion_collapsed_no_shared_present_paper_dup <- tibble(
    outcome = "mean_confusion",
    comparison = "Schroeder vs present_paper, collapsed old/new, excluding copied present_paper_old duplicates",
    mean_present_paper = mean(present_paper_c_no_shared, na.rm = TRUE),
    mean_Schroeder = mean(schroeder_c_no_shared, na.rm = TRUE),
    t = unname(tp_confuse_present_paper_schroeder_no_shared$statistic),
    df = unname(tp_confuse_present_paper_schroeder_no_shared$parameter),
    p = tp_confuse_present_paper_schroeder_no_shared$p.value,
    ci_low = tp_confuse_present_paper_schroeder_no_shared$conf.int[1],
    ci_high = tp_confuse_present_paper_schroeder_no_shared$conf.int[2],
    d_Schroeder_minus_present_paper = cohen_d_ind(schroeder_c_no_shared, present_paper_c_no_shared),
    n_present_paper = sum(!is.na(present_paper_c_no_shared)),
    n_Schroeder = sum(!is.na(schroeder_c_no_shared))
  )
  cat("
Sensitivity collapsed Schroeder vs present_paper confusion excluding copied present_paper_old duplicates:
")
  print(wording_confusion_collapsed_no_shared_present_paper_dup, n = Inf, width = Inf)
}

confuse_paired_present_paper <- confuse_by_type %>%
  filter(scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES) %>%
  mutate(
    base = str_replace(input_id, "_(new|old)$", ""),
    cond = str_extract(input_id, "(new|old)$")
  ) %>%
  dplyr::select(base, cond, mean_confusion) %>%
  pivot_wider(names_from = cond, values_from = mean_confusion) %>%
  filter(!is.na(new) & !is.na(old))

if (nrow(confuse_paired_present_paper) > 2) {
  tp_confuse_present_paper <- t.test(
    confuse_paired_present_paper$new,
    confuse_paired_present_paper$old,
    paired = TRUE
  )

  wording_confusion_paired_present_paper <- tibble(
    outcome = "mean_confusion",
    comparison = "present_paper_new vs present_paper_old, paired",
    mean_new = mean(confuse_paired_present_paper$new, na.rm = TRUE),
    mean_old = mean(confuse_paired_present_paper$old, na.rm = TRUE),
    mean_diff_new_minus_old = mean(confuse_paired_present_paper$new - confuse_paired_present_paper$old, na.rm = TRUE),
    t = unname(tp_confuse_present_paper$statistic),
    df = unname(tp_confuse_present_paper$parameter),
    p = tp_confuse_present_paper$p.value,
    ci_low = tp_confuse_present_paper$conf.int[1],
    ci_high = tp_confuse_present_paper$conf.int[2],
    dz = cohen_d_paired(confuse_paired_present_paper$new, confuse_paired_present_paper$old),
    n_pairs = nrow(confuse_paired_present_paper)
  )

  cat("\nPaired present_paper confusion, new vs old:\n")
  print(wording_confusion_paired_present_paper, n = Inf, width = Inf)
}


# Empirical human response variability by scenario source and version.
sd_by_type <- human_stats %>%
  filter(scenario_type %in% WORDING_SCENARIO_TYPES) %>%
  mutate(
    scenario_version = make_scenario_version(scenario_type),
    scenario_source = case_when(
      scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES ~ "present_paper",
      scenario_type %in% SCHROEDER_SCENARIO_TYPES ~ "Schroeder",
      TRUE ~ NA_character_
    )
  ) %>%
  dplyr::select(input_id, scenario_type, scenario_source, scenario_version, human_sd)

sd_by_type_no_shared_present_paper_dup <- sd_by_type %>%
  filter(!(scenario_type == "present_paper_old" & input_id %in% shared_present_paper_old_ids))

cat("\n── Human response variability by scenario type: present_paper + Schroeder ──\n")
wording_sd_summary <- sd_by_type %>%
  group_by(scenario_type, scenario_source, scenario_version) %>%
  summarise(
    mean_human_sd = mean(human_sd, na.rm = TRUE),
    sd_human_sd = sd(human_sd, na.rm = TRUE),
    n_scenarios = n(),
    .groups = "drop"
  ) %>%
  arrange(scenario_source, scenario_version, scenario_type)
print(wording_sd_summary, n = Inf, width = Inf)

cat("\n── Planned pairwise tests: human response variability ──\n")
wording_sd_pairwise <- bind_rows(
  welch_compare(sd_by_type, human_sd, "Schroeder_new", "present_paper_new"),
  welch_compare(sd_by_type, human_sd, "Schroeder_new", "present_paper_old"),
  welch_compare(sd_by_type, human_sd, "Schroeder_new", "Schroeder_old")
) %>%
  mutate(p_holm = p.adjust(p, method = "holm"))
print(wording_sd_pairwise, n = Inf, width = Inf)

sd_paired_schroeder <- sd_by_type %>%
  filter(scenario_type %in% SCHROEDER_SCENARIO_TYPES) %>%
  mutate(
    base = str_replace(input_id, "^Schroeder_(new|old)_", ""),
    cond = ifelse(str_detect(input_id, "Schroeder_new_"), "new", "old")
  ) %>%
  dplyr::select(base, cond, human_sd) %>%
  pivot_wider(names_from = cond, values_from = human_sd) %>%
  filter(!is.na(new) & !is.na(old))

if (nrow(sd_paired_schroeder) > 2) {
  tp_sd_schroeder <- t.test(sd_paired_schroeder$new,
                         sd_paired_schroeder$old,
                         paired = TRUE)
  d_sd_schroeder <- cohen_d_paired(sd_paired_schroeder$new,
                                sd_paired_schroeder$old)
  wording_sd_paired_schroeder <- tibble(
    outcome = "human_sd",
    comparison = "Schroeder_new vs Schroeder_old, paired",
    mean_new = mean(sd_paired_schroeder$new, na.rm = TRUE),
    mean_old = mean(sd_paired_schroeder$old, na.rm = TRUE),
    mean_diff_new_minus_old = mean(sd_paired_schroeder$new - sd_paired_schroeder$old, na.rm = TRUE),
    t = unname(tp_sd_schroeder$statistic),
    df = unname(tp_sd_schroeder$parameter),
    p = tp_sd_schroeder$p.value,
    ci_low = tp_sd_schroeder$conf.int[1],
    ci_high = tp_sd_schroeder$conf.int[2],
    dz = d_sd_schroeder,
    n_pairs = nrow(sd_paired_schroeder)
  )
  cat("\nPaired Schroeder human SD, new vs old:\n")
  print(wording_sd_paired_schroeder, n = Inf, width = Inf)
}

# Paired present-paper human SD, new vs old.
sd_paired_present_paper <- sd_by_type %>%
  filter(scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES) %>%
  mutate(
    base = str_replace(input_id, "_(new|old)$", ""),
    cond = str_extract(input_id, "(new|old)$")
  ) %>%
  dplyr::select(base, cond, human_sd) %>%
  pivot_wider(names_from = cond, values_from = human_sd) %>%
  filter(!is.na(new) & !is.na(old))

if (nrow(sd_paired_present_paper) > 2) {
  tp_sd_present_paper <- t.test(
    sd_paired_present_paper$new,
    sd_paired_present_paper$old,
    paired = TRUE
  )

  wording_sd_paired_present_paper <- tibble(
    outcome = "human_sd",
    comparison = "present_paper_new vs present_paper_old, paired",
    mean_new = mean(sd_paired_present_paper$new, na.rm = TRUE),
    mean_old = mean(sd_paired_present_paper$old, na.rm = TRUE),
    mean_diff_new_minus_old = mean(sd_paired_present_paper$new - sd_paired_present_paper$old, na.rm = TRUE),
    t = unname(tp_sd_present_paper$statistic),
    df = unname(tp_sd_present_paper$parameter),
    p = tp_sd_present_paper$p.value,
    ci_low = tp_sd_present_paper$conf.int[1],
    ci_high = tp_sd_present_paper$conf.int[2],
    dz = cohen_d_paired(sd_paired_present_paper$new, sd_paired_present_paper$old),
    n_pairs = nrow(sd_paired_present_paper)
  )

  cat("\nPaired present_paper human SD, new vs old:\n")
  print(wording_sd_paired_present_paper, n = Inf, width = Inf)
}

present_paper_sd <- sd_by_type %>%
  filter(scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES) %>%
  pull(human_sd)
schroeder_sd <- sd_by_type %>%
  filter(scenario_type %in% SCHROEDER_SCENARIO_TYPES) %>%
  pull(human_sd)
if (length(present_paper_sd) > 2 && length(schroeder_sd) > 2) {
  tp_sd_present_paper_schroeder <- t.test(schroeder_sd, present_paper_sd)
  wording_sd_collapsed <- tibble(
    outcome = "human_sd",
    comparison = "Schroeder vs present_paper, collapsed old/new",
    mean_present_paper = mean(present_paper_sd, na.rm = TRUE),
    mean_Schroeder = mean(schroeder_sd, na.rm = TRUE),
    t = unname(tp_sd_present_paper_schroeder$statistic),
    df = unname(tp_sd_present_paper_schroeder$parameter),
    p = tp_sd_present_paper_schroeder$p.value,
    ci_low = tp_sd_present_paper_schroeder$conf.int[1],
    ci_high = tp_sd_present_paper_schroeder$conf.int[2],
    d_Schroeder_minus_present_paper = cohen_d_ind(schroeder_sd, present_paper_sd),
    n_present_paper = sum(!is.na(present_paper_sd)),
    n_Schroeder = sum(!is.na(schroeder_sd))
  )
  cat("\nCollapsed Schroeder vs present_paper human SD:\n")
  print(wording_sd_collapsed, n = Inf, width = Inf)
}

wording_sd_pairwise_no_shared_present_paper_dup <- bind_rows(
  welch_compare(sd_by_type_no_shared_present_paper_dup, human_sd, "Schroeder_new", "present_paper_new"),
  welch_compare(sd_by_type_no_shared_present_paper_dup, human_sd, "Schroeder_new", "present_paper_old"),
  welch_compare(sd_by_type_no_shared_present_paper_dup, human_sd, "Schroeder_new", "Schroeder_old")
) %>%
  mutate(p_holm = p.adjust(p, method = "holm"))
cat("
Sensitivity pairwise human-SD tests excluding copied present_paper_old duplicates:
")
print(wording_sd_pairwise_no_shared_present_paper_dup, n = Inf, width = Inf)

present_paper_sd_no_shared <- sd_by_type_no_shared_present_paper_dup %>%
  filter(scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES) %>%
  pull(human_sd)
schroeder_sd_no_shared <- sd_by_type_no_shared_present_paper_dup %>%
  filter(scenario_type %in% SCHROEDER_SCENARIO_TYPES) %>%
  pull(human_sd)
if (length(present_paper_sd_no_shared) > 2 && length(schroeder_sd_no_shared) > 2) {
  tp_sd_present_paper_schroeder_no_shared <- t.test(schroeder_sd_no_shared, present_paper_sd_no_shared)
  wording_sd_collapsed_no_shared_present_paper_dup <- tibble(
    outcome = "human_sd",
    comparison = "Schroeder vs present_paper, collapsed old/new, excluding copied present_paper_old duplicates",
    mean_present_paper = mean(present_paper_sd_no_shared, na.rm = TRUE),
    mean_Schroeder = mean(schroeder_sd_no_shared, na.rm = TRUE),
    t = unname(tp_sd_present_paper_schroeder_no_shared$statistic),
    df = unname(tp_sd_present_paper_schroeder_no_shared$parameter),
    p = tp_sd_present_paper_schroeder_no_shared$p.value,
    ci_low = tp_sd_present_paper_schroeder_no_shared$conf.int[1],
    ci_high = tp_sd_present_paper_schroeder_no_shared$conf.int[2],
    d_Schroeder_minus_present_paper = cohen_d_ind(schroeder_sd_no_shared, present_paper_sd_no_shared),
    n_present_paper = sum(!is.na(present_paper_sd_no_shared)),
    n_Schroeder = sum(!is.na(schroeder_sd_no_shared))
  )
  cat("
Sensitivity collapsed Schroeder vs present_paper human SD excluding copied present_paper_old duplicates:
")
  print(wording_sd_collapsed_no_shared_present_paper_dup, n = Inf, width = Inf)
}

wording_models_focal <- c(
  "gpt-35-turbo_1106",
  "gpt-4o-mini_2024-07-18",
  "gpt-5-chat_2025-08-07",
  "gpt-oss-20b",
  "qwen-3-32B"
)

wording_model_labels_add <- c(
  "gpt-35-turbo_1106"      = "GPT-3.5",
  "gpt-4o-mini_2024-07-18" = "GPT-4o-mini",
  "gpt-5-chat_2025-08-07"  = "GPT-5",
  "gpt-oss-20b"            = "GPT-OSS-20B",
  "qwen-3-32B"             = "Qwen-3-32B"
)

model_labels <- c(
  model_labels[setdiff(names(model_labels), names(wording_model_labels_add))],
  wording_model_labels_add
)

prompt_measure_labels <- c(
  "confidence_prompt_model_rating"      = "Confidence prompt own judgment",
  "distribution_prompt_human_mean"    = "Distribution prompt predicted human mean",
  "confidence_prompt_predicted_confusion" = "Confidence prompt predicted human confusion"
)


scenario_source_label <- function(scenario_type) {
  case_when(
    scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES ~ "present_paper",
    scenario_type %in% SCHROEDER_SCENARIO_TYPES ~ "Schroeder",
    TRUE ~ NA_character_
  )
}

make_pair_base <- function(input_id, scenario_set) {
  case_when(
    scenario_set == "present_paper" ~ str_replace(input_id, "_(new|old)$", ""),
    scenario_set == "Schroeder" ~ str_replace(input_id, "^Schroeder_(new|old)_", ""),
    TRUE ~ NA_character_
  )
}

pull_lm_term <- function(fit, term_name, label = NA_character_) {
  broom::tidy(fit, conf.int = TRUE) %>%
    filter(term == term_name) %>%
    mutate(
      analysis_label = label,
      r.squared = broom::glance(fit)$r.squared,
      adj.r.squared = broom::glance(fit)$adj.r.squared,
      df.residual = broom::glance(fit)$df.residual,
      n = stats::nobs(fit)
    )
}


# Model-human mean alignment for wording analyses.
wording_model_means_distribution <- distribution_estimates %>%
  mutate(input_id = canonical_scenario_id(input_id)) %>%
  filter(
    input_id %in% wording_scenarios_with_humans,
    model_name %in% wording_models_focal,
    !is.na(distribution_human_mean)
  ) %>%
  dplyr::select(input_id, model_name, pred_mean = distribution_human_mean) %>%
  mutate(source = "distribution_prompt_human_mean")

wording_model_means_confidence <- confidence_estimates %>%
  mutate(input_id = canonical_scenario_id(input_id)) %>%
  filter(
    input_id %in% wording_scenarios_with_humans,
    model_name %in% wording_models_focal,
    !is.na(conf_model_moral_rating)
  ) %>%
  dplyr::select(input_id, model_name, pred_mean = conf_model_moral_rating) %>%
  mutate(source = "confidence_prompt_model_rating")

wording_model_means_all_available <- bind_rows(
  wording_model_means_distribution,
  wording_model_means_confidence
) %>%
  mutate(
    model_label = recode(model_name, !!!model_labels, .default = model_name),
    prompt_measure = recode(source, !!!prompt_measure_labels, .default = source)
  )

cat("\n── Model rows available for wording analyses ──\n")
wording_model_means_all_available %>%
  count(model_label, model_name, prompt_measure, source) %>%
  arrange(model_label, prompt_measure) %>%
  print(n = Inf, width = Inf)

wording_model_means_all <- select_primary_scenario_mean_source(
  wording_model_means_all_available
)

cat("\n── Selected model rows for wording analyses ──\n")
wording_model_means_all %>%
  count(model_label, model_name, prompt_measure, source) %>%
  arrange(model_label, prompt_measure) %>%
  print(n = Inf, width = Inf)

wording_mean_fit <- wording_model_means_all %>%
  inner_join(
    human_stats %>%
      dplyr::select(input_id, human_mean, scenario_type),
    by = "input_id"
  ) %>%
  filter(scenario_type %in% WORDING_SCENARIO_TYPES) %>%
  mutate(
    scenario_version = make_scenario_version(scenario_type),
    scenario_source = scenario_source_label(scenario_type)
  ) %>%
  group_by(
    model_label, model_name,
    prompt_measure, source,
    scenario_type, scenario_source, scenario_version
  ) %>%
  summarise(
    r = safe_cor(pred_mean, human_mean),
    mse = mean((pred_mean - human_mean)^2, na.rm = TRUE),
    mae = mean(abs(pred_mean - human_mean), na.rm = TRUE),
    n_scenarios = n_distinct(input_id),
    .groups = "drop"
  ) %>%
  arrange(model_label, prompt_measure, scenario_source, scenario_version)

cat("\n── Model-human mean fit by scenario type: present_paper + Schroeder ──\n")
print(
  wording_mean_fit %>%
    mutate(across(c(r, mse, mae), ~ round(.x, 3))),
  n = Inf,
  width = Inf
)

wording_mean_fit_primary_ranges <- wording_mean_fit %>%
  group_by(scenario_source, scenario_version) %>%
  summarise(
    min_r = min(r, na.rm = TRUE),
    max_r = max(r, na.rm = TRUE),
    min_mse = min(mse, na.rm = TRUE),
    max_mse = max(mse, na.rm = TRUE),
    min_mae = min(mae, na.rm = TRUE),
    max_mae = max(mae, na.rm = TRUE),
    n_models = n_distinct(model_name),
    models = paste(sort(unique(model_label)), collapse = ", "),
    sources = paste(sort(unique(prompt_measure)), collapse = "; "),
    .groups = "drop"
  )

cat("\n── Primary mean-source fit ranges for manuscript text, including Qwen ──\n")
print(wording_mean_fit_primary_ranges, n = Inf, width = Inf)

wording_confusion_sd <- human_stats %>%
  dplyr::select(input_id, scenario_type, human_sd) %>%
  inner_join(
    human_confuse_means %>%
      dplyr::select(input_id, mean_confusion),
    by = "input_id"
  ) %>%
  filter(scenario_type %in% WORDING_SCENARIO_TYPES) %>%
  mutate(
    scenario_version = make_scenario_version(scenario_type),
    scenario_source = scenario_source_label(scenario_type),
    mean_confusion_z = as.numeric(scale(mean_confusion)),
    human_sd_z = as.numeric(scale(human_sd)),
    scenario_type = factor(scenario_type, levels = WORDING_SCENARIO_TYPES)
  )

cat("\n── Confusion and human response variability ──\n")

confusion_variability_cor <- cor.test(
  wording_confusion_sd$mean_confusion,
  wording_confusion_sd$human_sd
)

cat("\nCorrelation: human-rated confusion and human response variability\n")
print(confusion_variability_cor)

m_confusion_variability_b <- lm(
  human_sd ~ mean_confusion,
  data = wording_confusion_sd
)

m_confusion_variability_beta <- lm(
  human_sd_z ~ mean_confusion_z,
  data = wording_confusion_sd
)

m_confusion_variability_beta_type <- lm(
  human_sd_z ~ mean_confusion_z + scenario_type,
  data = wording_confusion_sd
)

m_confusion_variability_b_type <- lm(
  human_sd ~ mean_confusion + scenario_type,
  data = wording_confusion_sd
)
wording_sd_adjusted_unstandardized <- broom::tidy(
  m_confusion_variability_b_type, conf.int = TRUE
) %>%
  mutate(
    n = stats::nobs(m_confusion_variability_b_type),
    df = stats::df.residual(m_confusion_variability_b_type),
    reference_category = levels(wording_confusion_sd$scenario_type)[1],
    outcome = "human response SD (original scale)",
    specification = "human_sd ~ mean_confusion + scenario_type"
  )
write.csv(wording_sd_adjusted_unstandardized,
          file.path(out_dir, "table_wording_sd_adjusted_unstandardized.csv"), row.names = FALSE)
cat("\nUnstandardized human-SD regression, controlling for scenario type:\n")
print(wording_sd_adjusted_unstandardized, n = Inf, width = Inf)

confusion_variability_results <- bind_rows(
  pull_lm_term(
    m_confusion_variability_b,
    "mean_confusion",
    "Unstandardized: human SD ~ confusion"
  ),
  pull_lm_term(
    m_confusion_variability_beta,
    "mean_confusion_z",
    "Standardized: human SD ~ confusion"
  ),
  pull_lm_term(
    m_confusion_variability_beta_type,
    "mean_confusion_z",
    "Standardized: human SD ~ confusion + scenario type"
  )
)

cat("\nRegression results: confusion predicting human response variability\n")
print(confusion_variability_results, n = Inf, width = Inf)


# Model-error regressions test whether confusion and human variability explain absolute prediction error.
wording_model_error_primary <- wording_model_means_all %>%
  inner_join(
    human_stats %>%
      filter(scenario_type %in% WORDING_SCENARIO_TYPES) %>%
      dplyr::select(input_id, human_mean, human_sd, scenario_type),
    by = "input_id"
  ) %>%
  inner_join(
    human_confuse_means %>%
      dplyr::select(input_id, mean_confusion),
    by = "input_id"
  ) %>%
  mutate(
    scenario_version = make_scenario_version(scenario_type),
    scenario_source = scenario_source_label(scenario_type),
    abs_error = abs(pred_mean - human_mean),
    squared_error = (pred_mean - human_mean)^2,
    signed_error = pred_mean - human_mean,
    abs_error_z = as.numeric(scale(abs_error)),
    mean_confusion_z = as.numeric(scale(mean_confusion)),
    human_sd_z = as.numeric(scale(human_sd)),
    model_label = factor(model_label),
    model_name = factor(model_name),
    scenario_type = factor(scenario_type, levels = WORDING_SCENARIO_TYPES),
    scenario_source = factor(scenario_source, levels = c("present_paper", "Schroeder"))
  )

write.csv(wording_model_error_primary,
          file.path(out_dir, "table_wording_model_error_primary_by_item.csv"), row.names = FALSE)

cat("\n── Model-error data check, primary mean source including Qwen ──\n")
wording_model_error_primary %>%
  count(model_label, model_name, scenario_source) %>%
  arrange(model_label, scenario_source) %>%
  print(n = Inf, width = Inf)

m_error_confusion_b <- lm(
  abs_error ~ mean_confusion + model_label,
  data = wording_model_error_primary
)

m_error_confusion_beta <- lm(
  abs_error_z ~ mean_confusion_z + model_label,
  data = wording_model_error_primary
)

model_error_confusion_results <- bind_rows(
  pull_lm_term(
    m_error_confusion_b,
    "mean_confusion",
    "Unstandardized: absolute model error ~ confusion + model identity"
  ),
  pull_lm_term(
    m_error_confusion_beta,
    "mean_confusion_z",
    "Standardized: absolute model error ~ confusion + model identity"
  )
)

cat("\n── Overall: confusion predicting absolute model error, primary mean source including Qwen ──\n")
print(model_error_confusion_results, n = Inf, width = Inf)

m_error_variability_b <- lm(
  abs_error ~ human_sd + model_label,
  data = wording_model_error_primary
)

m_error_variability_beta <- lm(
  abs_error_z ~ human_sd_z + model_label,
  data = wording_model_error_primary
)

model_error_variability_results <- bind_rows(
  pull_lm_term(
    m_error_variability_b,
    "human_sd",
    "Unstandardized: absolute model error ~ human response variability + model identity"
  ),
  pull_lm_term(
    m_error_variability_beta,
    "human_sd_z",
    "Standardized: absolute model error ~ human response variability + model identity"
  )
)

cat("\n── Overall: human response variability predicting absolute model error, primary mean source including Qwen ──\n")
print(model_error_variability_results, n = Inf, width = Inf)

m_error_joint_b <- lm(
  abs_error ~ mean_confusion + human_sd + model_label,
  data = wording_model_error_primary
)

m_error_joint_beta <- lm(
  abs_error_z ~ mean_confusion_z + human_sd_z + model_label,
  data = wording_model_error_primary
)

model_error_joint_results <- bind_rows(
  pull_lm_term(
    m_error_joint_b,
    "mean_confusion",
    "Joint unstandardized: confusion"
  ),
  pull_lm_term(
    m_error_joint_b,
    "human_sd",
    "Joint unstandardized: human response variability"
  ),
  pull_lm_term(
    m_error_joint_beta,
    "mean_confusion_z",
    "Joint standardized: confusion"
  ),
  pull_lm_term(
    m_error_joint_beta,
    "human_sd_z",
    "Joint standardized: human response variability"
  )
)

cat("\n── Overall: joint model predicting absolute model error, primary mean source including Qwen ──\n")
print(model_error_joint_results, n = Inf, width = Inf)

fit_error_predictors_by_source <- function(dat) {
  dat <- dat %>%
    ungroup() %>%
    mutate(
      abs_error_z_local = as.numeric(scale(abs_error)),
      mean_confusion_z_local = as.numeric(scale(mean_confusion)),
      human_sd_z_local = as.numeric(scale(human_sd)),
      model_label = factor(model_label)
    )
  
  m_conf_b <- lm(abs_error ~ mean_confusion + model_label, data = dat)
  m_var_b  <- lm(abs_error ~ human_sd + model_label, data = dat)
  m_joint_b <- lm(abs_error ~ mean_confusion + human_sd + model_label, data = dat)
  
  m_conf_beta <- lm(abs_error_z_local ~ mean_confusion_z_local + model_label, data = dat)
  m_var_beta  <- lm(abs_error_z_local ~ human_sd_z_local + model_label, data = dat)
  m_joint_beta <- lm(
    abs_error_z_local ~ mean_confusion_z_local + human_sd_z_local + model_label,
    data = dat
  )
  
  bind_rows(
    pull_lm_term(
      m_conf_b,
      "mean_confusion",
      "Unstandardized: error ~ confusion + model identity"
    ) %>%
      mutate(model_type = "confusion_only"),
    
    pull_lm_term(
      m_conf_beta,
      "mean_confusion_z_local",
      "Standardized: error ~ confusion + model identity"
    ) %>%
      mutate(model_type = "confusion_only"),
    
    pull_lm_term(
      m_var_b,
      "human_sd",
      "Unstandardized: error ~ human SD + model identity"
    ) %>%
      mutate(model_type = "variability_only"),
    
    pull_lm_term(
      m_var_beta,
      "human_sd_z_local",
      "Standardized: error ~ human SD + model identity"
    ) %>%
      mutate(model_type = "variability_only"),
    
    pull_lm_term(
      m_joint_b,
      "mean_confusion",
      "Joint unstandardized: confusion"
    ) %>%
      mutate(model_type = "joint"),
    
    pull_lm_term(
      m_joint_b,
      "human_sd",
      "Joint unstandardized: human SD"
    ) %>%
      mutate(model_type = "joint"),
    
    pull_lm_term(
      m_joint_beta,
      "mean_confusion_z_local",
      "Joint standardized: confusion"
    ) %>%
      mutate(model_type = "joint"),
    
    pull_lm_term(
      m_joint_beta,
      "human_sd_z_local",
      "Joint standardized: human SD"
    ) %>%
      mutate(model_type = "joint")
  )
}

model_error_by_source_results <- wording_model_error_primary %>%
  group_by(scenario_source) %>%
  group_modify(~ fit_error_predictors_by_source(.x)) %>%
  ungroup() %>%
  dplyr::select(
    scenario_source, model_type, analysis_label, term,
    estimate, std.error, statistic, p.value,
    conf.low, conf.high,
    r.squared, adj.r.squared, df.residual, n
  )

cat("\n── Model error by dataset, controlling for confusion and variability ──\n")
print(model_error_by_source_results, n = Inf, width = Inf)

fit_error_predictors_single_model <- function(dat) {
  dat <- dat %>%
    ungroup() %>%
    mutate(
      abs_error_z_local = as.numeric(scale(abs_error)),
      mean_confusion_z_local = as.numeric(scale(mean_confusion)),
      human_sd_z_local = as.numeric(scale(human_sd))
    )
  
  m_joint_b <- lm(abs_error ~ mean_confusion + human_sd, data = dat)
  
  m_joint_beta <- lm(
    abs_error_z_local ~ mean_confusion_z_local + human_sd_z_local,
    data = dat
  )
  
  joint_b <- broom::tidy(m_joint_b, conf.int = TRUE) %>%
    filter(term %in% c("mean_confusion", "human_sd")) %>%
    mutate(
      model_type = "joint_unstandardized",
      predictor = case_when(
        term == "mean_confusion" ~ "confusion",
        term == "human_sd" ~ "human_response_variability",
        TRUE ~ term
      ),
      r.squared = broom::glance(m_joint_b)$r.squared,
      adj.r.squared = broom::glance(m_joint_b)$adj.r.squared,
      df.residual = broom::glance(m_joint_b)$df.residual,
      n = stats::nobs(m_joint_b)
    )
  
  joint_beta <- broom::tidy(m_joint_beta, conf.int = TRUE) %>%
    filter(term %in% c("mean_confusion_z_local", "human_sd_z_local")) %>%
    mutate(
      model_type = "joint_standardized",
      predictor = case_when(
        term == "mean_confusion_z_local" ~ "confusion",
        term == "human_sd_z_local" ~ "human_response_variability",
        TRUE ~ term
      ),
      r.squared = broom::glance(m_joint_beta)$r.squared,
      adj.r.squared = broom::glance(m_joint_beta)$adj.r.squared,
      df.residual = broom::glance(m_joint_beta)$df.residual,
      n = stats::nobs(m_joint_beta)
    )
  
  bind_rows(joint_b, joint_beta)
}

model_error_by_source_and_model_results <- wording_model_error_primary %>%
  group_by(scenario_source, model_label, model_name) %>%
  group_modify(~ fit_error_predictors_single_model(.x)) %>%
  ungroup() %>%
  dplyr::select(
    scenario_source, model_label, model_name,
    model_type, predictor, term,
    estimate, std.error, statistic, p.value,
    conf.low, conf.high,
    r.squared, adj.r.squared, df.residual, n
  )

cat("\n── Model error by dataset × model, joint confusion + variability ──\n")
print(model_error_by_source_and_model_results, n = Inf, width = Inf)

qwen_distribution_models <- character()

wording_alignment_item <- wording_model_means_all %>%
  inner_join(
    human_stats %>%
      dplyr::select(input_id, human_mean, human_sd, scenario_type),
    by = "input_id"
  ) %>%
  inner_join(
    human_confuse_means %>%
      dplyr::select(input_id, mean_confusion),
    by = "input_id"
  ) %>%
  filter(
    scenario_type %in% WORDING_SCENARIO_TYPES,
    model_name %in% wording_models_focal
  ) %>%
  mutate(
    scenario_set = scenario_source_label(scenario_type),
    version = make_scenario_version(scenario_type),
    base = make_pair_base(input_id, scenario_set),
    signed_error = pred_mean - human_mean,
    abs_error = abs(pred_mean - human_mean),
    squared_error = signed_error^2
  ) %>%
  filter(!is.na(scenario_set), !is.na(version), !is.na(base))

# Matched old/new pairs are used to estimate alignment gaps between original and reworded scenarios.
wording_alignment_pairs <- wording_alignment_item %>%
  dplyr::select(
    scenario_set,
    model_name, model_label,
    prompt_measure, source,
    base, version,
    abs_error, squared_error, signed_error,
    mean_confusion, human_sd
  ) %>%
  group_by(
    scenario_set,
    model_name, model_label,
    prompt_measure, source,
    base, version
  ) %>%
  summarise(
    abs_error = mean(abs_error, na.rm = TRUE),
    squared_error = mean(squared_error, na.rm = TRUE),
    signed_error = mean(signed_error, na.rm = TRUE),
    mean_confusion = first(mean_confusion),
    human_sd = first(human_sd),
    .groups = "drop"
  ) %>%
  pivot_wider(
    names_from = version,
    values_from = c(
      abs_error, squared_error, signed_error,
      mean_confusion, human_sd
    )
  ) %>%
  filter(
    !is.na(abs_error_new),
    !is.na(abs_error_old),
    !is.na(mean_confusion_new),
    !is.na(mean_confusion_old),
    !is.na(human_sd_new),
    !is.na(human_sd_old)
  ) %>%
  mutate(
    diff_abs_error = abs_error_new - abs_error_old,
    diff_squared_error = squared_error_new - squared_error_old,
    diff_signed_error = signed_error_new - signed_error_old,
    diff_confusion = mean_confusion_new - mean_confusion_old,
    diff_human_sd = human_sd_new - human_sd_old,
    scenario_set = factor(scenario_set, levels = c("present_paper", "Schroeder"))
  )

cat("\n── Old/new alignment-pair rows available ──\n")
wording_alignment_pairs %>%
  count(scenario_set, model_label, prompt_measure, source) %>%
  arrange(scenario_set, model_label, prompt_measure) %>%
  print(n = Inf, width = Inf)

wording_alignment_pairs_model_item <- wording_alignment_pairs %>%
  group_by(scenario_set, base, model_name, model_label) %>%
  summarise(
    diff_abs_error = mean(diff_abs_error, na.rm = TRUE),
    abs_error_new = mean(abs_error_new, na.rm = TRUE),
    abs_error_old = mean(abs_error_old, na.rm = TRUE),
    diff_squared_error = mean(diff_squared_error, na.rm = TRUE),
    diff_signed_error = mean(diff_signed_error, na.rm = TRUE),
    diff_confusion = first(diff_confusion),
    diff_human_sd = first(diff_human_sd),
    human_sd_new = first(human_sd_new),
    human_sd_old = first(human_sd_old),
    mean_confusion_new = first(mean_confusion_new),
    mean_confusion_old = first(mean_confusion_old),
    .groups = "drop"
  )

wording_alignment_pairs_model_equal_item <- wording_alignment_pairs_model_item %>%
  group_by(scenario_set, base) %>%
  summarise(
    diff_abs_error = mean(diff_abs_error, na.rm = TRUE),
    abs_error_new = mean(abs_error_new, na.rm = TRUE),
    abs_error_old = mean(abs_error_old, na.rm = TRUE),
    diff_squared_error = mean(diff_squared_error, na.rm = TRUE),
    diff_signed_error = mean(diff_signed_error, na.rm = TRUE),
    diff_confusion = first(diff_confusion),
    diff_human_sd = first(diff_human_sd),
    human_sd_new = first(human_sd_new),
    human_sd_old = first(human_sd_old),
    mean_confusion_new = first(mean_confusion_new),
    mean_confusion_old = first(mean_confusion_old),
    n_models = n_distinct(model_name),
    models = paste(sort(unique(model_label)), collapse = ", "),
    .groups = "drop"
  )

cat("\n── Model-equal item-level alignment data check ──\n")
wording_alignment_pairs_model_equal_item %>%
  count(scenario_set, n_models, models) %>%
  print(n = Inf, width = Inf)

fit_gap_models <- function(dat) {
  dat <- dat %>%
    ungroup()

  sd_y <- sd(dat$diff_abs_error, na.rm = TRUE)
  sd_conf <- sd(dat$diff_confusion, na.rm = TRUE)
  sd_var <- sd(dat$diff_human_sd, na.rm = TRUE)

  slope_beta <- function(estimate, sd_x, sd_y) {
    if (!is.finite(sd_x) || !is.finite(sd_y) || sd_y == 0) {
      return(rep(NA_real_, length(estimate)))
    }
    estimate * sd_x / sd_y
  }

  intercept_dz <- function(estimate, sd_y) {
    ifelse(
      is.na(estimate) | is.na(sd_y) | sd_y == 0,
      NA_real_,
      estimate / sd_y
    )
  }

  m_unadj <- lm(diff_abs_error ~ 1, data = dat)
  m_conf <- lm(diff_abs_error ~ diff_confusion, data = dat)
  m_both <- lm(diff_abs_error ~ diff_confusion + diff_human_sd, data = dat)

  bind_rows(
    broom::tidy(m_unadj, conf.int = TRUE) %>%
      filter(term == "(Intercept)") %>%
      mutate(
        model = "unadjusted",
        effect = "old_new_alignment_gap",
        beta_std = NA_real_,
        dz = intercept_dz(estimate, sd_y),
        r.squared = broom::glance(m_unadj)$r.squared,
        adj.r.squared = broom::glance(m_unadj)$adj.r.squared,
        df.residual = broom::glance(m_unadj)$df.residual,
        n_pairs = nrow(dat)
      ),

    broom::tidy(m_conf, conf.int = TRUE) %>%
      filter(term %in% c("(Intercept)", "diff_confusion")) %>%
      mutate(
        model = "adjusted_for_confusion",
        effect = case_when(
          term == "(Intercept)" ~ "old_new_alignment_gap",
          term == "diff_confusion" ~ "confusion_difference_slope",
          TRUE ~ term
        ),
        beta_std = case_when(
          term == "(Intercept)" ~ NA_real_,
          term == "diff_confusion" ~ slope_beta(estimate, sd_conf, sd_y),
          TRUE ~ NA_real_
        ),
        dz = case_when(
          term == "(Intercept)" ~ intercept_dz(estimate, sd_y),
          TRUE ~ NA_real_
        ),
        r.squared = broom::glance(m_conf)$r.squared,
        adj.r.squared = broom::glance(m_conf)$adj.r.squared,
        df.residual = broom::glance(m_conf)$df.residual,
        n_pairs = nrow(dat)
      ),

    broom::tidy(m_both, conf.int = TRUE) %>%
      filter(term %in% c("(Intercept)", "diff_confusion", "diff_human_sd")) %>%
      mutate(
        model = "adjusted_for_confusion_and_variability",
        effect = case_when(
          term == "(Intercept)" ~ "old_new_alignment_gap",
          term == "diff_confusion" ~ "confusion_difference_slope",
          term == "diff_human_sd" ~ "human_variability_difference_slope",
          TRUE ~ term
        ),
        beta_std = case_when(
          term == "(Intercept)" ~ NA_real_,
          term == "diff_confusion" ~ slope_beta(estimate, sd_conf, sd_y),
          term == "diff_human_sd" ~ slope_beta(estimate, sd_var, sd_y),
          TRUE ~ NA_real_
        ),
        dz = case_when(
          term == "(Intercept)" ~ intercept_dz(estimate, sd_y),
          TRUE ~ NA_real_
        ),
        r.squared = broom::glance(m_both)$r.squared,
        adj.r.squared = broom::glance(m_both)$adj.r.squared,
        df.residual = broom::glance(m_both)$df.residual,
        n_pairs = nrow(dat)
      )
  )
}

alignment_gap_model_equal_by_set <- wording_alignment_pairs_model_equal_item %>%
  group_by(scenario_set) %>%
  group_modify(~ fit_gap_models(.x)) %>%
  ungroup() %>%
  dplyr::select(
    scenario_set, model, effect, term, n_pairs,
    estimate, beta_std, dz, std.error, statistic, p.value,
    conf.low, conf.high,
    r.squared, adj.r.squared, df.residual
  )

write.csv(alignment_gap_model_equal_by_set,
          file.path(out_dir, "table_alignment_gap_models_by_set.csv"), row.names = FALSE)

cat("\n── Model-equal old/new alignment gaps ──\n")
print(alignment_gap_model_equal_by_set, n = Inf, width = Inf)

alignment_gap_model_equal_gap_only <- alignment_gap_model_equal_by_set %>%
  filter(effect == "old_new_alignment_gap")

cat("\n── Gap-only rows ──\n")
print(alignment_gap_model_equal_gap_only, n = Inf, width = Inf)

alignment_gap_by_model <- wording_alignment_pairs_model_item %>%
  group_by(scenario_set, model_name, model_label) %>%
  group_modify(~ fit_gap_models(.x)) %>%
  ungroup() %>%
  dplyr::select(
    scenario_set, model_label, model_name,
    model, effect, term, n_pairs,
    estimate, beta_std, dz, std.error, statistic, p.value,
    conf.low, conf.high,
    r.squared, adj.r.squared, df.residual
  )

write.csv(alignment_gap_by_model,
          file.path(out_dir, "table_alignment_gap_models_by_model.csv"), row.names = FALSE)

cat("\n── Old/new alignment gaps by model ──\n")
print(alignment_gap_by_model, n = Inf, width = Inf)

alignment_gap_by_model_gap_only <- alignment_gap_by_model %>%
  filter(effect == "old_new_alignment_gap")

cat("\n── Gap-only rows by model ──\n")
print(alignment_gap_by_model_gap_only, n = Inf, width = Inf)

schroeder_adjusted_gap_by_model <- alignment_gap_by_model %>%
  filter(
    scenario_set == "Schroeder",
    model == "adjusted_for_confusion_and_variability",
    effect == "old_new_alignment_gap"
  ) %>%
  arrange(p.value)

cat("\n── Schroeder old/new gap by model, adjusted for confusion + variability ──\n")
print(schroeder_adjusted_gap_by_model, n = Inf, width = Inf)

alignment_gap_by_model_prompt <- wording_alignment_pairs %>%
  group_by(scenario_set, model_name, model_label, prompt_measure, source) %>%
  group_modify(~ fit_gap_models(.x)) %>%
  ungroup() %>%
  dplyr::select(
    scenario_set, model_label, model_name,
    prompt_measure, source,
    model, effect, term, n_pairs,
    estimate, beta_std, dz, std.error, statistic, p.value,
    conf.low, conf.high,
    r.squared, adj.r.squared, df.residual
  )

write.csv(alignment_gap_by_model_prompt,
          file.path(out_dir, "table_alignment_gap_models_by_model_prompt.csv"), row.names = FALSE)

cat("\n── Old/new alignment gaps by model × prompt ──\n")
print(alignment_gap_by_model_prompt, n = Inf, width = Inf)

alignment_descriptives_model_equal <- wording_alignment_pairs_model_equal_item %>%
  group_by(scenario_set) %>%
  summarise(
    n_pairs = n(),
    mean_error_new = mean(abs_error_new, na.rm = TRUE),
    mean_error_old = mean(abs_error_old, na.rm = TRUE),
    mean_diff_abs_error = mean(diff_abs_error, na.rm = TRUE),
    mean_confusion_new = mean(mean_confusion_new, na.rm = TRUE),
    mean_confusion_old = mean(mean_confusion_old, na.rm = TRUE),
    mean_diff_confusion = mean(diff_confusion, na.rm = TRUE),
    mean_human_sd_new = mean(human_sd_new, na.rm = TRUE),
    mean_human_sd_old = mean(human_sd_old, na.rm = TRUE),
    mean_diff_human_sd = mean(diff_human_sd, na.rm = TRUE),
    .groups = "drop"
  )

cat("\n── Model-equal old/new alignment descriptives ──\n")
print(alignment_descriptives_model_equal, n = Inf, width = Inf)

# Derive the included models from the available confidence prompt data.
models_with_confusion_prediction <- confidence_estimates %>%
  filter(!is.na(confusion_estimate)) %>%
  count(model_name, name = "n_confusion") %>%
  filter(n_confusion >= 30) %>%
  pull(model_name) %>%
  sort()

cat("\n── Models with model-predicted confusion ──\n")
cat("  ", paste(models_with_confusion_prediction, collapse = ", "), "\n")
audit_record(
  "A6 confusion prediction", "select models with usable confusion estimates",
  rows_in = n_distinct(confidence_estimates$model_name),
  rows_out = length(models_with_confusion_prediction),
  reason = "retain every model with at least 30 usable confusion estimates",
  detail = paste(models_with_confusion_prediction, collapse = "; ")
)


# Compare model-predicted human confusion with observed human confusion ratings.
model_predicted_confusion_df <- confidence_estimates %>%
  mutate(input_id = canonical_scenario_id(input_id)) %>%
  filter(
    input_id %in% wording_scenarios_with_humans,
    model_name %in% models_with_confusion_prediction,
    !is.na(confusion_estimate)
  ) %>%
  dplyr::select(
    input_id,
    model_name,
    model_predicted_confusion = confusion_estimate
  ) %>%
  mutate(
    model_label = recode(model_name, !!!model_labels, .default = model_name)
  ) %>%
  inner_join(
    human_confuse_means %>%
      dplyr::select(input_id, mean_confusion),
    by = "input_id"
  ) %>%
  inner_join(
    human_stats %>%
      dplyr::select(input_id, scenario_type),
    by = "input_id"
  ) %>%
  filter(scenario_type %in% WORDING_SCENARIO_TYPES)

fit_predicted_confusion <- function(dat) {
  dat <- dat %>%
    ungroup() %>%
    mutate(
      mean_confusion_z = as.numeric(scale(mean_confusion)),
      model_predicted_confusion_z = as.numeric(scale(model_predicted_confusion))
    )

  cor_out <- cor.test(
    dat$model_predicted_confusion,
    dat$mean_confusion
  )

  m_b <- lm(mean_confusion ~ model_predicted_confusion, data = dat)

  m_beta <- lm(
    mean_confusion_z ~ model_predicted_confusion_z,
    data = dat
  )

  unstd <- broom::tidy(m_b, conf.int = TRUE) %>%
    filter(term == "model_predicted_confusion") %>%
    mutate(
      model_type = "unstandardized",
      r.squared = broom::glance(m_b)$r.squared,
      adj.r.squared = broom::glance(m_b)$adj.r.squared,
      df.residual = broom::glance(m_b)$df.residual,
      n = stats::nobs(m_b)
    )

  std <- broom::tidy(m_beta, conf.int = TRUE) %>%
    filter(term == "model_predicted_confusion_z") %>%
    mutate(
      model_type = "standardized",
      r.squared = broom::glance(m_beta)$r.squared,
      adj.r.squared = broom::glance(m_beta)$adj.r.squared,
      df.residual = broom::glance(m_beta)$df.residual,
      n = stats::nobs(m_beta)
    )

  bind_rows(unstd, std) %>%
    mutate(
      r = unname(cor_out$estimate),
      cor_p = cor_out$p.value,
      cor_conf_low = cor_out$conf.int[1],
      cor_conf_high = cor_out$conf.int[2]
    )
}

model_predicted_confusion_results <- model_predicted_confusion_df %>%
  group_by(model_name, model_label) %>%
  group_modify(~ fit_predicted_confusion(.x)) %>%
  ungroup() %>%
  dplyr::select(
    model_label, model_name,
    model_type, term,
    estimate, std.error, statistic, p.value,
    conf.low, conf.high,
    r, cor_p, cor_conf_low, cor_conf_high,
    r.squared, adj.r.squared, df.residual, n
  )

q2_confusion_family_holm <- model_predicted_confusion_results %>%
  filter(model_type == "unstandardized") %>%
  dplyr::select(model_name, p.value) %>%
  mutate(p_holm = stats::p.adjust(p.value, method = "holm")) %>%
  dplyr::select(model_name, p_holm)
model_predicted_confusion_results <- model_predicted_confusion_results %>%
  left_join(q2_confusion_family_holm, by = "model_name")

cat("\n── model-predicted human confusion vs human-rated confusion ──\n")
print(model_predicted_confusion_results, n = Inf, width = Inf)


# test whether model confidence predicts its own absolute error.
pred_error <- confidence_estimates %>%
  mutate(input_id = canonical_scenario_id(input_id)) %>%
  filter(
    input_id %in% scenarios_with_humans,
    !is.na(conf_model_moral_rating),
    !is.na(rating_confidence)
  ) %>%
  inner_join(
    human_stats %>%
      dplyr::select(input_id, human_mean, scenario_type),
    by = "input_id"
  ) %>%
  mutate(
    pred_mean = conf_model_moral_rating,
    signed_error = pred_mean - human_mean,
    abs_error = abs(signed_error),
    model_name = factor(model_name)
  )

cat("\n── Combined: error ~ confidence + confusion + model ──\n")
combined <- pred_error %>% inner_join(human_confuse_means, by="input_id") %>%
  filter(!is.na(rating_confidence), !is.na(mean_confusion))
if (nrow(combined)>10)
  print(summary(lm(abs_error ~ rating_confidence + mean_confusion + model_name, data=combined)))

stopifnot(setequal(unique(as.character(pred_error$model_name)),
                   CONFIDENCE_EXPECTED_MODELS))

fit_confidence_error <- function(d, formula_obj, model_set_label) {
  if (nrow(d) < 10) return(tibble())
  d <- d %>% mutate(model_name = droplevels(factor(model_name)))
  fit <- stats::lm(formula_obj, data = d)
  broom::tidy(fit, conf.int = TRUE) %>%
    mutate(model_set = model_set_label,
           n = stats::nobs(fit),
           df_residual = stats::df.residual(fit),
           n_models = dplyr::n_distinct(d$model_name),
           .before = 1)
}

confidence_error_lm_tidy <- fit_confidence_error(
  pred_error, abs_error ~ rating_confidence + model_name, "five_model"
)

confidence_error_model_controls_lm_tidy <- fit_confidence_error(
  combined, abs_error ~ rating_confidence + mean_confusion + model_name,
  "five_model"
)

Q5_CALIBRATION_FOCAL_TERMS <- c("rating_confidence", "mean_confusion")
q5_calibration_family_holm <- bind_rows(
  confidence_error_lm_tidy %>% mutate(spec = "confidence + model"),
  confidence_error_model_controls_lm_tidy %>%
    mutate(spec = "confidence + confusion + model")
) %>%
  filter(term %in% Q5_CALIBRATION_FOCAL_TERMS) %>%
  group_by(model_set) %>%
  mutate(p_holm = stats::p.adjust(p.value, method = "holm")) %>%
  ungroup() %>%
  dplyr::select(model_set, spec, term, p_holm)

confidence_error_lm_tidy <- confidence_error_lm_tidy %>%
  left_join(
    q5_calibration_family_holm %>%
      filter(spec == "confidence + model") %>% dplyr::select(-spec),
    by = c("model_set", "term")
  )
confidence_error_model_controls_lm_tidy <- confidence_error_model_controls_lm_tidy %>%
  left_join(
    q5_calibration_family_holm %>%
      filter(spec == "confidence + confusion + model") %>% dplyr::select(-spec),
    by = c("model_set", "term")
  )


if (!(requireNamespace("lme4", quietly = TRUE) &&
      requireNamespace("lmerTest", quietly = TRUE) &&
      requireNamespace("broom.mixed", quietly = TRUE))) {
  stop("Q5 pooled models require lme4, lmerTest, and broom.mixed.")
}

fit_q5_pooled_lmer <- function(d, with_confusion, spec_label, model_set_label) {
  d <- d %>%
    ungroup() %>%
    filter(!is.na(abs_error), !is.na(rating_confidence)) %>%
    { if (with_confusion) filter(., !is.na(mean_confusion)) else . } %>%
    mutate(
      abs_error_z = as.numeric(scale(abs_error)),
      rating_confidence_z = as.numeric(scale(rating_confidence)),
      model_name = droplevels(factor(model_name))
    )
  if (with_confusion) {
    d <- d %>% mutate(mean_confusion_z = as.numeric(scale(mean_confusion)))
  }
  if (nrow(d) < 10 || dplyr::n_distinct(d$input_id) < 5) return(tibble())
  form <- if (with_confusion) {
    abs_error_z ~ rating_confidence_z + mean_confusion_z + model_name + (1 | input_id)
  } else {
    abs_error_z ~ rating_confidence_z + model_name + (1 | input_id)
  }
  fit <- lmerTest::lmer(form, data = d)
  broom.mixed::tidy(fit, effects = "fixed", conf.int = TRUE) %>%
    mutate(!!!as.list(model_fit_diagnostics(fit))) %>%
    mutate(
      spec = spec_label, model_set = model_set_label,
      n_rows = nrow(d),
      n_scenarios = dplyr::n_distinct(d$input_id),
      n_models = dplyr::n_distinct(d$model_name),
      .before = 1
    )
}

q5_calibration_pooled_lmer <- bind_rows(
  fit_q5_pooled_lmer(
    pred_error, FALSE, "confidence + model", "five_model"),
  fit_q5_pooled_lmer(
    combined, TRUE, "confidence + confusion + model", "five_model")
) %>%
  dplyr::select(
    spec, model_set, n_rows, n_scenarios, n_models,
    effect, term, estimate, std.error, statistic, df, p.value,
    conf.low, conf.high
  )

cat("\n-- Q5 clustering-robust companion: scenario random intercept (supplementary) --\n")
print(as.data.frame(
  q5_calibration_pooled_lmer %>%
    filter(term %in% c("rating_confidence_z", "mean_confusion_z")) %>%
    dplyr::select(spec, model_set, term, estimate, std.error, df, p.value) %>%
    mutate(across(where(is.numeric), ~ round(.x, 4)))
), row.names = FALSE)

write.csv(q5_calibration_pooled_lmer,
          file.path(out_dir, "table_q5_calibration_pooled_lmer.csv"),
          row.names = FALSE)

cat("\n-- confidence -> abs_error, rating_confidence coefficient --\n")
print(as.data.frame(
  bind_rows(
    confidence_error_lm_tidy %>% mutate(spec = "confidence + model"),
    confidence_error_model_controls_lm_tidy %>%
      mutate(spec = "confidence + confusion + model")
  ) %>%
    filter(term == "rating_confidence") %>%
    dplyr::select(spec, model_set, n, df_residual, estimate, std.error,
                  statistic, p.value, p_holm) %>%
    mutate(across(where(is.numeric), ~ round(.x, 4)))
), row.names = FALSE)


# Test whether predicted human variation tracks observed human SD, separately for each model.
cat("\n── Q3: model-predicted variation vs human SD and human confusion ──\n")

q3_variation_df <- confidence_estimates %>%
  mutate(input_id = canonical_scenario_id(input_id)) %>%
  filter(input_id %in% scenarios_with_humans, !is.na(variation_estimate)) %>%
  dplyr::select(input_id, model_name, variation_estimate) %>%
  mutate(model_label = recode(model_name, !!!model_labels, .default = model_name)) %>%
  inner_join(human_stats %>% dplyr::select(input_id, human_sd), by = "input_id") %>%
  left_join(human_confuse_means %>% dplyr::select(input_id, mean_confusion),
            by = "input_id")

audit_record(
  "Q3 validity", "confidence rows on present-paper scope with parsed Q3",
  rows_in = nrow(confidence_estimates), rows_out = nrow(q3_variation_df),
  reason = "restrict to the 144 present-paper scenarios the manuscript scope uses",
  detail = paste0("models: ", n_distinct(q3_variation_df$model_name),
                  "; scenarios: ", n_distinct(q3_variation_df$input_id))
)

q3_test_one <- function(d, outcome_col, outcome_label) {
  d <- d %>% filter(!is.na(.data[[outcome_col]]))
  if (nrow(d) < 4) return(tibble())
  y <- d[[outcome_col]]
  x <- d$variation_estimate
  ct <- stats::cor.test(x, y)
  tb <- broom::tidy(stats::lm(y ~ x), conf.int = TRUE)[2, ]
  tz <- broom::tidy(stats::lm(as.numeric(scale(y)) ~ as.numeric(scale(x))),
                    conf.int = TRUE)[2, ]
  tibble(
    outcome = outcome_label, n = nrow(d),
    r = unname(ct$estimate), r_ci_low = ct$conf.int[1], r_ci_high = ct$conf.int[2],
    t = unname(ct$statistic), df = unname(ct$parameter), p_value = ct$p.value,
    b_unstd = tb$estimate, se_unstd = tb$std.error,
    beta_std = tz$estimate, se_std = tz$std.error
  )
}

q3_variation_validity <- q3_variation_df %>%
  group_by(model_name, model_label) %>%
  group_modify(~ bind_rows(
    q3_test_one(.x, "human_sd", "human_sd"),
    q3_test_one(.x, "mean_confusion", "human_mean_confusion")
  )) %>%
  ungroup() %>%
  # Holm within the family: the ten per-model tests (5 models x 2 criteria).
  mutate(p_holm = stats::p.adjust(p_value, method = "holm")) %>%
  arrange(outcome, model_name)

print(as.data.frame(
  q3_variation_validity %>% mutate(across(where(is.numeric), ~ round(.x, 4)))
), row.names = FALSE)

if (!(requireNamespace("lme4", quietly = TRUE) &&
      requireNamespace("lmerTest", quietly = TRUE) &&
      requireNamespace("broom.mixed", quietly = TRUE))) {
  stop("Q3 pooled model requires lme4, lmerTest, and broom.mixed.")
}
q3_pooled_rows <- list()
for (q3_oc in c("human_sd", "mean_confusion")) {
  q3_d <- q3_variation_df %>%
    filter(!is.na(.data[[q3_oc]])) %>%
    mutate(
      criterion_z = as.numeric(scale(.data[[q3_oc]])),
      variation_z = as.numeric(scale(variation_estimate))
    )
  if (nrow(q3_d) < 10) next
  q3_fit <- lmerTest::lmer(
    variation_z ~ criterion_z + model_name + (1 | input_id),
    data = q3_d
  )
  q3_pooled_rows[[q3_oc]] <- broom.mixed::tidy(
    q3_fit, effects = "fixed", conf.int = TRUE
  ) %>%
    filter(term == "criterion_z") %>%
    mutate(
      outcome = q3_oc, n_rows = nrow(q3_d),
      n_scenarios = dplyr::n_distinct(q3_d$input_id),
      n_models = dplyr::n_distinct(q3_d$model_name),
      .before = 1
    )
}
q3_pooled_lmer <- bind_rows(q3_pooled_rows)
cat("\n  Pooled (scenario random intercept), standardized:\n")
print(as.data.frame(q3_pooled_lmer), row.names = FALSE)

q3_scale_use <- confidence_estimates %>%
  mutate(input_id = canonical_scenario_id(input_id)) %>%
  filter(input_id %in% scenarios_with_humans) %>%
  tidyr::pivot_longer(
    c(confusion_estimate, variation_estimate, sd_estimate, rating_confidence),
    names_to = "measure", values_to = "value"
  ) %>%
  filter(!is.na(value)) %>%
  group_by(model_name, measure) %>%
  summarise(
    n = n(), min_value = min(value), max_value = max(value),
    n_distinct_values = dplyr::n_distinct(value), sd_value = sd(value),
    .groups = "drop"
  ) %>%
  mutate(limitation = ifelse(
    model_name == "qwen-3-32B" & measure == "confusion_estimate" &
      max_value <= 3,
    "restricted range: qwen confusion ratings span 1-3; associations attenuated",
    ""
  ))
cat("\n  Scale use (restriction-of-range check):\n")
print(as.data.frame(q3_scale_use), row.names = FALSE)

write.csv(q3_variation_validity,
          file.path(out_dir, "table_q3_predicted_variation_validity.csv"),
          row.names = FALSE)
write.csv(q3_pooled_lmer,
          file.path(out_dir, "table_q3_predicted_variation_pooled_lmer.csv"),
          row.names = FALSE)
write.csv(q3_scale_use,
          file.path(out_dir, "table_q3_confidence_scale_use.csv"),
          row.names = FALSE)


present_paper_mean_fit <- model_means_primary %>%
  inner_join(
    human_stats %>%
      dplyr::select(input_id, human_mean, scenario_type),
    by = "input_id"
  ) %>%
  filter(scenario_type %in% c("present_paper_new", "present_paper_old")) %>%
  mutate(
    scenario_version = recode(
      scenario_type,
      "present_paper_new" = "new",
      "present_paper_old" = "old"
    ),
    model_label = recode(model_name, !!!model_labels, .default = model_name)
  ) %>%
  group_by(model_name, model_label, source, prompt_measure, scenario_version) %>%
  summarise(
    r = safe_cor(pred_mean, human_mean),
    mse = mean((pred_mean - human_mean)^2, na.rm = TRUE),
    mae = mean(abs(pred_mean - human_mean), na.rm = TRUE),
    n_scenarios = n_distinct(input_id),
    .groups = "drop"
  ) %>%
  arrange(model_name, scenario_version)

print(present_paper_mean_fit, n = Inf)

present_paper_predhuman_ttests <- model_means_primary %>%
  inner_join(
    human_stats %>%
      dplyr::select(input_id, human_mean, scenario_type),
    by = "input_id"
  ) %>%
  filter(
    scenario_type %in% c("present_paper_new", "present_paper_old"),
    model_name %in% writeup_models_focal
  ) %>%
  mutate(
    scenario_version = recode(
      scenario_type,
      "present_paper_new" = "new",
      "present_paper_old" = "old"
    ),
    model_label = recode(model_name, !!!model_labels, .default = model_name),
    diff = pred_mean - human_mean
  ) %>%
  group_by(model_label, scenario_version) %>%
  group_modify(~ {
    x <- .x %>% filter(!is.na(pred_mean), !is.na(human_mean))
    mean_diff <- mean(x$diff, na.rm = TRUE)
    diff_sd <- sd(x$diff, na.rm = TRUE)

    dz <- ifelse(
      !is.na(diff_sd) && diff_sd > 0,
      mean_diff / diff_sd,
      NA_real_
    )

    if (nrow(x) < 2 || is.na(diff_sd) || diff_sd == 0) {
      return(tibble(
        mean_model = mean(x$pred_mean, na.rm = TRUE),
        mean_human = mean(x$human_mean, na.rm = TRUE),
        mean_diff = mean_diff,
        t = NA_real_,
        df = NA_real_,
        p = NA_real_,
        ci_low = NA_real_,
        ci_high = NA_real_,
        dz = dz,
        n_scenarios = n_distinct(x$input_id)
      ))
    }

    tt <- t.test(x$pred_mean, x$human_mean, paired = TRUE)

    tibble(
      mean_model = mean(x$pred_mean, na.rm = TRUE),
      mean_human = mean(x$human_mean, na.rm = TRUE),
      mean_diff = mean_diff,
      t = unname(tt$statistic),
      df = unname(tt$parameter),
      p = tt$p.value,
      ci_low = tt$conf.int[1],
      ci_high = tt$conf.int[2],
      dz = dz,
      n_scenarios = n_distinct(x$input_id)
    )
  }) %>%
  ungroup() %>%
  arrange(model_label, scenario_version)

print(present_paper_predhuman_ttests, n = Inf)

# Apply Holm adjustment

scen_holm_family <- function(p) {
  p <- as.numeric(p)
  if (any(!is.na(p) & (!is.finite(p) | p < 0 | p > 1)))
    stop("Invalid p-value in Scenarios Holm family.")
  n_tested <- sum(!is.na(p))
  adjusted <- stats::p.adjust(p, method = "holm", n = n_tested)
  data.frame(
    n_planned = rep(length(p), length(p)),
    n_tested = rep(n_tested, length(p)),
    n_in_family = rep(n_tested, length(p)),
    holm_policy = rep("Holm over estimable tests; NA tests excluded", length(p)),
    p_holm = adjusted, sig_raw = p < .05, sig_holm = adjusted < .05,
    flipped_by_correction = (p < .05) & !(adjusted < .05)
  )
}

.scen_reporting_env <- environment()
e3_registry <- list()

e3_add <- function(obj_name, family, p_col = "p", label_cols = character()) {
  if (!exists(obj_name, envir = .scen_reporting_env, inherits = FALSE)) return(invisible(NULL))
  x <- get(obj_name, envir = .scen_reporting_env, inherits = FALSE)
  if (!is.data.frame(x) || !p_col %in% names(x) || nrow(x) == 0) return(invisible(NULL))
  e3_registry[[length(e3_registry) + 1L]] <<- tibble(
    object = obj_name, family = family, row_index = seq_len(nrow(x)),
    label = if (length(label_cols) && all(label_cols %in% names(x))) {
      apply(x[, label_cols, drop = FALSE], 1, function(r) paste(r, collapse = " | "))
    } else NA_character_,
    p_raw = as.numeric(x[[p_col]])
  )
  invisible(NULL)
}

e3_add("present_paper_predhuman_ttests", "predhuman_directional_bias", "p",
       c("model_label", "scenario_version"))
e3_add("wording_confusion_paired_present_paper", "wording_confusion", "p", c("outcome", "comparison"))
e3_add("wording_confusion_paired_schroeder",     "wording_confusion", "p", c("outcome", "comparison"))
e3_add("wording_confusion_collapsed",            "wording_confusion", "p", c("outcome", "comparison"))
e3_add("wording_sd_paired_present_paper",        "wording_human_sd",  "p", c("outcome", "comparison"))
e3_add("wording_sd_paired_schroeder",            "wording_human_sd",  "p", c("outcome", "comparison"))
e3_add("wording_sd_collapsed",                   "wording_human_sd",  "p", c("outcome", "comparison"))

if (length(e3_registry) > 0) {
  e3_corrections <- bind_rows(e3_registry) %>%
    group_by(family) %>%
    group_modify(~ bind_cols(.x, scen_holm_family(.x$p_raw))) %>%
    ungroup()

  # Write the adjusted p back onto each source object so the exported tables
  # carry both columns.
  for (nm in unique(e3_corrections$object)) {
    x <- get(nm, envir = .scen_reporting_env, inherits = FALSE)
    add <- e3_corrections %>% filter(object == nm) %>% arrange(row_index)
    x$p_raw <- add$p_raw
    x$p_holm <- add$p_holm
    x$holm_family <- add$family
    x$n_tests_in_family <- add$n_in_family
    x$n_planned <- add$n_planned
    x$n_tested <- add$n_tested
    x$holm_policy <- add$holm_policy
    assign(nm, x, envir = .scen_reporting_env)
  }

  cat("  Families and sizes:\n")
  print(as.data.frame(
    e3_corrections %>% distinct(family, n_planned, n_tested, n_in_family)
  ))
  cat("\n  Tests significant raw but NOT after Holm:",
      sum(e3_corrections$flipped_by_correction, na.rm = TRUE), "of",
      sum(e3_corrections$sig_raw, na.rm = TRUE), "raw-significant\n")
  if (any(e3_corrections$flipped_by_correction, na.rm = TRUE)) {
    cat("  ⚠ These claims do not survive correction:\n")
    print(as.data.frame(
      e3_corrections %>%
        filter(flipped_by_correction) %>%
        dplyr::select(family, object, label, p_raw, p_holm)
    ))
  }

  write.csv(e3_corrections,
            file.path(out_dir, "table_e3_multiple_comparison_corrections.csv"),
            row.names = FALSE)
}

write.csv(mean_comparison, file.path(out_dir,"table_mean_comparison.csv"), row.names=FALSE)
write.csv(sd_comparison, file.path(out_dir,"table_sd_comparison.csv"), row.names=FALSE)
write.csv(dist_summary, file.path(out_dir,"table_dist_summary.csv"), row.names=FALSE)
expanded_coverage_and_fit <- dist_by_scenario %>%
  filter(method == "distribution_full") %>%
  left_join(a84_diag %>% select(model_name, input_id, fit_status), by = c("model_name", "input_id"))
stopifnot(!anyNA(expanded_coverage_and_fit$fit_status))
expanded_sensitivity <- bind_rows(
  expanded_coverage_and_fit %>% mutate(frame = "all_usable_including_fallbacks"),
  expanded_coverage_and_fit %>% filter(fit_status %in% c("converged_moment_fit", "exact_point_mass", "exact_feasible_repair")) %>%
    mutate(frame = "moment_accurate_reconstructions_only")
) %>% group_by(model_name, frame) %>%
  summarise(n_cells = n(), across(c(tvd, emd, jsd), ~ mean(.x, na.rm = TRUE)), .groups = "drop")
write.csv(expanded_sensitivity, file.path(out_dir, "table_expanded_success_sensitivity.csv"), row.names = FALSE)
# Every method is compared on the same moment-accurate Expanded cells within model.
expanded_matched_sensitivity <- dist_by_scenario %>%
  filter(method %in% focal_distribution_methods,
         if_all(c(tvd, emd, jsd), ~ is.finite(.x))) %>%
  semi_join(a84_diag %>% filter(fit_status %in% c("converged_moment_fit", "exact_point_mass", "exact_feasible_repair")),
            by = c("model_name", "input_id")) %>%
  group_by(model_name, input_id) %>%
  filter(n_distinct(method) == length(focal_distribution_methods)) %>% ungroup() %>%
  group_by(model_name, method) %>%
  summarise(n_cells = n(), across(c(tvd, emd, jsd), ~ mean(.x, na.rm = TRUE)), .groups = "drop")
write.csv(expanded_matched_sensitivity,
          file.path(out_dir, "table_methods_matched_successful_expanded.csv"), row.names = FALSE)

write.csv(dist_by_method, file.path(out_dir,"table_dist_by_method.csv"), row.names=FALSE)
write.csv(dist_by_type, file.path(out_dir,"table_dist_by_type.csv"), row.names=FALSE)
write.csv(relabel_scenario_version(robustness), file.path(out_dir,"table_robustness.csv"), row.names=FALSE)
write.csv(relabel_scenario_version(dist_by_scenario), file.path(out_dir,"dist_by_scenario.csv"), row.names=FALSE)
write.csv(present_paper_focal_pooled_distribution_methods %>% mutate(across(c(TVD, EMD, JSD), ~ round(.x, 3))), file.path(out_dir,"table_present_paper_distribution_methods_models_pooled.csv"), row.names=FALSE)
write.csv(relabel_scenario_version(present_paper_focal_old_new_methods_paper), file.path(out_dir,"table_present_paper_distribution_methods_old_vs_new_models_avg.csv"), row.names=FALSE)
write.csv(relabel_scenario_version(present_paper_focal_old_new_best), file.path(out_dir,"table_present_paper_distribution_best_methods_old_vs_new_models_avg.csv"), row.names=FALSE)
write.csv(present_paper_focal_old_new_by_model %>% mutate(across(c(TVD, EMD, JSD), ~ round(.x, 3))) %>% relabel_scenario_version(), file.path(out_dir,"table_present_paper_distribution_methods_old_vs_new_by_model.csv"), row.names=FALSE)
write.csv(relabel_scenario_version(present_paper_focal_best_emd_by_model), file.path(out_dir,"table_present_paper_best_emd_methods_old_vs_new_by_model.csv"), row.names=FALSE)
write.csv(relabel_scenario_version(wording_confusion_summary), file.path(out_dir,"table_wording_confusion_summary_present_paper_and_schroeder.csv"), row.names=FALSE)
write.csv(wording_confusion_pairwise, file.path(out_dir,"table_wording_confusion_pairwise_present_paper_and_schroeder.csv"), row.names=FALSE)
if (exists("wording_confusion_paired_schroeder")) write.csv(wording_confusion_paired_schroeder, file.path(out_dir,"table_wording_confusion_paired_schroeder_new_vs_old.csv"), row.names=FALSE)
if (exists("wording_confusion_collapsed")) write.csv(wording_confusion_collapsed, file.path(out_dir,"table_wording_confusion_schroeder_vs_present_paper_collapsed.csv"), row.names=FALSE)
if (exists("wording_confusion_paired_present_paper")) write.csv(wording_confusion_paired_present_paper, file.path(out_dir,"table_wording_confusion_paired_present_paper_new_vs_old.csv"), row.names=FALSE)
write.csv(relabel_scenario_version(wording_sd_summary), file.path(out_dir,"table_wording_human_sd_summary_present_paper_and_schroeder.csv"), row.names=FALSE)
write.csv(wording_sd_pairwise, file.path(out_dir,"table_wording_human_sd_pairwise_present_paper_and_schroeder.csv"), row.names=FALSE)
if (exists("wording_sd_paired_schroeder")) write.csv(wording_sd_paired_schroeder, file.path(out_dir,"table_wording_human_sd_paired_schroeder_new_vs_old.csv"), row.names=FALSE)
if (exists("wording_sd_paired_present_paper")) write.csv(wording_sd_paired_present_paper, file.path(out_dir,"table_wording_human_sd_paired_present_paper_new_vs_old.csv"), row.names=FALSE)
if (exists("wording_sd_collapsed")) write.csv(wording_sd_collapsed, file.path(out_dir,"table_wording_human_sd_schroeder_vs_present_paper_collapsed.csv"), row.names=FALSE)
write.csv(wording_mean_fit %>% mutate(across(c(r, mse, mae), ~ round(.x, 3))) %>% relabel_scenario_version(), file.path(out_dir,"table_wording_mean_fit_present_paper_and_schroeder.csv"), row.names=FALSE)
write.csv(relabel_scenario_version(wording_confusion_sd), file.path(out_dir,"table_wording_confusion_human_sd_present_paper_and_schroeder.csv"), row.names=FALSE)
write.csv(relabel_scenario_version(present_paper_mean_fit), file.path(out_dir,"table_present_paper_mean_fit_old_vs_new.csv"), row.names=FALSE)
write.csv(relabel_scenario_version(present_paper_predhuman_ttests), file.path(out_dir,"table_present_paper_predhuman_ttests_old_vs_new.csv"), row.names=FALSE)
if (exists("model_predicted_confusion_results")) write.csv(model_predicted_confusion_results, file.path(out_dir,"table_q2_predicted_confusion.csv"), row.names=FALSE)
if (exists("confidence_error_lm_tidy")) write.csv(confidence_error_lm_tidy, file.path(out_dir,"table_confidence_error_lm.csv"), row.names=FALSE)
if (exists("confidence_error_model_controls_lm_tidy")) write.csv(confidence_error_model_controls_lm_tidy, file.path(out_dir,"table_confidence_error_model_controls_lm.csv"), row.names=FALSE)


# Distribution-method comparisons, implied SDs and uncertainty analyses.

e_have_lmer    <- requireNamespace("lme4", quietly = TRUE) &&
                  requireNamespace("lmerTest", quietly = TRUE)
e_have_emmeans <- requireNamespace("emmeans", quietly = TRUE)
e_have_mumin   <- requireNamespace("MuMIn", quietly = TRUE)
e_have_broom_mixed <- requireNamespace("broom.mixed", quietly = TRUE)

cat("  lme4/lmerTest:", e_have_lmer,
    " emmeans:", e_have_emmeans,
    " MuMIn:", e_have_mumin,
    " broom.mixed:", e_have_broom_mixed, "\n")

if (!all(c(e_have_lmer, e_have_emmeans, e_have_mumin, e_have_broom_mixed))) {
  stop(
    "Part E requires lme4, lmerTest, emmeans, MuMIn, and broom.mixed; ",
    "install the missing package(s) before running the paper analyses."
  )
}

E_METRICS <- c("tvd", "emd", "jsd")
E_BOOT_R <- as.integer(Sys.getenv("SCEN_BOOT_R", unset = "2000"))


# Compare methods on matched scenarios and export confidence intervals and adjusted tests.
cat("\n", strrep("-", 70),
    "\nE1 — METHOD DIFFERENCES: CONTRASTS, CIs, ADJUSTED p\n", strrep("-", 70), "\n")

e1_all_methods <- sort(focal_distribution_methods)
cat("  Methods:", paste(e1_all_methods, collapse = ", "), "\n")

e1_matched <- dist_by_scenario %>%
  filter(method %in% e1_all_methods) %>%
  filter(if_all(all_of(E_METRICS), ~ !is.na(.x))) %>%
  group_by(model_name, input_id) %>%
  filter(n_distinct(method) == length(e1_all_methods)) %>%
  ungroup() %>%
  mutate(method = factor(method, levels = e1_all_methods))

cat("  Matched subset:", nrow(e1_matched), "rows,",
    n_distinct(e1_matched$input_id), "items,",
    n_distinct(e1_matched$model_name), "models\n")

e1_coverage <- dist_by_scenario %>%
  group_by(model_name) %>%
  summarise(items_any_method = n_distinct(input_id), .groups = "drop") %>%
  left_join(
    e1_matched %>%
      group_by(model_name) %>%
      summarise(items_all_methods = n_distinct(input_id), .groups = "drop"),
    by = "model_name"
  ) %>%
  mutate(items_all_methods = tidyr::replace_na(items_all_methods, 0L))

if (!setequal(unique(e1_matched$model_name), wording_models_focal) ||
    any(e1_coverage$items_all_methods == 0L)) {
  readr::write_csv(
    e1_coverage,
    file.path(out_dir, "CHECK_e1_model_method_coverage.csv")
  )
  stop(
    "Scenario E1 must retain matched five-method items for all five focal models; ",
    "see CHECK_e1_model_method_coverage.csv."
  )
}

cat("\n  Item coverage per model (any method vs. all methods):\n")
print(as.data.frame(e1_coverage))

audit_record(
  "E1 method contrasts", "restrict to items where every method produced output",
  rows_in = nrow(dist_by_scenario), rows_out = nrow(e1_matched),
  keys_in = n_distinct(dist_by_scenario$input_id),
  keys_out = n_distinct(e1_matched$input_id),
  reason = "unmatched items would let a method look better by being scored on an easier subset",
  detail = paste0("methods required: ", length(e1_all_methods))
)

e1_emmeans_rows <- list()
e1_contrast_rows <- list()

if (e_have_lmer && e_have_emmeans && nrow(e1_matched) > 0) {
  for (mdl in sort(unique(e1_matched$model_name))) {
    for (met in E_METRICS) {
      dat <- e1_matched %>%
        filter(model_name == mdl) %>%
        mutate(.y = .data[[met]]) %>%
        filter(!is.na(.y))
      if (n_distinct(dat$method) < 2 || n_distinct(dat$input_id) < 3) next

      fit <- try(
        lmerTest::lmer(.y ~ method + (1 | input_id), data = dat),
        silent = TRUE
      )
      if (inherits(fit, "try-error")) {
        cat("  ⚠ lmer failed:", mdl, met, "\n")
        next
      }

      emm <- try(emmeans::emmeans(fit, ~ method), silent = TRUE)
      if (inherits(emm, "try-error")) next

      ctr <- try(
        as.data.frame(summary(
          emmeans::contrast(emm, method = "pairwise", adjust = "holm"),
          infer = c(TRUE, TRUE)
        )),
        silent = TRUE
      )
      ctr_raw <- try(
        as.data.frame(summary(
          emmeans::contrast(emm, method = "pairwise", adjust = "none"),
          infer = c(TRUE, TRUE)
        )),
        silent = TRUE
      )
      if (inherits(ctr, "try-error")) next

      resid_sd <- stats::sigma(fit)

      e1_emmeans_rows[[length(e1_emmeans_rows) + 1]] <- as.data.frame(emm) %>%
        mutate(model_name = mdl, metric = met, !!!as.list(model_fit_diagnostics(fit)), .before = 1)

      ctr_out <- ctr %>%
        mutate(
          model_name = mdl,
          metric = met, !!!as.list(model_fit_diagnostics(fit)),
          p_raw = if (!inherits(ctr_raw, "try-error")) ctr_raw$p.value else NA_real_,
          p_holm = p.value,
          ci_low_simultaneous = lower.CL,
          ci_high_simultaneous = upper.CL,
          # Per-contrast unadjusted interval
          ci_low_unadjusted = if (!inherits(ctr_raw, "try-error")) ctr_raw$lower.CL else NA_real_,
          ci_high_unadjusted = if (!inherits(ctr_raw, "try-error")) ctr_raw$upper.CL else NA_real_,
          residual_sd = resid_sd,
          std_contrast_resid_sd = estimate / resid_sd,
          .before = 1
        ) %>%
        mutate(
          holm_sig_but_simultaneous_ci_spans_zero =
            p_holm < .05 & (ci_low_simultaneous <= 0 & ci_high_simultaneous >= 0),
          bound_nearest_zero_unadjusted =
            pmin(abs(ci_low_unadjusted), abs(ci_high_unadjusted))
        )
      e1_contrast_rows[[length(e1_contrast_rows) + 1]] <- ctr_out
    }
  }
}

if (length(e1_contrast_rows) > 0) {
  e1_method_contrasts <- bind_rows(e1_contrast_rows)
  e1_method_emmeans <- bind_rows(e1_emmeans_rows)
  expected_e1_contrasts <- n_distinct(e1_matched$model_name) *
    length(E_METRICS) * choose(length(e1_all_methods), 2)
  if (nrow(e1_method_contrasts) != expected_e1_contrasts) {
    write.csv(
      e1_method_contrasts,
      file.path(out_dir, "CHECK_e1_incomplete_method_contrasts.csv"),
      row.names = FALSE
    )
    stop(
      "Scenario E1 produced ", nrow(e1_method_contrasts), " contrasts; expected ",
      expected_e1_contrasts,
      ". See CHECK_e1_incomplete_method_contrasts.csv."
    )
  }
  write.csv(e1_method_contrasts, file.path(out_dir, "table_e1_method_contrasts.csv"), row.names = FALSE)
  write.csv(e1_method_emmeans, file.path(out_dir, "table_e1_method_emmeans.csv"), row.names = FALSE)
  cat("\n  Wrote", nrow(e1_method_contrasts), "contrasts across",
      n_distinct(e1_method_contrasts$model_name), "models x", length(E_METRICS), "metrics\n")
  cat("  Contrasts significant after Holm (within model x metric):",
      sum(e1_method_contrasts$p_holm < .05, na.rm = TRUE), "of",
      nrow(e1_method_contrasts), "\n")
  cat("  Of those, simultaneous (Bonferroni-width) CI still spans zero:",
      sum(e1_method_contrasts$holm_sig_but_simultaneous_ci_spans_zero, na.rm = TRUE),
      "— Holm and the interval use different corrections; not a contradiction.\n")

  # Which significant contrasts are small enough that Monte Carlo noise in the
  # underlying method means would matter?
  E1_MC_FLOOR <- 0.00814
  E1_SIMULATED_METHODS <- c("distribution_full", "direct_proportions")
  e1_is_simulated <- function(contrast_label) {
    parts <- trimws(strsplit(as.character(contrast_label), " - ", fixed = TRUE)[[1]])
    any(parts %in% E1_SIMULATED_METHODS)
  }
  e1_fragile <- e1_method_contrasts %>%
    filter(p_holm < .05, !is.na(bound_nearest_zero_unadjusted)) %>%
    mutate(
      involves_simulated_method = vapply(contrast, e1_is_simulated, logical(1)),
      bound_vs_mc_floor = bound_nearest_zero_unadjusted / E1_MC_FLOOR,
      below_mc_floor = bound_nearest_zero_unadjusted < E1_MC_FLOOR
    ) %>%
    filter(bound_nearest_zero_unadjusted < 0.02) %>%
    arrange(bound_nearest_zero_unadjusted)

  write.csv(e1_fragile, file.path(out_dir, "table_e1_contrasts_near_zero.csv"), row.names = FALSE)
  cat("  Significant contrasts with unadjusted CI bound within 0.02 of zero:",
      nrow(e1_fragile), "\n")
  cat("    of those, involving a still-simulated method:",
      sum(e1_fragile$involves_simulated_method), "\n")
  cat("    of those, below the heuristic threshold AND simulated:",
      sum(e1_fragile$involves_simulated_method & e1_fragile$below_mc_floor),
      "— flagged for Monte Carlo sensitivity checks\n")
  cat("  This threshold cannot establish seed stability or rule out other changes.\n")
} else {
  stop("Scenario E1 did not produce any method contrasts.")
}

# Cluster bootstrap over items for each method's mean metric.
set.seed(20260804)
e1_boot_rows <- list()
if (nrow(e1_matched) > 0) {
  for (mdl in sort(unique(e1_matched$model_name))) {
    dat <- e1_matched %>% filter(model_name == mdl)
    items <- unique(dat$input_id)
    if (length(items) < 3) next
    idx <- split(seq_len(nrow(dat)), dat$input_id)

    for (met in E_METRICS) {
      obs <- dat %>%
        group_by(method) %>%
        summarise(mean_metric = mean(.data[[met]], na.rm = TRUE), .groups = "drop")

      boots <- matrix(NA_real_, nrow = E_BOOT_R, ncol = nlevels(dat$method),
                      dimnames = list(NULL, levels(dat$method)))
      for (b in seq_len(E_BOOT_R)) {
        take <- sample(items, length(items), replace = TRUE)
        rows <- unlist(idx[take], use.names = FALSE)
        bd <- dat[rows, ]
        agg <- tapply(bd[[met]], bd$method, mean, na.rm = TRUE)
        boots[b, names(agg)] <- agg
      }

      e1_boot_rows[[length(e1_boot_rows) + 1]] <- obs %>%
        rowwise() %>%
        mutate(
          model_name = mdl,
          metric = met,
          ci_low  = unname(stats::quantile(boots[, as.character(method)], .025, na.rm = TRUE)),
          ci_high = unname(stats::quantile(boots[, as.character(method)], .975, na.rm = TRUE)),
          boot_se = stats::sd(boots[, as.character(method)], na.rm = TRUE),
          n_items = length(items),
          n_boot  = E_BOOT_R
        ) %>%
        ungroup()
    }
  }
}

if (length(e1_boot_rows) > 0) {
  e1_method_cluster_bootstrap <- bind_rows(e1_boot_rows) %>%
    dplyr::select(model_name, metric, method, mean_metric, ci_low, ci_high,
                  boot_se, n_items, n_boot)
  write.csv(e1_method_cluster_bootstrap,
            file.path(out_dir, "table_e1_method_cluster_bootstrap.csv"), row.names = FALSE)
  cat("  Wrote cluster-bootstrap CIs:", nrow(e1_method_cluster_bootstrap), "rows\n")
}

e1_friedman_rows <- list()
e1_win_rows <- list()
if (nrow(e1_matched) > 0) {
  for (mdl in sort(unique(e1_matched$model_name))) {
    dat <- e1_matched %>% filter(model_name == mdl)
    items <- unique(dat$input_id)
    for (met in E_METRICS) {
      wide <- dat %>%
        dplyr::select(input_id, method, all_of(met)) %>%
        tidyr::pivot_wider(names_from = method, values_from = all_of(met)) %>%
        tidyr::drop_na()
      if (nrow(wide) < 3 || ncol(wide) < 3) next
      mat <- as.matrix(wide[, -1, drop = FALSE])

      ft <- try(stats::friedman.test(mat), silent = TRUE)
      if (!inherits(ft, "try-error")) {
        e1_friedman_rows[[length(e1_friedman_rows) + 1]] <- tibble(
          model_name = mdl, metric = met,
          chi_sq = unname(ft$statistic), df = unname(ft$parameter),
          p_value = ft$p.value, n_items = nrow(mat), n_methods = ncol(mat)
        )
      }

      # Split credit equally among exact tied minima, including component fallbacks.
      win_credit <- (mat == apply(mat, 1, min))
      win_credit <- win_credit / rowSums(win_credit)
      obs_win <- colMeans(win_credit)
      bw <- matrix(NA_real_, nrow = E_BOOT_R, ncol = ncol(mat),
                   dimnames = list(NULL, colnames(mat)))
      for (b in seq_len(E_BOOT_R)) {
        take <- sample(seq_len(nrow(mat)), nrow(mat), replace = TRUE)
        bw[b, ] <- colMeans(win_credit[take, , drop = FALSE])
      }
      e1_win_rows[[length(e1_win_rows) + 1]] <- tibble(
        model_name = mdl, metric = met, method = colnames(mat),
        win_proportion = as.numeric(obs_win),
        ci_low  = apply(bw, 2, stats::quantile, .025, na.rm = TRUE),
        ci_high = apply(bw, 2, stats::quantile, .975, na.rm = TRUE),
        n_items = nrow(mat), n_boot = E_BOOT_R
      )
    }
  }
}

if (length(e1_friedman_rows) > 0) {
  e1_friedman <- bind_rows(e1_friedman_rows)
  write.csv(e1_friedman, file.path(out_dir, "table_e1_friedman.csv"), row.names = FALSE)
  cat("  Wrote Friedman tests:", nrow(e1_friedman), "rows\n")
}
if (length(e1_win_rows) > 0) {
  e1_method_win_rates <- bind_rows(e1_win_rows)
  write.csv(e1_method_win_rates, file.path(out_dir, "table_e1_method_win_rates.csv"), row.names = FALSE)
  cat("  Wrote method win rates:", nrow(e1_method_win_rates), "rows\n")
}


# Compare model-implied and human SDs for every estimation method.
cat("\n", strrep("-", 70),
    "\nE2 — IMPLIED SD VERSUS HUMAN SD\n", strrep("-", 70), "\n")

e2_implied <- sim_props %>%
  filter(method %in% e1_all_methods) %>%
  mutate(y = as.numeric(as.character(bin))) %>%
  filter(!is.na(sim_prop), !is.na(y)) %>%
  group_by(input_id, model_name, method) %>%
  summarise(
    p_total = sum(sim_prop, na.rm = TRUE),
    implied_mean = sum(y * sim_prop, na.rm = TRUE) / sum(sim_prop, na.rm = TRUE),
    implied_sd = sqrt(pmax(
      0,
      sum(sim_prop * y^2, na.rm = TRUE) / sum(sim_prop, na.rm = TRUE) -
        (sum(y * sim_prop, na.rm = TRUE) / sum(sim_prop, na.rm = TRUE))^2
    )),
    .groups = "drop"
  ) %>%
  filter(p_total > 0)

E2_MIN_HUMAN_SD <- 0.25

e2_joined <- e2_implied %>%
  inner_join(human_stats %>% dplyr::select(input_id, human_sd, human_mean, scenario_type),
             by = "input_id") %>%
  filter(scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES, !is.na(human_sd)) %>%
  mutate(ratio_eligible = is.finite(human_sd) & human_sd >= E2_MIN_HUMAN_SD &
           is.finite(implied_sd) & implied_sd > 0)

audit_record(
  "E2 implied SD", "join implied SD to human SD",
  rows_in = nrow(e2_implied), rows_out = nrow(e2_joined),
  keys_in = n_distinct(e2_implied$input_id), keys_out = n_distinct(e2_joined$input_id),
  reason = "restricted to present-paper scenarios with a human SD",
  detail = "implied SD computed from the binned model distribution"
)

e2_sd_by_method <- e2_joined %>%
  group_by(model_name, method) %>%
  summarise(
    n_items = n(),
    mean_implied_sd = mean(implied_sd, na.rm = TRUE),
    mean_human_sd = mean(human_sd, na.rm = TRUE),
    mean_bias = mean(implied_sd - human_sd, na.rm = TRUE),
    mae = mean(abs(implied_sd - human_sd), na.rm = TRUE),
    rmse = sqrt(mean((implied_sd - human_sd)^2, na.rm = TRUE)),
    r = suppressWarnings(stats::cor(implied_sd, human_sd, use = "complete.obs")),
    n_ratio_items = sum(ratio_eligible),
    n_zero_implied_sd = sum(is.finite(implied_sd) & implied_sd == 0),
    n_zero_implied_sd_eligible_human = sum(is.finite(implied_sd) & implied_sd == 0 &
      is.finite(human_sd) & human_sd >= E2_MIN_HUMAN_SD),
    median_log_ratio = if (any(ratio_eligible)) stats::median(
      log(implied_sd[ratio_eligible] / human_sd[ratio_eligible])) else NA_real_,
    .groups = "drop"
  ) %>%
  arrange(model_name, mean_bias)

# Correlation CIs via Fisher z.
e2_sd_by_method <- e2_sd_by_method %>%
  mutate(
    r_ci_low = ifelse(n_items > 3, tanh(atanh(r) - 1.96 / sqrt(n_items - 3)), NA_real_),
    r_ci_high = ifelse(n_items > 3, tanh(atanh(r) + 1.96 / sqrt(n_items - 3)), NA_real_)
  )

write.csv(e2_sd_by_method, file.path(out_dir, "table_e2_implied_sd_by_method.csv"), row.names = FALSE)
write.csv(e2_joined, file.path(out_dir, "table_e2_implied_sd_by_item.csv"), row.names = FALSE)

cat("\n  Implied vs human SD by method (pooled across models):\n")
print(
  e2_joined %>%
    group_by(method) %>%
    summarise(
      n = n(),
      mean_implied_sd = mean(implied_sd, na.rm = TRUE),
      mean_human_sd = mean(human_sd, na.rm = TRUE),
      mean_bias = mean(implied_sd - human_sd, na.rm = TRUE),
      mae = mean(abs(implied_sd - human_sd), na.rm = TRUE),
      r = suppressWarnings(stats::cor(implied_sd, human_sd, use = "complete.obs")),
      .groups = "drop"
    ) %>%
    arrange(mean_bias) %>%
    as.data.frame()
)

e2_plot_df <- e2_joined %>%
  dplyr::select(input_id, model_name, method, implied_sd, human_sd) %>%
  tidyr::pivot_longer(c(implied_sd, human_sd), names_to = "source", values_to = "sd_value") %>%
  mutate(source = recode(source, implied_sd = "Model-implied", human_sd = "Human"))

e2_plot <- ggplot(e2_plot_df, aes(x = method, y = sd_value, fill = source)) +
  geom_boxplot(outlier.size = 0.5, position = position_dodge(width = 0.8)) +
  scale_x_discrete(labels = c(Repeated_sampling = "Repeated", distribution_mean_sd = "Mean + SD",
    distribution_full = "Expanded", hybrid_proportions_mean_sd = "Hybrid",
    direct_proportions_analytic = "Proportions")) +
  facet_wrap(~ model_name, ncol = 2) +
  labs(
    title = "Model-implied SD versus empirical human SD, by method",
    subtitle = "Repeated sampling compresses variance relative to the direct-elicitation methods",
    x = "Method", y = "SD of the response distribution", fill = NULL
  ) +
  theme_minimal(base_size = 10) +
  theme(axis.text.x = element_text(angle = 35, hjust = 1), legend.position = "bottom")

e2_pdf <- file.path(out_dir, "figure_e2_implied_vs_human_sd.pdf")
save_figure_pdf_checked(e2_pdf, e2_plot, width = 11, height = 8,
  diagnostic_path = file.path(out_dir, "CHECK_e2_pdf_export.csv"), prefer_cairo = FALSE)


# Check whether EMD differences track implied-SD calibration.
if (exists("e2_sd_by_method")) {
  emd_gap_vs_calibration <- prop_vs_rep %>%
    mutate(emd_gap = direct_proportions_analytic - Repeated_sampling) %>%
    dplyr::select(model_name, emd_gap, proportions_worse_than_repeated) %>%
    left_join(
      e2_sd_by_method %>%
        filter(method == "direct_proportions_analytic") %>%
        transmute(model_name, prop_implied_sd = mean_implied_sd,
                  prop_bias = mean_bias, human_sd = mean_human_sd),
      by = "model_name"
    ) %>%
    left_join(
      e2_sd_by_method %>%
        filter(method == "Repeated_sampling") %>%
        transmute(model_name, rep_implied_sd = mean_implied_sd, rep_bias = mean_bias),
      by = "model_name"
    ) %>%
    arrange(emd_gap)

  write.csv(emd_gap_vs_calibration,
            file.path(out_dir, "table_emd_gap_vs_implied_sd_calibration.csv"),
            row.names = FALSE)

  cat("\n── Does the EMD split track implied-SD calibration? ──\n")
  print(as.data.frame(emd_gap_vs_calibration %>%
                        mutate(across(where(is.numeric), ~ round(.x, 4)))))
  if (nrow(emd_gap_vs_calibration) >= 4) {
    cat(sprintf(
      "\n  r(emd_gap, proportions over-dispersion) = %+.3f   (Spearman %+.3f)\n",
      stats::cor(emd_gap_vs_calibration$emd_gap, emd_gap_vs_calibration$prop_bias),
      stats::cor(emd_gap_vs_calibration$emd_gap, emd_gap_vs_calibration$prop_bias,
                 method = "spearman")))
    cat(sprintf(
      "  r(emd_gap, repeated-sampling compression) = %+.3f   (Spearman %+.3f)\n",
      stats::cor(emd_gap_vs_calibration$emd_gap, emd_gap_vs_calibration$rep_bias),
      stats::cor(emd_gap_vs_calibration$emd_gap, emd_gap_vs_calibration$rep_bias,
                 method = "spearman")))
    cat("  n = 5 models: descriptive only, no inference.\n")
  }
}


# Association between human-rated confusion and human response variability.
cat("\n", strrep("-", 70),
    "\nE7 — CONFUSION x HUMAN SD\n", strrep("-", 70), "\n")

e7_df <- wording_confusion_sd %>%
  filter(!is.na(mean_confusion), !is.na(human_sd)) %>%
  mutate(
    scenario_source = ifelse(grepl("^Schroeder", scenario_type), "Schroeder", "Present paper"),
    scenario_source = factor(scenario_source, levels = c("Present paper", "Schroeder"))
  )

cat("  Scenarios:", nrow(e7_df), "  by source:\n")
print(as.data.frame(count(e7_df, scenario_source, name = "n_scenarios")))

e7_cor_pooled <- stats::cor.test(e7_df$mean_confusion, e7_df$human_sd)
e7_cor_rows <- list(
  tibble(
    subset = "Pooled", n = nrow(e7_df), r = unname(e7_cor_pooled$estimate),
    ci_low = e7_cor_pooled$conf.int[1], ci_high = e7_cor_pooled$conf.int[2],
    t = unname(e7_cor_pooled$statistic), df = unname(e7_cor_pooled$parameter),
    p_value = e7_cor_pooled$p.value
  )
)
for (src in levels(e7_df$scenario_source)) {
  d <- e7_df %>% filter(scenario_source == src)
  if (nrow(d) < 4) next
  ct <- stats::cor.test(d$mean_confusion, d$human_sd)
  e7_cor_rows[[length(e7_cor_rows) + 1]] <- tibble(
    subset = src, n = nrow(d), r = unname(ct$estimate),
    ci_low = ct$conf.int[1], ci_high = ct$conf.int[2],
    t = unname(ct$statistic), df = unname(ct$parameter), p_value = ct$p.value
  )
}
# Sensitivity
if (exists("shared_present_paper_old_ids")) {
  e7_df_no_shared <- e7_df %>%
    filter(!(scenario_type == "present_paper_old" &
             input_id %in% shared_present_paper_old_ids))
  if (nrow(e7_df_no_shared) >= 4) {
    ct_ns <- stats::cor.test(e7_df_no_shared$mean_confusion, e7_df_no_shared$human_sd)
    e7_cor_rows[[length(e7_cor_rows) + 1]] <- tibble(
      subset = "Pooled, excluding copied present_paper_old duplicates (sensitivity)",
      n = nrow(e7_df_no_shared), r = unname(ct_ns$estimate),
      ci_low = ct_ns$conf.int[1], ci_high = ct_ns$conf.int[2],
      t = unname(ct_ns$statistic), df = unname(ct_ns$parameter),
      p_value = ct_ns$p.value
    )
  }
}
e7_confusion_sd_correlations <- bind_rows(e7_cor_rows)
write.csv(e7_confusion_sd_correlations,
          file.path(out_dir, "table_e7_confusion_sd_correlations.csv"), row.names = FALSE)
cat("\n  Correlations:\n")
print(as.data.frame(e7_confusion_sd_correlations))

# Does the association differ by stimulus source?
e7_fit <- stats::lm(human_sd ~ mean_confusion * scenario_source, data = e7_df)
e7_tidy <- broom::tidy(e7_fit, conf.int = TRUE) %>%
  mutate(
    r_squared = summary(e7_fit)$r.squared,
    adj_r_squared = summary(e7_fit)$adj.r.squared
  )
write.csv(e7_tidy, file.path(out_dir, "table_e7_confusion_sd_interaction.csv"), row.names = FALSE)
cat("\n  human_sd ~ confusion * scenario_source:\n")
print(as.data.frame(e7_tidy))

# Incremental R-squared and Cohen's f-squared for the interaction term.
e7_reduced <- stats::lm(human_sd ~ mean_confusion + scenario_source, data = e7_df)
e7_r2_full <- summary(e7_fit)$r.squared
e7_r2_red <- summary(e7_reduced)$r.squared
cat("  Interaction delta R^2:", round(e7_r2_full - e7_r2_red, 5),
    "  Cohen's f^2:", round((e7_r2_full - e7_r2_red) / (1 - e7_r2_full), 5), "\n")

# Simple slopes within each source
e7_simple_slope <- function(dat, ref) {
  d <- dat %>% mutate(src = stats::relevel(scenario_source, ref = ref))
  f <- stats::lm(human_sd ~ mean_confusion * src, data = d)
  co <- summary(f)$coefficients
  ci <- stats::confint(f)["mean_confusion", ]
  tibble(
    scenario_source = ref,
    n = sum(dat$scenario_source == ref),
    simple_slope = unname(co["mean_confusion", "Estimate"]),
    std_error = unname(co["mean_confusion", "Std. Error"]),
    ci_low = ci[1], ci_high = ci[2],
    t = unname(co["mean_confusion", "t value"]),
    p_value = unname(co["mean_confusion", "Pr(>|t|)"])
  )
}
e7_simple_slopes <- bind_rows(lapply(levels(e7_df$scenario_source),
                                     function(l) e7_simple_slope(e7_df, l)))

e7_src_scale <- e7_df %>%
  group_by(scenario_source) %>%
  summarise(
    n = n(),
    sd_confusion = stats::sd(mean_confusion),
    sd_human_sd = stats::sd(human_sd),
    r = stats::cor(mean_confusion, human_sd),
    .groups = "drop"
  ) %>%
  mutate(implied_raw_slope = r * sd_human_sd / sd_confusion)

e7_r1 <- e7_src_scale$r[1]; e7_n1 <- e7_src_scale$n[1]
e7_r2 <- e7_src_scale$r[2]; e7_n2 <- e7_src_scale$n[2]
e7_z_se <- sqrt(1 / (e7_n1 - 3) + 1 / (e7_n2 - 3))
e7_z <- (atanh(e7_r2) - atanh(e7_r1)) / e7_z_se

e7_scale_check <- tibble(
  comparison = paste(e7_src_scale$scenario_source, collapse = " vs "),
  r_1 = e7_r1, n_1 = e7_n1, r_2 = e7_r2, n_2 = e7_n2,
  confusion_sd_ratio = e7_src_scale$sd_confusion[2] / e7_src_scale$sd_confusion[1],
  fisher_z = e7_z,
  fisher_p = 2 * stats::pnorm(-abs(e7_z)),
  z_diff = atanh(e7_r2) - atanh(e7_r1),
  z_ci_low = (atanh(e7_r2) - atanh(e7_r1)) - 1.96 * e7_z_se,
  z_ci_high = (atanh(e7_r2) - atanh(e7_r1)) + 1.96 * e7_z_se
)

e7_within_z <- e7_df %>%
  group_by(scenario_source) %>%
  mutate(cz = as.numeric(scale(mean_confusion)), sz = as.numeric(scale(human_sd))) %>%
  ungroup()
e7_fit_z <- stats::lm(sz ~ cz * scenario_source, data = e7_within_z)
e7_within_std_interaction <- broom::tidy(e7_fit_z, conf.int = TRUE) %>%
  filter(grepl("^cz:", term))

write.csv(e7_simple_slopes, file.path(out_dir, "table_e7_simple_slopes_by_source.csv"), row.names = FALSE)
write.csv(e7_scale_check, file.path(out_dir, "table_e7_interaction_scale_check.csv"), row.names = FALSE)
write.csv(e7_within_std_interaction,
          file.path(out_dir, "table_e7_within_source_standardized_interaction.csv"), row.names = FALSE)

cat("\n  Simple slopes (confusion -> human SD) within each source:\n")
print(as.data.frame(e7_simple_slopes))
cat("\n  Scale check — do the CORRELATIONS differ, or only the raw slopes?\n")
print(as.data.frame(e7_scale_check))
cat("\n  Interaction after within-source standardization:\n")
print(as.data.frame(e7_within_std_interaction))

if (is.finite(e7_scale_check$fisher_p) && e7_scale_check$fisher_p > .05) {
  cat("\n  The correlation-difference test did not reject (Fisher p =",
      round(e7_scale_check$fisher_p, 4), "). This does not establish equivalence.\n")
  cat("  Differences in predictor spread may contribute to the raw slope gap.\n")
  cat("  The two sources share six stimuli; the independent-sample Fisher test\n")
  cat("  should be treated as descriptive, not definitive source-comparison inference.\n")
}

e7_plot <- ggplot(e7_df, aes(x = mean_confusion, y = human_sd, colour = scenario_type)) +
  geom_point(alpha = 0.7, size = 1.8) +
  geom_smooth(aes(group = scenario_type), method = "lm", se = FALSE, linewidth = 0.5) +
  geom_smooth(aes(group = 1), method = "lm", colour = "black", linewidth = 1.1, se = TRUE) +
  labs(
    title = "Human-rated confusion and human response variability",
    subtitle = "Black line pools all scenarios; coloured lines fit within scenario type",
    x = "Mean human-rated confusion", y = "Human SD of moral ratings", colour = "Scenario type"
  ) +
  theme_minimal(base_size = 11) +
  theme(legend.position = "bottom")

e7_pdf <- file.path(out_dir, "figure_e7_confusion_vs_human_sd.pdf")
save_figure_pdf_checked(e7_pdf, e7_plot, width = 9, height = 7,
  diagnostic_path = file.path(out_dir, "CHECK_e7_pdf_export.csv"), prefer_cairo = FALSE)


# Account for repeated model observations with multilevel regressions.
cat("\n", strrep("-", 70),
    "\nE6 — MULTILEVEL MODELS (scenario random intercept)\n", strrep("-", 70), "\n")

e6_rows <- list()
e6_icc_rows <- list()

e6_report <- function(fit, label, ols_fit = NULL) {
  cat("\nConvergence check:", label, "\n")
  print(fit@optinfo$conv)
  cat("Singular fit:", lme4::isSingular(fit), "\n")
  diagnostics <- model_fit_diagnostics(fit)
  td <- broom.mixed::tidy(fit, effects = "fixed", conf.int = TRUE) %>%
    mutate(!!!as.list(diagnostics))
  vc <- as.data.frame(lme4::VarCorr(fit))
  var_between <- sum(vc$vcov[!is.na(vc$grp) & vc$grp != "Residual"], na.rm = TRUE)
  var_resid <- vc$vcov[vc$grp == "Residual"][1]
  icc <- var_between / (var_between + var_resid)
  r2 <- if (e_have_mumin) {
    tryCatch(MuMIn::r.squaredGLMM(fit), error = function(e) matrix(NA_real_, 1, 2))
  } else matrix(NA_real_, 1, 2)

  e6_icc_rows[[length(e6_icc_rows) + 1]] <<- tibble(
    model = label, icc = icc, !!!as.list(diagnostics),
    var_between = var_between, var_residual = var_resid,
    r2_marginal = r2[1, 1], r2_conditional = r2[1, 2],
    n_obs = stats::nobs(fit)
  )
  e6_rows[[length(e6_rows) + 1]] <<- td %>%
    mutate(model = label, .before = 1) %>%
    mutate(
      ols_estimate = if (!is.null(ols_fit)) {
        oc <- stats::coef(summary(ols_fit))
        unname(oc[match(term, rownames(oc)), "Estimate"])
      } else NA_real_
    )
  cat("  ", label, " — ICC:", round(icc, 4),
      " R2m:", round(r2[1, 1], 4), " R2c:", round(r2[1, 2], 4),
      " n:", stats::nobs(fit), "\n")
  invisible(NULL)
}

if (e_have_lmer) {
  # Model absolute error explained by confusion and human SD.
  e6_dat <- wording_model_error_primary %>%
    filter(!is.na(abs_error), !is.na(mean_confusion_z), !is.na(human_sd_z))
  if (nrow(e6_dat) > 20) {
    e6_fit_error <- try(lmerTest::lmer(
      abs_error ~ mean_confusion_z + human_sd_z + model_label + (1 | input_id),
      data = e6_dat
    ), silent = TRUE)
    e6_ols_error <- stats::lm(
      abs_error ~ mean_confusion_z + human_sd_z + model_label, data = e6_dat
    )
    if (!inherits(e6_fit_error, "try-error")) {
      e6_report(e6_fit_error, "abs_error ~ confusion_z + human_sd_z + model (1|input_id)", e6_ols_error)
    }
  }

  e6_conf_dat <- model_predicted_confusion_df %>%
    group_by(model_name) %>%
    mutate(model_predicted_confusion_z = as.numeric(scale(model_predicted_confusion))) %>%
    ungroup() %>%
    filter(!is.na(model_predicted_confusion_z), !is.na(mean_confusion)) %>%
    mutate(mean_confusion_z = as.numeric(scale(mean_confusion)))

  if (nrow(e6_conf_dat) > 20 && n_distinct(e6_conf_dat$input_id) > 5) {
    e6_fit_conf_degenerate <- try(lmerTest::lmer(
      mean_confusion ~ model_predicted_confusion_z + model_label + (1 | input_id),
      data = e6_conf_dat
    ), silent = TRUE)
    if (!inherits(e6_fit_conf_degenerate, "try-error")) {
      e6_report(
        e6_fit_conf_degenerate,
        "SUPPLEMENT / specification check (outcome is scenario-constant): human_confusion ~ model_confusion_z + model (1|input_id)"
      )
      cat("     ^ Supplement only. ICC = 1 by construction: this is the specification\n")
      cat("       check demonstrating why the roles have to run the other way.\n")
    }

    e6_fit_conf <- try(lmerTest::lmer(
      model_predicted_confusion ~ mean_confusion_z + model_label + (1 | input_id),
      data = e6_conf_dat
    ), silent = TRUE)
    e6_ols_conf <- stats::lm(
      model_predicted_confusion ~ mean_confusion_z + model_label, data = e6_conf_dat
    )
    if (!inherits(e6_fit_conf, "try-error")) {
      e6_report(e6_fit_conf,
                "PRIMARY: model_confusion ~ human_confusion_z + model (1|input_id)", e6_ols_conf)
    }
  }

  # Original vs new wording gap
  e6_pair_dat <- wording_model_error_primary %>%
    filter(grepl("^[0-9]+_(new|old)$", as.character(input_id))) %>%
    mutate(
      pair_id = stringr::str_replace(as.character(input_id), "_(new|old)$", ""),
      version = ifelse(grepl("_new$", as.character(input_id)), "new", "old")
    ) %>%
    filter(!is.na(abs_error))
  e6_pair_ok <- e6_pair_dat %>%
    group_by(pair_id) %>%
    filter(n_distinct(version) == 2) %>%
    ungroup()
  if (nrow(e6_pair_ok) > 20 && n_distinct(e6_pair_ok$pair_id) > 5) {
    e6_fit_pair <- try(lmerTest::lmer(
      abs_error ~ version + mean_confusion_z + human_sd_z + model_label + (1 | pair_id),
      data = e6_pair_ok
    ), silent = TRUE)
    if (!inherits(e6_fit_pair, "try-error")) {
      e6_report(e6_fit_pair, "Present-paper pairs only: abs_error ~ version + confusion_z + human_sd_z + model (1|pair_id)")
    }
  }
}

if (length(e6_rows) > 0) {
  e6_multilevel_coefs <- bind_rows(e6_rows)
  e6_multilevel_fit <- bind_rows(e6_icc_rows)
  write.csv(e6_multilevel_coefs, file.path(out_dir, "table_e6_multilevel_coefficients.csv"), row.names = FALSE)
  write.csv(e6_multilevel_fit, file.path(out_dir, "table_e6_multilevel_fit_icc.csv"), row.names = FALSE)
  cat("  Wrote", nrow(e6_multilevel_coefs), "coefficients across",
      nrow(e6_multilevel_fit), "multilevel models\n")
} else {
  cat("  ⚠ No multilevel models fitted.\n")
}


# Describe differences among elicitation formats and test moderation by human confusion.
cat("\n", strrep("-", 70),
    "\nE8 — ELICITATION CONFOUND AND STIMULUS AMBIGUITY\n", strrep("-", 70), "\n")

e8_confound <- tibble::tribble(
  ~method,                       ~target,                      ~temperature, ~response_format,       ~n_generations, ~post_processing,
  "Repeated_sampling",           "single rating per draw",     "1",          "bare number or prose", "500",          "empirical histogram of draws",
  "direct_proportions_analytic", "probability of each option", "0",          "nine-bin JSON",        "1",            "used analytically, no Monte Carlo",
  "distribution_mean_sd",        "mean from moments prompt; standalone SD", "0", "two prompt responses", "2",            "truncated normal, binned",
  "distribution_full",           "mean, SD, skew, kurtosis, peaks", "0",     "moment JSON",          "1",            "discrete moment fit",
  "hybrid_proportions_mean_sd", "mean + proportions from moments prompt; standalone SD", "0", "two prompt responses", "2",            "average of two distributions"
)


write.csv(e8_confound, file.path(out_dir, "table_e8_elicitation_confound.csv"), row.names = FALSE)

# Test whether human confusion moderates the advantage of distributional methods.
e8_mod_candidates <- dist_by_scenario %>%
  filter(method %in% e1_all_methods) %>%
  inner_join(human_confuse_means %>% dplyr::select(input_id, mean_confusion), by = "input_id") %>%
  mutate(method = factor(method, levels = e1_all_methods)) %>%
  filter(!is.na(mean_confusion))

e8_mod_complete <- e8_mod_candidates %>%
  group_by(model_name, input_id) %>%
  filter(n_distinct(method) == length(e1_all_methods)) %>%
  ungroup()

e8_model_coverage <- e8_mod_complete %>%
  distinct(model_name, input_id) %>%
  count(model_name, name = "complete_items") %>%
  tidyr::complete(model_name = wording_models_focal, fill = list(complete_items = 0L))
readr::write_csv(
  e8_model_coverage,
  file.path(out_dir, "CHECK_e8_model_method_coverage.csv")
)

if (sum(e8_model_coverage$complete_items > 0) < 2L) {
  stop(
    "E8 requires at least two models with complete five-method cells; ",
    "see CHECK_e8_model_method_coverage.csv."
  )
}

e8_mod_dat <- e8_mod_complete

e8_confusion_reference <- e8_mod_dat %>%
  distinct(input_id, mean_confusion)
e8_confusion_mean <- mean(e8_confusion_reference$mean_confusion)
e8_confusion_sd <- stats::sd(e8_confusion_reference$mean_confusion)
if (!is.finite(e8_confusion_sd) || e8_confusion_sd <= 0) {
  stop("E8 human confusion has zero or undefined variance on the matched two-source frame.")
}
e8_mod_dat <- e8_mod_dat %>%
  mutate(mean_confusion_z = (mean_confusion - e8_confusion_mean) / e8_confusion_sd)

e8_rows <- list()
for (met in E_METRICS) {
  d <- e8_mod_dat %>% mutate(.y = .data[[met]]) %>% filter(!is.na(.y))
  if (nrow(d) < 40) next
  if (e_have_lmer) {
    f <- try(lmerTest::lmer(
      .y ~ method * mean_confusion_z + model_name + (1 | input_id),
      data = d
    ),
             silent = TRUE)
    if (!inherits(f, "try-error")) {
      e8_rows[[length(e8_rows) + 1]] <- broom.mixed::tidy(f, effects = "fixed", conf.int = TRUE) %>%
        mutate(metric = met, subset = "Present paper", !!!as.list(model_fit_diagnostics(f)), .before = 1)
    }
  }
}

if (length(e8_rows) > 0) {
  e8_confusion_moderation <- bind_rows(e8_rows)
  e8_fit_grid <- e8_confusion_moderation %>%
    distinct(metric, subset)
  expected_e8_fit_grid <- tidyr::crossing(
    metric = E_METRICS,
    subset = "Present paper"
  )
  if (!setequal(
    paste(e8_fit_grid$metric, e8_fit_grid$subset),
    paste(expected_e8_fit_grid$metric, expected_e8_fit_grid$subset)
  )) {
    readr::write_csv(
      e8_fit_grid,
      file.path(out_dir, "CHECK_e8_incomplete_fit_grid.csv")
    )
    stop(
      "E8 did not produce all 3 metrics x 3 source subsets; ",
      "see CHECK_e8_incomplete_fit_grid.csv."
    )
  }
  # Holm within metric x subset, across the interaction terms only.
  e8_confusion_moderation <- e8_confusion_moderation %>%
    group_by(metric, subset) %>%
    mutate(
      is_interaction = grepl(":mean_confusion_z$", term),
      p_holm_interactions = ifelse(
        is_interaction,
        stats::p.adjust(ifelse(is_interaction, p.value, NA_real_), method = "holm"),
        NA_real_
      )
    ) %>%
    ungroup()
  write.csv(e8_confusion_moderation,
            file.path(out_dir, "table_e8_confusion_moderation.csv"), row.names = FALSE)
  cat("  Wrote confusion-moderation models:", nrow(e8_confusion_moderation), "coefficient rows,",
      n_distinct(paste(e8_confusion_moderation$metric, e8_confusion_moderation$subset)),
      "metric x subset fits\n")
  cat("  Significant method x confusion interactions after Holm:",
      sum(e8_confusion_moderation$p_holm_interactions < .05, na.rm = TRUE), "\n")
} else {
  stop("E8 did not produce any confusion-moderation models.")
}

cat("\n", strrep("=",70),
    "\nPRIMARY SCENARIO ANALYSES COMPLETE; continuing with paper additions.\n",
    strrep("=",70), "\n")



# New scenario distribution tables

new_table_models <- c(
  "gpt-35-turbo_1106",
  "gpt-4o-mini_2024-07-18",
  "gpt-5-chat_2025-08-07",
  "gpt-oss-20b",
  "qwen-3-32B"
)

new_model_labels <- c(
  "gpt-35-turbo_1106"      = "GPT-3.5",
  "gpt-4o-mini_2024-07-18" = "GPT-4o-mini",
  "gpt-5-chat_2025-08-07"  = "GPT-5",
  "gpt-oss-20b"            = "GPT-OSS-20B",
  "qwen-3-32B"             = "Qwen-3-32B"
)

new_proportions_method <- if ("direct_proportions_analytic" %in% unique(dist_by_scenario$method)) {
  "direct_proportions_analytic"
} else {
  "direct_proportions"
}

new_distribution_methods <- c(
  "Repeated_sampling",
  "distribution_mean_sd",
  "distribution_full",
  "hybrid_proportions_mean_sd",
  new_proportions_method
)

new_method_labels <- c(
  "Repeated_sampling"    = "Repeated sampling",
  "distribution_mean_sd" = "Moments: Mean + SD",
  "distribution_full"    = "Moments: Expanded",
  "hybrid_proportions_mean_sd"    = "Hybrid Proportions + Moments",
  "direct_proportions_analytic"      = "Proportions",
  "direct_proportions"             = "Proportions"
)

new_method_order <- c(
  "Repeated sampling",
  "Moments: Mean + SD",
  "Moments: Expanded",
  "Hybrid Proportions + Moments",
  "Proportions"
)

dist_tmp <- dist_by_scenario

if (!"scenario_type" %in% names(dist_tmp)) {
  dist_tmp <- dist_tmp %>%
    mutate(scenario_type = classify_scenario(input_id))
}

n_new_scenarios <- human_stats %>%
  filter(scenario_type == "present_paper_new") %>%
  summarise(n = n_distinct(input_id)) %>%
  pull(n)

cat("New scenarios denominator:", n_new_scenarios, "\n")

table3_new_scenarios_unrounded <- dist_tmp %>%
  filter(
    scenario_type == "present_paper_new",
    model_name %in% new_table_models,
    method %in% new_distribution_methods
  ) %>%
  mutate(
    Model = recode(model_name, !!!new_model_labels),
    Method = recode(method, !!!new_method_labels)
  ) %>%
  group_by(Model, Method) %>%
  summarise(
    TVD = mean(tvd, na.rm = TRUE),
    EMD = mean(emd, na.rm = TRUE),
    JSD = mean(jsd, na.rm = TRUE),
    n_covered = n_distinct(input_id),
    .groups = "drop"
  ) %>%
  mutate(
    `Scenarios covered` = paste0(n_covered, "/", n_new_scenarios),
    Model = factor(Model, levels = unname(new_model_labels)),
    Method = factor(Method, levels = new_method_order)
  ) %>%
  arrange(Model, Method) %>%
  transmute(
    Model = as.character(Model),
    Method = as.character(Method),
    TVD = TVD,
    EMD = EMD,
    JSD = JSD,
    `Scenarios covered`
  )

table3_new_scenarios <- table3_new_scenarios_unrounded %>%
  mutate(across(c(TVD, EMD, JSD), ~ round(.x, 2)))

cat("\nTable 3. Fit of distributional methods to empirical human moral response distributions by model — NEW scenarios only\n")
print(table3_new_scenarios, n = Inf, width = Inf)

table4_new_scenarios <- table3_new_scenarios_unrounded %>%
  mutate(
    covered_n = as.numeric(str_extract(`Scenarios covered`, "^[0-9]+"))
  ) %>%
  group_by(Method) %>%
  summarise(
    `Average TVD` = mean(TVD, na.rm = TRUE),
    `Average EMD` = mean(EMD, na.rm = TRUE),
    `Average JSD` = mean(JSD, na.rm = TRUE),
    covered_n = sum(covered_n, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    Method = factor(Method, levels = new_method_order),
    `Model-scenarios covered` = paste0(
      covered_n, "/", length(new_table_models) * n_new_scenarios
    )
  ) %>%
  arrange(Method) %>%
  transmute(
    Method = as.character(Method),
    `Average TVD` = round(`Average TVD`, 2),
    `Average EMD` = round(`Average EMD`, 2),
    `Average JSD` = round(`Average JSD`, 2),
    `Model-scenarios covered`
  )

cat("\nTable 4. Average performance of each distributional method across models — NEW scenarios only\n")
print(table4_new_scenarios, n = Inf, width = Inf)

write.csv(
  table3_new_scenarios,
  file.path(out_dir, "table3_distribution_methods_new_scenarios_only.csv"),
  row.names = FALSE
)

write.csv(
  table4_new_scenarios,
  file.path(out_dir, "table4_average_distribution_methods_new_scenarios_only.csv"),
  row.names = FALSE
)


# Human split-half reliability check
# Repeatedly split respondents into two groups to estimate the natural discrepancy between two human means.
cat("\n", strrep("=", 70),
    "\nHUMAN SPLIT-HALF ABSOLUTE DISCREPANCY CHECK\n",
    strrep("=", 70), "\n")

set.seed(20260605)

B <- 1000

human_for_split <- human_long %>%
  mutate(scenario_type = classify_scenario(input_id)) %>%
  filter(scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES) %>%
  filter(!is.na(human_y), !is.na(respondent_id), !is.na(input_id))

cat("\nHuman split-half input check:\n")
cat("  Observations:", nrow(human_for_split), "\n")
cat("  Respondents: ", n_distinct(human_for_split$respondent_id), "\n")
cat("  Scenarios:   ", n_distinct(human_for_split$input_id), "\n")
print(
  human_for_split %>%
    count(scenario_type, name = "n_obs") %>%
    mutate(n_scenarios = map_int(scenario_type, ~ n_distinct(human_for_split$input_id[human_for_split$scenario_type == .x]))),
  n = Inf,
  width = Inf
)


# One split-half resample: assign respondents to halves, compute scenario means, and measure absolute differences.
run_one_human_split <- function(b, dat = human_for_split) {

  split_ids <- dat %>%
    distinct(respondent_id) %>%
    mutate(split_half = sample(rep(c("A", "B"), length.out = n())))

  dat %>%
    inner_join(split_ids, by = "respondent_id") %>%
    group_by(input_id, scenario_type, split_half) %>%
    summarise(
      split_mean = mean(human_y, na.rm = TRUE),
      split_n = n(),
      .groups = "drop"
    ) %>%
    pivot_wider(
      names_from = split_half,
      values_from = c(split_mean, split_n),
      names_sep = "_"
    ) %>%
    filter(!is.na(split_mean_A), !is.na(split_mean_B)) %>%
    mutate(
      split_id = b,
      scenario_version = make_scenario_version(scenario_type),
      signed_diff = split_mean_A - split_mean_B,
      abs_diff = abs(signed_diff)
    )
}

human_split_results <- purrr::map_dfr(seq_len(B), run_one_human_split)

human_split_tests <- human_split_results %>%
  group_by(split_id) %>%
  summarise(
    n_scenarios = n_distinct(input_id),

    mean_signed_diff = mean(signed_diff, na.rm = TRUE),
    sd_signed_diff = sd(signed_diff, na.rm = TRUE),

    mean_abs_diff = mean(abs_diff, na.rm = TRUE),
    sd_abs_diff = sd(abs_diff, na.rm = TRUE),
    median_abs_diff = median(abs_diff, na.rm = TRUE),
    prop_exact_zero = mean(abs_diff == 0, na.rm = TRUE),

    signed_t = unname(t.test(signed_diff, mu = 0)$statistic),
    signed_df = unname(t.test(signed_diff, mu = 0)$parameter),
    signed_p = t.test(signed_diff, mu = 0)$p.value,

    abs_t = unname(t.test(abs_diff, mu = 0, alternative = "greater")$statistic),
    abs_df = unname(t.test(abs_diff, mu = 0, alternative = "greater")$parameter),
    abs_p = t.test(abs_diff, mu = 0, alternative = "greater")$p.value,

    abs_cohen_d = mean(abs_diff, na.rm = TRUE) / sd(abs_diff, na.rm = TRUE),

    .groups = "drop"
  )

human_split_summary <- human_split_tests %>%
  summarise(
    splits = n(),
    mean_n_scenarios = mean(n_scenarios, na.rm = TRUE),

    sd_signed_diff_across_resamples = sd(mean_signed_diff, na.rm = TRUE),
    mean_signed_diff = mean(mean_signed_diff, na.rm = TRUE),
    prop_signed_p_lt_05 = mean(signed_p < .05, na.rm = TRUE),

    sd_abs_diff_across_resamples = sd(mean_abs_diff, na.rm = TRUE),
    mean_abs_diff = mean(mean_abs_diff, na.rm = TRUE),
    mean_median_abs_diff = mean(median_abs_diff, na.rm = TRUE),
    mean_prop_exact_zero = mean(prop_exact_zero, na.rm = TRUE),
    prop_all_abs_nonzero = mean(prop_exact_zero == 0, na.rm = TRUE),

    mean_abs_t = mean(abs_t, na.rm = TRUE),
    median_abs_t = median(abs_t, na.rm = TRUE),
    min_abs_t = min(abs_t, na.rm = TRUE),
    max_abs_t = max(abs_t, na.rm = TRUE),
    mean_abs_df = mean(abs_df, na.rm = TRUE),

    mean_abs_p = mean(abs_p, na.rm = TRUE),
    median_abs_p = median(abs_p, na.rm = TRUE),
    max_abs_p = max(abs_p, na.rm = TRUE),
    prop_abs_p_lt_05 = mean(abs_p < .05, na.rm = TRUE),

    mean_abs_cohen_d = mean(abs_cohen_d, na.rm = TRUE),
    median_abs_cohen_d = median(abs_cohen_d, na.rm = TRUE),

    .groups = "drop"
  )

cat("\n── Human split-half absolute discrepancy summary ──\n")
print(human_split_summary, width = Inf)

human_split_by_version <- human_split_results %>%
  group_by(split_id, scenario_version) %>%
  summarise(
    n_scenarios = n_distinct(input_id),

    mean_signed_diff = mean(signed_diff, na.rm = TRUE),
    sd_signed_diff = sd(signed_diff, na.rm = TRUE),

    mean_abs_diff = mean(abs_diff, na.rm = TRUE),
    sd_abs_diff = sd(abs_diff, na.rm = TRUE),
    median_abs_diff = median(abs_diff, na.rm = TRUE),

    signed_t = unname(t.test(signed_diff, mu = 0)$statistic),
    signed_df = unname(t.test(signed_diff, mu = 0)$parameter),
    signed_p = t.test(signed_diff, mu = 0)$p.value,

    abs_t = unname(t.test(abs_diff, mu = 0, alternative = "greater")$statistic),
    abs_df = unname(t.test(abs_diff, mu = 0, alternative = "greater")$parameter),
    abs_p = t.test(abs_diff, mu = 0, alternative = "greater")$p.value,

    abs_cohen_d = mean(abs_diff, na.rm = TRUE) / sd(abs_diff, na.rm = TRUE),

    .groups = "drop"
  ) %>%
  group_by(scenario_version) %>%
  summarise(
    splits = n(),
    mean_n_scenarios = mean(n_scenarios, na.rm = TRUE),

    sd_signed_diff_across_resamples = sd(mean_signed_diff, na.rm = TRUE),
    mean_signed_diff = mean(mean_signed_diff, na.rm = TRUE),
    prop_signed_p_lt_05 = mean(signed_p < .05, na.rm = TRUE),

    sd_abs_diff_across_resamples = sd(mean_abs_diff, na.rm = TRUE),
    mean_abs_diff = mean(mean_abs_diff, na.rm = TRUE),
    mean_median_abs_diff = mean(median_abs_diff, na.rm = TRUE),

    mean_abs_t = mean(abs_t, na.rm = TRUE),
    min_abs_t = min(abs_t, na.rm = TRUE),
    max_abs_t = max(abs_t, na.rm = TRUE),
    max_abs_p = max(abs_p, na.rm = TRUE),
    prop_abs_p_lt_05 = mean(abs_p < .05, na.rm = TRUE),

    mean_abs_cohen_d = mean(abs_cohen_d, na.rm = TRUE),

    .groups = "drop"
  )

cat("\n── Human split-half absolute discrepancy by scenario version ──\n")
print(human_split_by_version, width = Inf)

human_split_text_stats <- human_split_summary %>%
  transmute(
    text = paste0(
      "Across ", splits, " split-half resamples, the average absolute discrepancy ",
      "between two human-estimated scenario means was ", sprintf("%.2f", mean_abs_diff),
      " scale points (SD across resamples = ", sprintf("%.2f", sd_abs_diff_across_resamples),
      "; mean median absolute discrepancy = ", sprintf("%.2f", mean_median_abs_diff),
      "). These summarize variability across random splits of the observed sample; ",
      "they are not population confidence intervals or tests of substantive unreliability."
    )
  )

cat("\n── Manuscript-ready split-half sentence ──\n")
cat(human_split_text_stats$text, "\n")

readr::write_csv(
  relabel_scenario_version(human_split_results),
  file.path(out_dir, "human_split_half_abs_discrepancy_by_scenario.csv")
)

readr::write_csv(
  human_split_tests,
  file.path(out_dir, "human_split_half_abs_discrepancy_tests.csv")
)

readr::write_csv(
  human_split_summary,
  file.path(out_dir, "human_split_half_abs_discrepancy_summary.csv")
)

readr::write_csv(
  relabel_scenario_version(human_split_by_version),
  file.path(out_dir, "human_split_half_abs_discrepancy_by_version.csv")
)

readr::write_csv(
  human_split_text_stats,
  file.path(out_dir, "human_split_half_abs_discrepancy_text_stats.csv")
)


# Compare model absolute error with the human split-half benchmark on the same response scale.
cat("\n", strrep("=", 70),
    "\nE5 — MODEL ERROR VERSUS HUMAN SPLIT-HALF DISCREPANCY, COMMON SCALE\n",
    strrep("=", 70), "\n")

# Per item
e5_split_by_item <- human_split_results %>%
  filter(!is.na(abs_diff), split_n_A > 0, split_n_B > 0) %>%
  mutate(
    n_total = split_n_A + split_n_B,
    se_halfdiff_unit = sqrt(1 / split_n_A + 1 / split_n_B),
    se_fullmean_unit = sqrt(1 / n_total),
    scale_factor = se_fullmean_unit / se_halfdiff_unit,
    abs_diff_fullscale = abs_diff * scale_factor
  ) %>%
  group_by(input_id, scenario_type) %>%
  summarise(
    n_splits = n(),
    human_n = round(mean(n_total)),
    mean_abs_halfdiff_raw = mean(abs_diff, na.rm = TRUE),
    mean_abs_halfdiff_fullscale = mean(abs_diff_fullscale, na.rm = TRUE),
    q025_halfdiff_raw = stats::quantile(abs_diff, .025, na.rm = TRUE),
    q975_halfdiff_raw = stats::quantile(abs_diff, .975, na.rm = TRUE),
    q025_halfdiff_fullscale = stats::quantile(abs_diff_fullscale, .025, na.rm = TRUE),
    q975_halfdiff_fullscale = stats::quantile(abs_diff_fullscale, .975, na.rm = TRUE),
    mean_scale_factor = mean(scale_factor, na.rm = TRUE),
    .groups = "drop"
  )

cat("  Items with split-half estimates:", nrow(e5_split_by_item), "\n")
cat("  Mean rescaling factor (SE full mean / SE half-half):",
    round(mean(e5_split_by_item$mean_scale_factor, na.rm = TRUE), 4),
    "  [0.5 is the equal-n expectation]\n")

# Bootstrap sampling distribution of each item's full-sample mean
set.seed(20260805)
E5_BOOT_R <- as.integer(Sys.getenv("SCEN_E5_BOOT_R", unset = "2000"))

e5_boot_one_item <- function(y) {
  y <- y[!is.na(y)]
  if (length(y) < 3) {
    return(tibble(human_n = length(y), full_mean = mean(y),
                  boot_sd_of_mean = NA_real_,
                  boot_q025_abs_dev = NA_real_, boot_q975_abs_dev = NA_real_))
  }
  m <- mean(y)
  bm <- replicate(E5_BOOT_R, mean(sample(y, length(y), replace = TRUE)))
  ad <- abs(bm - m)
  tibble(
    human_n = length(y),
    full_mean = m,
    boot_sd_of_mean = stats::sd(bm),
    boot_q025_abs_dev = unname(stats::quantile(ad, .025)),
    boot_q975_abs_dev = unname(stats::quantile(ad, .975))
  )
}

e5_boot_fullmean <- human_for_split %>%
  filter(!is.na(human_y)) %>%
  group_by(input_id, scenario_type) %>%
  group_modify(~ e5_boot_one_item(.x$human_y)) %>%
  ungroup()

e5_model_error <- wording_model_error_primary %>%
  dplyr::select(input_id, model_name, model_label, scenario_type, abs_error) %>%
  filter(!is.na(abs_error))

e5_joined <- e5_model_error %>%
  inner_join(e5_split_by_item %>% dplyr::select(-scenario_type), by = "input_id") %>%
  inner_join(e5_boot_fullmean %>% dplyr::select(-scenario_type), by = "input_id")

e5_duplicate_cells <- e5_joined %>%
  count(model_name, input_id, name = "n_rows") %>%
  filter(n_rows != 1L)
e5_expected_items <- n_distinct(e5_split_by_item$input_id)
e5_model_coverage <- e5_joined %>%
  distinct(model_name, input_id) %>%
  count(model_name, name = "n_items") %>%
  tidyr::complete(
    model_name = wording_models_focal,
    fill = list(n_items = 0L)
  ) %>%
  mutate(
    expected_items = e5_expected_items,
    status = ifelse(n_items == expected_items, "ok", "INCOMPLETE")
  )
readr::write_csv(
  e5_model_coverage,
  file.path(out_dir, "CHECK_e5_model_item_coverage.csv")
)

if (nrow(e5_duplicate_cells) > 0 ||
    !setequal(unique(e5_joined$model_name), wording_models_focal) ||
    any(e5_model_coverage$status != "ok")) {
  if (nrow(e5_duplicate_cells) > 0) {
    readr::write_csv(
      e5_duplicate_cells,
      file.path(out_dir, "CHECK_e5_duplicate_model_item_cells.csv")
    )
  }
  stop(
    "E5 requires one row for every focal model x item cell; ",
    "see CHECK_e5_model_item_coverage.csv",
    if (nrow(e5_duplicate_cells) > 0) " and CHECK_e5_duplicate_model_item_cells.csv." else "."
  )
}

audit_record(
  "E5 split-half comparison", "join model error to per-item split-half and bootstrap benchmarks",
  rows_in = nrow(e5_model_error), rows_out = nrow(e5_joined),
  keys_in = n_distinct(e5_model_error$input_id), keys_out = n_distinct(e5_joined$input_id),
  reason = "items need both a split-half estimate and a bootstrap sampling distribution",
  detail = "per-item n used for rescaling rather than a common n"
)

e5_summary <- e5_joined %>%
  group_by(model_label) %>%
  summarise(
    n_items = n_distinct(input_id),
    mean_model_abs_error = mean(abs_error, na.rm = TRUE),
    mean_human_halfdiff_raw = mean(mean_abs_halfdiff_raw, na.rm = TRUE),
    mean_human_halfdiff_fullscale = mean(mean_abs_halfdiff_fullscale, na.rm = TRUE),
    diff_vs_raw = mean(abs_error - mean_abs_halfdiff_raw, na.rm = TRUE),
    diff_vs_fullscale = mean(abs_error - mean_abs_halfdiff_fullscale, na.rm = TRUE),

    prop_at_or_below_upper_raw = mean(
      abs_error <= q975_halfdiff_raw,
      na.rm = TRUE
    ),
    prop_at_or_below_upper_fullscale = mean(
      abs_error <= q975_halfdiff_fullscale,
      na.rm = TRUE
    ),
    prop_at_or_below_upper_bootstrap = mean(
      abs_error <= boot_q975_abs_dev,
      na.rm = TRUE
    ),
    .groups = "drop"
  )

# Paired tests of the two magnitudes, with CIs and dz.
e5_tests <- e5_joined %>%
  group_by(model_label) %>%
  group_modify(function(x, key) {
    out <- list()
    for (bench in c("mean_abs_halfdiff_raw", "mean_abs_halfdiff_fullscale")) {
      d <- x$abs_error - x[[bench]]
      d <- d[!is.na(d)]
      if (length(d) < 3) next
      tt <- stats::t.test(d)
      out[[length(out) + 1]] <- tibble(
        benchmark = bench,
        n = length(d),
        mean_difference = unname(tt$estimate),
        ci_low = tt$conf.int[1], ci_high = tt$conf.int[2],
        t = unname(tt$statistic), df = unname(tt$parameter),
        p_raw = tt$p.value,
        dz = mean(d) / stats::sd(d)
      )
    }
    bind_rows(out)
  }) %>%
  ungroup() %>%
  group_by(benchmark) %>%
  mutate(p_holm = stats::p.adjust(p_raw, method = "holm")) %>%
  ungroup()

readr::write_csv(e5_joined, file.path(out_dir, "table_e5_split_half_vs_model_error_by_item.csv"))
readr::write_csv(e5_summary, file.path(out_dir, "table_e5_split_half_vs_model_error_summary.csv"))
readr::write_csv(e5_tests, file.path(out_dir, "table_e5_split_half_vs_model_error_tests.csv"))

cat("\n  Model error vs human split-half discrepancy:\n")
print(as.data.frame(e5_summary))
cat("\n  Paired tests (Holm-adjusted within benchmark):\n")
print(as.data.frame(e5_tests))

cat("\n  Interpretation note written to output: the raw split-half benchmark is\n")
cat("  inflated relative to model error because it is a difference of two\n")
cat("  half-sample means. The fullscale column is the corrected comparison.\n")


# Demographic subgroup analyses.
cat("\n", strrep("=", 70),
    "\nPART D — SCENARIO DEMOGRAPHICS (D1 merge, D4 mappings)\n",
    strrep("=", 70), "\n")

DEMO_SHARED_COLS <- c("gender", "age", "race", "pop_size", "which_rel",
                      "religiosity_1", "religiosity_2", "country_born",
                      "degree", "politics", "income", "class")

demo_boost_raw_all <- read.csv(path_demographic_boost, stringsAsFactors = FALSE)

# Apply the attention-check exclusion when loading the demographic boost sample
demo_boost_botcatch <- function(x) {
  dplyr::case_when(
    is.na(x) | x == "" ~ "missing",
    as.character(x) == "1" ~ "pass",
    TRUE ~ "fail"
  )
}
demo_boost_raw <- demo_boost_raw_all %>%
  filter(demo_boost_botcatch(botcatch_1) == "pass")

cat("\n── D1: merging the two human surveys ──\n")
cat("  Main rows:", nrow(people),
    "  Boost rows recruited:", nrow(demo_boost_raw_all),
    "→ retained after bot-catch:", nrow(demo_boost_raw), "\n")

demo_missing_cols <- setdiff(DEMO_SHARED_COLS, names(demo_boost_raw))
if (length(demo_missing_cols) > 0) {
  cat("  ⚠ Boost file missing shared demographic columns:",
      paste(demo_missing_cols, collapse = ", "), "\n")
}

demo_respondents <- bind_rows(
  people %>%
    dplyr::select(any_of(c(DEMO_SHARED_COLS))) %>%
    mutate(sample = "main", row_in_sample = row_number()),
  demo_boost_raw %>%
    dplyr::select(any_of(c(DEMO_SHARED_COLS, "botcatch_1"))) %>%
    mutate(sample = "demo_boost", row_in_sample = row_number())
) %>%
  mutate(respondent_uid = paste0(sample, "_", row_in_sample))

# Long-format moral responses for each sample
demo_long_one <- function(df, sample_label) {
  mcols <- names(df)[
    str_detect(names(df), "_moral$") |
      (str_detect(names(df), "^t_[no]_") & str_detect(names(df), "_m$")) |
      str_detect(names(df), "^Schroeder_(new|old)_.*_m$")
  ]
  raw_long <- df %>%
    select(all_of(mcols)) %>% mutate(row_in_sample = row_number()) %>%
    pivot_longer(-row_in_sample, names_to = "colname", values_to = "raw") %>%
    filter(!is.na(raw), trimws(as.character(raw)) != "") %>%
    validate_human_moral_rows(sample_label, "CHECK_demo_invalid_raw_ratings") %>%
    mutate(input_id = map_col_to_id(colname))
  raw_long %>% filter(!is.na(input_id)) %>%
    mutate(human_y = raw_num - 5, sample = sample_label,
           respondent_uid = paste0(sample_label, "_", row_in_sample)) %>%
    select(respondent_uid, sample, input_id, human_y)
}

demo_human_long <- bind_rows(
  demo_long_one(people, "main"),
  demo_long_one(demo_boost_raw, "demo_boost")
)

demo_responders <- demo_human_long %>% distinct(sample, respondent_uid)

# Expected coverage for the supplied data collection.
demo_n_main_rows  <- nrow(people)
demo_n_boost_rows <- nrow(demo_boost_raw_all)
demo_n_main_resp  <- sum(demo_responders$sample == "main")
demo_n_boost_resp <- sum(demo_responders$sample == "demo_boost")

# Pre-exclusion tally
demo_boost_pre_responder_rows <- demo_long_one(demo_boost_raw_all, "pre") %>%
  distinct(respondent_uid) %>%
  mutate(row_in_sample = as.integer(sub("^pre_", "", respondent_uid))) %>%
  pull(row_in_sample)
demo_boost_bot_pre <- tibble(
  bot = demo_boost_botcatch(demo_boost_raw_all$botcatch_1[demo_boost_pre_responder_rows])
)

demo_boost_items <- demo_human_long %>%
  filter(sample == "demo_boost") %>% distinct(input_id)

# Use the retained boost-sample respondents on the 24 shared scenarios.
demo_shared_items <- demo_boost_items$input_id

demo_assertions <- tibble::tribble(
  ~check,                              ~expected, ~observed,
  "main rows",                          870L,      as.integer(demo_n_main_rows),
  "main responders",                    727L,      as.integer(demo_n_main_resp),
  "boost rows recruited",               276L,      as.integer(demo_n_boost_rows),
  "boost responders pre-exclusion",     249L,      as.integer(length(demo_boost_pre_responder_rows)),
  "boost botcatch pass",                239L,      as.integer(sum(demo_boost_bot_pre$bot == "pass")),
  "boost botcatch fail",                6L,        as.integer(sum(demo_boost_bot_pre$bot == "fail")),
  "boost botcatch missing",             4L,        as.integer(sum(demo_boost_bot_pre$bot == "missing")),
  "boost retained for analysis",        239L,      as.integer(demo_n_boost_resp),
  "boost scenarios covered",            24L,       as.integer(nrow(demo_boost_items)),
  "boost scenarios all _new",           24L,       as.integer(sum(grepl("_new$", demo_boost_items$input_id)))
) %>%
  mutate(match = expected == observed)

cat("\n  D1 assertions:\n")
print(as.data.frame(demo_assertions))
if (!all(demo_assertions$match)) {
  cat("  ⚠ ASSERTION MISMATCH — the data does not match the documented counts.\n")
} else {
  cat("  ✓ All documented counts reproduce exactly.\n")
}
write.csv(demo_assertions, file.path(out_dir, "table_d1_merge_assertions.csv"), row.names = FALSE)

audit_record(
  "D1 survey merge", "row-bind main and boost surveys",
  rows_in = demo_n_main_rows + demo_n_boost_rows,
  rows_out = nrow(demo_respondents),
  keys_in = demo_n_main_rows + demo_n_boost_rows,
  keys_out = n_distinct(demo_respondents$respondent_uid),
  reason = "identical demographic blocks and no respondent ID in either file, so this is a row-bind not a key join",
  detail = "respondent_uid assigned uniquely within sample; boost arm is post bot-catch"
)


# Map survey demographics to the categories used in model prompts.
cat("\n── D4: demographic category mappings ──\n")

MIN_SUBGROUP_N <- 20

na9999 <- function(x) {
  x <- as.character(x)
  x[is.na(x) | x == "" | x == "9999"] <- NA_character_
  x
}
num9999 <- function(x) suppressWarnings(as.numeric(na9999(x)))

map_politics <- function(x) {
  v <- num9999(x)
  dplyr::case_when(v >= 1 & v <= 4 ~ "democrats",
                   v >= 6 & v <= 9 ~ "republicans",
                   TRUE ~ NA_character_)
}

map_gender <- function(x) {
  v <- na9999(x)
  dplyr::case_when(v == "1" ~ "men", v == "2" ~ "women", TRUE ~ NA_character_)
}

map_age_band <- function(x) {
  v <- num9999(x)
  dplyr::case_when(
    v >= 18 & v <= 28 ~ "18-28", v >= 29 & v <= 36 ~ "29-36",
    v >= 37 & v <= 47 ~ "37-47", v >= 48 & v <= 57 ~ "48-57",
    v >= 58 & v <= 81 ~ "58-81", TRUE ~ NA_character_
  )
}

RACE_MAP <- c(
  "1" = "arabic or central asian", "2" = "black or african",
  "3" = "east asian", "4" = "latino/a", "5" = "native american",
  "6" = "south asian", "7" = "white", "8" = "multiracial"
)
RACE_MULTIRACIAL_CODE <- "8"
RACE_OTHER_CODE <- "9"
map_race_exclusive <- function(x) {
  raw <- as.character(x)
  raw[is.na(raw) | raw == ""] <- NA_character_
  vapply(raw, function(s) {
    if (is.na(s)) return(NA_character_)
    parts <- trimws(strsplit(s, ",")[[1]])
    parts <- parts[parts != "" & parts != "9999"]
    parts <- parts[parts %in% as.character(1:9)]
    if (length(parts) == 0) return(NA_character_)
    if (RACE_OTHER_CODE %in% parts && length(parts) == 1) return(NA_character_)
    if (length(unique(parts)) > 1 || RACE_MULTIRACIAL_CODE %in% parts) return("multiracial")
    unname(RACE_MAP[parts[1]])
  }, character(1), USE.NAMES = FALSE)
}

map_income <- function(x) {
  v <- num9999(x)
  dplyr::case_when(
    v %in% 1:2 ~ "very low income", v %in% 3:4 ~ "low to moderate income",
    v %in% 5:6 ~ "middle income", v %in% 7:8 ~ "high income",
    v %in% 9:10 ~ "extremely high income", TRUE ~ NA_character_
  )
}

CLASS_MAP <- c("1" = "upper class", "2" = "upper middle class",
               "3" = "lower middle class", "4" = "working class",
               "5" = "lower class")
POP_SIZE_MAP <- c("1" = "population under 1,000", "2" = "population 1,000-9,999",
                  "3" = "population 10,000-49,999", "4" = "population 50,000-249,999",
                  "5" = "population 250,000-999,999", "6" = "population 1 million or more")
map_class <- function(x) unname(CLASS_MAP[na9999(x)])
map_pop_size <- function(x) unname(POP_SIZE_MAP[na9999(x)])

demo_categories <- demo_respondents %>%
  mutate(
    dim_politics    = map_politics(politics),
    dim_gender      = map_gender(gender),
    dim_race        = map_race_exclusive(race),
    dim_age         = map_age_band(age),
    dim_income      = map_income(income),
    dim_class       = map_class(class),
    dim_pop_size    = map_pop_size(pop_size)
  )

demo_age_outside_prompt <- demo_categories %>%
  mutate(age_numeric = num9999(age)) %>%
  filter(is.finite(age_numeric), age_numeric < 18 | age_numeric > 81) %>%
  select(respondent_uid, sample, age, age_numeric) %>%
  mutate(handling = "excluded from age dimension only: outside prompted 18-81 range")
write_csv(demo_age_outside_prompt, file.path(out_dir, "CHECK_demo_age_outside_prompt.csv"))

# Audit demographic category mappings and list unmatched survey values.
.race_diag <- demo_categories %>%
  mutate(.race_raw = trimws(as.character(race))) %>%
  filter(is.na(dim_race)) %>%
  mutate(
    .race_class = dplyr::case_when(
      is.na(.race_raw) | .race_raw == ""                 ~ "intended_NA: blank",
      .race_raw == "9999"                                 ~ "intended_NA: 9999 prefer-not-to-answer",
      .race_raw == "9"                                    ~ "intended_NA: code 9 another-group",
      grepl("^[1-8]9,999$", .race_raw)                    ~ "ARTIFACT: [code]9,999 comma-shift",
      TRUE                                                ~ "UNEXPECTED: unmapped value"
    )
  ) %>%
  count(.race_class, .race_raw, name = "n_respondents") %>%
  arrange(.race_class, dplyr::desc(n_respondents))
cat("\n-- Race mapping diagnostic (NA-mapped raw values) --\n")
print(as.data.frame(.race_diag), row.names = FALSE)
cat("   comma-shift artifact respondents:",
    sum(.race_diag$n_respondents[grepl("^ARTIFACT", .race_diag$.race_class)]),
    "| other unexpected:",
    sum(.race_diag$n_respondents[grepl("^UNEXPECTED", .race_diag$.race_class)]), "\n")
readr::write_csv(.race_diag,
                 file.path(out_dir, "CHECK_race_unmapped_values.csv"))

# Coverage per dimension
demo_cat_responders <- demo_categories %>%
  filter(respondent_uid %in% demo_responders$respondent_uid)

demo_dimension_coverage <- demo_cat_responders %>%
  dplyr::select(sample, starts_with("dim_")) %>%
  pivot_longer(starts_with("dim_"), names_to = "dimension", values_to = "category") %>%
  group_by(dimension) %>%
  summarise(
    n_respondents = n(),
    n_mapped = sum(!is.na(category)),
    n_excluded = sum(is.na(category)),
    pct_excluded = 100 * sum(is.na(category)) / n(),
    n_categories = n_distinct(category[!is.na(category)]),
    .groups = "drop"
  ) %>%
  arrange(desc(pct_excluded))

cat("\n  Coverage by dimension (responders only):\n")
print(as.data.frame(demo_dimension_coverage %>% mutate(pct_excluded = round(pct_excluded, 1))))

demo_category_counts <- demo_cat_responders %>%
  dplyr::select(sample, starts_with("dim_")) %>%
  pivot_longer(starts_with("dim_"), names_to = "dimension", values_to = "category") %>%
  count(dimension, category, sample, name = "n") %>%
  pivot_wider(names_from = sample, values_from = n, values_fill = 0) %>%
  mutate(pooled = main + demo_boost,
         below_min_subgroup_n = pooled < MIN_SUBGROUP_N) %>%
  arrange(dimension, desc(pooled))

# Construct the analysis samples and report demographic category coverage in each.
DEMO_DIMENSIONS <- c("dim_politics", "dim_gender", "dim_race",
                     "dim_age", "dim_income", "dim_class",
                     "dim_pop_size")

demo_long_labelled <- demo_human_long %>%
  inner_join(
    demo_categories %>% dplyr::select(respondent_uid, all_of(DEMO_DIMENSIONS)),
    by = "respondent_uid"
  ) %>%
  pivot_longer(all_of(DEMO_DIMENSIONS), names_to = "dimension", values_to = "category") %>%
  filter(!is.na(category))

demo_frame_pooled24 <- demo_long_labelled %>%
  filter(input_id %in% demo_shared_items) %>%
  mutate(analysis_scope = "demographic_pooled_24")

demo_frame_mainonly <- demo_long_labelled %>%
  filter(sample == "main", input_id %in% scenarios_with_humans) %>%
  mutate(analysis_scope = "demographic_main_only_breadth")

DEMO_GROUP_CROSSWALK <- tibble::tribble(
  ~group_index, ~dimension,     ~category,
  1L,  "politics",    "democrats",
  2L,  "politics",    "republicans",
  3L,  "gender",      "men",
  4L,  "gender",      "women",
  5L,  "race",        "white",
  6L,  "race",        "black or african",
  7L,  "race",        "latino/a",
  8L,  "race",        "east asian",
  9L,  "race",        "south asian",
  10L, "race",        "arabic or central asian",
  11L, "race",        "native american",
  12L, "race",        "multiracial",
  22L, "age",         "18-28",
  23L, "age",         "29-36",
  24L, "age",         "37-47",
  25L, "age",         "48-57",
  26L, "age",         "58-81",
  32L, "income",      "very low income",
  33L, "income",      "low to moderate income",
  34L, "income",      "middle income",
  35L, "income",      "high income",
  36L, "income",      "extremely high income",
  37L, "class",       "upper class",
  38L, "class",       "upper middle class",
  39L, "class",       "lower middle class",
  40L, "class",       "working class",
  41L, "class",       "lower class",
  42L, "pop_size",    "population under 1,000",
  43L, "pop_size",    "population 1,000-9,999",
  44L, "pop_size",    "population 10,000-49,999",
  45L, "pop_size",    "population 50,000-249,999",
  46L, "pop_size",    "population 250,000-999,999",
  47L, "pop_size",    "population 1 million or more"
) %>%
  mutate(dimension = paste0("dim_", dimension))

demo_main_intended_items <- sort(intersect(
  stats::na.omit(map_col_to_id(moral_cols)), scenarios_with_humans))
demo_breadth_scope_audit <- tibble(input_id = sort(unique(scenarios_with_humans))) %>%
  mutate(in_primary_scope = TRUE, in_demographic_main_scope = input_id %in% demo_main_intended_items,
         note = "demographic breadth uses original questionnaire IDs without copied stimulus aliases")
write_csv(demo_breadth_scope_audit, file.path(out_dir, "CHECK_demographic_breadth_scope.csv"))

complete_demo_coverage <- function(observed, intended_items, intended_categories) {
  grid <- merge(intended_items, intended_categories, by = NULL, sort = FALSE) %>% as_tibble()
  if (anyDuplicated(observed[c("analysis_scope", "dimension", "category", "input_id")]))
    stop("Duplicate observed demographic coverage keys.")
  grid %>% left_join(observed, by = c("analysis_scope", "dimension", "category", "input_id")) %>%
    mutate(cell_n = tidyr::replace_na(cell_n, 0L))
}
demo_intended_items <- bind_rows(
  tibble(analysis_scope = "demographic_pooled_24", input_id = sort(unique(demo_shared_items))),
  tibble(analysis_scope = "demographic_main_only_breadth", input_id = demo_main_intended_items)
)
demo_cell_counts <- complete_demo_coverage(
  bind_rows(demo_frame_pooled24, demo_frame_mainonly) %>%
    distinct(analysis_scope, dimension, category, input_id, respondent_uid) %>%
    count(analysis_scope, dimension, category, input_id, name = "cell_n"),
  demo_intended_items, DEMO_GROUP_CROSSWALK %>% distinct(dimension, category))
write_csv(demo_cell_counts, file.path(out_dir, "CHECK_demographic_cell_coverage_complete.csv"))
demo_cell_coverage <- demo_cell_counts %>%
  group_by(analysis_scope, dimension, category) %>%
  summarise(n_scenarios = n_distinct(input_id),
    n_scenarios_observed = sum(cell_n > 0), n_zero_cells = sum(cell_n == 0),
    median_cell_n = stats::median(cell_n), min_cell_n = min(cell_n),
    pct_cells_ge_min = 100 * mean(cell_n >= MIN_SUBGROUP_N), .groups = "drop") %>%
  mutate(clears_threshold = median_cell_n >= MIN_SUBGROUP_N)

demo_category_coverage <- demo_cell_coverage %>%
  dplyr::select(dimension, category, analysis_scope, median_cell_n, clears_threshold) %>%
  pivot_wider(names_from = analysis_scope,
              values_from = c(median_cell_n, clears_threshold)) %>%
  rename(
    pooled24_median_cell_n   = median_cell_n_demographic_pooled_24,
    mainonly_median_cell_n   = median_cell_n_demographic_main_only_breadth,
    pooled24_clears_20       = clears_threshold_demographic_pooled_24,
    mainonly_clears_20       = clears_threshold_demographic_main_only_breadth
  ) %>%
  mutate(
    across(c(pooled24_clears_20, mainonly_clears_20), ~ tidyr::replace_na(.x, FALSE)),
    analyzable_in = dplyr::case_when(
      pooled24_clears_20 & mainonly_clears_20 ~ "both frames",
      pooled24_clears_20 & !mainonly_clears_20 ~ "pooled-24 only",
      !pooled24_clears_20 & mainonly_clears_20 ~ "main-only breadth only",
      TRUE ~ "neither frame"
    )
  ) %>%
  arrange(dimension, desc(pooled24_median_cell_n))

write.csv(demo_category_coverage, file.path(out_dir, "table_d2_category_coverage_by_frame.csv"), row.names = FALSE)

cat("\n── D2: per-category coverage in both frames (MIN_SUBGROUP_N =",
    MIN_SUBGROUP_N, ") ──\n")
cat("  Categories defined:", nrow(demo_category_coverage), "\n")
print(as.data.frame(demo_category_coverage))

demo_dimension_resolution <- demo_category_coverage %>%
  group_by(dimension) %>%
  summarise(
    n_categories = n(),
    n_pooled24_ok = sum(pooled24_clears_20),
    n_mainonly_ok = sum(mainonly_clears_20),
    full_resolution_pooled24 = n_pooled24_ok == n_categories,
    full_resolution_mainonly = n_mainonly_ok == n_categories,
    retained_pooled24 = paste(sort(category[pooled24_clears_20]), collapse = "; "),
    excluded_pooled24 = paste(sort(category[!pooled24_clears_20]), collapse = "; "),
    .groups = "drop"
  ) %>%
  arrange(desc(full_resolution_pooled24), dimension)

write.csv(demo_dimension_resolution,
          file.path(out_dir, "table_d2_dimension_resolution.csv"), row.names = FALSE)

cat("\n  Dimension resolution (per-scenario subgroup means):\n")
print(as.data.frame(
  demo_dimension_resolution %>%
    dplyr::select(dimension, n_categories, n_pooled24_ok, n_mainonly_ok,
                  full_resolution_pooled24, full_resolution_mainonly)
))

cat("\n  NOT analyzable at full resolution in the pooled-24 frame:\n")
for (i in seq_len(nrow(demo_dimension_resolution))) {
  r <- demo_dimension_resolution[i, ]
  if (!r$full_resolution_pooled24) {
    cat(sprintf("    %-18s %d of %d categories retained. Excluded (N below %d): %s\n",
                r$dimension, r$n_pooled24_ok, r$n_categories, MIN_SUBGROUP_N,
                ifelse(nzchar(r$excluded_pooled24), r$excluded_pooled24, "-")))
  }
}

demo_frame_asymmetric <- demo_category_coverage %>%
  filter(analyzable_in %in% c("pooled-24 only", "main-only breadth only"))
cat("\n  Categories analyzable in only ONE frame:", nrow(demo_frame_asymmetric), "\n")
if (nrow(demo_frame_asymmetric) > 0) {
  print(as.data.frame(demo_frame_asymmetric %>%
    dplyr::select(dimension, category, pooled24_median_cell_n,
                  mainonly_median_cell_n, analyzable_in)))
}

demo_frame_capacity <- demo_dimension_resolution %>%
  transmute(
    dimension = sub("^dim_", "", dimension),
    n_categories,
    pooled_24_categories_analyzable = n_pooled24_ok,
    main_only_breadth_categories_analyzable = n_mainonly_ok,
    pooled_24_full_resolution = full_resolution_pooled24,
    main_only_full_resolution = full_resolution_mainonly
  ) %>%
  arrange(main_only_breadth_categories_analyzable, dimension)

# Generate caption counts from the current sample-capacity table.
demo_cap_full_pooled <- sum(demo_frame_capacity$pooled_24_full_resolution)
demo_cap_full_main   <- demo_frame_capacity$dimension[demo_frame_capacity$main_only_full_resolution]
demo_cap_race        <- demo_frame_capacity[demo_frame_capacity$dimension == "race", ]
demo_cap_age         <- demo_frame_capacity[demo_frame_capacity$dimension == "age", ]
stopifnot(nrow(demo_cap_race) == 1L, nrow(demo_cap_age) == 1L)

DEMO_FRAME_CAPACITY_CAPTION <- paste0(
  "Demographic resolution supported by each human-sample frame. ",
  "Entries are the number of categories in each dimension whose MEDIAN ",
  "per-scenario subgroup cell reaches MIN_SUBGROUP_N = ", MIN_SUBGROUP_N,
  " raters, including zero counts for unobserved scenario-category cells. ",
  "The pooled frame (", length(unique(demo_shared_items)),
  " boosted scenarios, main + bot-pass boost) supports full resolution on ",
  demo_cap_full_pooled, " of ", nrow(demo_frame_capacity), " dimensions. ",
  "The main-only breadth frame (", length(demo_main_intended_items),
  " original questionnaire scenario IDs in the primary scope, without copied aliases) ",
  "supports full resolution on ",
  if (length(demo_cap_full_main)) paste(demo_cap_full_main, collapse = ", ") else "no dimensions",
  "; it clears ",
  demo_cap_race$main_only_breadth_categories_analyzable, " of ",
  demo_cap_race$n_categories, " race categories and ",
  demo_cap_age$main_only_breadth_categories_analyzable, " of ",
  demo_cap_age$n_categories, " age categories. These counts describe the ",
  "resolution supported by the observed sample at the stated threshold."
)

write.csv(demo_frame_capacity,
          file.path(out_dir, "table_d2_frame_demographic_capacity.csv"), row.names = FALSE)
writeLines(DEMO_FRAME_CAPACITY_CAPTION,
           file.path(out_dir, "table_d2_frame_demographic_capacity_caption.txt"))

demo_excluded_categories <- demo_category_coverage %>%
  filter(!pooled24_clears_20 | !mainonly_clears_20) %>%
  left_join(
    demo_category_counts %>%
      transmute(dimension, category, n_main = main, n_boost = demo_boost, n_pooled = pooled),
    by = c("dimension", "category")
  ) %>%
  transmute(
    dimension = sub("^dim_", "", dimension),
    category,
    n_respondents_pooled = coalesce(n_pooled, 0L),
    pooled24_median_cell_n, mainonly_median_cell_n,
    excluded_from = dplyr::case_when(
      !pooled24_clears_20 & !mainonly_clears_20 ~ "both frames",
      !pooled24_clears_20 ~ "pooled-24",
      TRUE ~ "main-only breadth"
    )
  ) %>%
  arrange(excluded_from, dimension, n_respondents_pooled)

# Generate the coverage caption from the current exclusion and coverage tables.
demo_excl_both   <- demo_excluded_categories[demo_excluded_categories$excluded_from == "both frames", ]
demo_excl_race_n <- sum(demo_excl_both$dimension == "race")
demo_race_total  <- sum(sub("^dim_", "", demo_category_coverage$dimension) == "race")


write.csv(demo_excluded_categories,
          file.path(out_dir, "table_d2_excluded_categories.csv"), row.names = FALSE)

write.csv(demo_category_counts, file.path(out_dir, "table_d4_demographic_category_counts.csv"), row.names = FALSE)
write.csv(demo_dimension_coverage, file.path(out_dir, "table_d4_dimension_coverage.csv"), row.names = FALSE)

# Size of the two surfaced exclusions.
demo_excluded_politics <- sum(num9999(demo_cat_responders$politics) == 5, na.rm = TRUE)
cat("\n  Politics midpoint excluded:", demo_excluded_politics,
    sprintf("(%.1f%% of responders)\n", 100 * demo_excluded_politics / nrow(demo_cat_responders)))

audit_record(
  "D4 politics mapping", "drop ideology midpoint",
  rows_in = nrow(demo_cat_responders),
  rows_out = nrow(demo_cat_responders) - demo_excluded_politics,
  reason = "the 1-9 ideology midpoint has no party counterpart in the prompts",
  detail = "construct mismatch between ideology and party identification stated as a limitation"
)


# Compare the main and demographic boost samples on their 24 shared scenarios.
demo_item_means <- demo_human_long %>%
  filter(input_id %in% demo_shared_items) %>%
  group_by(input_id, sample) %>%
  summarise(item_mean = mean(human_y, na.rm = TRUE), n_raters = n(), .groups = "drop") %>%
  pivot_wider(names_from = sample, values_from = c(item_mean, n_raters)) %>%
  filter(!is.na(item_mean_main), !is.na(item_mean_demo_boost))

demo_sample_r <- stats::cor(demo_item_means$item_mean_main, demo_item_means$item_mean_demo_boost)
demo_sample_t <- stats::t.test(demo_item_means$item_mean_demo_boost,
                               demo_item_means$item_mean_main, paired = TRUE)

demo_sample_equivalence <- tibble(
  n_items = nrow(demo_item_means),
  r_item_means = demo_sample_r,
  mean_main = mean(demo_item_means$item_mean_main),
  mean_boost = mean(demo_item_means$item_mean_demo_boost),
  mean_difference_boost_minus_main = unname(demo_sample_t$estimate),
  ci_low = demo_sample_t$conf.int[1], ci_high = demo_sample_t$conf.int[2],
  t = unname(demo_sample_t$statistic), df = unname(demo_sample_t$parameter),
  p_value = demo_sample_t$p.value,
  dz = unname(demo_sample_t$estimate) /
    stats::sd(demo_item_means$item_mean_demo_boost - demo_item_means$item_mean_main),
  median_n_raters_main = stats::median(demo_item_means$n_raters_main),
  median_n_raters_boost = stats::median(demo_item_means$n_raters_demo_boost)
)

write.csv(demo_sample_equivalence, file.path(out_dir, "table_d1_sample_equivalence.csv"), row.names = FALSE)
cat("\n  D1 sample comparison on the", nrow(demo_item_means), "shared items:\n")
print(as.data.frame(demo_sample_equivalence %>% mutate(across(where(is.numeric), ~ round(.x, 4)))))

cat("\n", strrep("=", 70),
    "\nPART D3 — DEMOGRAPHIC RUN A / RUN B\n", strrep("=", 70), "\n")

DEMO_EXCLUDED_GROUP_SETS <- list(
  religion    = 13:21,
  religiosity = 27:31
)
DEMO_EXCLUDED_GROUP_INDEX <- sort(unlist(DEMO_EXCLUDED_GROUP_SETS, use.names = FALSE))
DEMO_N_GROUPS <- nrow(DEMO_GROUP_CROSSWALK)

write.csv(DEMO_GROUP_CROSSWALK,
          file.path(out_dir, "table_d3_group_crosswalk.csv"), row.names = FALSE)

demo_crosswalk_check <- DEMO_GROUP_CROSSWALK %>%
  left_join(demo_category_coverage %>% dplyr::select(dimension, category) %>%
              mutate(on_human_side = TRUE),
            by = c("dimension", "category")) %>%
  mutate(on_human_side = tidyr::replace_na(on_human_side, FALSE))

cat("  Crosswalk groups matched to a human category:",
    sum(demo_crosswalk_check$on_human_side), "of", nrow(demo_crosswalk_check), "\n")
if (any(!demo_crosswalk_check$on_human_side)) {
  readr::write_csv(
    demo_crosswalk_check %>% filter(!on_human_side),
    file.path(out_dir, "CHECK_demographic_crosswalk_unmatched.csv")
  )
  stop(
    "The demographic crosswalk has unmatched human categories; ",
    "see CHECK_demographic_crosswalk_unmatched.csv."
  )
}

# Run A loader
path_demo_runA <- c(
  "gpt-4o-mini"  = file.path(base_dir, "gpt4o_reworded_runA_temp0_47_enriched_v2.jsonl"),
  "gpt-3.5"      = file.path(base_dir, "gpt35_reworded_runA_temp0_47_enriched_v2.jsonl"),
  "gpt-5.1"      = file.path(base_dir, "gpt51_reworded_runA_temp0_47_enriched_v2.jsonl"),
  "gpt-oss"      = file.path(base_dir, "gptoss_reworded_runA_temp0_47_enriched_v2.jsonl"),
  "qwen"         = file.path(base_dir, "qwen_reworded_runA_temp0_47_enriched_v2.jsonl")
)

load_demo_runA <- function(path, label) {
  if (!file.exists(path)) { cat("  ⚠ Not found:", label, "\n"); return(NULL) }
  raw <- read_model_file_safe(path, basename(path))
  n_all <- nrow(raw)
  t0 <- raw %>% filter(as.character(temperature) == "0")
  audit_record(
    "D3 Run A", paste0("filter ", label, " to temperature 0"),
    rows_in = n_all, rows_out = nrow(t0),
    reason = "Run A is the temperature-0 point-estimate design",
    detail = basename(path)
  )
  ext <- extract_rating(t0$output_seq)
  parsed <- t0 %>%
    mutate(rating = ext$rating, rating_rule = ext$source,
           group_index = suppressWarnings(as.integer(
             stringr::str_match(prompt_src_basename, "repeat_500_(\\d+)_")[, 2])),
           model_name = normalize_model_name(model_name),
           input_id = canonical_scenario_id(input_id))
  write_rating_parse_audit(parsed, paste0("demo_runA_", label))
  bad <- parsed %>% filter(is.na(rating) | is.na(group_index) | is.na(input_id))
  if (nrow(bad) > 0) {
    safe_label <- stringr::str_replace_all(label, "[^A-Za-z0-9]+", "_")
    check_file <- paste0("CHECK_demo_runA_unusable_", safe_label, ".csv")
    readr::write_csv(
      bad %>% dplyr::select(any_of(c(
        "input_id", "model_name", "temperature", "prompt_src_basename",
        "group_index", "rating", "rating_rule", "output_seq"
      ))),
      file.path(out_dir, check_file)
    )

    warning(
      label, " Run A non-response: ", nrow(bad), " of ", nrow(parsed),
      " temperature-0 rows are unusable (",
      sprintf("%.2f%%", 100 * nrow(bad) / nrow(parsed)),
      "); recorded in ", check_file,
      call. = FALSE, immediate. = TRUE
    )
    cat(sprintf("  Non-response: %d of %d rows (%.2f%%) unusable -> %s\n",
                nrow(bad), nrow(parsed), 100 * nrow(bad) / nrow(parsed), check_file))
  }
  parsed <- parsed %>% filter(!is.na(rating), !is.na(group_index), !is.na(input_id))

  out <- parsed %>% filter(!group_index %in% DEMO_EXCLUDED_GROUP_INDEX)
  audit_record(
    "D3 Run A", paste0("load ", label),
    rows_in = n_all, rows_out = nrow(out),
    keys_in = n_all, keys_out = n_distinct(paste(out$input_id, out$group_index)),
    reason = "drop rows with no recoverable rating or no group index",
    detail = basename(path)
  )
  cat(sprintf("  %-12s %6d rows  %3d scenarios  %2d groups  model: %s\n",
              label, nrow(out), n_distinct(out$input_id),
              n_distinct(out$group_index), paste(unique(out$model_name), collapse = ",")))
  out %>% dplyr::select(input_id, model_name, group_index, rating)
}

cat("\n── Run A (temperature 0, one shot, point estimate) ──\n")
demo_runA <- purrr::imap(path_demo_runA, ~ load_demo_runA(.x, .y)) %>%
  purrr::compact() %>% bind_rows()

if (nrow(demo_runA) > 0) {
  demo_runA_dupes <- demo_runA %>%
    count(model_name, input_id, group_index, name = "n") %>% filter(n > 1)
  cat("  Duplicated model x scenario x group cells:", nrow(demo_runA_dupes), "\n")
  cat("  Run A total:", nrow(demo_runA), "rows,",
      n_distinct(demo_runA$model_name), "models\n")
  audit_record(
    "D3 Run A", "assert one record per model x scenario x group",
    rows_in = nrow(demo_runA), rows_out = nrow(demo_runA),
    unmatched_keys = nrow(demo_runA_dupes),
    reason = "the v2 files are documented as one record per cell with no duplicates",
    detail = paste0(nrow(demo_runA_dupes), " duplicated cells")
  )

  DEMO_RUNA_EXPECTED_MODELS <- c(
    "gpt-35-turbo_1106",
    "gpt-4o-mini_2024-07-18",
    "gpt-5.1_2025-11-13",
    "gpt-oss-20b",
    "qwen-3-32B"
  )
  demo_runA_coverage <- demo_runA %>%
    distinct(model_name, input_id, group_index) %>%
    count(model_name, name = "n_cells") %>%
    tidyr::complete(
      model_name = DEMO_RUNA_EXPECTED_MODELS,
      fill = list(n_cells = 0L)
    ) %>%
    mutate(
      expected_cells = 145L * DEMO_N_GROUPS,
      cell_coverage = n_cells / expected_cells
    )
  readr::write_csv(
    demo_runA_coverage,
    file.path(out_dir, "CHECK_demo_runA_coverage.csv")
  )

  DEMO_RUNA_MIN_CELL_COVERAGE <- 0.99
  if (any(demo_runA_coverage$n_cells < demo_runA_coverage$expected_cells &
          demo_runA_coverage$cell_coverage >= DEMO_RUNA_MIN_CELL_COVERAGE)) {
    shortA <- demo_runA_coverage %>%
      filter(n_cells < expected_cells, cell_coverage >= DEMO_RUNA_MIN_CELL_COVERAGE)
    warning(
      "Run A cell shortfall: ", nrow(shortA), " model(s) below the nominal ",
      unique(demo_runA_coverage$expected_cells), " cells but at or above ",
      sprintf("%.0f%%", 100 * DEMO_RUNA_MIN_CELL_COVERAGE), " coverage (min ",
      min(shortA$n_cells), ", max ", max(shortA$n_cells),
      "); see CHECK_demo_runA_coverage.csv.",
      call. = FALSE, immediate. = TRUE
    )
    cat(sprintf("  Run A cell shortfall: %d model(s), %d-%d of %d cells (min coverage %.2f%%)\n",
                nrow(shortA), min(shortA$n_cells), max(shortA$n_cells),
                unique(demo_runA_coverage$expected_cells),
                100 * min(shortA$cell_coverage)))
  }
  #duplicates, wrong model set, or coverage below the threshold.
  if (nrow(demo_runA_dupes) > 0 ||
      !setequal(unique(demo_runA$model_name), DEMO_RUNA_EXPECTED_MODELS) ||
      any(demo_runA_coverage$cell_coverage < DEMO_RUNA_MIN_CELL_COVERAGE) ||
      any(demo_runA_coverage$n_cells > demo_runA_coverage$expected_cells)) {
    if (nrow(demo_runA_dupes) > 0) {
      readr::write_csv(
        demo_runA_dupes,
        file.path(out_dir, "CHECK_demo_runA_duplicate_cells.csv")
      )
    }
    stop(
      "Run A must cover 5 models x 145 scenarios x ", DEMO_N_GROUPS,
      " groups (religion and religiosity groups ",
      paste(DEMO_EXCLUDED_GROUP_INDEX, collapse = ","), " excluded) with at least ",
      sprintf("%.0f%%", 100 * DEMO_RUNA_MIN_CELL_COVERAGE),
      " cell coverage and no duplicates; see CHECK_demo_runA_coverage.csv."
    )
  }
} else {
  stop("No valid Run A rows were loaded.")
}

# Run B loader
path_demo_runB <- c(
  "gpt-5.1"     = file.path(demographics_dir, "demographics_runB_temp1_500reps_47_gpt5.jsonl"),
  "qwen"        = file.path(demographics_dir, "demographics_runB_temp1_500reps_47_qwen32B.jsonl"),
  "gpt-4o-mini" = file.path(demographics_dir, "demographics_runB_temp1_500reps_47_gpt4o"),
  "gpt-oss"     = file.path(demographics_dir, "demographics_runB_temp1_500reps_47_enriched_gptoss")
)

load_demo_runB <- function(path, label) {
  if (!file.exists(path)) { cat("  ⚠ Not found:", label, "->", path, "\n"); return(NULL) }
  raw <- read_model_file_safe(path, basename(path))
  n_all <- nrow(raw)
  t1 <- raw %>% filter(as.character(temperature) == "1")
  ext <- extract_rating(t1$output_seq)
  parsed <- t1 %>%
    mutate(rating = ext$rating, rating_rule = ext$source,
           group_index = suppressWarnings(as.integer(prompt_id)),
           model_name = normalize_model_name(model_name),
           input_id = canonical_scenario_id(
             stringr::str_replace(stringr::str_replace(input_id, "^X", ""), "_moral$", "")))
  write_rating_parse_audit(parsed, paste0("demo_runB_", label))
  bad <- parsed %>% filter(is.na(rating) | is.na(group_index) | is.na(input_id))
  if (nrow(bad) > 0) {
    safe_label <- stringr::str_replace_all(label, "[^A-Za-z0-9]+", "_")
    check_file <- paste0("CHECK_demo_runB_unusable_", safe_label, ".csv")
    readr::write_csv(
      bad %>% dplyr::select(any_of(c(
        "input_id", "model_name", "temperature", "prompt_id", "group_index",
        "rating", "output_seq"
      ))),
      file.path(out_dir, check_file)
    )
    warning(
      label, " Run B non-response: ", nrow(bad), " of ", nrow(parsed),
      " temperature-1 rows are unusable (",
      sprintf("%.2f%%", 100 * nrow(bad) / nrow(parsed)),
      "); recorded in ", check_file,
      call. = FALSE, immediate. = TRUE
    )
    cat(sprintf("  Non-response: %d of %d rows (%.2f%%) unusable -> %s\n",
                nrow(bad), nrow(parsed), 100 * nrow(bad) / nrow(parsed), check_file))
  }
  parsed <- parsed %>% filter(!is.na(rating), !is.na(group_index), !is.na(input_id))

  out <- parsed %>% filter(!group_index %in% DEMO_EXCLUDED_GROUP_INDEX)
  audit_record(
    "D3 Run B", paste0("load ", label),
    rows_in = n_all, rows_out = nrow(out),
    keys_in = n_all, keys_out = n_distinct(paste(out$input_id, out$group_index)),
    reason = "filter to temperature 1, drop unparseable ratings, crosswalk X<id>_moral to canonical scenario id",
    detail = basename(path)
  )
  cat(sprintf("  %-10s %7d draws  %2d scenarios  %2d groups  model: %s\n",
              label, nrow(out), n_distinct(out$input_id),
              n_distinct(out$group_index), paste(unique(out$model_name), collapse = ",")))

  out %>%
    mutate(y = clamp_scale(rating)) %>%
    count(input_id, model_name, group_index, y, name = "n_draws") %>%
    dplyr::select(input_id, model_name, group_index, y, n_draws)
}

cat("\n── Run B (temperature 1, 500 repetitions, distribution) ──\n")
demo_runB <- purrr::imap(path_demo_runB, ~ load_demo_runB(.x, .y)) %>%
  purrr::compact() %>% bind_rows()

DEMO_RUNB_EXPECTED_MODELS <- c(
  "gpt-4o-mini_2024-07-18",
  "gpt-5.1_2025-11-13",
  "gpt-oss-20b",
  "qwen-3-32B"
)
demo_runB_cell_coverage <- demo_runB %>%
  group_by(model_name, input_id, group_index) %>%
  summarise(draws = sum(n_draws), .groups = "drop")
demo_runB_model_coverage <- demo_runB_cell_coverage %>%
  group_by(model_name) %>%
  summarise(
    n_cells = n(),
    n_scenarios = n_distinct(input_id),
    n_groups = n_distinct(group_index),
    min_draws = min(draws),
    median_draws = stats::median(draws),
    max_draws = max(draws),
    n_below_floor = sum(draws < REPEATED_MIN_DRAWS),
    n_below_nominal = sum(draws < REPEATED_NOMINAL_DRAWS),
    .groups = "drop"
  ) %>%
  tidyr::complete(
    model_name = DEMO_RUNB_EXPECTED_MODELS,
    fill = list(
      n_cells = 0L, n_scenarios = 0L, n_groups = 0L,
      min_draws = 0L, max_draws = 0L
    )
  )
readr::write_csv(
  demo_runB_model_coverage,
  file.path(out_dir, "CHECK_demo_runB_coverage.csv")
)

demo_runB_below_floor <- demo_runB_cell_coverage %>%
  filter(draws < REPEATED_MIN_DRAWS)
demo_runB_below_nominal <- demo_runB_cell_coverage %>%
  filter(draws < REPEATED_NOMINAL_DRAWS, draws >= REPEATED_MIN_DRAWS)

if (nrow(demo_runB_below_nominal) > 0) {
  warning(
    "Run B: ", nrow(demo_runB_below_nominal), " of ", nrow(demo_runB_cell_coverage),
    " model x scenario x group cells are below the nominal ", REPEATED_NOMINAL_DRAWS,
    " draws but at or above the ", REPEATED_MIN_DRAWS, " floor (min ",
    min(demo_runB_below_nominal$draws), ", median ",
    stats::median(demo_runB_below_nominal$draws), ", max ",
    max(demo_runB_below_nominal$draws), "); see CHECK_demo_runB_coverage.csv.",
    call. = FALSE, immediate. = TRUE
  )
  cat(sprintf("  Run B draw shortfall: %d of %d cells in [%d, %d) draws (min %d, median %g, max %d)\n",
              nrow(demo_runB_below_nominal), nrow(demo_runB_cell_coverage),
              REPEATED_MIN_DRAWS, REPEATED_NOMINAL_DRAWS,
              min(demo_runB_below_nominal$draws),
              stats::median(demo_runB_below_nominal$draws),
              max(demo_runB_below_nominal$draws)))
}
if (!setequal(unique(demo_runB$model_name), DEMO_RUNB_EXPECTED_MODELS) ||
    any(demo_runB_model_coverage$n_cells != 24L * DEMO_N_GROUPS) ||
    any(demo_runB_model_coverage$n_scenarios != 24L) ||
    any(demo_runB_model_coverage$n_groups != DEMO_N_GROUPS) ||
    nrow(demo_runB_below_floor) > 0 ||
    any(demo_runB_model_coverage$max_draws > REPEATED_NOMINAL_DRAWS)) {
  stop(
    "Run B must cover 4 models x 24 scenarios x ", DEMO_N_GROUPS,
    " groups (religion and religiosity groups ",
    paste(DEMO_EXCLUDED_GROUP_INDEX, collapse = ","),
    " excluded) with at least ", REPEATED_MIN_DRAWS, " draws per cell; ",
    "see CHECK_demo_runB_coverage.csv."
  )
}


# Evaluate model alignment with demographic group means.
cat("\n", strrep("=", 70),
    "\nPART D5 — SUBGROUP ALIGNMENT\n", strrep("=", 70), "\n")

demo_frames_all <- bind_rows(demo_frame_pooled24, demo_frame_mainonly)

# Human group means per frame x dimension x category x scenario, with N.
demo_subgroup_means <- demo_frames_all %>%
  group_by(analysis_scope, dimension, category, input_id) %>%
  summarise(subgroup_mean = mean(human_y, na.rm = TRUE),
            subgroup_sd = stats::sd(human_y, na.rm = TRUE),
            subgroup_n = n(), .groups = "drop")

demo_categories_analyzable <- demo_cell_coverage %>%
  filter(clears_threshold) %>%
  dplyr::select(analysis_scope, dimension, category)

demo_subgroup_means_ok <- demo_subgroup_means %>%
  filter(subgroup_n >= MIN_SUBGROUP_N) %>%
  semi_join(demo_categories_analyzable,
            by = c("analysis_scope", "dimension", "category"))

cat("  Subgroup x scenario cells:", nrow(demo_subgroup_means),
    "\n  cells meeting MIN_SUBGROUP_N:",
    sum(demo_subgroup_means$subgroup_n >= MIN_SUBGROUP_N),
    "\n  cells retained after category-level gating:", nrow(demo_subgroup_means_ok), "\n")

audit_record(
  "D5 subgroup gating", "apply cell-level AND category-level MIN_SUBGROUP_N",
  rows_in = sum(demo_subgroup_means$subgroup_n >= MIN_SUBGROUP_N),
  rows_out = nrow(demo_subgroup_means_ok),
  reason = "a category whose median cell is below threshold would otherwise contribute only its upper-half cells, contradicting the coverage tables and resting on a self-selected scenario subset",
  detail = "category-level gate matches the rule reported in table_d2_category_coverage_by_frame.csv"
)

demo_runA_joined <- demo_runA %>%
  inner_join(DEMO_GROUP_CROSSWALK, by = "group_index") %>%
  inner_join(demo_subgroup_means_ok, by = c("dimension", "category", "input_id"),
             relationship = "many-to-many") %>%
  mutate(signed_error = rating - subgroup_mean,
         abs_error = abs(signed_error))

# One row per model x scenario x group x frame, and no more.
demo_runA_join_dupes <- demo_runA_joined %>%
  count(model_name, input_id, group_index, analysis_scope, name = "n") %>%
  filter(n > 1)
cat("  Run A join fan-out check — rows beyond one per model x scenario x group x frame:",
    nrow(demo_runA_join_dupes), "\n")
if (nrow(demo_runA_join_dupes) > 0) {
  cat("  ⚠ The join fanned out unexpectedly.\n")
  print(head(as.data.frame(demo_runA_join_dupes), 10))
}

audit_record(
  "D5 Run A alignment", "join Run A predictions to human subgroup means",
  rows_in = nrow(demo_runA), rows_out = nrow(demo_runA_joined),
  keys_in = n_distinct(paste(demo_runA$model_name, demo_runA$input_id, demo_runA$group_index)),
  keys_out = n_distinct(paste(demo_runA_joined$model_name, demo_runA_joined$input_id,
                              demo_runA_joined$group_index, demo_runA_joined$analysis_scope)),
  reason = "restricted to subgroup x scenario cells meeting MIN_SUBGROUP_N, in both frames",
  detail = "Run A is a point estimate and is evaluated against subgroup means only"
)

fisher_ci <- function(r, n) {
  if (is.na(r) || n < 4) return(c(NA_real_, NA_real_))
  se <- 1 / sqrt(n - 3)
  c(tanh(atanh(r) - 1.96 * se), tanh(atanh(r) + 1.96 * se))
}

# Per model x frame x dimension x category, with subgroup N on every row.
demo_runA_alignment_category <- demo_runA_joined %>%
  group_by(analysis_scope, model_name, dimension, category) %>%
  summarise(
    n_scenarios = n_distinct(input_id),
    median_subgroup_n = stats::median(subgroup_n),
    min_subgroup_n = min(subgroup_n),
    r = suppressWarnings(stats::cor(rating, subgroup_mean, use = "complete.obs")),
    mse = mean(signed_error^2, na.rm = TRUE),
    mae = mean(abs_error, na.rm = TRUE),
    signed_bias = mean(signed_error, na.rm = TRUE),
    bias_ci_low = signed_bias - stats::qt(.975, df = n() - 1) * stats::sd(signed_error, na.rm = TRUE) / sqrt(n()),
    bias_ci_high = signed_bias + stats::qt(.975, df = n() - 1) * stats::sd(signed_error, na.rm = TRUE) / sqrt(n()),
    .groups = "drop"
  ) %>%
  rowwise() %>%
  mutate(r_ci_low = fisher_ci(r, n_scenarios)[1],
         r_ci_high = fisher_ci(r, n_scenarios)[2]) %>%
  ungroup() %>%
  mutate(human_sample_source = ifelse(analysis_scope == "demographic_pooled_24",
                                      "main + bot-pass boost", "main only"),
         model_run = "Run A", prompt_type = "single rating",
         temperature_design = "temperature 0, one shot") %>%
  arrange(analysis_scope, model_name, dimension, desc(r))

demo_runA_alignment_dimension <- demo_runA_joined %>%
  group_by(analysis_scope, model_name, dimension) %>%
  summarise(
    n_categories = n_distinct(category),
    n_scenarios = n_distinct(input_id),
    median_subgroup_n = stats::median(subgroup_n),
    r = suppressWarnings(stats::cor(rating, subgroup_mean, use = "complete.obs")),
    mse = mean(signed_error^2, na.rm = TRUE),
    mae = mean(abs_error, na.rm = TRUE),
    signed_bias = mean(signed_error, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(human_sample_source = ifelse(analysis_scope == "demographic_pooled_24",
                                      "main + bot-pass boost", "main only"),
         model_run = "Run A", prompt_type = "single rating",
         temperature_design = "temperature 0, one shot")

write.csv(demo_runA_alignment_category,
          file.path(out_dir, "table_d5_runA_alignment_by_category.csv"), row.names = FALSE)
write.csv(demo_runA_alignment_dimension,
          file.path(out_dir, "table_d5_runA_alignment_by_dimension.csv"), row.names = FALSE)

cat("\n  Run A alignment by model x dimension (pooled-24 frame):\n")
print(as.data.frame(
  demo_runA_alignment_dimension %>%
    filter(analysis_scope == "demographic_pooled_24") %>%
    dplyr::select(model_name, dimension, n_categories, median_subgroup_n, r, mae, signed_bias) %>%
    mutate(across(where(is.numeric), ~ round(.x, 3)))
))

demo_runA_decomp <- demo_runA_joined %>%
  group_by(analysis_scope, model_name, dimension, input_id) %>%
  filter(n() >= 2) %>%
  mutate(
    model_within = rating - mean(rating, na.rm = TRUE),
    human_within = subgroup_mean - mean(subgroup_mean, na.rm = TRUE)
  ) %>%
  ungroup()

demo_runA_r_components <- demo_runA_decomp %>%
  group_by(analysis_scope, model_name, dimension) %>%
  summarise(
    n_obs = n(),
    n_scenarios = n_distinct(input_id),
    n_categories = n_distinct(category),
    median_subgroup_n = stats::median(subgroup_n),
    r_overall = suppressWarnings(stats::cor(rating, subgroup_mean, use = "complete.obs")),
    r_within_scenario = suppressWarnings(stats::cor(model_within, human_within, use = "complete.obs")),
    sd_model_within = stats::sd(model_within, na.rm = TRUE),
    sd_human_within = stats::sd(human_within, na.rm = TRUE),
    .groups = "drop"
  )

# Between-scenario component: collapse groups to a scenario mean on each side.
demo_runA_r_between <- demo_runA_joined %>%
  group_by(analysis_scope, model_name, dimension, input_id) %>%
  summarise(model_scen = mean(rating, na.rm = TRUE),
            human_scen = mean(subgroup_mean, na.rm = TRUE), .groups = "drop") %>%
  group_by(analysis_scope, model_name, dimension) %>%
  summarise(r_between_scenario = suppressWarnings(
    stats::cor(model_scen, human_scen, use = "complete.obs")), .groups = "drop")

demo_runA_r_components <- demo_runA_r_components %>%
  left_join(demo_runA_r_between, by = c("analysis_scope", "model_name", "dimension")) %>%
  mutate(
    within_sd_ratio = sd_model_within / sd_human_within,
    human_sample_source = ifelse(analysis_scope == "demographic_pooled_24",
                                 "main + bot-pass boost", "main only"),
    model_run = "Run A"
  ) %>%
  dplyr::select(analysis_scope, human_sample_source, model_run, model_name, dimension,
                n_scenarios, n_categories, median_subgroup_n,
                r_overall, r_between_scenario, r_within_scenario,
                sd_model_within, sd_human_within, within_sd_ratio)

write.csv(demo_runA_r_components,
          file.path(out_dir, "table_d5_runA_correlation_decomposition.csv"), row.names = FALSE)

cat("\n── Run A correlation decomposition (pooled-24): overall vs within-scenario ──\n")
print(as.data.frame(
  demo_runA_r_components %>%
    filter(analysis_scope == "demographic_pooled_24") %>%
    dplyr::select(model_name, dimension, r_overall, r_between_scenario,
                  r_within_scenario, within_sd_ratio) %>%
    mutate(across(where(is.numeric), ~ round(.x, 3)))
), max = 400)

# HOW MUCH DO MODELS DIFFERENTIATE GROUPS AT ALL?
demo_group_differentiation <- demo_runA_joined %>%
  group_by(analysis_scope, model_name, input_id) %>%
  filter(n_distinct(category) >= 2) %>%
  summarise(
    n_groups = n_distinct(paste(dimension, category)),
    sd_model_across_groups = stats::sd(rating, na.rm = TRUE),
    sd_human_across_groups = stats::sd(subgroup_mean, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(sd_ratio = sd_model_across_groups / sd_human_across_groups)

demo_group_differentiation_summary <- demo_group_differentiation %>%
  group_by(analysis_scope, model_name) %>%
  summarise(
    n_scenarios = n(),
    median_n_groups = stats::median(n_groups),
    mean_sd_model = mean(sd_model_across_groups, na.rm = TRUE),
    mean_sd_human = mean(sd_human_across_groups, na.rm = TRUE),
    median_sd_ratio = stats::median(sd_ratio, na.rm = TRUE),
    pct_scenarios_model_flatter = 100 * mean(sd_ratio < 1, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(human_sample_source = ifelse(analysis_scope == "demographic_pooled_24",
                                      "main + bot-pass boost", "main only"),
         model_run = "Run A") %>%
  arrange(analysis_scope, median_sd_ratio)

write.csv(demo_group_differentiation,
          file.path(out_dir, "table_d5_group_differentiation_by_scenario.csv"), row.names = FALSE)
write.csv(demo_group_differentiation_summary,
          file.path(out_dir, "table_d5_group_differentiation_summary.csv"), row.names = FALSE)

cat("\n── Do models differentiate groups at all? (pooled-24) ──\n")
print(as.data.frame(
  demo_group_differentiation_summary %>%
    filter(analysis_scope == "demographic_pooled_24") %>%
    dplyr::select(model_name, n_scenarios, median_n_groups, mean_sd_model,
                  mean_sd_human, median_sd_ratio, pct_scenarios_model_flatter) %>%
    mutate(across(where(is.numeric), ~ round(.x, 3)))
))

# Variance decomposition: share of variance between scenarios versus between
# groups, computed the same way for models and for humans.
demo_variance_decomposition <- bind_rows(
  demo_runA_joined %>%
    transmute(analysis_scope, source = model_name, input_id,
              group = paste(dimension, category), value = rating),
  demo_runA_joined %>%
    distinct(analysis_scope, input_id, dimension, category, subgroup_mean) %>%
    transmute(analysis_scope, source = "HUMAN", input_id,
              group = paste(dimension, category), value = subgroup_mean)
) %>%
  group_by(analysis_scope, source) %>%
  group_modify(function(x, key) {
    x <- x %>% filter(!is.na(value))
    grand <- mean(x$value)
    ss_total <- sum((x$value - grand)^2)
    scen <- x %>% group_by(input_id) %>%
      summarise(m = mean(value), n = n(), .groups = "drop")
    grp <- x %>% group_by(group) %>%
      summarise(m = mean(value), n = n(), .groups = "drop")
    ss_scen <- sum(scen$n * (scen$m - grand)^2)
    ss_grp  <- sum(grp$n * (grp$m - grand)^2)
    tibble(
      n_obs = nrow(x), n_scenarios = nrow(scen), n_groups = nrow(grp),
      sd_overall = stats::sd(x$value),
      ss_total = ss_total, ss_between_scenarios = ss_scen, ss_between_groups = ss_grp,
      pct_between_scenarios = 100 * ss_scen / ss_total,
      pct_between_groups = 100 * ss_grp / ss_total
    )
  }) %>%
  ungroup() %>%
  arrange(analysis_scope, desc(pct_between_groups))

write.csv(demo_variance_decomposition,
          file.path(out_dir, "table_d5_variance_decomposition.csv"), row.names = FALSE)

cat("\n── Variance between scenarios vs between groups (pooled-24) ──\n")
print(as.data.frame(
  demo_variance_decomposition %>%
    filter(analysis_scope == "demographic_pooled_24") %>%
    dplyr::select(source, n_groups, sd_overall, pct_between_scenarios, pct_between_groups) %>%
    mutate(across(where(is.numeric), ~ round(.x, 3)))
))

audit_record(
  "D5 correlation decomposition", "separate within-scenario from between-scenario alignment",
  rows_in = nrow(demo_runA_joined), rows_out = nrow(demo_runA_decomp),
  reason = "an overall r near-identical across dimensions is consistent with a model that does not vary by group; within-scenario centering isolates group tracking",
  detail = "scenarios with fewer than 2 analyzable categories cannot be centered and are dropped"
)


# IS THE HUMAN BETWEEN-GROUP SIGNAL REAL OR SAMPLING NOISE?
set.seed(20260806)
DEMO_PERM_B <- as.integer(Sys.getenv("SCEN_DEMO_PERM_B", unset = "1000"))

demo_perm_base <- demo_frame_pooled24 %>%
  semi_join(demo_categories_analyzable %>%
              filter(analysis_scope == "demographic_pooled_24"),
            by = c("dimension", "category")) %>%
  dplyr::select(respondent_uid, sample, input_id, human_y, dimension, category)

# Observed between-group SD per dimension x scenario.
demo_between_group_sd <- function(df) {
  df %>%
    group_by(dimension, category, input_id) %>%
    summarise(m = mean(human_y, na.rm = TRUE), n = n(), .groups = "drop") %>%
    filter(n >= MIN_SUBGROUP_N) %>%
    group_by(dimension, input_id) %>%
    filter(n() >= 2) %>%
    summarise(between_group_sd = stats::sd(m), .groups = "drop")
}

demo_obs_bgsd <- demo_between_group_sd(demo_perm_base)

# Respondent -> category lookup per dimension, which is what gets shuffled.
demo_resp_labels <- demo_perm_base %>%
  distinct(dimension, respondent_uid, sample, category)

# Per-scenario nulls are retained as well as dimension-level ones, so each
# scenario can be normalised by its OWN null rather than compared on raw SD.
demo_perm_null_scen <- vector("list", DEMO_PERM_B)
for (b in seq_len(DEMO_PERM_B)) {
  shuffled <- demo_resp_labels %>%
    group_by(dimension, sample) %>%
    mutate(category = sample(category)) %>%
    ungroup()
  perm_df <- demo_perm_base %>%
    dplyr::select(-category) %>%
    inner_join(shuffled, by = c("dimension", "respondent_uid", "sample"))
  demo_perm_null_scen[[b]] <- demo_between_group_sd(perm_df) %>% mutate(perm = b)
}
demo_perm_null_scen <- bind_rows(demo_perm_null_scen)

demo_perm_null <- demo_perm_null_scen %>%
  group_by(perm, dimension) %>%
  summarise(mean_bgsd = mean(between_group_sd), .groups = "drop")

demo_perm_test <- demo_obs_bgsd %>%
  group_by(dimension) %>%
  summarise(observed_mean_bgsd = mean(between_group_sd),
            n_scenarios = n(), .groups = "drop") %>%
  left_join(
    demo_perm_null %>%
      group_by(dimension) %>%
      summarise(null_mean = mean(mean_bgsd), null_sd = stats::sd(mean_bgsd),
                null_q025 = stats::quantile(mean_bgsd, .025),
                null_q975 = stats::quantile(mean_bgsd, .975), .groups = "drop"),
    by = "dimension"
  ) %>%
  left_join(
    demo_perm_null %>%
      left_join(demo_obs_bgsd %>% group_by(dimension) %>%
                  summarise(obs = mean(between_group_sd), .groups = "drop"),
                by = "dimension") %>%
      group_by(dimension) %>%
      summarise(p_perm = (1 + sum(mean_bgsd >= obs)) / (1 + n()), .groups = "drop"),
    by = "dimension"
  ) %>%
  mutate(
    excess_over_null = observed_mean_bgsd - null_mean,
    ratio_to_null = observed_mean_bgsd / null_mean,
    signal_detected_unadjusted = p_perm < .05,
    p_perm_holm = stats::p.adjust(p_perm, method = "holm"),
    signal_detected = p_perm_holm < .05,
    n_permutations = DEMO_PERM_B
  ) %>%
  arrange(p_perm)

write.csv(demo_perm_test,
          file.path(out_dir, "table_d5_human_between_group_permutation.csv"), row.names = FALSE)

TABLE_B_MAIN_MODELS <- c("gpt-4o-mini_2024-07-18", "gpt-5.1_2025-11-13")

demo_table_b_all <- demo_runA_r_components %>%
  filter(analysis_scope == "demographic_pooled_24") %>%
  dplyr::select(model_name, dimension, n_scenarios, n_categories,
                median_subgroup_n, r_overall, r_between_scenario,
                r_within_scenario, sd_model_within, sd_human_within,
                within_sd_ratio) %>%
  left_join(
    demo_perm_test %>%
      dplyr::select(dimension, observed_mean_bgsd, null_mean, ratio_to_null,
                    p_perm, p_perm_holm, signal_detected, n_permutations),
    by = "dimension"
  ) %>%
  mutate(analysis_scope = "demographic_pooled_24",
         human_sample_source = "main + bot-pass boost",
         model_run = "Run A") %>%
  arrange(desc(ratio_to_null), model_name, dimension)

write.csv(demo_table_b_all %>% filter(model_name %in% TABLE_B_MAIN_MODELS),
          file.path(out_dir, "table_d5_ordering_vs_signal_two_model.csv"),
          row.names = FALSE)
write.csv(demo_table_b_all,
          file.path(out_dir, "table_d5_ordering_vs_signal_five_model.csv"),
          row.names = FALSE)

cat("\n── Table B: within-scenario tracking against human between-group signal ──\n")
print(as.data.frame(
  demo_table_b_all %>% filter(model_name %in% TABLE_B_MAIN_MODELS) %>%
    dplyr::select(model_name, dimension, r_within_scenario, within_sd_ratio,
                  observed_mean_bgsd, ratio_to_null, p_perm, p_perm_holm, signal_detected) %>%
    mutate(across(where(is.numeric), ~ round(.x, 4)))
), row.names = FALSE)

cat("\n── Is the human between-group signal real? Permutation test ──\n")
cat("  Permutation unit: respondent within sample.", DEMO_PERM_B, "permutations.\n")
print(as.data.frame(demo_perm_test %>%
  dplyr::select(dimension, n_scenarios, observed_mean_bgsd, null_mean,
                null_q025, null_q975, ratio_to_null, p_perm, p_perm_holm, signal_detected) %>%
  mutate(across(where(is.numeric), ~ round(.x, 4)))))

audit_record(
  "D5 permutation test", "permute demographic labels at respondent level within sample",
  rows_in = nrow(demo_perm_base), rows_out = DEMO_PERM_B,
  reason = "tests whether the observed human between-group SD exceeds what cell-size noise alone produces",
  detail = paste0(sum(demo_perm_test$signal_detected), " of ", nrow(demo_perm_test),
                  " dimensions show detectable demographic signal after Holm correction")
)

path_scenario_text <- file.path(base_dir, "scenario_text.csv")
scenario_text_lookup <- if (file.exists(path_scenario_text)) {
  readr::read_csv(path_scenario_text, show_col_types = FALSE) %>%
    mutate(input_id = canonical_scenario_id(input_id))
} else {
  cat("  ⚠ scenario_text.csv not found; ranking will have no stimulus text\n")
  tibble(input_id = character(), scenario_text = character())
}

demo_scenario_bgsd <- demo_obs_bgsd %>%
  group_by(input_id) %>%
  summarise(mean_between_group_sd = mean(between_group_sd),
            n_dimensions = n(), .groups = "drop") %>%
  left_join(
    demo_human_long %>%
      filter(input_id %in% demo_shared_items) %>%
      distinct(respondent_uid, input_id, human_y) %>%
      group_by(input_id) %>%
      summarise(human_overall_sd = stats::sd(human_y, na.rm = TRUE),
                human_mean = mean(human_y, na.rm = TRUE),
                n_raters = n(), .groups = "drop"),
    by = "input_id"
  ) %>%
  left_join(
    demo_perm_null_scen %>%
      # Match the observed statistic: average dimensions within each draw.
      group_by(input_id, perm) %>%
      summarise(between_group_sd = mean(between_group_sd), .groups = "drop") %>%
      group_by(input_id) %>%
      summarise(null_bgsd_mean = mean(between_group_sd),
                null_bgsd_q975 = stats::quantile(between_group_sd, .975),
                .groups = "drop"),
    by = "input_id"
  ) %>%
  left_join(
    demo_obs_bgsd %>%
      group_by(input_id) %>%
      summarise(obs = mean(between_group_sd), .groups = "drop") %>%
      left_join(demo_perm_null_scen %>%
                  group_by(perm, input_id) %>%
                  summarise(m = mean(between_group_sd), .groups = "drop"),
                by = "input_id") %>%
      group_by(input_id) %>%
      summarise(p_perm_scenario = (1 + sum(m >= obs)) / (1 + n()), .groups = "drop"),
    by = "input_id"
  ) %>%
  mutate(ratio_to_null = mean_between_group_sd / null_bgsd_mean) %>%
  left_join(scenario_text_lookup, by = "input_id") %>%
  arrange(desc(ratio_to_null))

demo_bgsd_vs_overall_sd <- suppressWarnings(stats::cor.test(
  demo_scenario_bgsd$mean_between_group_sd, demo_scenario_bgsd$human_overall_sd))

cat(sprintf("\n  r(between-group SD, overall human SD) = %.3f [%.3f, %.3f], p = %.4f\n",
            demo_bgsd_vs_overall_sd$estimate, demo_bgsd_vs_overall_sd$conf.int[1],
            demo_bgsd_vs_overall_sd$conf.int[2], demo_bgsd_vs_overall_sd$p.value))


# SEPARATING DEMOGRAPHIC STRUCTURE FROM GENERAL CONTESTEDNESS

DEMO_GROUP_RELEVANT_IDS <- c(
  "436_new",  
  "348_new", 
  "58_new",   
  "216_new",  
  "105_new",  
  "313_new",  
  "116_new",  
  "1_new",    
  "136_new",  
  "425_new",  
  "41_new"    
)

demo_scenario_content <- demo_scenario_bgsd %>%
  mutate(group_relevant = as.integer(input_id %in% DEMO_GROUP_RELEVANT_IDS))

partial_cor <- function(x, y, z) {
  ok <- is.finite(x) & is.finite(y) & is.finite(z)
  x <- x[ok]; y <- y[ok]; z <- z[ok]
  n <- length(x)
  empty <- function(status) tibble(r = NA_real_, ci_low = NA_real_, ci_high = NA_real_,
    t = NA_real_, df = NA_real_, p_value = NA_real_, n = n, status = status)
  if (n < 5L || stats::sd(x) == 0 || stats::sd(y) == 0 || stats::sd(z) == 0)
    return(empty("insufficient observations or constant variable"))
  rx <- stats::resid(stats::lm(x ~ z)); ry <- stats::resid(stats::lm(y ~ z))
  if (sum(rx^2) <= .Machine$double.eps * sum((x - mean(x))^2) ||
      sum(ry^2) <= .Machine$double.eps * sum((y - mean(y))^2))
    return(empty("zero residual variance"))
  r <- max(-1, min(1, stats::cor(rx, ry)))
  df <- n - 3L
  t_value <- if (abs(r) == 1) sign(r) * Inf else r * sqrt(df / (1 - r^2))
  ci <- if (abs(r) == 1) rep(r, 2) else
    tanh(atanh(r) + c(-1, 1) * stats::qnorm(.975) / sqrt(n - 4L))
  tibble(r = r, ci_low = ci[1], ci_high = ci[2], t = t_value, df = df,
         p_value = 2 * stats::pt(-abs(t_value), df), n = n, status = "ok")
}

demo_content_diagnostics <- bind_rows(
  partial_cor(demo_scenario_content$mean_between_group_sd,
              demo_scenario_content$group_relevant,
              demo_scenario_content$human_overall_sd) %>%
    mutate(outcome = "raw between-group SD", control = "overall human SD", .before = 1),
  partial_cor(demo_scenario_content$ratio_to_null,
              demo_scenario_content$group_relevant,
              demo_scenario_content$human_overall_sd) %>%
    mutate(outcome = "between-group SD / permutation null", control = "overall human SD", .before = 1)
)

demo_content_zero_order <- bind_rows(
  local({ ct <- stats::cor.test(demo_scenario_content$mean_between_group_sd,
                                demo_scenario_content$group_relevant)
    tibble(outcome = "raw between-group SD", control = "none",
           r = unname(ct$estimate), ci_low = ct$conf.int[1], ci_high = ct$conf.int[2],
           t = unname(ct$statistic), df = unname(ct$parameter), p_value = ct$p.value,
           n = nrow(demo_scenario_content)) }),
  local({ ct <- stats::cor.test(demo_scenario_content$ratio_to_null,
                                demo_scenario_content$group_relevant)
    tibble(outcome = "between-group SD / permutation null", control = "none",
           r = unname(ct$estimate), ci_low = ct$conf.int[1], ci_high = ct$conf.int[2],
           t = unname(ct$statistic), df = unname(ct$parameter), p_value = ct$p.value,
           n = nrow(demo_scenario_content)) })
)

demo_content_diagnostics <- bind_rows(
  demo_content_zero_order,
  demo_content_diagnostics
)

write.csv(demo_content_diagnostics,
          file.path(out_dir, "table_d5_content_vs_contestedness.csv"), row.names = FALSE)
write.csv(demo_scenario_content,
          file.path(out_dir, "table_d5_scenario_between_group_sd_ranking.csv"), row.names = FALSE)

cat("\n── Demographic structure vs general contestedness ──\n")
cat("  Group-relevant items (author-coded):", length(DEMO_GROUP_RELEVANT_IDS), "of 24\n")
print(as.data.frame(demo_content_diagnostics %>% mutate(across(where(is.numeric), ~ round(.x, 4)))))

cat("\n  Scenarios ranked by RATIO to permutation null (top 5):\n")
print(as.data.frame(head(demo_scenario_content, 5) %>%
  dplyr::select(input_id, ratio_to_null, mean_between_group_sd, human_overall_sd,
                p_perm_scenario, group_relevant, scenario_text) %>%
  mutate(across(where(is.numeric), ~ round(.x, 3)))))
cat("\n  Bottom 5 by ratio:\n")
print(as.data.frame(tail(demo_scenario_content, 5) %>%
  dplyr::select(input_id, ratio_to_null, mean_between_group_sd, human_overall_sd,
                p_perm_scenario, group_relevant, scenario_text) %>%
  mutate(across(where(is.numeric), ~ round(.x, 3)))))

demo_binary_check <- demo_runA_r_components %>%
  filter(analysis_scope == "demographic_pooled_24",
         dimension %in% c("dim_politics", "dim_gender")) %>%
  dplyr::select(model_name, dimension, n_categories, r_overall, r_within_scenario) %>%
  tidyr::pivot_wider(names_from = dimension,
                     values_from = c(n_categories, r_overall, r_within_scenario)) %>%
  mutate(politics_minus_gender_within = r_within_scenario_dim_politics -
           r_within_scenario_dim_gender)

demo_binary_test <- stats::t.test(demo_binary_check$politics_minus_gender_within)

write.csv(demo_binary_check,
          file.path(out_dir, "table_d5_politics_vs_gender_binary_control.csv"), row.names = FALSE)

cat("\n── Politics vs gender: both binary, so this controls category count ──\n")
print(as.data.frame(demo_binary_check %>%
  dplyr::select(model_name, n_categories_dim_politics, n_categories_dim_gender,
                r_within_scenario_dim_politics, r_within_scenario_dim_gender,
                politics_minus_gender_within) %>%
  mutate(across(where(is.numeric), ~ round(.x, 3)))))
cat(sprintf("\n  Politics - gender within-scenario r: mean %+.3f, 95%% CI [%+.3f, %+.3f], p = %.4f (n = %d models)\n",
            unname(demo_binary_test$estimate), demo_binary_test$conf.int[1],
            demo_binary_test$conf.int[2], demo_binary_test$p.value,
            nrow(demo_binary_check)))
cat("  Also compare the permutation ratios: politics",
    round(demo_perm_test$ratio_to_null[demo_perm_test$dimension == "dim_politics"], 3),
    "vs gender",
    round(demo_perm_test$ratio_to_null[demo_perm_test$dimension == "dim_gender"], 3),
    "on the human side.\n")

demo_politics_split <- demo_runA_r_components %>%
  mutate(dimension_class = ifelse(dimension == "dim_politics",
                                  "politics", "all other dimensions")) %>%
  group_by(analysis_scope, model_name, dimension_class) %>%
  summarise(n_dimensions = n(),
            median_r_overall = stats::median(r_overall),
            median_r_within_scenario = stats::median(r_within_scenario),
            min_r_within_scenario = min(r_within_scenario),
            max_r_within_scenario = max(r_within_scenario),
            .groups = "drop") %>%
  arrange(analysis_scope, model_name, desc(dimension_class))

write.csv(demo_politics_split,
          file.path(out_dir, "table_d5_politics_reported_separately.csv"), row.names = FALSE)

cat("\n── Politics reported separately (pooled-24) ──\n")
print(as.data.frame(
  demo_politics_split %>%
    filter(analysis_scope == "demographic_pooled_24") %>%
    dplyr::select(model_name, dimension_class, n_dimensions,
                  median_r_overall, median_r_within_scenario) %>%
    mutate(across(where(is.numeric), ~ round(.x, 3)))
))

demo_gptoss_politics <- demo_runA_r_components %>%
  filter(analysis_scope == "demographic_pooled_24") %>%
  mutate(is_politics = dimension == "dim_politics",
         is_gptoss = model_name == "gpt-oss-20b") %>%
  group_by(is_gptoss, is_politics) %>%
  summarise(n = n(), median_r_within = stats::median(r_within_scenario), .groups = "drop") %>%
  mutate(cell = paste0(ifelse(is_gptoss, "gpt-oss", "other models"), " / ",
                       ifelse(is_politics, "politics", "other dimensions")))

cat("\n  gpt-oss politics check (median within-scenario r):\n")
print(as.data.frame(demo_gptoss_politics %>%
  dplyr::select(cell, n, median_r_within) %>%
  mutate(median_r_within = round(median_r_within, 3))))

# NOISE CEILING PER SUBGROUP
set.seed(20260807)
DEMO_SPLIT_B <- as.integer(Sys.getenv("SCEN_DEMO_SPLIT_B", unset = "200"))

demo_noise_ceiling <- demo_frame_pooled24 %>%
  semi_join(demo_categories_analyzable %>%
              filter(analysis_scope == "demographic_pooled_24"),
            by = c("dimension", "category")) %>%
  group_by(dimension, category) %>%
  group_modify(function(x, key) {
    rs <- numeric(0)
    resp <- unique(x$respondent_uid)
    if (length(resp) < 8) return(tibble(reliability_sb = NA_real_, n_splits = 0L,
                                        n_respondents = length(resp)))
    for (b in seq_len(DEMO_SPLIT_B)) {
      half <- sample(resp, floor(length(resp) / 2))
      a <- x %>% filter(respondent_uid %in% half) %>%
        group_by(input_id) %>% summarise(m = mean(human_y), .groups = "drop")
      bb <- x %>% filter(!respondent_uid %in% half) %>%
        group_by(input_id) %>% summarise(m = mean(human_y), .groups = "drop")
      j <- inner_join(a, bb, by = "input_id")
      if (nrow(j) >= 4) rs <- c(rs, suppressWarnings(stats::cor(j$m.x, j$m.y)))
    }
    r_half <- mean(rs, na.rm = TRUE)
    tibble(reliability_sb = (2 * r_half) / (1 + r_half),
           n_splits = length(rs), n_respondents = length(resp))
  }) %>%
  ungroup()

demo_alignment_with_ceiling <- demo_runA_alignment_category %>%
  filter(analysis_scope == "demographic_pooled_24") %>%
  left_join(demo_noise_ceiling, by = c("dimension", "category")) %>%
  mutate(
    r_attenuation_corrected = ifelse(!is.na(reliability_sb) & reliability_sb > 0,
                                     r / sqrt(reliability_sb), NA_real_),
    note = "reliability reported alongside r; corrected value is r / sqrt(reliability), not a proportion of ceiling"
  ) %>%
  dplyr::select(analysis_scope, model_name, dimension, category, n_scenarios,
                median_subgroup_n, n_respondents, r, r_ci_low, r_ci_high,
                reliability_sb, r_attenuation_corrected, note)

write.csv(demo_noise_ceiling, file.path(out_dir, "table_d5_subgroup_noise_ceiling.csv"), row.names = FALSE)
write.csv(demo_alignment_with_ceiling,
          file.path(out_dir, "table_d5_alignment_with_noise_ceiling.csv"), row.names = FALSE)

cat("\n── Subgroup noise ceilings (split-half, Spearman-Brown) ──\n")
print(as.data.frame(demo_noise_ceiling %>%
  arrange(reliability_sb) %>% head(10) %>%
  mutate(across(where(is.numeric), ~ round(.x, 3)))))


# Supplementary rating-level models
demo_rating_level <- demo_frame_pooled24 %>%
  inner_join(demo_runA %>% inner_join(DEMO_GROUP_CROSSWALK, by = "group_index"),
             by = c("dimension", "category", "input_id"),
             relationship = "many-to-many") %>%
  mutate(abs_error = abs(rating - human_y))

demo_lmer_rows <- list()
if (e_have_lmer && nrow(demo_rating_level) > 0) {
  for (dim in sort(unique(demo_rating_level$dimension))) {
    d <- demo_rating_level %>% filter(dimension == dim) %>%
      mutate(category = factor(category), model_name = factor(model_name),
             sample = factor(sample))
    if (n_distinct(d$category) < 2 || nrow(d) < 200) next
    f <- try(lmerTest::lmer(
      abs_error ~ category * model_name + sample + (1 | respondent_uid) + (1 | input_id),
      data = d), silent = TRUE)
    if (inherits(f, "try-error")) {
      cat("  ⚠ lmer failed for", dim, "\n"); next
    }
    demo_lmer_rows[[length(demo_lmer_rows) + 1]] <- broom.mixed::tidy(
      f, effects = "fixed", conf.int = TRUE) %>%
      mutate(dimension = dim, n_obs = stats::nobs(f),
             n_categories = n_distinct(d$category), .before = 1)
    cat("  fitted:", dim, " n =", stats::nobs(f),
        " categories =", n_distinct(d$category), "\n")
  }
}

if (length(demo_lmer_rows) > 0) {
  demo_lmer_by_dimension <- bind_rows(demo_lmer_rows) %>%
    mutate(analysis_scope = "demographic_pooled_24",
           quantity = "rating-level absolute error (supplementary; category fixed effects)",
           model_run = "Run A")
  write.csv(demo_lmer_by_dimension,
            file.path(out_dir, "table_d5_lmer_by_dimension.csv"), row.names = FALSE)
  cat("  Wrote per-dimension lmer:", nrow(demo_lmer_by_dimension), "coefficient rows across",
      n_distinct(demo_lmer_by_dimension$dimension), "dimensions\n")
  audit_record(
    "D5 per-dimension lmer", "fit rating-level absolute-error models per dimension",
    rows_in = nrow(demo_rating_level), rows_out = nrow(demo_lmer_by_dimension),
    reason = "supplementary to the subgroup-mean analysis; participant-level error includes within-group disagreement and is a different quantity",
    detail = "model identity and sample are fixed effects; respondent and scenario are random"
  )
}


# Representativeness gap per model per dimension
demo_representativeness_gap <- demo_runA_alignment_category %>%
  filter(!is.na(r)) %>%
  group_by(analysis_scope, model_name, dimension) %>%
  filter(n() >= 2) %>%
  summarise(
    n_categories = n(),
    best_category = category[which.max(r)], best_r = max(r),
    worst_category = category[which.min(r)], worst_r = min(r),
    gap_r = max(r) - min(r),
    subgroup_n_min = min(median_subgroup_n), subgroup_n_max = max(median_subgroup_n),
    .groups = "drop"
  ) %>%
  mutate(human_sample_source = ifelse(analysis_scope == "demographic_pooled_24",
                                      "main + bot-pass boost", "main only"),
         model_run = "Run A") %>%
  arrange(analysis_scope, desc(gap_r))

write.csv(demo_representativeness_gap,
          file.path(out_dir, "table_d5_representativeness_gap.csv"), row.names = FALSE)

cat("\n  Representativeness gap (pooled-24), largest first:\n")
print(as.data.frame(
  demo_representativeness_gap %>%
    filter(analysis_scope == "demographic_pooled_24") %>%
    dplyr::select(model_name, dimension, best_category, best_r, worst_category,
                  worst_r, gap_r, subgroup_n_min, subgroup_n_max) %>%
    mutate(across(where(is.numeric), ~ round(.x, 3)))
))


# Run B — subgroup DISTRIBUTIONS
if (nrow(demo_runB) > 0) {
  demo_runB_props <- demo_runB %>%
    group_by(model_name, group_index, input_id) %>%
    complete(y = -4:4, fill = list(n_draws = 0)) %>%
    mutate(model_prop = n_draws / sum(n_draws)) %>%
    ungroup() %>%
    filter(!is.na(model_prop)) %>%
    mutate(bin = factor(y, levels = -4:4)) %>%
    dplyr::select(model_name, group_index, input_id, bin, model_prop)

  demo_human_subgroup_props <- demo_frames_all %>%
    filter(analysis_scope == "demographic_pooled_24") %>%
    mutate(y = clamp_scale(human_y)) %>%
    count(dimension, category, input_id, y, name = "n") %>%
    group_by(dimension, category, input_id) %>%
    mutate(subgroup_n = sum(n)) %>%
    complete(y = -4:4, fill = list(n = 0)) %>%
    mutate(subgroup_n = max(subgroup_n, na.rm = TRUE),
           human_prop = n / sum(n)) %>%
    ungroup() %>%
    filter(subgroup_n >= MIN_SUBGROUP_N) %>%
    semi_join(
      demo_categories_analyzable %>%
        filter(analysis_scope == "demographic_pooled_24") %>%
        dplyr::select(dimension, category),
      by = c("dimension", "category")
    ) %>%
    mutate(bin = factor(y, levels = -4:4)) %>%
    dplyr::select(dimension, category, input_id, bin, human_prop, subgroup_n)

  demo_runB_dist <- demo_runB_props %>%
    inner_join(DEMO_GROUP_CROSSWALK, by = "group_index") %>%
    inner_join(demo_human_subgroup_props, by = c("dimension", "category", "input_id", "bin")) %>%
    arrange(model_name, dimension, category, input_id, bin) %>%
    group_by(model_name, dimension, category, input_id) %>%
    summarise(
      subgroup_n = dplyr::first(subgroup_n),
      tvd = tvd_dist(human_prop, model_prop),
      emd = emd_1d(human_prop, model_prop),
      jsd = jsd(human_prop, model_prop),
      .groups = "drop"
    )

  demo_runB_alignment <- demo_runB_dist %>%
    group_by(model_name, dimension, category) %>%
    summarise(n_scenarios = n_distinct(input_id),
              median_subgroup_n = stats::median(subgroup_n),
              across(c(tvd, emd, jsd), ~ mean(.x, na.rm = TRUE)),
              .groups = "drop") %>%
    mutate(analysis_scope = "demographic_pooled_24",
           human_sample_source = "main + bot-pass boost",
           model_run = "Run B", prompt_type = "repeated single rating",
           temperature_design = "temperature 1, 500 repetitions") %>%
    arrange(model_name, dimension, tvd)

  write.csv(demo_runB_dist,
            file.path(out_dir, "table_d5_runB_distribution_by_item.csv"), row.names = FALSE)
  write.csv(demo_runB_alignment,
            file.path(out_dir, "table_d5_runB_alignment_by_category.csv"), row.names = FALSE)

  cat("\n  Run B distributional alignment by model x dimension:\n")
  print(as.data.frame(
    demo_runB_alignment %>%
      group_by(model_name, dimension) %>%
      summarise(n_categories = n(), median_subgroup_n = stats::median(median_subgroup_n),
                tvd = mean(tvd), emd = mean(emd), jsd = mean(jsd), .groups = "drop") %>%
      mutate(across(where(is.numeric), ~ round(.x, 3)))
  ))
  audit_record(
    "D5 Run B alignment", "join Run B distributions to human subgroup distributions",
    rows_in = nrow(demo_runB_props), rows_out = nrow(demo_runB_dist) * 9L,
    reason = "pooled-24 frame only: Run B's 24 scenarios are an exact match to the boosted set",
    detail = "Run B is a distribution and is never compared against subgroup means"
  )
}


cat("\n", strrep("=", 70),
    "\nPART D6 — ELICITATION COMPARISON: PROPORTIONS vs REPEATED SAMPLING\n",
    strrep("=", 70), "\n")

path_demo_props <- c(
  "gpt-4o-mini" = file.path(demographics_dir,
                            "reworded_runA_temp0_47_enriched_gpt4o"),
  "gpt-5.1"     = file.path(demographics_dir,
                            "reworded_runA_temp0_47_enriched-gpt5.jsonl")
)

DEMO_PROPS_EXPECTED_RECORDS <- 7003L
DEMO_PROPS_BINS <- as.character(-4:4)

DEMO_D6_EXPECTED_CELLS <- c(
  "gpt-4o-mini_2024-07-18" = 389L,
  "gpt-5.1_2025-11-13"     = 422L
)

extract_nine_bin <- function(x) {
  s <- stringr::str_trim(as.character(x))
  if (is.na(s) || s == "") return(list(shape = "empty", w = NULL))
  if (!stringr::str_starts(s, "\\{")) {
    num <- suppressWarnings(as.numeric(s))
    return(list(shape = if (is.na(num)) "unparseable" else "bare_scalar", w = NULL))
  }
  o <- tryCatch(jsonlite::fromJSON(s, simplifyVector = TRUE),
                error = function(e) NULL)
  if (is.null(o) || is.null(names(o))) return(list(shape = "object_unparseable", w = NULL))
  if (anyDuplicated(names(o))) return(list(shape = "duplicate_keys", w = NULL))
  if (!setequal(names(o), DEMO_PROPS_BINS)) {
    return(list(shape = paste0("other_object:",
                               paste(sort(names(o)), collapse = "|")), w = NULL))
  }
  w <- suppressWarnings(as.numeric(unlist(o[DEMO_PROPS_BINS], use.names = FALSE)))
  # Reject negative probabilities even when the vector has positive total mass.
  if (anyNA(w) || !is.finite(sum(w)) || sum(w) <= 0 || any(w < 0)) {
    return(list(shape = "nine_bin_invalid", w = NULL))
  }
  list(shape = "nine_bin", w = w)
}

load_demo_props <- function(path, label) {
  if (!file.exists(path)) {
    stop("Proportions file not found for ", label, ": ", path,
         "\nSet SCEN_DEMOGRAPHICS_DIR to the folder holding the reworded_runA files.")
  }
  raw <- read_model_file_safe(path, basename(path))
  if (nrow(raw) != DEMO_PROPS_EXPECTED_RECORDS) {
    stop(label, " proportions file has ", nrow(raw), " records; expected ",
         DEMO_PROPS_EXPECTED_RECORDS, ". This is a different generation of the ",
         "file than the one this section was written against - stop and check ",
         "before trusting anything downstream.")
  }
  n_all <- nrow(raw)
  t0 <- raw %>% filter(as.character(temperature) == "0")
  audit_record(
    "D6 proportions", paste0("filter ", label, " to temperature 0"),
    rows_in = n_all, rows_out = nrow(t0),
    reason = "the proportions arm is the temperature-0 single-elicitation design",
    detail = basename(path)
  )

  parsed_shapes <- purrr::map(t0$output_seq, extract_nine_bin)
  # input_id and model_name are already canonicalised by standardize_model_rows.
  t0 <- t0 %>%
    mutate(
      prop_shape = vapply(parsed_shapes, function(z) z$shape, character(1)),
      group_index = suppressWarnings(as.integer(
        stringr::str_match(prompt_src_basename, "repeat_500_(\\d+)_")[, 2]))
    )

  stopifnot(all(t0$group_index == as.integer(t0$prompt_id)))

  if (!any(t0$prop_shape == "nine_bin")) {
    stop(label, " has no nine-bin [-4..4] records. This file is not a ",
         "proportions file; do not substitute a point-estimate generation.")
  }

  bad <- t0 %>% filter(prop_shape != "nine_bin" | is.na(group_index) | is.na(input_id))
  if (nrow(bad) > 0) {
    safe_label <- stringr::str_replace_all(label, "[^A-Za-z0-9]+", "_")
    check_file <- paste0("CHECK_demo_props_unusable_", safe_label, ".csv")
    readr::write_csv(
      bad %>% dplyr::select(any_of(c("input_id", "model_name", "temperature",
                                     "prompt_src_basename", "group_index",
                                     "prop_shape", "output_seq"))),
      file.path(out_dir, check_file)
    )
    cat(sprintf("  Non-compliant: %d of %d rows (%.1f%%) not nine-bin -> %s\n",
                nrow(bad), nrow(t0), 100 * nrow(bad) / nrow(t0), check_file))
  }

  keep <- which(t0$prop_shape == "nine_bin" &
                  !is.na(t0$group_index) & !is.na(t0$input_id))
  n_pre_excl <- length(keep)
  for (excl_dim in names(DEMO_EXCLUDED_GROUP_SETS)) {
    excl_idx <- DEMO_EXCLUDED_GROUP_SETS[[excl_dim]]
    n_excl <- sum(t0$group_index[keep] %in% excl_idx)
    audit_record(
      "D6 proportions", paste0("exclude ", excl_dim, " prompt groups from ", label),
      rows_in = n_pre_excl, rows_out = n_pre_excl - n_excl,
      reason = paste0(excl_dim, " is excluded from all demographic analyses"),
      detail = paste0("dropped group_index ",
                      paste(range(excl_idx), collapse = "-"), "; ", n_excl, " rows")
    )
  }
  keep <- keep[!(t0$group_index[keep] %in% DEMO_EXCLUDED_GROUP_INDEX)]

  # .ingest_ord is the line ordinal within the file, so take-first below is the
  # first occurrence in the input, reproducibly across runs and platforms.
  cells <- tibble(
    input_id = t0$input_id[keep], model_name = t0$model_name[keep],
    group_index = t0$group_index[keep], .ingest_ord = keep,
    w = parsed_shapes[keep]
  )
  shape_counts <- t0 %>% count(prop_shape, name = "n_records") %>%
    mutate(model_label = label, file = basename(path))

  cat(sprintf("  %-12s %6d nine-bin cells  %3d scenarios  %2d groups  model: %s\n",
              label, nrow(cells), n_distinct(cells$input_id),
              n_distinct(cells$group_index),
              paste(unique(cells$model_name), collapse = ",")))
  list(cells = cells, shapes = shape_counts)
}

cat("\n── Proportions arm (temperature 0, nine-bin [-4..4]) ──\n")
demo_props_loaded <- purrr::imap(path_demo_props, ~ load_demo_props(.x, .y))
demo_props_shapes <- bind_rows(purrr::map(demo_props_loaded, "shapes"))
demo_props_cells_raw <- bind_rows(purrr::map(demo_props_loaded, "cells"))

write.csv(demo_props_shapes,
          file.path(out_dir, "table_d6_props_compliance_by_model.csv"), row.names = FALSE)

# DEDUP
demo_props_dupes <- demo_props_cells_raw %>%
  count(model_name, input_id, group_index, name = "n") %>% filter(n > 1)
if (nrow(demo_props_dupes) > 0) {
  readr::write_csv(demo_props_dupes,
                   file.path(out_dir, "CHECK_demo_props_duplicate_cells.csv"))
  cat("  Duplicated model x scenario x group cells:", nrow(demo_props_dupes),
      "- resolved by deterministic take-first\n")
}
demo_props_cells <- demo_props_cells_raw %>%
  arrange(model_name, input_id, group_index, .ingest_ord) %>%
  group_by(model_name, input_id, group_index) %>%
  slice(1) %>%
  ungroup()
audit_record(
  "D6 proportions", "resolve duplicate model x scenario x group cells",
  rows_in = nrow(demo_props_cells_raw), rows_out = nrow(demo_props_cells),
  reason = "best-parse then deterministic take-first on the ingestion ordinal",
  detail = paste0(nrow(demo_props_dupes), " duplicated cells")
)

demo_props_props <- demo_props_cells %>%
  mutate(w = purrr::map(w, "w")) %>%
  tidyr::unnest_longer(w, indices_to = ".bin_ix") %>%
  mutate(y = as.integer(DEMO_PROPS_BINS[.bin_ix])) %>%
  group_by(model_name, group_index, input_id) %>%
  mutate(model_prop = w / sum(w)) %>%
  ungroup() %>%
  mutate(bin = factor(y, levels = -4:4)) %>%
  dplyr::select(model_name, group_index, input_id, bin, model_prop)

if (!exists("demo_runB_dist") || nrow(demo_runB_dist) == 0) {
  stop("D6 needs Run B distances to compare against, and demo_runB_dist is ",
       "absent or empty. The elicitation comparison cannot be built one-armed.")
}
if (!exists("demo_human_subgroup_props") || nrow(demo_human_subgroup_props) == 0) {
  stop("D6 needs demo_human_subgroup_props (built at 9423-9435) and it is ",
       "absent or empty.")
}

demo_props_dist <- demo_props_props %>%
  inner_join(DEMO_GROUP_CROSSWALK, by = "group_index") %>%
  inner_join(demo_human_subgroup_props,
             by = c("dimension", "category", "input_id", "bin")) %>%
  arrange(model_name, dimension, category, input_id, bin) %>%
  group_by(model_name, dimension, category, input_id) %>%
  summarise(
    subgroup_n = dplyr::first(subgroup_n),
    tvd = tvd_dist(human_prop, model_prop),
    emd = emd_1d(human_prop, model_prop),
    jsd = jsd(human_prop, model_prop),
    .groups = "drop"
  )

demo_elicitation_cells <- demo_props_dist %>%
  dplyr::rename(tvd_props = tvd, emd_props = emd, jsd_props = jsd,
                subgroup_n_props = subgroup_n) %>%
  inner_join(
    demo_runB_dist %>%
      dplyr::rename(tvd_runB = tvd, emd_runB = emd, jsd_runB = jsd,
                    subgroup_n_runB = subgroup_n),
    by = c("model_name", "dimension", "category", "input_id")
  ) %>%
  mutate(d_tvd = tvd_props - tvd_runB,
         d_emd = emd_props - emd_runB,
         d_jsd = jsd_props - jsd_runB) %>%
  arrange(model_name, dimension, category, input_id)

stopifnot(all(demo_elicitation_cells$subgroup_n_props ==
                demo_elicitation_cells$subgroup_n_runB))
demo_elicitation_cells <- demo_elicitation_cells %>%
  mutate(subgroup_n = subgroup_n_props) %>%
  dplyr::select(-subgroup_n_props, -subgroup_n_runB)

demo_d6_observed_cells <- demo_elicitation_cells %>%
  count(model_name, name = "n_cells")
cat("\n  Head-to-head cells per model:\n")
print(as.data.frame(demo_d6_observed_cells))
write.csv(demo_d6_observed_cells %>%
            mutate(expected_cells = unname(DEMO_D6_EXPECTED_CELLS[model_name])),
          file.path(out_dir, "CHECK_d6_observed_vs_expected_coverage.csv"), row.names = FALSE)
stopifnot(setequal(demo_d6_observed_cells$model_name, names(DEMO_D6_EXPECTED_CELLS)))
stopifnot(all(demo_d6_observed_cells$n_cells ==
                DEMO_D6_EXPECTED_CELLS[demo_d6_observed_cells$model_name]))

write.csv(demo_elicitation_cells,
          file.path(out_dir, "table_d6_elicitation_props_vs_runB_by_cell.csv"),
          row.names = FALSE)

audit_record(
  "D6 head-to-head", "join proportions distances to Run B distances",
  rows_in = nrow(demo_props_dist), rows_out = nrow(demo_elicitation_cells),
  keys_in = n_distinct(paste(demo_props_dist$model_name, demo_props_dist$dimension,
                             demo_props_dist$category, demo_props_dist$input_id)),
  keys_out = n_distinct(paste(demo_elicitation_cells$model_name,
                              demo_elicitation_cells$dimension,
                              demo_elicitation_cells$category,
                              demo_elicitation_cells$input_id)),
  reason = "cells where BOTH arms are usable; Run B is complete, so every drop is a proportions drop",
  detail = "joined on model x dimension x category x scenario; subgroup_n asserted equal, not joined on"
)

demo_elicitation_by_category <- demo_elicitation_cells %>%
  group_by(model_name, dimension, category) %>%
  summarise(n_scenarios = n_distinct(input_id),
            median_subgroup_n = stats::median(subgroup_n),
            across(c(tvd_props, emd_props, jsd_props,
                     tvd_runB, emd_runB, jsd_runB,
                     d_tvd, d_emd, d_jsd), ~ mean(.x, na.rm = TRUE)),
            .groups = "drop") %>%
  mutate(analysis_scope = "demographic_pooled_24",
         human_sample_source = "main + bot-pass boost",
         better_arm_tvd = ifelse(d_tvd < 0, "proportions", "repeated sampling")) %>%
  arrange(model_name, dimension, category)

write.csv(demo_elicitation_by_category,
          file.path(out_dir, "table_d6_elicitation_props_vs_runB_by_category.csv"),
          row.names = FALSE)

# PAIRED TEST of the arm difference
cluster_mean_test <- function(d, cluster) {
  ok <- is.finite(d) & !is.na(cluster)
  d <- d[ok]; cluster <- cluster[ok]
  n <- length(d); g <- n_distinct(cluster)
  dbar <- mean(d)
  e <- d - dbar
  gsum <- vapply(split(e, cluster), sum, numeric(1))
  vhat <- (g / (g - 1)) * sum(gsum^2) / (n^2)
  se <- sqrt(vhat)
  tstat <- dbar / se
  df <- g - 1
  list(n = n, g = g, mean = dbar, se = se, t = tstat, df = df,
       p = 2 * stats::pt(-abs(tstat), df = df),
       ci_low = dbar - stats::qt(0.975, df) * se,
       ci_high = dbar + stats::qt(0.975, df) * se)
}

demo_elicitation_tests <- purrr::map_dfr(
  sort(unique(demo_elicitation_cells$model_name)), function(m) {
    dm <- demo_elicitation_cells %>% filter(model_name == m)
    purrr::map_dfr(c("tvd", "emd", "jsd"), function(metric) {
      d <- dm[[paste0("d_", metric)]]
      cl <- dm$input_id
      cr <- cluster_mean_test(d, cl)
      dd <- d[is.finite(d)]
      tt <- stats::t.test(dd)
      tibble(model_name = m, metric = metric,
             n_pairs = cr$n, n_clusters = cr$g,
             cluster_unit = "input_id (scenario)",
             mean_props = mean(dm[[paste0(metric, "_props")]], na.rm = TRUE),
             mean_runB = mean(dm[[paste0(metric, "_runB")]], na.rm = TRUE),
             mean_diff_props_minus_runB = cr$mean,
             se_cluster = cr$se, t_cluster = cr$t, df_cluster = cr$df,
             p_cluster = cr$p,
             ci_low_cluster = cr$ci_low, ci_high_cluster = cr$ci_high,
             dz_unclustered = mean(dd) / stats::sd(dd),
             t_unclustered = unname(tt$statistic),
             df_unclustered = unname(tt$parameter),
             p_unclustered = tt$p.value)
    }) %>% mutate(p_holm_cluster = stats::p.adjust(p_cluster, method = "holm"),
                  holm_family = paste0(m, ": 3 metrics"))
  })

write.csv(demo_elicitation_tests,
          file.path(out_dir, "table_d6_elicitation_paired_tests.csv"), row.names = FALSE)


D6_FIT_MIN_SCENARIOS <- 4L

d6_fit_long_one <- function(d, keys) {
  bind_rows(
    d %>% group_by(across(all_of(keys))) %>%
      summarise(method = "proportions",
                n_cells = n(), n_scenarios = n_distinct(input_id),
                median_subgroup_n = stats::median(subgroup_n),
                mean_tvd = mean(tvd_props, na.rm = TRUE),
                mean_emd = mean(emd_props, na.rm = TRUE),
                mean_jsd = mean(jsd_props, na.rm = TRUE), .groups = "drop"),
    d %>% group_by(across(all_of(keys))) %>%
      summarise(method = "repeated_sampling",
                n_cells = n(), n_scenarios = n_distinct(input_id),
                median_subgroup_n = stats::median(subgroup_n),
                mean_tvd = mean(tvd_runB, na.rm = TRUE),
                mean_emd = mean(emd_runB, na.rm = TRUE),
                mean_jsd = mean(jsd_runB, na.rm = TRUE), .groups = "drop")
  )
}

# Paired difference per group, clustered on scenario. 
d6_fit_diff_one <- function(d, keys) {
  d %>% group_by(across(all_of(keys))) %>%
    group_modify(function(g, k) {
      purrr::map_dfr(c("tvd", "emd", "jsd"), function(metric) {
        dv <- g[[paste0("d_", metric)]]
        ok <- is.finite(dv)
        n_scen <- dplyr::n_distinct(g$input_id[ok])
        base <- tibble(metric = metric,
                       diff_props_minus_runB = mean(dv[ok], na.rm = TRUE))
        if (n_scen < D6_FIT_MIN_SCENARIOS) {
          base %>% mutate(se_cluster = NA_real_, t_cluster = NA_real_,
                          df_cluster = NA_real_, p_cluster = NA_real_,
                          ci_low_cluster = NA_real_, ci_high_cluster = NA_real_,
                          d_ci_basis = paste0("withheld: ", n_scen,
                                              " scenario clusters < ",
                                              D6_FIT_MIN_SCENARIOS))
        } else {
          cr <- cluster_mean_test(dv, g$input_id)
          base %>% mutate(se_cluster = cr$se, t_cluster = cr$t,
                          df_cluster = cr$df, p_cluster = cr$p,
                          ci_low_cluster = cr$ci_low, ci_high_cluster = cr$ci_high,
                          d_ci_basis = paste0("CR1 clustered on input_id, G = ",
                                              cr$g))
        }
      })
    }) %>% ungroup()
}

d6_fit_assemble <- function(keys) {
  d6_fit_long_one(demo_elicitation_cells, keys) %>%
    tidyr::pivot_longer(c(mean_tvd, mean_emd, mean_jsd),
                        names_to = "metric", values_to = "mean_distance") %>%
    mutate(metric = sub("^mean_", "", metric)) %>%
    left_join(d6_fit_diff_one(demo_elicitation_cells, keys),
              by = c(keys, "metric")) %>%
    # The paired difference is a property of the matched pair, not of one arm,
    # so both method rows of a group carry the same value and test.
    mutate(analysis_scope = "demographic_pooled_24",
           human_sample_source = "main + bot-pass boost") %>%
    dplyr::select(all_of(keys), method, metric, mean_distance,
                  n_cells, n_scenarios, median_subgroup_n,
                  diff_props_minus_runB, se_cluster, t_cluster, df_cluster,
                  p_cluster, ci_low_cluster, ci_high_cluster, d_ci_basis,
                  analysis_scope, human_sample_source) %>%
    arrange(across(all_of(c(keys, "metric", "method"))))
}

demo_d6_fit_by_category  <- d6_fit_assemble(c("model_name", "dimension", "category"))
demo_d6_fit_by_dimension <- d6_fit_assemble(c("model_name", "dimension"))

write.csv(demo_d6_fit_by_category,
          file.path(out_dir, "table_d6_fit_by_category.csv"), row.names = FALSE)
write.csv(demo_d6_fit_by_dimension,
          file.path(out_dir, "table_d6_fit_by_dimension.csv"), row.names = FALSE)

cat("\n  D6 fit by dimension (TVD, both arms):\n")
print(as.data.frame(
  demo_d6_fit_by_dimension %>% filter(metric == "tvd") %>%
    dplyr::select(model_name, dimension, method, mean_distance, n_cells,
                  diff_props_minus_runB, p_cluster) %>%
    mutate(across(where(is.numeric), ~ round(.x, 4)))
), row.names = FALSE)


# Test whether distributional elicitation preserves ordinal tracking across demographic groups.
d6_implied_mean <- function(df, prop_col) {
  df %>%
    mutate(.bin_val = as.numeric(as.character(bin))) %>%
    group_by(model_name, group_index, input_id) %>%
    summarise(implied_mean = sum(.bin_val * .data[[prop_col]], na.rm = TRUE),
              .groups = "drop")
}

d6_matched_keys <- demo_elicitation_cells %>%
  dplyr::select(model_name, dimension, category, input_id) %>% distinct()

d6_human_mean <- demo_human_subgroup_props %>%
  mutate(.bin_val = as.numeric(as.character(bin))) %>%
  group_by(dimension, category, input_id) %>%
  summarise(human_group_mean = sum(.bin_val * human_prop, na.rm = TRUE),
            subgroup_n = dplyr::first(subgroup_n), .groups = "drop")

d6_ordering_input <- bind_rows(
  d6_implied_mean(demo_props_props, "model_prop") %>% mutate(method = "proportions"),
  d6_implied_mean(demo_runB_props,  "model_prop") %>% mutate(method = "repeated_sampling")
) %>%
  inner_join(DEMO_GROUP_CROSSWALK, by = "group_index") %>%
  inner_join(d6_matched_keys, by = c("model_name", "dimension", "category", "input_id")) %>%
  inner_join(d6_human_mean, by = c("dimension", "category", "input_id"))

demo_d6_ordering_by_dimension <- d6_ordering_input %>%
  group_by(method, model_name, dimension, input_id) %>%
  filter(n() >= 2) %>%
  mutate(model_within = implied_mean - mean(implied_mean, na.rm = TRUE),
         human_within = human_group_mean - mean(human_group_mean, na.rm = TRUE)) %>%
  ungroup() %>%
  group_by(method, model_name, dimension) %>%
  summarise(
    n_cells = n(),
    n_scenarios = n_distinct(input_id),
    n_categories = n_distinct(category),
    median_subgroup_n = stats::median(subgroup_n),
    r_overall = suppressWarnings(stats::cor(implied_mean, human_group_mean, use = "complete.obs")),
    r_within_scenario = suppressWarnings(stats::cor(model_within, human_within, use = "complete.obs")),
    sd_model_within = stats::sd(model_within, na.rm = TRUE),
    sd_human_within = stats::sd(human_within, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(within_sd_ratio = sd_model_within / sd_human_within,
         analysis_scope = "demographic_pooled_24",
         human_sample_source = "main + bot-pass boost",
         model_run = "D6 distributional arms") %>%
  dplyr::select(method, model_name, dimension, n_cells, n_scenarios, n_categories,
                median_subgroup_n, r_overall, r_within_scenario,
                sd_model_within, sd_human_within, within_sd_ratio,
                analysis_scope, human_sample_source, model_run) %>%
  arrange(method, model_name, dimension)

write.csv(demo_d6_ordering_by_dimension,
          file.path(out_dir, "table_d6_ordering_by_dimension.csv"), row.names = FALSE)

cat("\n  D6 ordering: within-scenario tracking by arm (politics rows first):\n")
print(as.data.frame(
  demo_d6_ordering_by_dimension %>%
    arrange(dimension != "dim_politics", model_name, method) %>%
    dplyr::select(model_name, dimension, method, r_within_scenario, r_overall,
                  within_sd_ratio, n_cells) %>%
    mutate(across(where(is.numeric), ~ round(.x, 4)))
), row.names = FALSE, max = 400)

# COVERAGE, full-cell and matched-cell
DEMO_D6_FRAME_CELLS <- 24L * DEMO_N_GROUPS
demo_elicitation_coverage <- purrr::map_dfr(
  sort(unique(demo_props_cells$model_name)), function(m) {
    runb_frame <- demo_runB %>% filter(model_name == m) %>%
      distinct(input_id, group_index)
    props_frame <- demo_props_cells %>% filter(model_name == m) %>%
      semi_join(runb_frame, by = "input_id") %>% distinct(input_id, group_index)
    tibble(
      model_name = m,
      frame_cells = DEMO_D6_FRAME_CELLS,
      props_usable_cells = nrow(props_frame),
      runB_usable_cells = nrow(runb_frame),
      both_usable_cells = nrow(dplyr::intersect(props_frame, runb_frame)),
      props_compliance_pct = 100 * nrow(props_frame) / DEMO_D6_FRAME_CELLS,
      matched_cells_after_human_gate =
        sum(demo_elicitation_cells$model_name == m),
      matched_categories =
        n_distinct(paste(demo_elicitation_cells$dimension,
                         demo_elicitation_cells$category)[
                           demo_elicitation_cells$model_name == m])
    )
  })
write.csv(demo_elicitation_coverage,
          file.path(out_dir, "table_d6_elicitation_coverage.csv"), row.names = FALSE)

cat("\n  Elicitation coverage (24 scenarios x", DEMO_N_GROUPS, "groups):\n")
print(as.data.frame(demo_elicitation_coverage))
cat("\n  Paired arm difference (proportions minus repeated sampling),",
    "clustered by scenario:\n")
print(as.data.frame(demo_elicitation_tests %>%
        dplyr::select(model_name, metric, n_pairs, n_clusters, mean_props,
                      mean_runB, mean_diff_props_minus_runB, se_cluster,
                      p_cluster, p_holm_cluster, p_unclustered) %>%
        mutate(across(where(is.numeric), ~ round(.x, 4)))))

demo_props_prompt_src <- purrr::imap_dfr(path_demo_props, function(p, lbl) {
  r <- read_model_file_safe(p, basename(p))
  tibble(arm = "proportions", model_label = lbl, file = basename(p),
         n_basenames = n_distinct(r$prompt_src_basename),
         prompt_src_root = paste(sort(unique(dirname(dirname(r$prompt_src)))),
                                 collapse = "; "))
})
demo_v2_prompt_src <- purrr::imap_dfr(
  path_demo_runA[c("gpt-4o-mini", "gpt-5.1")], function(p, lbl) {
    if (!file.exists(p)) return(tibble())
    r <- read_model_file_safe(p, basename(p))
    tibble(arm = "v2", model_label = lbl, file = basename(p),
           n_basenames = n_distinct(r$prompt_src_basename),
           prompt_src_root = paste(sort(unique(dirname(dirname(r$prompt_src)))),
                                   collapse = "; "))
  })
demo_v2_provenance <- bind_rows(demo_props_prompt_src, demo_v2_prompt_src) %>%
  mutate(included_as_third_arm = FALSE,
         reason = "basenames match but prompt_src directories differ; prompt text not verifiable")
write.csv(demo_v2_provenance,
          file.path(out_dir, "CHECK_demo_props_v2_prompt_provenance.csv"), row.names = FALSE)
cat("\n  v2 third arm: EXCLUDED (prompt provenance differs). See",
    "CHECK_demo_props_v2_prompt_provenance.csv\n")


cat("\n", strrep("=", 70),
    "\nPART D7 — NON-COMPLIANCE, COMPOSITION, BASELINES, TARGET-DISTANCE COMPARISON\n",
    strrep("=", 70), "\n")

# Compare demographic distribution estimates with human group and marginal targets.

D7_MODELS <- sort(unique(demo_props_cells$model_name))
D7_FRAME_SCENARIOS <- sort(unique(demo_runB$input_id))
D7_FRAME_GROUPS <- sort(DEMO_GROUP_CROSSWALK$group_index)
D7_FRAME_CELLS <- length(D7_FRAME_SCENARIOS) * length(D7_FRAME_GROUPS)
D7_UNIFORM <- rep(1 / 9, 9)

D7_EXPECTED_GATED_CELLS <- 647L
write.csv(data.frame(
  observed_cells = nrow(dplyr::distinct(demo_human_subgroup_props, dimension, category, input_id)),
  expected_cells = D7_EXPECTED_GATED_CELLS),
  file.path(out_dir, "CHECK_d7_human_observed_vs_expected_coverage.csv"), row.names = FALSE)
stopifnot(
  nrow(dplyr::distinct(demo_human_subgroup_props, dimension, category, input_id)) ==
    D7_EXPECTED_GATED_CELLS,
  min(demo_human_subgroup_props$subgroup_n) >= MIN_SUBGROUP_N
)

# Use scenario-clustered inference for demographic comparisons.
cluster_group_diff <- function(y, x, cluster) {
  ok <- is.finite(y) & is.finite(x) & !is.na(cluster)
  y <- y[ok]; x <- x[ok]; cluster <- cluster[ok]
  X <- cbind(1, x); N <- length(y); K <- 2L
  XtX_inv <- solve(crossprod(X))
  beta <- XtX_inv %*% crossprod(X, y)
  e <- as.vector(y - X %*% beta)
  g_levels <- unique(cluster); G <- length(g_levels)
  meat <- matrix(0, K, K)
  for (g in g_levels) {
    m <- cluster == g
    s <- crossprod(X[m, , drop = FALSE], e[m])
    meat <- meat + tcrossprod(s)
  }
  V <- XtX_inv %*% ((G / (G - 1)) * ((N - 1) / (N - K)) * meat) %*% XtX_inv
  se <- sqrt(diag(V))[2]
  tstat <- beta[2] / se
  df <- G - 1
  list(estimate = as.numeric(beta[2]), se = se, t = as.numeric(tstat),
       df = df, p = 2 * stats::pt(-abs(tstat), df = df), g = G, n = N)
}

cluster_weighted_mean <- function(y, w, cluster) {
  ok <- is.finite(y) & is.finite(w) & !is.na(cluster)
  y <- y[ok]; w <- w[ok]; cluster <- cluster[ok]
  mu <- sum(w * y) / sum(w)
  e <- w * (y - mu)
  g_levels <- unique(cluster); G <- length(g_levels)
  gsum <- vapply(g_levels, function(g) sum(e[cluster == g]), numeric(1))
  se <- sqrt((G / (G - 1)) * sum(gsum^2) / (sum(w)^2))
  tstat <- mu / se; df <- G - 1
  list(estimate = mu, se = se, t = tstat, df = df,
       p = 2 * stats::pt(-abs(tstat), df = df), g = G, n = length(y))
}

# Report noncompliance with the requested nine-bin Proportions format.
d7_shape_records <- purrr::imap_dfr(path_demo_props, function(p, lbl) {
  r <- read_model_file_safe(p, basename(p)) %>%
    filter(as.character(temperature) == "0")
  tibble(
    model_name = r$model_name,
    input_id = r$input_id,
    group_index = suppressWarnings(as.integer(r$prompt_id)),
    shape_raw = vapply(purrr::map(r$output_seq, extract_nine_bin),
                       function(z) z$shape, character(1))
  )
}) %>%
  filter(input_id %in% D7_FRAME_SCENARIOS, group_index %in% D7_FRAME_GROUPS) %>%
  mutate(record_shape = dplyr::case_when(
    shape_raw == "other_object:Q1|Q2|Q3|Q4|Q5|Q6|Q7" ~ "Q1..Q7",
    shape_raw == "other_object:response"             ~ "response",
    startsWith(shape_raw, "other_object:")           ~ "other_object",
    TRUE                                             ~ shape_raw
  ))

d7_frame <- tidyr::crossing(model_name = D7_MODELS,
                            input_id = D7_FRAME_SCENARIOS,
                            group_index = D7_FRAME_GROUPS)
d7_usable <- demo_props_cells %>%
  filter(input_id %in% D7_FRAME_SCENARIOS, group_index %in% D7_FRAME_GROUPS) %>%
  distinct(model_name, input_id, group_index)
d7_missing <- dplyr::anti_join(d7_frame, d7_usable,
                               by = c("model_name", "input_id", "group_index")) %>%
  inner_join(DEMO_GROUP_CROSSWALK, by = "group_index")

d7_props_missing_by_shape <- d7_missing %>%
  left_join(d7_shape_records %>%
              distinct(model_name, input_id, group_index, record_shape),
            by = c("model_name", "input_id", "group_index")) %>%
  mutate(record_shape = ifelse(is.na(record_shape), "(no record)", record_shape)) %>%
  group_by(model_name, input_id, group_index) %>%
  summarise(record_shape = paste(sort(unique(record_shape)), collapse = "+"),
            .groups = "drop") %>%
  count(model_name, record_shape, name = "n_missing_cells") %>%
  mutate(frame_cells = as.integer(D7_FRAME_CELLS)) %>%
  arrange(model_name, record_shape)

d7_props_missing_by_scenario <- tidyr::crossing(
    model_name = D7_MODELS, input_id = D7_FRAME_SCENARIOS) %>%
  left_join(d7_missing %>% count(model_name, input_id, name = "n_missing"),
            by = c("model_name", "input_id")) %>%
  mutate(n_missing = as.integer(tidyr::replace_na(n_missing, 0L)),
         groups_in_frame = length(D7_FRAME_GROUPS),
         pct_missing = 100 * n_missing / groups_in_frame) %>%
  arrange(model_name, input_id)

d7_dim_ncat <- DEMO_GROUP_CROSSWALK %>% count(dimension, name = "n_categories")
d7_props_missing_by_dimension <- tidyr::crossing(
    model_name = D7_MODELS, dimension = sort(d7_dim_ncat$dimension)) %>%
  left_join(d7_dim_ncat, by = "dimension") %>%
  left_join(d7_missing %>% count(model_name, dimension, name = "n_missing"),
            by = c("model_name", "dimension")) %>%
  mutate(n_missing = as.integer(tidyr::replace_na(n_missing, 0L)),
         cells_in_frame = as.integer(n_categories * length(D7_FRAME_SCENARIOS)),
         pct_missing = 100 * n_missing / cells_in_frame) %>%
  dplyr::select(model_name, dimension, n_categories, cells_in_frame,
                n_missing, pct_missing) %>%
  arrange(model_name, dimension)

d7_props_missing_by_category <- tidyr::crossing(
    model_name = D7_MODELS,
    DEMO_GROUP_CROSSWALK %>% dplyr::select(dimension, category)) %>%
  left_join(d7_missing %>% count(model_name, dimension, category, name = "n_missing"),
            by = c("model_name", "dimension", "category")) %>%
  mutate(n_missing = as.integer(tidyr::replace_na(n_missing, 0L)),
         scenarios = length(D7_FRAME_SCENARIOS),
         pct_missing = 100 * n_missing / scenarios) %>%
  arrange(model_name, dimension, category)

d7_cofail_counts <- purrr::map(D7_MODELS, function(m) {
  d7_missing %>% filter(model_name == m) %>%
    transmute(cell = paste(input_id, group_index)) %>% pull(cell)
})
names(d7_cofail_counts) <- D7_MODELS
d7_a <- length(d7_cofail_counts[[1]]); d7_b <- length(d7_cofail_counts[[2]])
d7_ov <- length(intersect(d7_cofail_counts[[1]], d7_cofail_counts[[2]]))
d7_n11 <- d7_ov; d7_n10 <- d7_a - d7_ov; d7_n01 <- d7_b - d7_ov
d7_n00 <- D7_FRAME_CELLS - d7_a - d7_b + d7_ov
d7_m11 <- as.numeric(d7_n11); d7_m10 <- as.numeric(d7_n10)
d7_m01 <- as.numeric(d7_n01); d7_m00 <- as.numeric(d7_n00)
d7_cofail_denom <- (d7_m11 + d7_m10) * (d7_m01 + d7_m00) *
  (d7_m11 + d7_m01) * (d7_m10 + d7_m00)
d7_chi <- as.numeric(D7_FRAME_CELLS) *
  (d7_m11 * d7_m00 - d7_m10 * d7_m01)^2 / d7_cofail_denom
d7_phi <- (d7_m11 * d7_m00 - d7_m10 * d7_m01) / sqrt(d7_cofail_denom)
d7_props_cofailure <- tibble(
  frame_cells = as.integer(D7_FRAME_CELLS),
  both_missing = as.integer(d7_n11),
  neither = as.integer(d7_n00),
  expected_overlap_if_independent = d7_a * d7_b / D7_FRAME_CELLS,
  obs_over_exp = d7_ov / (d7_a * d7_b / D7_FRAME_CELLS),
  chi2_1df = d7_chi, phi = d7_phi
)
d7_props_cofailure[[paste0(D7_MODELS[1], "_missing")]] <- as.integer(d7_a)
d7_props_cofailure[[paste0(D7_MODELS[2], "_missing")]] <- as.integer(d7_b)
d7_props_cofailure[[paste0("only_", D7_MODELS[1])]] <- as.integer(d7_n10)
d7_props_cofailure[[paste0("only_", D7_MODELS[2])]] <- as.integer(d7_n01)
d7_props_cofailure <- d7_props_cofailure %>%
  dplyr::select(frame_cells,
                all_of(paste0(D7_MODELS[1], "_missing")),
                all_of(paste0(D7_MODELS[2], "_missing")),
                both_missing,
                all_of(paste0("only_", D7_MODELS[1])),
                all_of(paste0("only_", D7_MODELS[2])),
                neither, expected_overlap_if_independent, obs_over_exp,
                chi2_1df, phi)

# Compute cell-level distances for each estimator against both human targets.
d7_marginal <- demo_frames_all %>%
  filter(analysis_scope == "demographic_pooled_24") %>%
  distinct(respondent_uid, input_id, human_y) %>%
  mutate(y = clamp_scale(human_y)) %>%
  count(input_id, y, name = "n") %>%
  group_by(input_id) %>%
  complete(y = -4:4, fill = list(n = 0)) %>%
  mutate(marginal_prop = n / sum(n)) %>%
  ungroup() %>%
  mutate(bin = factor(y, levels = -4:4)) %>%
  dplyr::select(input_id, bin, marginal_prop)

d7_cell_bins <- purrr::map_dfr(D7_MODELS, function(m) {
  demo_human_subgroup_props %>%
    inner_join(DEMO_GROUP_CROSSWALK, by = c("dimension", "category")) %>%
    inner_join(d7_marginal, by = c("input_id", "bin")) %>%
    mutate(model_name = m) %>%
    left_join(demo_runB_props %>% filter(model_name == m) %>%
                dplyr::select(group_index, input_id, bin, runB_prop = model_prop),
              by = c("group_index", "input_id", "bin")) %>%
    left_join(demo_props_props %>% filter(model_name == m) %>%
                dplyr::select(group_index, input_id, bin, props_prop = model_prop),
              by = c("group_index", "input_id", "bin"))
})

d7_cells <- d7_cell_bins %>%
  arrange(model_name, dimension, category, input_id, bin) %>%
  group_by(model_name, dimension, category, input_id, group_index) %>%
  summarise(
    subgroup_n = dplyr::first(subgroup_n),
    props_usable = !anyNA(props_prop),
    human_sd = sqrt(sum(human_prop * (as.numeric(as.character(bin)) -
                                        sum(human_prop * as.numeric(as.character(bin))))^2) *
                      dplyr::first(subgroup_n) / (dplyr::first(subgroup_n) - 1)),
    human_entropy = -sum(ifelse(human_prop > 0, human_prop * log(human_prop), 0)),
    human_vs_marginal_tvd = tvd_dist(human_prop, marginal_prop),
    human_vs_marginal_emd = emd_1d(human_prop, marginal_prop),
    human_vs_marginal_jsd = jsd(human_prop, marginal_prop),
    uniform_vs_human_tvd = tvd_dist(human_prop, D7_UNIFORM),
    uniform_vs_human_emd = emd_1d(human_prop, D7_UNIFORM),
    uniform_vs_human_jsd = jsd(human_prop, D7_UNIFORM),
    runB_vs_human_tvd = tvd_dist(human_prop, runB_prop),
    runB_vs_human_emd = emd_1d(human_prop, runB_prop),
    runB_vs_human_jsd = jsd(human_prop, runB_prop),
    runB_vs_marginal_tvd = tvd_dist(marginal_prop, runB_prop),
    runB_vs_marginal_emd = emd_1d(marginal_prop, runB_prop),
    runB_vs_marginal_jsd = jsd(marginal_prop, runB_prop),
    props_vs_human_tvd = tvd_dist(human_prop, props_prop),
    props_vs_human_emd = emd_1d(human_prop, props_prop),
    props_vs_human_jsd = jsd(human_prop, props_prop),
    props_vs_marginal_tvd = tvd_dist(marginal_prop, props_prop),
    props_vs_marginal_emd = emd_1d(marginal_prop, props_prop),
    props_vs_marginal_jsd = jsd(marginal_prop, props_prop),
    .groups = "drop"
  ) %>%
  arrange(model_name, dimension, category, input_id)

stopifnot(all(d7_cells %>% count(model_name) %>% pull(n) == D7_EXPECTED_GATED_CELLS))

# Verify that paired format distances agree with the earlier direct comparison.
d7_reconcile <- d7_cells %>%
  filter(props_usable) %>%
  dplyr::select(model_name, dimension, category, input_id,
                props_vs_human_tvd, runB_vs_human_tvd) %>%
  inner_join(demo_elicitation_cells %>%
               dplyr::select(model_name, dimension, category, input_id,
                             tvd_props, tvd_runB),
             by = c("model_name", "dimension", "category", "input_id"))
if (nrow(d7_reconcile) != nrow(demo_elicitation_cells) ||
    max(abs(d7_reconcile$props_vs_human_tvd - d7_reconcile$tvd_props)) > 1e-10 ||
    max(abs(d7_reconcile$runB_vs_human_tvd - d7_reconcile$tvd_runB)) > 1e-10) {
  stop("D7 does not reproduce the D6 head-to-head distances; the two sections ",
       "are not scoring the same cells against the same human reference.")
}

# Compare repeated-sampling performance on cells retained versus lost by Proportions parsing.
d7_runB_difficulty <- purrr::map_dfr(D7_MODELS, function(m) {
  s <- d7_cells %>% filter(model_name == m)
  purrr::map_dfr(c("tvd", "emd", "jsd"), function(met) {
    y <- s[[paste0("runB_vs_human_", met)]]
    x <- as.numeric(!s$props_usable)
    cr <- cluster_group_diff(y, x, s$input_id)
    tibble(model_name = m, metric = met,
           n_kept = sum(s$props_usable), n_dropped = sum(!s$props_usable),
           runB_mean_kept = mean(y[s$props_usable]),
           runB_mean_dropped = mean(y[!s$props_usable]),
           diff_dropped_minus_kept = cr$estimate, se_cluster = cr$se,
           t = cr$t, df = cr$df, p_cluster = cr$p, n_clusters = cr$g)
  })
})

d7_human_correlates <- purrr::map_dfr(D7_MODELS, function(m) {
  s <- d7_cells %>% filter(model_name == m)
  purrr::map_dfr(c("subgroup_n", "human_sd", "human_entropy"), function(v) {
    y <- as.numeric(s[[v]])
    cr <- cluster_group_diff(y, as.numeric(!s$props_usable), s$input_id)
    tibble(model_name = m, variable = v,
           mean_kept = mean(y[s$props_usable]),
           mean_dropped = mean(y[!s$props_usable]),
           diff_dropped_minus_kept = cr$estimate, se_cluster = cr$se,
           t = cr$t, df = cr$df, p_cluster = cr$p, n_clusters = cr$g)
  })
})

# Compare elicitation formats by demographic dimension and after reweighting.
d7_gated_by_dim <- d7_cells %>%
  filter(model_name == D7_MODELS[1]) %>%
  count(dimension, name = "gated_cells")

d7_arm_by_dimension <- purrr::map_dfr(D7_MODELS, function(m) {
  d <- demo_elicitation_cells %>% filter(model_name == m)
  d %>%
    group_by(dimension) %>%
    summarise(n_cells = dplyr::n(),
              d_tvd = mean(d_tvd), d_emd = mean(d_emd), d_jsd = mean(d_jsd),
              tvd_props = mean(tvd_props), tvd_runB = mean(tvd_runB),
              emd_props = mean(emd_props), emd_runB = mean(emd_runB),
              jsd_props = mean(jsd_props), jsd_runB = mean(jsd_runB),
              .groups = "drop") %>%
    right_join(d7_gated_by_dim, by = "dimension") %>%
    mutate(model_name = m,
           n_cells = tidyr::replace_na(n_cells, 0L),
           pct_surviving = 100 * n_cells / gated_cells,
           share_surviving = n_cells / sum(n_cells),
           share_gated = gated_cells / sum(gated_cells)) %>%
    dplyr::select(model_name, dimension, n_cells, d_tvd, d_emd, d_jsd,
                  tvd_props, tvd_runB, emd_props, emd_runB, jsd_props, jsd_runB,
                  gated_cells, pct_surviving, share_surviving, share_gated) %>%
    arrange(dimension)
})

d7_arm_reweighted <- purrr::map_dfr(D7_MODELS, function(m) {
  d <- demo_elicitation_cells %>% filter(model_name == m)
  nd <- d %>% count(dimension, name = "n_surv")
  wt <- nd %>%
    inner_join(d7_gated_by_dim, by = "dimension") %>%
    mutate(w = (gated_cells / sum(gated_cells)) / (n_surv / sum(n_surv))) %>%
    dplyr::select(dimension, w)
  d <- d %>% inner_join(wt, by = "dimension")
  purrr::map_dfr(c("d_tvd", "d_emd", "d_jsd"), function(met) {
    a <- cluster_mean_test(d[[met]], d$input_id)
    b <- cluster_weighted_mean(d[[met]], d$w, d$input_id)
    tibble(model_name = m, metric = met, n_cells = nrow(d), n_clusters = a$g,
           reported = a$mean, se_reported = a$se, p_reported = a$p,
           reweighted = b$estimate, se_reweighted = b$se, p_reweighted = b$p,
           shift = b$estimate - a$mean,
           pct_shift = 100 * (b$estimate - a$mean) / abs(a$mean))
  })
})

# Compare model distributions with simple baseline predictions.
d7_baseline_distances <- purrr::map_dfr(D7_MODELS, function(m) {
  g <- d7_cells %>% filter(model_name == m)
  purrr::map_dfr(list(list("all_gated_647", g),
                      list("props_surviving", g %>% filter(props_usable))),
                 function(sc) {
    scope <- sc[[1]]; s <- sc[[2]]
    purrr::map_dfr(c("tvd", "emd", "jsd"), function(met) {
      tibble(model_name = m, scope = scope, n_cells = nrow(s), metric = met,
             runB = mean(s[[paste0("runB_vs_human_", met)]]),
             proportions = if (scope == "props_surviving")
               mean(s[[paste0("props_vs_human_", met)]]) else NA_real_,
             baseline_scenario_marginal = mean(s[[paste0("human_vs_marginal_", met)]]),
             baseline_uniform = mean(s[[paste0("uniform_vs_human_", met)]]))
    })
  })
})

d7_baseline_tests <- purrr::map_dfr(D7_MODELS, function(m) {
  g <- d7_cells %>% filter(model_name == m)
  purrr::map_dfr(list(list("Run B", "runB_vs_human_", g),
                      list("proportions", "props_vs_human_",
                           g %>% filter(props_usable))),
                 function(ar) {
    arm <- ar[[1]]; pre <- ar[[2]]; s <- ar[[3]]
    purrr::map_dfr(c("tvd", "emd", "jsd"), function(met) {
      purrr::map_dfr(list(list("scenario_marginal", "human_vs_marginal_"),
                          list("uniform", "uniform_vs_human_")), function(bl) {
        bn <- bl[[1]]; bc <- bl[[2]]
        cr <- cluster_mean_test(s[[paste0(pre, met)]] - s[[paste0(bc, met)]],
                                s$input_id)
        tibble(model_name = m, arm = arm, metric = met, baseline = bn,
               n_cells = nrow(s), n_clusters = cr$g,
               arm_mean = mean(s[[paste0(pre, met)]]),
               baseline_mean = mean(s[[paste0(bc, met)]]),
               diff_arm_minus_baseline = cr$mean, se_cluster = cr$se,
               t = cr$t, df = cr$df, p_cluster = cr$p,
               winner = if (cr$mean < 0) "arm" else "baseline")
      })
    })
  })
})

# Contrast errors against group and pooled empirical targets
d7_error_decomposition <- purrr::map_dfr(D7_MODELS, function(m) {
  g <- d7_cells %>% filter(model_name == m)
  purrr::map_dfr(list(list("Run B", "runB_", g),
                      list("proportions", "props_", g %>% filter(props_usable))),
                 function(ar) {
    arm <- ar[[1]]; pre <- ar[[2]]; s <- ar[[3]]
    purrr::map_dfr(c("tvd", "emd", "jsd"), function(met) {
      cr <- cluster_mean_test(s[[paste0(pre, "vs_human_", met)]] -
                                s[[paste0(pre, "vs_marginal_", met)]], s$input_id)
      tibble(model_name = m, arm = arm, metric = met,
             n_cells = nrow(s), n_clusters = cr$g,
             vs_group_distribution = mean(s[[paste0(pre, "vs_human_", met)]]),
             vs_scenario_marginal = mean(s[[paste0(pre, "vs_marginal_", met)]]),
             group_minus_marginal = cr$mean, se_cluster = cr$se,
             t = cr$t, df = cr$df, p_cluster = cr$p,
             relative_distance_reduction_pct =
               if (mean(s[[paste0(pre, "vs_human_", met)]]) > 0)
                 100 * cr$mean / mean(s[[paste0(pre, "vs_human_", met)]]) else NA_real_,
             human_group_vs_marginal_reference =
               mean(s[[paste0("human_vs_marginal_", met)]]))
    })
  })
})

# Export demographic distribution comparisons.
write.csv(d7_props_missing_by_shape,
          file.path(out_dir, "table_d7_props_missing_by_shape.csv"), row.names = FALSE)
write.csv(d7_props_missing_by_scenario,
          file.path(out_dir, "table_d7_props_missing_by_scenario.csv"), row.names = FALSE)
write.csv(d7_props_missing_by_dimension,
          file.path(out_dir, "table_d7_props_missing_by_dimension.csv"), row.names = FALSE)
write.csv(d7_props_missing_by_category,
          file.path(out_dir, "table_d7_props_missing_by_category.csv"), row.names = FALSE)
write.csv(d7_props_cofailure,
          file.path(out_dir, "table_d7_props_cofailure_2x2.csv"), row.names = FALSE)
write.csv(d7_cells,
          file.path(out_dir, "table_d7_cell_level_all_distances.csv"), row.names = FALSE)
write.csv(d7_runB_difficulty,
          file.path(out_dir, "table_d7_runB_difficulty_kept_vs_dropped.csv"), row.names = FALSE)
write.csv(d7_human_correlates,
          file.path(out_dir, "table_d7_human_correlates_kept_vs_dropped.csv"), row.names = FALSE)
write.csv(d7_arm_by_dimension,
          file.path(out_dir, "table_d7_arm_difference_by_dimension.csv"), row.names = FALSE)
write.csv(d7_arm_reweighted,
          file.path(out_dir, "table_d7_arm_difference_reweighted.csv"), row.names = FALSE)
write.csv(d7_baseline_distances,
          file.path(out_dir, "table_d7_baseline_distances.csv"), row.names = FALSE)
write.csv(d7_baseline_tests,
          file.path(out_dir, "table_d7_baseline_paired_tests.csv"), row.names = FALSE)
write.csv(d7_error_decomposition,
          file.path(out_dir, "table_d7_error_decomposition_group_vs_marginal.csv"), row.names = FALSE)

audit_record(
  "D7 diagnostics", "characterise proportions non-compliance and contrast arm distances to subgroup and marginal targets",
  rows_in = nrow(d7_frame), rows_out = nrow(d7_cells),
  keys_in = nrow(d7_frame), keys_out = nrow(d7_cells),
  reason = "792-cell model frame reduced to the human-gated cells scored in D6",
  detail = paste0(nrow(d7_missing), " proportions cells missing across both models")
)

cat("\n  Proportions non-compliance in the ", D7_FRAME_CELLS, "-cell frame:\n", sep = "")
print(as.data.frame(d7_props_missing_by_shape))
cat("\n  Co-failure of the two models:\n")
print(as.data.frame(d7_props_cofailure))
cat("\n  Run B distance, cells where proportions succeeded vs failed:\n")
print(as.data.frame(d7_runB_difficulty %>%
        dplyr::select(model_name, metric, n_kept, n_dropped, runB_mean_kept,
                      runB_mean_dropped, diff_dropped_minus_kept, p_cluster) %>%
        mutate(across(where(is.numeric), ~ round(.x, 4)))))
cat("\n  Pooled arm difference, reported vs reweighted to gated composition:\n")
print(as.data.frame(d7_arm_reweighted %>%
        dplyr::select(model_name, metric, reported, p_reported, reweighted,
                      p_reweighted, pct_shift) %>%
        mutate(across(where(is.numeric), ~ round(.x, 4)))))
cat("\n  Arms vs uniform and in-sample empirical references:\n")
cat("  The empirical reference uses these same human data; it is not a held-out predictive baseline.\n")
print(as.data.frame(d7_baseline_distances %>%
        mutate(across(where(is.numeric), ~ round(.x, 4)))))
cat("\n  Distances to subgroup versus scenario-marginal targets:\n")
cat("  Their difference is not an additive or causal decomposition of model error.\n")
print(as.data.frame(d7_error_decomposition %>%
        dplyr::select(model_name, arm, metric, vs_group_distribution,
                      vs_scenario_marginal, group_minus_marginal, p_cluster,
                      relative_distance_reduction_pct) %>%
        mutate(across(where(is.numeric), ~ round(.x, 4)))))


cat("\n================ CHECK: AVERAGE-JUDGMENT SOURCE SELECTION ================\n")

model_means_primary %>%
  count(model_name, source, prompt_measure, name = "n_rows") %>%
  arrange(model_name, source) %>%
  print(n = Inf, width = Inf)

cat("\nMean comparison rows:\n")
print(mean_comparison, n = Inf, width = Inf)

cat("\nOld/new robustness rows:\n")
print(robustness, n = Inf, width = Inf)

cat("\nDirectional-bias t-tests:\n")
print(present_paper_predhuman_ttests, n = Inf, width = Inf)


cat("\n================ CHECK: WORDING SOURCE SELECTION ================\n")

wording_model_means_all %>%
  count(model_label, model_name, source, prompt_measure, name = "n_rows") %>%
  arrange(model_label, source) %>%
  print(n = Inf, width = Inf)

cat("\nNo duplicated model/item rows after source selection; should print 0 rows:\n")
wording_model_means_all %>%
  count(model_name, input_id, name = "n_rows") %>%
  filter(n_rows > 1) %>%
  print(n = Inf, width = Inf)

cat("\nWording mean-fit ranges using primary source:\n")
print(wording_mean_fit_primary_ranges, n = Inf, width = Inf)

cat("\nModel-error source coverage:\n")
wording_model_error_primary %>%
  count(scenario_source, model_label, source, prompt_measure, name = "n_rows") %>%
  arrange(scenario_source, model_label, source) %>%
  print(n = Inf, width = Inf)

cat("\nAlignment source coverage:\n")
wording_alignment_item %>%
  count(model_label, model_name, source, prompt_measure, name = "n_rows") %>%
  arrange(model_label, source) %>%
  print(n = Inf, width = Inf)

cat("\nOld/new alignment-pair rows by source and model:\n")
wording_alignment_pairs %>%
  count(scenario_set, model_label, source, prompt_measure, name = "n_pairs") %>%
  arrange(scenario_set, model_label, source) %>%
  print(n = Inf, width = Inf)

cat("\nModel coverage per scenario set:\n")
wording_alignment_pairs_model_equal_item %>%
  count(scenario_set, n_models, models, name = "n_pairs") %>%
  print(n = Inf, width = Inf)

cat("\nAlignment descriptives:\n")
print(alignment_descriptives_model_equal, n = Inf, width = Inf)

cat("\nGap-only alignment models:\n")
print(alignment_gap_model_equal_gap_only, n = Inf, width = Inf)

cat("\nSaved human split-half outputs to:\n")
cat("  ", out_dir, "\n")

cat("\n", strrep("=", 70),
    "\nDONE: HUMAN SPLIT-HALF ABSOLUTE DISCREPANCY CHECK\n",
    strrep("=", 70), "\n")


# NAME-MATCH AUDIT
cat("\n", strrep("=", 70),
    "\nNAME-MATCH AUDIT — whitelists, path lists, and name lookups\n",
    strrep("=", 70), "\n")

.nm_rows <- list()
nm_check <- function(site, expected_n, resolved_n, detail = NA_character_,
                     expect_zero = FALSE) {
  status <- if (is.na(resolved_n)) {
    "EMPTY"
  } else if (expect_zero) {
    if (resolved_n == 0) "ok" else "UNEXPECTED SIZE"
  } else if (resolved_n == 0) {
    "EMPTY"
  } else if (!is.na(expected_n) && resolved_n != expected_n) {
    "UNEXPECTED SIZE"
  } else {
    "ok"
  }
  .nm_rows[[length(.nm_rows) + 1L]] <<- tibble(
    script = "Scenarios.R", site = site,
    expected_n = as.integer(expected_n), resolved_n = as.integer(resolved_n),
    status = status, detail = as.character(detail)
  )
  invisible(NULL)
}

# Path lists: every declared input file must exist.
nm_check("path_confidence_files exist", length(path_confidence_files),
         sum(file.exists(path_confidence_files)),
         paste(basename(path_confidence_files), collapse = "; "))
# Include demographic objects in the final output audit.
if (exists("path_demo_runA")) {
  nm_check("path_demo_runA files exist", length(path_demo_runA),
           sum(file.exists(path_demo_runA)))
}
if (exists("path_demo_runB")) {
  nm_check("path_demo_runB files exist", length(path_demo_runB),
           sum(file.exists(path_demo_runB)))
}
for (p in c("path_repeated_500", "path_repeated_500_qwen", "path_repeated_500_gpt4omini",
            "path_repeated_500_gpt35", "path_repeated_500_gptoss",
            "path_distribution_main", "path_distribution_qwen", "path_distribution_gptoss",
            "path_sd_only_api", "path_sd_only_qwen", "path_sd_only_gpt35",
            "path_sd_only_gptoss", "path_human_csv", "path_demographic_boost",
            "path_scenario_text")) {
  if (exists(p)) nm_check(paste0(p, " exists"), 1L, as.integer(file.exists(get(p))),
                          basename(get(p)))
}

if (exists("dist_by_scenario")) {
  nm_check("PRESENT_PAPER_SCENARIO_TYPES resolve", length(PRESENT_PAPER_SCENARIO_TYPES),
           n_distinct(dist_by_scenario$scenario_type[
             dist_by_scenario$scenario_type %in% PRESENT_PAPER_SCENARIO_TYPES]))
  nm_check("e1_all_methods resolve", length(e1_all_methods),
           n_distinct(dist_by_scenario$method))
}
if (exists("human_stats")) {
  nm_check("SCHROEDER_SCENARIO_TYPES resolve", length(SCHROEDER_SCENARIO_TYPES),
           n_distinct(human_stats$scenario_type[
             human_stats$scenario_type %in% SCHROEDER_SCENARIO_TYPES]))
}
if (exists("distribution_estimates_for_sims")) {
  nm_check("bin_probability_cols present", length(bin_probability_cols),
           sum(bin_probability_cols %in% names(distribution_estimates_for_sims)))
}
if (exists("demo_respondents")) {
  nm_check("DEMO_SHARED_COLS present in merged survey", length(DEMO_SHARED_COLS),
           sum(DEMO_SHARED_COLS %in% names(demo_respondents)))
}
if (exists("demo_categories")) {
  nm_check("DEMO_DIMENSIONS present", length(DEMO_DIMENSIONS),
           sum(DEMO_DIMENSIONS %in% names(demo_categories)))
}
if (exists("DEMO_GROUP_CROSSWALK") && exists("demo_category_coverage")) {
  nm_check("crosswalk groups matched to human categories", DEMO_N_GROUPS,
           sum(paste(DEMO_GROUP_CROSSWALK$dimension, DEMO_GROUP_CROSSWALK$category) %in%
                 paste(demo_category_coverage$dimension, demo_category_coverage$category)))
}
if (exists("rep500")) {
  nm_check("rep500 models loaded", 5L, n_distinct(rep500$model_name),
           paste(sort(unique(rep500$model_name)), collapse = "; "))
}
if (exists("e3_corrections")) {
  nm_check("E3 registry objects found", 7L, n_distinct(e3_corrections$object),
           "object names must match live objects or the block silently no-ops")
}
if (exists("demo_runA")) {
  nm_check("Run A models", 5L, n_distinct(demo_runA$model_name))
  nm_check("Run A groups", DEMO_N_GROUPS, n_distinct(demo_runA$group_index))
}
if (exists("demo_runB") && nrow(demo_runB) > 0) {
  nm_check("Run B models", 4L, n_distinct(demo_runB$model_name))
  nm_check("Run B groups", DEMO_N_GROUPS, n_distinct(demo_runB$group_index))
}
if (exists("scenario_text_lookup")) {
  nm_check("scenario text rows", 24L, nrow(scenario_text_lookup))
}

scen_name_match_audit <- bind_rows(.nm_rows)
write.csv(scen_name_match_audit, file.path(out_dir, "table_name_match_audit.csv"),
          row.names = FALSE)
print(as.data.frame(scen_name_match_audit))
n_bad <- sum(scen_name_match_audit$status != "ok")
cat("\n  Sites checked:", nrow(scen_name_match_audit), "  problems:", n_bad, "\n")
if (n_bad > 0) {
  cat("  ⚠ Review these before trusting downstream numbers:\n")
  print(as.data.frame(scen_name_match_audit %>% filter(status != "ok")))
}

# Write accumulated filter, join and exclusion audit records.
cat("\n── Audit table of filters, joins, and exclusions ──\n")
write_audit_table()

# Model-set consistency audit.

cat("\n── Model-set consistency across paper-ready tables ──\n")

MODEL_SET_EXPECTED_N <- length(new_table_models)
MODEL_SET_EXPECTED_IDS <- sort(new_table_models)
MODEL_SET_EXPECTED_LABELS <- sort(unname(new_model_labels[new_table_models]))
model_set_col_candidates <- c("model_name", "Model", "model", "model_label")
model_set_file_patterns <- c("^table_present_paper_", "^table3_", "^table4_",
                             "^table_wording_", "^table_dist_", "^table_e5_",
                             "^table_e8_", "^table_confidence_")

model_set_files <- list.files(out_dir, pattern = "[.]csv$")
# Audit only output files written during the current run.
.msf_mtime <- file.info(file.path(out_dir, model_set_files))$mtime
.msf_stale <- model_set_files[!is.na(.msf_mtime) & .msf_mtime < .scen_run_started]
if (length(.msf_stale) > 0) {
  cat("  WARNING: skipping", length(.msf_stale),
      "stale CSVs from an earlier run in this out_dir:\n   ",
      paste(utils::head(.msf_stale, 10), collapse = ", "),
      if (length(.msf_stale) > 10) "..." else "", "\n")
  model_set_files <- setdiff(model_set_files, .msf_stale)
}
model_set_files <- model_set_files[Reduce(
  `|`, lapply(model_set_file_patterns, function(p) grepl(p, model_set_files)))]

scen_model_set_audit <- purrr::map_dfr(sort(model_set_files), function(f) {
  d <- tryCatch(suppressWarnings(readr::read_csv(file.path(out_dir, f),
                show_col_types = FALSE, progress = FALSE)),
                error = function(e) NULL)
  if (is.null(d)) return(tibble())
  mc <- intersect(names(d), model_set_col_candidates)
  if (length(mc) == 0) return(tibble())
  v <- sort(unique(as.character(d[[mc[1]]])))
  v <- v[!is.na(v)]
  id_overlap <- length(intersect(v, MODEL_SET_EXPECTED_IDS))
  label_overlap <- length(intersect(v, MODEL_SET_EXPECTED_LABELS))
  expected <- if (id_overlap >= label_overlap) {
    MODEL_SET_EXPECTED_IDS
  } else {
    MODEL_SET_EXPECTED_LABELS
  }
  exact_match <- setequal(v, expected)
  tibble(
    file = f, column = mc[1], n_models = length(v),
    expected_n = MODEL_SET_EXPECTED_N,
    status = if (exact_match) "ok" else "MODEL SET MISMATCH",
    models = paste(v, collapse = "; "),
    expected_models = paste(expected, collapse = "; "),
    missing_models = paste(setdiff(expected, v), collapse = "; "),
    unexpected_models = paste(setdiff(v, expected), collapse = "; ")
  )
})

if (nrow(scen_model_set_audit) > 0) {
  readr::write_csv(scen_model_set_audit,
                   file.path(out_dir, "table_model_set_audit.csv"))
  n_model_bad <- sum(scen_model_set_audit$status != "ok")
  cat("  Tables with a model column:", nrow(scen_model_set_audit),
      "  expected models:", MODEL_SET_EXPECTED_N,
      "  problems:", n_model_bad, "\n")
  if (n_model_bad > 0) {
    cat("  ⚠ These tables do not carry the full model set:\n")
    print(as.data.frame(scen_model_set_audit %>%
            dplyr::filter(status != "ok") %>%
            dplyr::select(file, column, n_models, expected_n, models,
                          missing_models, unexpected_models)),
          row.names = FALSE)
    stop(
      "Paper-ready tables have inconsistent model identities; ",
      "see table_model_set_audit.csv."
    )
  }
} else {
  stop(
    "No paper-ready table carried a recognisable model column; ",
    "check model_set_col_candidates."
  )
}

cat("\n", strrep("=", 70), "\nDONE. Outputs:", out_dir,
    "\n", strrep("=", 70), "\n")


# Additional exports for confidence, usable draw counts and moment diagnostics.

cat("\n", strrep("=", 70),
    "\nADDITIONAL ANALYSIS EXPORTS\n",
    strrep("=", 70), "\n")

# Shared per-model confidence helper. The five-model frame and both compatible
# table filenames are written below from one five-model frame.
permodel_conf_test <- function(d, outcome_col, outcome_label) {
  d <- d %>% filter(!is.na(.data[[outcome_col]]), !is.na(rating_confidence))
  if (nrow(d) < 4) return(tibble())
  y <- d[[outcome_col]]
  x <- d$rating_confidence
  ct <- stats::cor.test(x, y)
  tb <- broom::tidy(stats::lm(y ~ x), conf.int = TRUE)[2, ]
  tz <- broom::tidy(stats::lm(as.numeric(scale(y)) ~ as.numeric(scale(x))),
                    conf.int = TRUE)[2, ]
  tibble(
    outcome = outcome_label, n = nrow(d),
    r = unname(ct$estimate), r_ci_low = ct$conf.int[1], r_ci_high = ct$conf.int[2],
    b = tb$estimate, se_b = tb$std.error,
    b_ci_low = tb$conf.low, b_ci_high = tb$conf.high,
    beta = tz$estimate, se_beta = tz$std.error,
    t = unname(ct$statistic), df = unname(ct$parameter), p = ct$p.value
  )
}

set.seed(20260817)
SUBSAMPLE_COMMON_DRAWS <- 280L

rep_sub_dist <- repeated_sampling_sim %>%
  filter(input_id %in% scenarios_with_humans) %>%
  group_by(model_name, input_id) %>%
  slice_sample(n = SUBSAMPLE_COMMON_DRAWS) %>%
  ungroup() %>%
  count(input_id, model_name, y, name = "n") %>%
  group_by(input_id, model_name) %>%
  complete(y = -4:4, fill = list(n = 0)) %>%
  mutate(sub_prop = n / sum(n)) %>%
  ungroup() %>%
  mutate(bin = factor(y, levels = -4:4)) %>%
  dplyr::select(input_id, model_name, bin, sub_prop) %>%
  inner_join(human_props, by = c("input_id", "bin")) %>%
  arrange(input_id, model_name, bin) %>%
  group_by(input_id, model_name) %>%
  summarise(
    tvd = tvd_dist(human_prop, sub_prop),
    emd = emd_1d(human_prop, sub_prop),
    jsd = jsd(human_prop, sub_prop),
    .groups = "drop"
  )

rep_sub_means <- rep_sub_dist %>%
  group_by(model_name) %>%
  summarise(
    n_scenarios_sub = n_distinct(input_id),
    sub_tvd = mean(tvd, na.rm = TRUE),
    sub_emd = mean(emd, na.rm = TRUE),
    sub_jsd = mean(jsd, na.rm = TRUE),
    .groups = "drop"
  )

rep_full_means <- dist_by_scenario %>%
  filter(method == "Repeated_sampling") %>%
  group_by(model_name) %>%
  summarise(
    n_scenarios_full = n_distinct(input_id),
    full_tvd = mean(tvd, na.rm = TRUE),
    full_emd = mean(emd, na.rm = TRUE),
    full_jsd = mean(jsd, na.rm = TRUE),
    .groups = "drop"
  )

check_repeated_subsample_280 <- rep_full_means %>%
  inner_join(rep_sub_means, by = "model_name") %>%
  mutate(
    subsample_n = SUBSAMPLE_COMMON_DRAWS,
    delta_tvd = sub_tvd - full_tvd,
    delta_emd = sub_emd - full_emd,
    delta_jsd = sub_jsd - full_jsd,
    rank_full_tvd = rank(full_tvd), rank_sub_tvd = rank(sub_tvd),
    rank_full_emd = rank(full_emd), rank_sub_emd = rank(sub_emd),
    rank_full_jsd = rank(full_jsd), rank_sub_jsd = rank(sub_jsd)
  ) %>%
  arrange(full_emd)

write.csv(check_repeated_subsample_280,
          file.path(out_dir, "CHECK_repeated_subsample_280.csv"),
          row.names = FALSE)
cat("\n  B2 subsampling-floor diagnostic (common n = 280, seed 20260817):\n")
print(as.data.frame(
  check_repeated_subsample_280 %>%
    mutate(across(where(is.numeric), ~ round(.x, 5)))
), row.names = FALSE)
cat("  max |delta| across metrics:",
    format(max(abs(c(check_repeated_subsample_280$delta_tvd,
                     check_repeated_subsample_280$delta_emd,
                     check_repeated_subsample_280$delta_jsd))), digits = 4),
    "\n")
cat("  rank order unchanged:",
    with(check_repeated_subsample_280,
         all(rank_full_tvd == rank_sub_tvd) &&
         all(rank_full_emd == rank_sub_emd) &&
         all(rank_full_jsd == rank_sub_jsd)), "\n")

# Test associations between GPT-5 usable draw counts and human confusion or variability.
gpt5_draw_counts <- repeated_sampling_sim %>%
  filter(model_name == "gpt-5-chat_2025-08-07",
         input_id %in% scenarios_with_humans) %>%
  count(input_id, name = "n_draws") %>%
  left_join(human_confuse_means %>% dplyr::select(input_id, mean_confusion),
            by = "input_id") %>%
  left_join(human_stats %>% dplyr::select(input_id, human_sd), by = "input_id")

gpt5_draws_cor <- function(d, crit_col, crit_label) {
  d <- d %>% filter(!is.na(.data[[crit_col]]))
  if (nrow(d) < 4) return(tibble())
  ct <- stats::cor.test(d$n_draws, d[[crit_col]])
  tibble(
    criterion = crit_label, n = nrow(d),
    r = unname(ct$estimate),
    r_ci_low = ct$conf.int[1], r_ci_high = ct$conf.int[2],
    t = unname(ct$statistic), df = unname(ct$parameter), p = ct$p.value
  )
}

check_gpt5_draws_difficulty <- bind_rows(
  gpt5_draws_cor(gpt5_draw_counts, "mean_confusion", "human_mean_confusion"),
  gpt5_draws_cor(gpt5_draw_counts, "human_sd", "human_sd")
)

write.csv(check_gpt5_draws_difficulty,
          file.path(out_dir, "CHECK_gpt5_draws_difficulty.csv"),
          row.names = FALSE)
cat("\n  B3 GPT-5 draw count vs difficulty:\n")
print(as.data.frame(
  check_gpt5_draws_difficulty %>%
    mutate(across(where(is.numeric), ~ round(.x, 4)))
), row.names = FALSE)

# Summarize elicited Q4 excess-kurtosis values by model
check_scen_kurtosis_convention <- .scen_fullfit_qc %>%
  group_by(model_name) %>%
  summarise(
    n = sum(!is.na(target_kurt)),
    n_missing = sum(is.na(target_kurt)),
    median_kurt = stats::median(target_kurt, na.rm = TRUE),
    pct_in_ordinary_band_2p5_3p5 =
      100 * mean(target_kurt >= 2.5 & target_kurt <= 3.5, na.rm = TRUE),
    pct_negative = 100 * mean(target_kurt < 0, na.rm = TRUE),
    min_kurt = min(target_kurt, na.rm = TRUE),
    max_kurt = max(target_kurt, na.rm = TRUE),
    .groups = "drop"
  )

write.csv(check_scen_kurtosis_convention,
          file.path(out_dir, "CHECK_scen_kurtosis_convention.csv"),
          row.names = FALSE)
cat("\n  B4 elicited-kurtosis convention diagnostic:\n")
print(as.data.frame(
  check_scen_kurtosis_convention %>%
    mutate(across(where(is.numeric), ~ round(.x, 3)))
), row.names = FALSE)

# Export per-model confidence regressions for all five models, with Holm adjustment within outcome.
permodel_conf_frame_5 <- confidence_estimates %>%
  mutate(input_id = canonical_scenario_id(input_id)) %>%
  filter(
    input_id %in% scenarios_with_humans,
    model_name %in% CONFIDENCE_EXPECTED_MODELS,
    !is.na(rating_confidence)
  ) %>%
  dplyr::select(input_id, model_name, rating_confidence) %>%
  left_join(human_stats %>% dplyr::select(input_id, human_sd), by = "input_id") %>%
  left_join(human_confuse_means %>% dplyr::select(input_id, mean_confusion),
            by = "input_id") %>%
  left_join(pred_error %>% dplyr::select(input_id, model_name, abs_error),
            by = c("input_id", "model_name")) %>%
  left_join(
    dist_by_scenario %>%
      filter(method == PRIMARY_PROPORTIONS_METHOD) %>%
      dplyr::select(input_id, model_name, tvd, emd, jsd),
    by = c("input_id", "model_name")
  )

table_permodel_confidence_lms_fivemodel <- permodel_conf_frame_5 %>%
  mutate(model_label = recode(model_name, !!!model_labels, .default = model_name)) %>%
  group_by(model_name, model_label) %>%
  group_modify(~ bind_rows(
    permodel_conf_test(.x, "human_sd",       "human_sd"),
    permodel_conf_test(.x, "mean_confusion", "human_mean_confusion"),
    permodel_conf_test(.x, "abs_error",      "abs_error"),
    permodel_conf_test(.x, "emd",            "emd_direct_probability"),
    permodel_conf_test(.x, "jsd",            "jsd_direct_probability"),
    permodel_conf_test(.x, "tvd",            "tvd_direct_probability")
  )) %>%
  ungroup() %>%
  arrange(outcome, model_name) %>%
  # Holm within outcome family across the five models (manuscript policy:
  # families defined explicitly; here one family per outcome, n = 5 tests)
  group_by(outcome) %>%
  mutate(p_holm = p.adjust(p, method = "holm")) %>%
  ungroup()

# Both filenames contain the same five-model, Holm-adjusted results.
# Preserve the generic filename for downstream consumers.
table_permodel_confidence_lms <- table_permodel_confidence_lms_fivemodel
write.csv(table_permodel_confidence_lms,
          file.path(out_dir, "table_permodel_confidence_lms.csv"),
          row.names = FALSE)
write.csv(table_permodel_confidence_lms_fivemodel,
          file.path(out_dir, "table_permodel_confidence_lms_fivemodel.csv"),
          row.names = FALSE)
cat("\n  B5 five-model per-model confidence regressions:\n")
print(as.data.frame(
  table_permodel_confidence_lms_fivemodel %>%
    mutate(across(where(is.numeric), ~ round(.x, 4)))
), row.names = FALSE)

# Five-model pooled confidence versus human uncertainty.

fit_confidence_uncertainty_5 <- function(frame, outcome_col) {
  cols <- c(outcome_col, "rating_confidence", "model_name", "input_id")
  d <- as.data.frame(frame[, cols])
  d <- d[stats::complete.cases(d), , drop = FALSE]
  d <- d[is.finite(d[[outcome_col]]) & is.finite(d$rating_confidence), , drop = FALSE]
  d$model_name <- droplevels(factor(d$model_name))
  if (!setequal(as.character(unique(d$model_name)), CONFIDENCE_EXPECTED_MODELS)) {
    stop("Pooled confidence-uncertainty analysis requires all five focal models.")
  }
  if (anyDuplicated(d[c("input_id", "model_name")])) {
    stop("Duplicate model-scenario rows in pooled confidence-uncertainty frame.")
  }
  n_clusters <- length(unique(d$input_id))
  if (n_clusters < 3L) stop("Too few scenario clusters.")
  f <- stats::reformulate(c("rating_confidence", "model_name"), response = outcome_col)
  fit <- stats::lm(f, data = d, na.action = na.fail)
  V <- clubSandwich::vcovCR(fit, cluster = d$input_id, type = "CR2")
  test <- clubSandwich::coef_test(fit, vcov = V, test = "Satterthwaite",
                                 coefs = "rating_confidence")
  critical <- stats::qt(0.975, df = test$df_Satt)
  data.frame(
    outcome = outcome_col, model_set = "five_model",
    n_rows = stats::nobs(fit), n_clusters = n_clusters,
    n_models = length(unique(d$model_name)),
    inference = "Scenario-clustered CR2; Satterthwaite df",
    r = stats::cor(d$rating_confidence, d[[outcome_col]]),
    b = test$beta,
    beta = test$beta * stats::sd(d$rating_confidence) / stats::sd(d[[outcome_col]]),
    se = test$SE, t = test$tstat, df = test$df_Satt, p = test$p_Satt,
    ci_low = test$beta - critical * test$SE,
    ci_high = test$beta + critical * test$SE,
    stringsAsFactors = FALSE
  )
}

table_pooled_confidence_uncertainty_fivemodel <- bind_rows(
  fit_confidence_uncertainty_5(permodel_conf_frame_5, "mean_confusion"),
  fit_confidence_uncertainty_5(permodel_conf_frame_5, "human_sd")
) %>% mutate(p_holm = stats::p.adjust(p, method = "holm"))
write.csv(table_pooled_confidence_uncertainty_fivemodel,
          file.path(out_dir, "table_pooled_confidence_uncertainty_fivemodel.csv"),
          row.names = FALSE)
write.csv(permodel_conf_frame_5 %>%
            dplyr::select(input_id, model_name, rating_confidence, mean_confusion, human_sd),
          file.path(out_dir, "source_pooled_confidence_uncertainty_fivemodel.csv"),
          row.names = FALSE)
cat("\n  Five-model pooled confidence and human uncertainty:\n")
print(as.data.frame(table_pooled_confidence_uncertainty_fivemodel), row.names = FALSE)

# Pool confidence–distribution-error regressions across five models with scenario-clustered CR2 inference.
distconf_frame_5 <- dist_by_scenario %>%
  inner_join(
    confidence_estimates %>%
      mutate(input_id = canonical_scenario_id(input_id)) %>%
      filter(!is.na(rating_confidence)) %>%
      dplyr::select(input_id, model_name, rating_confidence),
    by = c("input_id", "model_name")
  ) %>%
  filter(model_name %in% CONFIDENCE_EXPECTED_MODELS,
         input_id %in% scenarios_with_humans)

fit_distconf_5 <- function(metric_col) {
  cols <- c(
    metric_col, "rating_confidence",
    "model_name", "method", "input_id"
  )
  
  d <- as.data.frame(distconf_frame_5[, cols])
  d <- d[complete.cases(d), , drop = FALSE]
  d <- d[
    is.finite(d[[metric_col]]) &
      is.finite(d$rating_confidence),
    , drop = FALSE
  ]
  
  n_clusters <- length(unique(d$input_id))
  if (n_clusters < 3L) stop("Too few scenario clusters.")
  
  f <- stats::as.formula(paste0(
    metric_col,
    " ~ rating_confidence + model_name + method"
  ))
  
  m <- stats::lm(f, data = d, na.action = na.fail)
  
  V <- clubSandwich::vcovCR(
    m,
    cluster = d$input_id,
    type = "CR2"
  )
  
  test <- clubSandwich::coef_test(
    m,
    vcov = V,
    test = "Satterthwaite",
    coefs = "rating_confidence"
  )
  
  critical <- stats::qt(0.975, df = test$df_Satt)
  
  tibble(
    metric = metric_col,
    n_rows = stats::nobs(m),
    n_clusters = n_clusters,
    inference = "Scenario-clustered CR2",
    b = test$beta,
    se = test$SE,
    t = test$tstat,
    df = test$df_Satt,
    p = test$p_Satt,
    ci_low = test$beta - critical * test$SE,
    ci_high = test$beta + critical * test$SE
  )
}

table_pooled_distconf_fivemodel <- bind_rows(
  fit_distconf_5("tvd"), fit_distconf_5("emd"), fit_distconf_5("jsd")
) %>%
  mutate(p_holm = p.adjust(p, method = "holm"))

write.csv(table_pooled_distconf_fivemodel,
          file.path(out_dir, "table_pooled_distconf_fivemodel.csv"),
          row.names = FALSE)
cat("\n  B6 five-model pooled distribution-fit confidence:\n")
print(as.data.frame(
  table_pooled_distconf_fivemodel %>%
    mutate(across(where(is.numeric), ~ round(.x, 4)))
), row.names = FALSE)
